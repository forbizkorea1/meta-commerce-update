<?php

namespace ForbizScm\Controller\Product;

/**
 * 개별상품등록
 *
 * @author hoksi
 */
class ManageProduct extends \ForbizAdminController
{

    public function __construct()
    {
        parent::__construct();
    }

    public function index($id = null)
    {
        // 타이틀 설정
        $this->setTitle('개별상품등록');
        // 버튼 설정
        $this->setTopBtn('저장', 'save');

        /* @var $productModel \CustomScm\Model\Product\Product */
        $productModel = $this->import('model.scm.product.product');

        /* @var $mandatoryModel \CustomScm\Model\Product\Mandatory */
        $mandatoryModel = $this->import('model.scm.product.mandatory');

        /* @var $iconModel \CustomScm\Model\Product\Icon */
        $iconModel = $this->import('model.scm.product.icon');

        /* @var $companyModel \CustomScm\Model\Company\Company */
        $companyModel = $this->import('model.scm.company.company');

        $companyId = $this->adminInfo->company_id;

        $this->setResponseData('manageLevel', $this->adminInfo->admin_level);
        $this->setResponseData('manageCompanyId', $companyId);
        $this->setResponseData('manageCompanyName', $this->adminInfo->company_name);

        $this->setResponseData('mdInfo', $companyModel->getCompanyMdInfo($companyId));

        $this->setResponseData('productGiftType', PRODUCT_TYPE_GIFT);

        //상품구분
        $this->setResponseData('productType', $productModel->getProductType());
        //전시타입
        $this->setResponseData('mobileUse', $productModel->getMobileUse());
        //판매기간
        $this->setResponseData('isSellDate', $productModel->getSellDate());
        //노출여부
        $this->setResponseData('disp', $productModel->getDisp());
        //면세여부
        $this->setResponseData('surtaxYorn', $productModel->getSurtaxYorn());
        //19금 상품
        $this->setResponseData('is_adult', $productModel->getIsAdult());
        //개별 적립금 사용여부
        $this->setResponseData('reserveYn', $productModel->getReserveYn());
        //상품정보고시 상품군
        $this->setResponseData('mandatorySelList', $mandatoryModel->getList('1'));
        //상품정보고시 여부
        $this->setResponseData('mandatoryUse', $productModel->getMandatoryUse());
        // 아이콘
        $this->setResponseData('icon', $iconModel->getUseList(1, 100));
        //개별수수료 사용
        $this->setResponseData('one_commission', $productModel->getOneCommission());
        //정산방식
        $this->setResponseData('account_type', $productModel->getAccountType());
        //노출여부
        $this->setResponseData('deliveryType', $productModel->getDeliveryType());
        //옵션명
        $this->setResponseData('stockUseYn', $productModel->getStockUseYn());

        $product = [];
        if ($id) {
            //버튼설정
            $this->setTopBtn('미리보기', 'preview')->setTopBtn('변경내역', 'history');

            $mode = 'put';
            //개별상품등록 수정
            $product = $productModel->getProduct($id);
            $state = $product['state'];
            $this->setResponseData('product', $product);
            $this->setResponseData('categoryRelation', $productModel->categoryRelation($id));

            // 관련상품 데이타
            $this->setResponseData('relProductData', $productModel->getRelProductList($id));
            // 상품사은품 데이타
            $this->setResponseData('relGiftProductData', $productModel->getRelGiftProductList($id));
            //이미지
            $this->setResponseData('basicImageSrc', get_product_images_src($id, 'basic'));
            foreach ($productModel->getAddImage($id) as $k => $v) {
                $num = $k + 1;
                $addSrc = 'addImageSrc' . $num;
                $this->setResponseData($addSrc, $v['url']);

                $addId = 'addImageId' . $num;
                $this->setResponseData($addId, $v['id']);
            }

            //옵션
            $optionData = $productModel->selectOption($id, 'b');
            if (!empty($optionData[0])) {
                $this->setResponseData('optionData', $optionData[0]);
                $this->setResponseData('optionDetailData', $productModel->selectOptionDetail($id, $optionData[0]['opn_ix']));
            }

            //추가구성 옵션
            $addOptionData = $productModel->selectOption($id, 'a');
            if ($addOptionData) {
                foreach ($addOptionData as $k => $v) {
                    $addOptionDataArray[] = $v;
                    $addOptionDetailDataArray[] = $productModel->selectOptionDetail($id, $v['opn_ix']);
                }
            } else {
                $addOptionDataArray = '';
                $addOptionDetailDataArray = '';
            }
            $this->setResponseData('addOptionData', $addOptionDataArray);
            $this->setResponseData('addOptionDetailData', $addOptionDetailDataArray);

            //배송비정책
            /* @var $deliveryModel \CustomScm\Model\Company\DeliveryPolicy */
            $deliveryModel = $this->import('model.scm.company.DeliveryPolicy');
            $deliveryList = $deliveryModel->setManageCompanyId($product['admin'])->getDeliveryTemplateList(1, false, []);
        } else {
            $mode = 'add';
            if ($this->adminInfo->admin_level == 9) {
                $state = '1';
            } else {
                $state = '3';
            }
            $product['state'] = $state;
            $product['product_type'] = PRODUCT_TYPE_NOMAL;
            $this->setResponseData('product', $product);

            //배송비정책
            /* @var $deliveryModel \CustomScm\Model\Company\DeliveryPolicy */
            $deliveryModel = $this->import('model.scm.company.DeliveryPolicy');
            $deliveryList = $deliveryModel->setManageCompanyId($this->adminInfo->company_id)->getDeliveryTemplateList(1, false, []);
        }

        //판매상태
        $this->setResponseData('state', $productModel->getChangeStatusList($mode, $state));

        $this->setResponseData('MALL_DOMAIN', MALL_DOMAIN);
        $this->setResponseData('mode', $mode);


        // 배송정책 리스트
        $this->setResponseData('deliveryList', $deliveryList);


    }

    public function getMandatorySelList()
    {
        /* @var $mandatoryModel \CustomScm\Model\Product\Mandatory */
        $mandatoryModel = $this->import('model.scm.product.mandatory');

        $this->setResponseData($mandatoryModel->getDetailList($this->input->post('mi_ix')));
        $this->setResponseResult('success');
    }

    public function getMandatoryGridList()
    {
        /* @var $productModel \CustomScm\Model\Product\Product */
        $productModel = $this->import('model.scm.product.product');

        $this->setResponseData($productModel->getNoticeGridList($this->input->post('pid')));
        $this->setResponseResult('success');
    }

    public function getDisplayGridList()
    {
        /* @var $productModel \CustomScm\Model\Product\Product */
        $productModel = $this->import('model.scm.product.product');

        $this->setResponseData($productModel->getDisplayGridList($this->input->post('pid')));
        $this->setResponseResult('success');
    }

    public function add()
    {
        // 입력 필수 항목
        $checkField = ['admin', 'is_sell_date', 'disp', 'state', 'pname', 'surtax_yorn', 'coprice', 'wholesale_price', 'wholesale_sellprice', 'listprice', 'sellprice', 'stock_use_yn', 'option_name'];

        // 필수 항목 점검
        if (form_validation($checkField)) {
            /* @var $productModel \CustomScm\Model\Product\Product */
            $productModel = $this->import('model.scm.product.product');

            $noticeGridData = json_decode($this->input->post('noticeGridData'), true);
            $displayGridData = json_decode($this->input->post('displayGridData'), true);
            $deleteDisplayGridList = json_decode($this->input->post('deleteDisplayGridList'), true);
            if (is_array($deleteDisplayGridList) && count($deleteDisplayGridList) > 0) {
                $productModel->deleteDisplayInfo($deleteDisplayGridList);
            }
            $relProductGridData = json_decode($this->input->post('relProductGridData'), true);
            $relGiftProductGridData = json_decode($this->input->post('relGiftProductGridData'), true);
            $deleteFile = json_decode($this->input->post('deleteFile'), true);
            $optionGridData = json_decode($this->input->post('optionGridData'), true);
            $optionSave = true;
            foreach ($optionGridData as $optionGridDataVal) {
                if ($optionGridDataVal['option_listprice'] <= 0 || $optionGridDataVal['option_price'] <= 0) {
                    $this->setResponseData('put');
                    $this->setResponseResult('optionSavefail');
                    $optionSave = false;
                }
                if ($optionGridDataVal['option_listprice'] < $optionGridDataVal['option_price']) {
                    $this->setResponseData('put');
                    $this->setResponseResult('optionSavefail');
                    $optionSave = false;
                }
            }
            $addOptionGridData = json_decode($this->input->post('addOptionGridData'), true);
            if (!empty($addOptionGridData)) {
                foreach ($addOptionGridData as $addOptionGridDataDetail) {
                    foreach ($addOptionGridDataDetail as $addOptionGridDataVal) {
                        if ($addOptionGridDataVal['option_listprice'] <= 0 || $addOptionGridDataVal['option_price'] <= 0) {
                            $this->setResponseData('put');
                            $this->setResponseResult('addOptionSavefail');
                            $optionSave = false;
                        }
                        if ($addOptionGridDataVal['option_listprice'] < $addOptionGridDataVal['option_price']) {
                            $this->setResponseData('put');
                            $this->setResponseResult('addOptionSavefail');
                            $optionSave = false;
                        }
                    }
                }
            }
            if ($optionSave) {
                $this->setResponseData($productModel->add($this->input->post(), $noticeGridData, $displayGridData,
                    $relProductGridData, $_FILES, $deleteFile, $optionGridData, $addOptionGridData, $relGiftProductGridData));
                $this->setResponseResult('success');
            }
        } else {
            log_message('error', validation_errors());
            $this->setResponseResult('fail')->setResponseData(validation_errors());
        }
    }

    public function put()
    {
        // 입력 필수 항목
        $checkField = ['admin', 'is_sell_date', 'disp', 'state', 'pname', 'surtax_yorn', 'coprice', 'wholesale_price', 'wholesale_sellprice', 'listprice', 'sellprice', 'stock_use_yn', 'option_name'];

        // 필수 항목 점검
        if (form_validation($checkField)) {
            /* @var $productModel \CustomScm\Model\Product\Product */
            $productModel = $this->import('model.scm.product.product');

            $noticeGridData = json_decode($this->input->post('noticeGridData'), true);
            $displayGridData = json_decode($this->input->post('displayGridData'), true);
            $deleteDisplayGridList = json_decode($this->input->post('deleteDisplayGridList'), true);
            if (is_array($deleteDisplayGridList) && count($deleteDisplayGridList) > 0) {
                $productModel->deleteDisplayInfo($deleteDisplayGridList);
            }
            $relProductGridData = json_decode($this->input->post('relProductGridData'), true);
            $relGiftProductGridData = json_decode($this->input->post('relGiftProductGridData'), true);
            $deleteFile = json_decode($this->input->post('deleteFile'), true);
            $optionGridData = json_decode($this->input->post('optionGridData'), true);
            $optionSave = true;
            foreach ($optionGridData as $optionGridDataVal) {
                if ($optionGridDataVal['option_listprice'] <= 0 || $optionGridDataVal['option_price'] <= 0) {
                    $this->setResponseData('put');
                    $this->setResponseResult('optionSavefail');
                    $optionSave = false;
                }
                if ($optionGridDataVal['option_listprice'] < $optionGridDataVal['option_price']) {
                    $this->setResponseData('put');
                    $this->setResponseResult('optionSavefail');
                    $optionSave = false;
                }
            }
            $addOptionGridData = json_decode($this->input->post('addOptionGridData'), true);
            if (!empty($addOptionGridData)) {
                foreach ($addOptionGridData as $addOptionGridDataDetail) {
                    foreach ($addOptionGridDataDetail as $addOptionGridDataVal) {
                        if ($addOptionGridDataVal['option_listprice'] <= 0 || $addOptionGridDataVal['option_price'] <= 0) {
                            $this->setResponseData('put');
                            $this->setResponseResult('addOptionSavefail');
                            $optionSave = false;
                        }
                        if ($addOptionGridDataVal['option_listprice'] < $addOptionGridDataVal['option_price']) {
                            $this->setResponseData('put');
                            $this->setResponseResult('addOptionSavefail');
                            $optionSave = false;
                        }
                    }
                }
            }
            if ($optionSave) {
                $productModel->put($this->input->post('id'), $this->input->post(), $noticeGridData, $displayGridData,
                    $relProductGridData, $_FILES, $deleteFile, $optionGridData, $addOptionGridData, $relGiftProductGridData);
                $this->setResponseData('put');
                $this->setResponseResult('success');
            }
        } else {
            log_message('error', validation_errors());
            $this->setResponseResult('fail')->setResponseData(validation_errors());
        }
    }

    public function del()
    {
        // 입력 필수 항목
        $checkField = ['id'];
        // 필수 항목 점검
        if (form_validation($checkField)) {
            /* @var $productModel \CustomScm\Model\Product\Product */
            $productModel = $this->import('model.scm.product.product');

            $ret = $productModel->del($this->input->post('id'));
            $this->setResponseData('delete');
            $this->setResponseResult($ret['result']);
        } else {
            log_message('error', validation_errors());
            $this->setResponseResult('fail')->setResponseData(validation_errors());
        }
    }
}