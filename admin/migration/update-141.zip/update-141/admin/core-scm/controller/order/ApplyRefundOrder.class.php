<?php

namespace ForbizScm\Controller\Order;

/**
 * 환불 모달
 *
 * @author hoksi
 * @property \CustomScm\Model\Order\Refund $refundModel 환불 모델
 */
class ApplyRefundOrder extends \ForbizAdminController
{
    protected $refundModel;

    public function __construct()
    {
        parent::__construct();

        $this->refundModel = $this->import('model.scm.order.refund');
    }

    public function index()
    {
        // 타이틀 설정
        $this->setTitle('환불 모달');

        $this->setLayout('layout_modal');

        // 입력 필수 항목
        $chekField = ['oid'];
        // 필수 항목 점검
        if (form_validation($chekField)) {
            $oid = $this->input->post('oid');

            $this->refundModel->setOid($oid);

            /* @var $orderModel \CustomScm\Model\Order\Order */
            $orderModel = $this->import('model.scm.order.order');
            $orderModel->setOid($oid);

            $product = $orderModel->getClaimProductList(['refund_status' => ORDER_STATUS_REFUND_APPLY]);
            $claim = [];
            $_totalRefundPrice = 0;
            $_totalRefundTaxPrice = 0;
            $_totalRefundTaxFreePrice = 0;
            $_totalReservePrice = 0;
            foreach ($product as $p) {
                $key = array_search($p['claim_group'], array_column($claim, 'claim_group'));
                if ($key === false) {
                    $claim[] = [
                        'claim_group' => $p['claim_group']
                        , 'claim_delivery_price' => $p['claim_delivery_price']
                        , 'refund_product_price' => $p['pt_dcprice']
                        , 'refund_reserve_price' => $p['use_reserve'] ?? 0
                    ];
                    $_totalRefundPrice += ($p['pt_dcprice'] + $p['claim_delivery_price']);
                    $_totalRefundTaxPrice += $p['claim_delivery_price'];
                } else {
                    $claim[$key]['refund_product_price'] += $p['pt_dcprice'];
                    $claim[$key]['refund_reserve_price'] += $p['use_reserve'] ?? 0;
                    $_totalRefundPrice += $p['pt_dcprice'];
                }

                $_totalReservePrice += $p['use_reserve'];

                if ($p['surtax_yorn'] == 'Y') {
                    $_totalRefundTaxFreePrice += $p['pt_dcprice'];
                } else {
                    $_totalRefundTaxPrice += $p['pt_dcprice'];
                }
            }

            $refundBankBool = false;
            $paymentList = $orderModel->getPaymentSummary();
            $odIxs = array_column($product, 'od_ix');

            $payment = [];
            $npaypgUsed = false; // 네이버페이 직연동 결제 여부
            //$paymentList 가 오브젝트로 인식해서 그리드에 노출안되서 배열로 처리
            foreach ($paymentList as $k => $v) {
                if ($v['remain_price'] > 0) {
                    if ($v['method'] == ORDER_METHOD_BANK) {
                        $v['manual'] = 'Y';
                    } else {
                        $v['manual'] = 'N';
                    }

                    if (in_array($v['method'], [ORDER_METHOD_BANK, ORDER_METHOD_VBANK, ORDER_METHOD_ESCROW_VBANK, ORDER_METHOD_ASCROW])) {
                        $refundBankBool = true;
                    }


                    if($v['method'] == ORDER_METHOD_RESERVE){

                        if ($_totalReservePrice > $v['remain_price']) {
                            $v['apply_refund_price'] = $v['remain_price'];
                            $_totalReservePrice -= $v['remain_price'];
                        } else {
                            $v['apply_refund_price'] = $_totalReservePrice;
                            $_totalReservePrice = 0;
                        }
                    }else{
                        if ($_totalRefundPrice > $v['remain_price']) {
                            $v['apply_refund_price'] = $v['remain_price'];
                            $_totalRefundPrice -= $v['remain_price'];
                        } else {
                            $v['apply_refund_price'] = $_totalRefundPrice;
                            $_totalRefundPrice = 0;
                        }
                    }



                    if ($v['remain_tax_free_price'] > 0 && $_totalRefundTaxFreePrice > 0) {
                        if ($_totalRefundTaxFreePrice >= $v['remain_tax_free_price']) {
                            $v['apply_refund_tax_free_price'] = $v['remain_tax_free_price'];
                            $_totalRefundTaxFreePrice -= $v['remain_tax_free_price'];
                            $v['apply_refund_tax_price'] = $v['apply_refund_price'] - $v['apply_refund_tax_free_price'];
                            $_totalRefundTaxPrice -= $v['apply_refund_tax_price'];
                        } else {
                            $v['apply_refund_tax_free_price'] = $_totalRefundTaxFreePrice;
                            $v['apply_refund_tax_price'] = 0;
                            $_totalRefundTaxFreePrice = 0;
                        }
                    } else {
                        $v['apply_refund_tax_price'] = $v['apply_refund_price'];
                        $v['apply_refund_tax_free_price'] = 0;
                        $_totalRefundTaxPrice -= $v['apply_refund_price'];
                    }

                    //네이버페이 결제 환불 디스크립션
                    if ($v['method'] == ORDER_METHOD_NPAY_ORDER) {
                        /* @var $naverPayModel \ForbizScm\Model\Npay */
                        $naverPayModel = $this->import('model.scm.npay');

                        $npayMethodData = $naverPayModel->getNpayPaymentData($odIxs);

                        $this->setResponseData('npayData', ['npayInfoText' => $npayMethodData[0], 'npayRefundFee' => $npayMethodData[1]]);
                    }

                    //네이버페이 직연동 결제 확인
                    if ($v['method'] == ORDER_METHOD_NPAY)
                    {
                        $npaypgUsed = true;
                    }

                    $payment[] = $v;
                }
            }

            $this->setResponseData('order', $orderModel->getOrder());
            $this->setResponseData('product', $product);
            $this->setResponseData('claim', $claim);
            $this->setResponseData('payment', $payment);
            $this->setResponseData('refundBankBool', $refundBankBool);
            $this->setResponseData('npaypgUsed', $npaypgUsed);
            if ($refundBankBool) {
                $this->setResponseData('bank', \ForbizConfig::getBankList());
                $this->setResponseData('refundBank', $this->refundModel->getRefundAccount());
            }
        } else {
            show_error('oid null');
        }
    }

    public function put()
    {
        // 입력 필수 항목
        $chekField = ['oid', 'product', 'claim', 'refund'];
        // 필수 항목 점검
        if (form_validation($chekField)) {
            $response = $this->refundModel
                ->setOid($this->input->post('oid'))
                ->doRefund(
                    json_decode($this->input->post('product'), true)
                    , json_decode($this->input->post('claim'), true)
                    , json_decode($this->input->post('refund'), true)
                    , $this->input->post()
                );
            $this->setResponseResult($response['result'])->setResponseData($response['data']);
        } else {
            $this->setResponseResult('validationFail')->setResponseData(validation_errors());
        }
    }
}