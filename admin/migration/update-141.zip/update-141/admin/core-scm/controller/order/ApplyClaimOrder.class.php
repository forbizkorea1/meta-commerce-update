<?php
namespace ForbizScm\Controller\Order;

/**
 * 클레임 신청
 *
 * @author hoksi
 * @property \CustomScm\Model\Order\Status $statusModel 주문 상태 모델
 */
class ApplyClaimOrder extends \ForbizAdminController
{

    protected $statusModel;

    public function __construct()
    {
        parent::__construct();

        $this->statusModel = $this->import('model.scm.order.status');
    }

    public function index($type = false, $oid = false, ...$odIxs)
    {
        if ($type === false && $oid === false && empty($odIxs)) {
            show_error('접근 권한 에러 oid null');
        } else {
            /* @var $orderModel \CustomScm\Model\Order\Order */
            $orderModel = $this->import('model.scm.order.order');
            $orderModel->setOid($oid);

            // 타이틀 설정
            $this->setTitle('클레임 신청');
            $this->setTopBtn('신청', 'apply');

            $this->setResponseData('oid', $oid);

            $typeTxt = '클레임';
            if ($type == ORDER_STATUS_CANCEL_APPLY) {
                $typeTxt = '취소';
                $reseon = \ForbizConfig::getOrderSelectStatus('A', ORDER_STATUS_DELIVERY_READY, ORDER_STATUS_CANCEL_APPLY);
                $applayStatus = [
                    ORDER_STATUS_CANCEL_COMPLETE => $this->statusModel->getStatus(ORDER_STATUS_CANCEL_COMPLETE)
                    , ORDER_STATUS_CANCEL_APPLY => $this->statusModel->getStatus(ORDER_STATUS_CANCEL_APPLY)
                ];
            } else if ($type == ORDER_STATUS_RETURN_APPLY) {
                $typeTxt = '반품';
                $reseon = \ForbizConfig::getOrderSelectStatus('A', ORDER_STATUS_DELIVERY_COMPLETE, ORDER_STATUS_RETURN_APPLY);
                $applayStatus = [
                    ORDER_STATUS_RETURN_ING => $this->statusModel->getStatus(ORDER_STATUS_RETURN_ING)
                    , ORDER_STATUS_RETURN_APPLY => $this->statusModel->getStatus(ORDER_STATUS_RETURN_APPLY)
                ];
            } else if ($type == ORDER_STATUS_EXCHANGE_APPLY) {
                $typeTxt = '교환';
                $reseon = \ForbizConfig::getOrderSelectStatus('A', ORDER_STATUS_DELIVERY_COMPLETE, ORDER_STATUS_EXCHANGE_APPLY);
                $applayStatus = [
                    ORDER_STATUS_EXCHANGE_ING => $this->statusModel->getStatus(ORDER_STATUS_EXCHANGE_ING)
                    , ORDER_STATUS_EXCHANGE_APPLY => $this->statusModel->getStatus(ORDER_STATUS_EXCHANGE_APPLY)
                ];
            } else {
                show_error('접근 권한 에러 oid null');
            }

            $this->setResponseData('typeTxt', $typeTxt);
            $this->setResponseData('type', $type);
            $this->setResponseData('reason', $reseon);
            $this->setResponseData('applayStatus', $applayStatus);

            $product = $orderModel->getNormalProductList(['od_ix' => $odIxs]);
            $this->setResponseData('product', $product);

            $paymentMethod = $orderModel->getProductPaymentMethodList(['od_ix' => $odIxs]);
            $this->setResponseData('paymentMethod', $paymentMethod);

            // 네이버페이 직연동 결제여부
            $naverpaypg = in_array(ORDER_METHOD_NPAY, $paymentMethod) ? true : false;
            $this->setResponseData('npaypgInclude', $naverpaypg);

            if ($type != ORDER_STATUS_CANCEL_APPLY) {
                $this->setResponseData('returnSendType', $orderModel->getReturnSendType());
                $this->setResponseData('quickList', \ForbizConfig::getDeliveryCompanyInfo());
                $this->setResponseData('deliveryInfo', $orderModel->getDeliveryInfo($product[0]['odd_ix']));
            }
        }
    }

    public function get()
    {
        // 입력 필수 항목
        $chekField = ['oid', 'reason', 'productList'];
        // 필수 항목 점검
        if (form_validation($chekField)) {
            $this->setResponseData($this->statusModel->claimCalculate(
                    $this->input->post('status')
                    , $this->input->post('oid')
                    , json_decode($this->input->post('productList'), true)
                    , $this->input->post()
                )
            );
        } else {
            $this->setResponseResult('validationFail')->setResponseData(validation_errors());
        }
    }

    public function add()
    {
        // 입력 필수 항목
        $chekField = ['oid', 'reason', 'reasonDetail', 'productList', 'claimDeliveryPrice'];
        // 필수 항목 점검
        if (form_validation($chekField)) {
            $this->setResponseData($this->statusModel->doClaim(
                $this->input->post('status')
                , $this->input->post('oid')
                , json_decode($this->input->post('productList'), true)
                , $this->input->post()
                , $this->input->post('claimDeliveryPrice') * ($this->input->post('subtraction') == 'Y' ? -1 : 1)
                )
            );
        } else {
            $this->setResponseResult('validationFail')->setResponseData(validation_errors());
        }
    }
}
