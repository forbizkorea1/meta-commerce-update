<?php
namespace ForbizScm\Controller\Order;

/**
 * 주문관리
 *
 * @author hoksi
 * @property \CustomScm\Model\Order\Order $orderModel 주문 모델
 */
class ManageOrder extends \ForbizAdminController
{

    protected $orderModel;

    public function __construct()
    {
        parent::__construct();
        $this->orderModel = $this->import('model.scm.order.order');

        //기본적인 oid set
        $oid = $this->input->post('oid');
        $this->orderModel->setOid($oid);
    }

    public function index($oid = false)
    {
        if ($oid === false) {
            show_error('접근 권한 에러 oid null');
        } else {
            $this->orderModel->setOid($oid);

            if (!$this->auth()) {
                show_error('접근 권한 에러 auth fail');
            }

            //주문 상태변경 응답 JS
            $this->setJs('changeOrderStatusResponse.js');

            /* @var $statusModel \CustomScm\Model\Order\Status */
            $statusModel = $this->import('model.scm.order.status');
            /* @var $deliveryCompanyModel \CustomScm\Model\Company\DeliveryCompany */
            $deliveryCompanyModel = $this->import('model.scm.company.deliveryCompany');

            // 타이틀 설정
            $this->setTitle('주문관리');
            $this->setTopBtn('주문분할', 'orderSeparate');
            $this->setTopBtn('변경내역', 'orderHistory');

            $orderData = $this->orderModel->getOrder();
            $orderBasicAddress = $this->orderModel->getBasicOrderAddress($oid);
            $orderData['orderBasicAddress'] = $orderBasicAddress['zip'].") ".$orderBasicAddress['addr1']." ".$orderBasicAddress['addr2'];
            $incomReadyBool = false;
            if ($orderData['status'] == ORDER_STATUS_INCOM_READY) {
                $incomReadyBool = true;
            }
            //입금 여부
            $this->setResponseData('incomReadyBool', $incomReadyBool);

            if ($this->adminInfo->admin_level == 9) {
                $this->setTopBtn('메모등록', 'addMemo');
            }

            $this->setResponseData('adminLevel', $this->adminInfo->admin_level);
            $this->setResponseData('order', $orderData);
            $this->setResponseData('changeOrderStatusList', [
                ORDER_STATUS_DELIVERY_READY => $statusModel->getStatus(ORDER_STATUS_DELIVERY_READY),
                ORDER_STATUS_DELIVERY_ING => $statusModel->getStatus(ORDER_STATUS_DELIVERY_ING),
                ORDER_STATUS_CANCEL_APPLY => $statusModel->getStatus(ORDER_STATUS_CANCEL_APPLY),
                ORDER_STATUS_RETURN_APPLY => $statusModel->getStatus(ORDER_STATUS_RETURN_APPLY),
                ORDER_STATUS_EXCHANGE_APPLY => $statusModel->getStatus(ORDER_STATUS_EXCHANGE_APPLY)
            ]);

            $this->setResponseData('useQuickList', $deliveryCompanyModel->getUseList());
        }
    }

    public function getProduct()
    {
        if (!$this->auth()) {
            $this->setResponseResult('failAuth');
        } else {
            $this->setResponseData('normalProduct', $this->orderModel->getNormalProductList())
                ->setResponseData('claimProduct', $this->orderModel->getClaimProductList());
        }
    }

    public function putBuyer()
    {
        if (!$this->auth()) {
            $this->setResponseResult('failAuth');
        } else {
            // 입력 필수 항목
            $chekField = ['bmobile'];
            // 필수 항목 점검
            if (form_validation($chekField)) {
                $this->orderModel->putOrder($this->input->post());
            } else {
                $this->setResponseResult('validationFail')->setResponseData(validation_errors());
            }
        }
    }

    public function getMemoList()
    {
        /* @var $memoModel \CustomScm\Model\Order\Memo */
        $memoModel = $this->import('model.scm.order.memo');

        if (!$this->auth()) {
            $this->setResponseResult('failAuth');
        } else {
            $this->setResponseData($memoModel->getList(1, 100, $this->input->post())['list']);
        }
    }

    public function getPaymentList()
    {
        if (!$this->auth()) {
            $this->setResponseResult('failAuth');
        } else {
            $this->setResponseData($this->orderModel->getPaymentSummary());
        }
    }

    public function putIncomComplete()
    {
        if ($this->adminInfo->admin_level == 9) {
            // 입력 필수 항목
            $chekField = ['oid'];
            // 필수 항목 점검
            if (form_validation($chekField)) {
                /* @var $statusModel \CustomScm\Model\Order\Status */
                $statusModel = $this->import('model.scm.order.status');

                $response = $statusModel->doIncomComplete($this->input->post('oid'));

                // 무통장 입금완료시 메세지 처리.
                if ($response['result']) {
                    $orderData = $this->orderModel->getOrder();
                    $paymentData = $this->orderModel->getPaymentList();

                    if ($paymentData['0']['method'] == '0') {
                        $this->event->trigger('bankDepositComplete', ['orderData' => $orderData]);
                    }
                }

                $this->setResponseResult($response['result'])->setResponseData($response['data']);
            } else {
                $this->setResponseResult('fail')->setResponseData(validation_errors());
            }
        } else {
            $this->setResponseResult('failAuth');
        }
    }

    public function putStatus()
    {
        if (!$this->auth()) {
            $this->setResponseResult('failAuth');
        } else {
            // 입력 필수 항목
            $chekField = ['view', 'od_ix', 'status', 'order_from'];
            // 필수 항목 점검
            if (form_validation($chekField)) {
                /* @var $statusModel \CustomScm\Model\Order\Status */
                $statusModel = $this->import('model.scm.order.status');

                $etcData = [];
                if ($this->input->post('status') == ORDER_STATUS_DELIVERY_ING) {
                    $etcData['quick'] = $this->input->post('quick');
                    $etcData['invoice_no'] = $this->input->post('invoice_no');

                    //제휴사 주문 일때 택배사 맵핑 확인
                    if($this->input->post('order_from') != 'self') {
                        /* @var $orderModel \CustomScm\Model\Order\Order */
                        $orderModel = $this->import('model.scm.order.order');

                        if(empty($orderModel->checkMappingDelivery($etcData['quick']))){
                            $response = [
                                'result' => 'fail',
                                'data' => [
                                    'failCode' => '',
                                    'failMsg' => '제휴사 택배사 코드에 맵핑된 정보가 없습니다.'
                                ]
                            ];
                            $this->setResponseResult($response['result'])->setResponseData($response['data']);
                        }
                    }
                }

                $response = $statusModel->doChangeStatus(
                    $this->input->post('status')
                    , json_decode($this->input->post('od_ix'), true)
                    , '주문관리'
                    , $etcData
                    , json_decode($this->input->post('view'), true)
                    , $this->input->post('order_from')
                );
                $this->setResponseResult($response['result'])->setResponseData($response['data']);
            } else {
                $this->setResponseResult('validationFail')->setResponseData(validation_errors());
            }
        }
    }

    /**
     * 권한 체크
     * @return boolean
     */
    protected function auth()
    {
        if (!$this->orderModel->checkSellerAuth()) {
            return false;
        } else {
            return true;
        }
    }
}
