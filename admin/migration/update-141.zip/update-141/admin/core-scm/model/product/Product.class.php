<?php

namespace ForbizScm\Model\Product;

/**
 * 상품 관련 모델
 *
 * @author hoksi
 */
class Product extends \ForbizModel
{
    //관리 company_id
    protected $manageCompanyId;
    protected $manageLevel;
    protected $productType = [
        PRODUCT_TYPE_NOMAL => '일반'
        //, PRODUCT_TYPE_GIFT => '사은품'
    ];
    protected $mobileUse = [
        'A' => '전체',
        'W' => '웹',
        'M' => '모바일',
        'P' => '앱전용'
    ];
    protected $dateType = [
        '0' => '미적용',
        '1' => '적용'
    ];
    protected $state = [
        '0' => '일시품절'
        , '1' => '판매중'
        , '2' => '판매금지'
        , '3' => '승인대기'
        , '4' => '승인거부'
        , '5' => '수정대기'
        , '6' => '수정거부'
        , '7' => '판매예정'
        , '8' => '판매종료'
    ];
    protected $disp = [
        '1' => '노출함',
        '0' => '노출안함'
    ];
    protected $isAdult = [
        '0' => '미적용'
        , '1' => '적용'
    ];
    protected $surtaxYorn = [
        'N' => '과세'
        //, 'Y' => '면세'
    ];
    protected $reserveYn = [
        'N' => '미적용'
        , 'Y' => '적용'
    ];
    protected $mandatoryUse = [
        'N' => '미사용'
        , 'Y' => '사용'
    ];
    protected $one_commission = [
        'N' => '사용안함'
        , 'Y' => '사용'
    ];
    protected $account_type = [
        '1' => '판매가 정산방식 (판매가에 수수료 적용)'
        , '2' => '매입가 정산방식 (공급가로 정산되며, 하단 수수료에 0 이 아닌 숫자를 입력시 그 숫자의 % 만큼 차감후 정산처리됩니다.)'
        , '3' => '미정산 (선매입이고 본사에 재고가 있으며, 상품등록을 셀러가 진행시에 사용되며, 정산에서 제외됩니다.)'
    ];
    protected $deliveryType = [
        '2' => '개별 배송'
    ];
    protected $stockUseYn = [
        'Q' => '가격+재고 옵션'
    ];

    /**
     * 기본 제휴사 연동 코드
     * @var string 
     */ 
    protected $siteCode = 'relaket';

    public function __construct()
    {
        parent::__construct();

        //셀러일 경우
        $this->manageLevel = $this->adminInfo->admin_level;

        if ($this->adminInfo->admin_level < 9) {
            $this->setManageCompanyId($this->adminInfo->company_id);
        }
    }

    /**
     * 상품구분
     * @return array
     */
    public function getProductType($key = false)
    {
        if ($key === false) {
            return $this->productType;
        } else {
            return $this->productType[$key] ?? '';
        }
    }

    /**
     * 전시타입
     * @return array
     */
    public function getMobileUse($key = false, $unkey = false)
    {
        if ($key === false) {
            return $this->mobileUse;
        } elseif ($unkey) {
            if(is_array($unkey)) {
                $diffArray = $this->mobileUse;

                foreach($unkey as $key => $val) {
                    $diffArray = array_diff_key($diffArray, array($val => ''));
                }

                return $diffArray;
            }else {
                return array_diff_key($this->mobileUse, array($unkey => ''));
            }
        } else {
            return $this->mobileUse[$key] ?? '';
        }
    }

    /**
     * 판매기간
     * @return array
     */
    public function getSellDate($key = false)
    {
        if ($key === false) {
            return $this->dateType;
        } else {
            return $this->dateType[$key] ?? '';
        }
    }

    /**
     * 판매상태
     * @return array
     */
    public function getState($key = false)
    {
        if ($key === false) {

            return $this->state;
        } else {
            return $this->state[$key] ?? '';
        }
    }

    /**
     * 노출여부
     * @param bool $key
     * @return array|mixed|string
     */
    public function getDisp($key = false)
    {
        if ($key === false) {
            return $this->disp;
        } else {
            return $this->disp[$key] ?? '';
        }
    }

    /**
     * 면세여부
     * @param bool $key
     * @return array|mixed|string
     */
    public function getSurtaxYorn($key = false)
    {
        if ($key === false) {
            return $this->surtaxYorn;
        } else {
            return $this->surtaxYorn[$key] ?? '';
        }
    }

    /**
     * 19금 상품
     * @param bool $key
     * @return array|mixed|string
     */
    public function getIsAdult($key = false)
    {
        if ($key === false) {
            return $this->isAdult;
        } else {
            return $this->isAdult[$key] ?? '';
        }
    }

    /**
     * 상품정보고시 여부
     * @param bool $key
     * @return array|mixed|string
     */
    public function getMandatoryUse($key = false)
    {
        if ($key === false) {
            return $this->mandatoryUse;
        } else {
            return $this->mandatoryUse[$key] ?? '';
        }
    }

    /**
     * 개별 적립금 사용여부
     * @param bool $key
     * @return array|mixed|string
     */
    public function getReserveYn($key = false)
    {
        if ($key === false) {
            return $this->reserveYn;
        } else {
            return $this->reserveYn[$key] ?? '';
        }
    }

    /**
     * 개별수수료 사용
     * @param bool $key
     * @return array|mixed|string
     */
    public function getOneCommission($key = false)
    {
        if ($key === false) {
            return $this->one_commission;
        } else {
            return $this->one_commission[$key] ?? '';
        }
    }

    /**
     * 정산방식
     * @param bool $key
     * @return array|mixed|string
     */
    public function getAccountType($key = false)
    {
        if ($key === false) {
            return $this->account_type;
        } else {
            return $this->account_type[$key] ?? '';
        }
    }

    /**
     * 배송타입
     * @return array
     */
    public function getDeliveryType($key = false)
    {
        if ($key === false) {
            return $this->deliveryType;
        } else {
            return $this->deliveryType[$key] ?? '';
        }
    }

    /**
     * 옵션명
     * @return array
     */
    public function getStockUseYn($key = false)
    {
        if ($key === false) {
            return $this->stockUseYn;
        } else {
            return $this->stockUseYn[$key] ?? '';
        }
    }

    /**
     * 변경 가능 판매 상태 리스트
     * @param $mode
     * @param $state
     * @return array
     */
    public function getChangeStatusList($mode, $state)
    {
        /*
        '0' => '일시품절'
        , '1' => '판매중'
        , '2' => '판매금지'
        , '3' => '승인대기'
        , '4' => '승인거부'
        , '5' => '수정대기'
        , '6' => '수정거부'
        , '7' => '판매예정'
        , '8' => '판매종료'
        */
        if ($mode == 'add') {
            if ($this->manageLevel == 9) { //관리자일때 전부
                $list = ['1', '0', '2', '3', '4', '5', '6', '7', '8'];
            } else {
                $list = ['3']; //셀러는 최초등록시 무조건 승인대기
            }
        } else {
            if ($mode == 'put') {
                if ($this->manageLevel == 9) { //관리자일때 전부
                    $list = ['1', '0', '2', '3', '4', '5', '6', '7', '8'];
                } else {
                    if ($state == 1 || $state == 0) { //판매중 또는 일시품절일때 (판매중, 일시품절)
                        $list = ['1', '0'];
                    } else {
                        $list = [$state];
                    }
                }
            }
        }

        $data = [];
        foreach ($list as $key) {
            $data[$key] = $this->getState($key);
        }
        return $data;
    }

    /**
     * 판매자정보
     * set manageCompanyId
     * @param type $manageCompanyId
     */
    public function setManageCompanyId($manageCompanyId)
    {
        $this->manageCompanyId = $manageCompanyId;
    }

    /**
     * 상품정보등록
     * @param $data
     * @return bool|\NunaResult
     * @throws \Exception
     */
    public function insertProduct($data)
    {
        $now = fb_now();

        $pid = $this->qb
            ->set($data)
            ->set('mall_ix', MALL_IX)
            ->set('regdate', $now)
            ->set('editdate', $now)
            ->insert(TBL_SHOP_PRODUCT)
            ->exec();

        return $pid;
    }

    /**
     * 카테고리 상품 등록정보
     * @param $pid
     * @param $data
     * @throws \Exception
     */
    public function insertProductRelation($pid, $data)
    {
        $this->qb
            ->set('cid', $data['cid'])
            ->set('pid', $pid)
            ->set('basic', $data['basic'])
            ->set('disp', '1')
            ->set('insert_yn', 'Y')
            ->set('regdate', fb_now())
            ->insert(TBL_SHOP_PRODUCT_RELATION)
            ->exec();
    }

    /**
     * 개별상품등록
     * @param $data
     * @return bool|\NunaResult
     * @throws \Exception
     */
    public function add(
        $data,
        $noticeGridData,
        $displayGridData,
        $relProductGridData,
        $file,
        $deleteFile = null,
        $optionGridData = null,
        $addOptionGridData = null,
        $relGiftProductGridData = null
    ) {
        //판매방식 및 카테고리닫기
        $productData['admin'] = $data['admin'];
        $productData['product_type'] = $data['product_type'];
        $productData['is_mobile_use'] = $data['is_mobile_use'];
        $productData['md_code'] = $data['md_code'];
        $productData['is_sell_date'] = $data['is_sell_date'];
        $productData['sell_priod_sdate'] = $data['sell_priod_sdate'];
        $productData['sell_priod_edate'] = $data['sell_priod_edate'];
        $productData['state'] = $data['state'];
        $productData['disp'] = $data['disp'];

        //기본정보
        $productData['pname'] = $data['pname'];
        $productData['pcode'] = $data['pcode'];
        $productData['search_keyword'] = $data['search_keyword'];
        $productData['origin'] = $data['origin'];
        $productData['brand'] = $data['brand'];
        $productData['brand_name'] = $data['brandText'] ?? '';
        $productData['surtax_yorn'] = $data['surtax_yorn'];

        //상세 및 고시정보
        $productData['shotinfo'] = $data['shotinfo'];
        $productData['basicinfo'] = $data['basicinfo'];
        if (!empty($data['m_basicinfo'])) {
            $productData['m_basicinfo'] = $data['m_basicinfo'];
        }
        $productData['mandatory_use'] = $data['mandatory_use'];

        //기타정보
        if (!empty($data['icons'])) {
            $productData['icons'] = implode( '|', $data['icons']);
        }
        $productData['is_adult'] = $data['is_adult'];
        $productData['reserve_yn'] = $data['reserve_yn'];
        $productData['reserve_rate'] = $data['reserve_rate'];
        $productData['rate_type'] = $data['rate_type'];
        $productData['one_commission'] = $data['one_commission'];
        $productData['account_type'] = $data['account_type'];
        $productData['commission'] = $data['commission'];
        $productData['wholesale_commission'] = $data['wholesale_commission'];

        if (isset($data['disp_naver']))
        {
            $productData['disp_naver'] = $data['disp_naver'];
        }

        if (isset($data['disp_daum']))
        {
            $productData['disp_daum'] = $data['disp_daum'];
        }

        //상품별 배송 정책 설정(shop_product)
        $productData['delivery_type'] = $data['delivery_type'];

        //가격+옵션
        $productData['stock_use_yn'] = $data['stock_use_yn'];
        $productData['coprice'] = $data['coprice'];
        $productData['listprice'] = $data['listprice'];
        $productData['sellprice'] = $data['sellprice'];
        $productData['wholesale_price'] = $data['wholesale_price'];
        $productData['wholesale_sellprice'] = $data['wholesale_sellprice'];
        $productData['allow_basic_cnt'] = $data['allow_basic_cnt'];
        $productData['allow_byoneperson_cnt'] = $data['allow_byoneperson_cnt'];

        $pid = $this->insertProduct($productData);
        if(is_array($data['cidList'])){
            foreach ($data['cidList'] as $k => $v) {
                $cateData['cid'] = $v;
                if ($data['basicCid'] == $v) {
                    $cateData['basic'] = '1';
                } else {
                    $cateData['basic'] = '0';
                }
                $this->insertProductRelation($pid, $cateData);
            }
        }

        //상품정보고시
        if ($noticeGridData) {
            foreach ($noticeGridData as $k => $v) {
                $this->insertProductMandatoryInfo($pid, $v);
                $mi_ix = $v['mi_ix'];
            }
            $this->qb
                ->set('mandatory_type', $mi_ix . '|1')
                ->update(TBL_SHOP_PRODUCT)
                ->where('id', $pid)
                ->exec();
        }

        //디스플레이
        if ($displayGridData) {
            foreach ($displayGridData as $k => $v) {
                $this->insertDisplayInfo($pid, $v);
            }
        }
        //관련상품 등록 및 수정
        if ($relProductGridData) {
            foreach ($relProductGridData as $k => $v) {
                $v['key'] = $k;
                $this->insertRelProduct($pid, $v);
            }
        }
        
        //상품사은품 등록 및 수정
        if ($relGiftProductGridData) {
            foreach ($relGiftProductGridData as $k => $v) {
                $v['key'] = $k;
                $this->insertRelGiftProduct($pid, $v);
            }
        }

        //이미지 업로드
        $imageData['addImage1'] = $data['addImage1'];
        $imageData['addImage2'] = $data['addImage2'];
        $imageData['addImage3'] = $data['addImage3'];
        $imageData['addImage4'] = $data['addImage4'];
        $imageData['addImage5'] = $data['addImage5'];
        $this->imageUpload($pid, $file, $imageData);
        if ($deleteFile) {
            foreach ($deleteFile as $k => $v) {
                $this->imageDelete($v['file']);
            }
        }

        //상품별 배송 정책 설정(shop_product_delivery)
        $deliveryData['dt_ix'] = $data['delivery_template'];
        $deliveryData['delivery_div'] = $data['delivery_type'];
        $this->insertDelivery($pid, $deliveryData);

        //가격
        if ($optionGridData) {
            $data['option_type'] ?? '9';

            $optionKind = 'b';
            $opn_ix = $this->insertOption($pid, $optionKind, $data['option_name'], $data['option_type']);
            foreach ($optionGridData as $k => $v) {
                $this->insertOptionDetail($pid, $opn_ix, $v);
            }
        }

        //추가구성옵션
        if ($addOptionGridData) {
            //추가구성옵션들
            foreach ($addOptionGridData as $k => $v) {
                $opn_ix = $this->insertOption($pid, 'a', $data['add_option_name'][$k], $data['option_type']);
                //옵션구분들
                foreach ($v as $kk => $vv) {
                    $this->insertOptionDetail($pid, $opn_ix, $vv);
                }
            }
        }

        return $pid;
    }

    /**
     * 기본 상품정보
     * @param $id
     * @return mixed
     * @throws \Exception
     */
    public function getProduct($id)
    {
        $list = $this->qb
            ->select('id')
            ->select('admin')
            ->select('md_code')
            ->select('product_type')
            ->select('is_mobile_use')
            ->select('state')
            ->select('disp')
            ->select('is_sell_date')
            ->select('sell_priod_sdate')
            ->select('sell_priod_edate')
            ->select('pname')
            ->select('pcode')
            ->select('search_keyword')
            ->select('shotinfo')
            ->select('origin')
            ->select('brand')
            ->select('surtax_yorn')
            ->select('basicinfo')
            ->select('m_basicinfo')
            ->select('reserve_yn')
            ->select('disp_naver')
            ->select('disp_daum')
            ->select('reserve_rate')
            ->select('is_adult')
            ->select('mandatory_use')
            ->select('icons')
            ->select('one_commission')
            ->select('account_type')
            ->select('commission')
            ->select('wholesale_commission')
            ->select('delivery_type')
            ->select('stock_use_yn')
            ->select('coprice')
            ->select('listprice')
            ->select('sellprice')
            ->select('wholesale_price')
            ->select('wholesale_sellprice')
            ->select('allow_basic_cnt')
            ->select('allow_byoneperson_cnt')
            ->select('mandatory_type')
            ->from(TBL_SHOP_PRODUCT)
            ->whereIn('id', $id)
            ->exec()
            ->getRowArray();

        if (!empty($list)) {
            $row = $this->qb
                ->select('com_name')
                ->from(TBL_COMMON_COMPANY_DETAIL)
                ->where('company_id', $list['admin'])
                ->exec()
                ->getRowArray();

            $list['com_name'] = $row['com_name'];

            if (!empty($list['brand'])) {
                $brand_name = $this->qb
                    ->select('brand_name')
                    ->from(TBL_SHOP_BRAND)
                    ->where('b_ix', $list['brand'])
                    ->exec()
                    ->getRow();
                $list['brandText'] = $brand_name->brand_name ?? '';
            }

            if (!empty($list['md_code'])) {
                $mdInfo = $this->qb
                    ->decryptSelect('name')
                    ->from(TBL_COMMON_MEMBER_DETAIL)
                    ->where('code', $list['md_code'])
                    ->exec()
                    ->getRowArray();
                $list['mdName'] = $mdInfo['name'] ?? "";
            }

            if (!empty($list['mandatory_type'])) {
                $mandatory_type_explode = explode('|', $list['mandatory_type']);
                $list['mandatory_type'] = $mandatory_type_explode[0];
            }

            $list['deliveryDtIx'] = $this->getDeliveryTemplate($id, '2')['dt_ix'] ?? ''; //개별배송
            $list['deliveryQuickDtIx'] = $this->getDeliveryTemplate($id, '1')['dt_ix'] ?? ''; // 통합배송
        }

        return $list;
    }

    /**
     * 상품 배송 정책 dt_ix 가지고 오기
     * @param $pid
     * @param string $delivery_div
     * @return string
     * @throws \Exception
     */
    public function getDeliveryTemplate($pid, $delivery_div = '')
    {
        if (!empty($delivery_div)) {
            $this->qb->where('pd.delivery_div', $delivery_div);
        }

        $row = $this->qb
            ->select('dt.dt_ix')
            ->select('dt.template_name')
            ->from(TBL_SHOP_PRODUCT_DELIVERY . ' AS pd')
            ->join(TBL_SHOP_DELIVERY_TEMPLATE . ' AS dt', 'dt.dt_ix=pd.dt_ix')
            ->where('pid', zerofill($pid, 10))
            ->exec()
            ->getRowArray();

        return $row;
    }

    /**
     * 카테고리 상세
     * @param $id
     * @return array
     * @throws \Exception
     */
    public function categoryRelation($id)
    {
        /* @var $categoryModel \CustomScm\Model\Product\Category */
        $categoryModel = $this->import('model.scm.product.category');

        $rows = $this->qb
            ->select('a.cid')
            ->select('a.basic')
            ->select('b.depth')
            ->from(TBL_SHOP_PRODUCT_RELATION . ' as a')
            ->join(TBL_SHOP_CATEGORY_INFO . ' as b', 'a.cid=b.cid', 'left')
            ->whereIn('pid', $id)
            ->exec()
            ->getResultArray();

        foreach ($rows as $key => $row) {
            $row['path'] = implode(" > ",
                array_column($categoryModel->getCategoryPath($row['cid'], $row['depth']), 'cname'));
            $rows[$key] = $row;
        }
        return $rows;
    }

    /**
     * 상품정보 수정
     * @param $pid
     * @param $data
     * @throws \Exception
     */
    public function updateProduct($pid, $data)
    {
        $historyReturn = add_history('product', TBL_SHOP_PRODUCT . '.id', $pid,
            [
                'is_sell_date' => '판매기간',
                'sell_priod_sdate' => '판매기간 시작일',
                'sell_priod_edate' => '판매기간 종료일',
                'state' => '판매상태',
                'pname' => '상품명',
                'surtax_yorn' => '면세제품',
                'origin' => '원산지',
                'brand' => '브랜드',
                'allow_basic_cnt' => '기본시작수량',
                'allow_byoneperson_cnt' => 'ID당구매수량',
                'coprice' => '구매단가(원가)',
                'wholesale_price' => '도매판매가',
                'wholesale_sellprice' => '도매할인가',
                'listprice' => '판매가',
                'sellprice' => '실판매가(할인가)',
                'one_commission' => '개별수수료 사용',
                'account_type' => '정산방식',
                'delivery_type' => '배송타입',
                'commission' => '소매수수료',
                'wholesale_commission' => '도매수수료',
                'reserve_yn' => '개별 적립금 사용여부',
                'disp' => '노출여부',
                'is_adult' => '19금상품 여부',
                'mandatory_use' => '상품정보고시 여부',
                'shotinfo' => '상품간략소개',
                'search_keyword' => '검색 키워드'
            ], $data);

        if (!isset($data['sell_priod_sdate']) || !isset($data['sell_priod_edate']) || !isset($data['state'])) {
            $productData = $this->selectProduct($pid);
            if (!isset($data['sell_priod_sdate'])) {
                $data['sell_priod_sdate'] = $productData['sell_priod_sdate'];
            }
            if (!isset($data['sell_priod_edate'])) {
                $data['sell_priod_edate'] = $productData['sell_priod_edate'];
            }
            if (!isset($data['state'])) {
                $data['state'] = $productData['state'];
            }
        }

        $bState = $data['state'];
        //일시품절, 판매중일때 가격변동시 수정대기 변경 + 셀러일때만
        if (sess_val('admininfo', 'mem_div') == 'S' && in_array($data['state'], ['0', '1'])) {
            //가격변동시 강제로 '수정대기'
            $checkPriceChange = ['coprice', 'listprice', 'sellprice', 'wholesale_price', 'wholesale_sellprice'];
            foreach ($historyReturn as $val) {
                if (in_array($val, $checkPriceChange)) {
                    $data['state'] = "5";
                    break;
                }
            }
        }

        //판매설정기간이 적용일 경우에만 해당
        if (!empty($data['is_sell_date']) && $data['is_sell_date'] == 1) {
            if (in_array($data['state'], ['1', '7', '8'])) {
                $sdate = substr($data['sell_priod_sdate'], 0, 10);
                $edate = substr($data['sell_priod_edate'], 0, 10);

                //판매중일때 판매기간 변경시 현재기준에 따라 판매중,판매예정,판매종료로 변경.
                if (date('Y-m-d') < $sdate) {
                    //판매시작일이 현재보다 미래라면 판매예정.
                    $data['state'] = "7";
                } else {
                    if (date('Y-m-d') > $edate) {
                        //판매종료일이 현재보다 과거라면 판매종료.
                        $data['state'] = "8";
                    } else {
                        if ((date('Y-m-d') >= $sdate) && (date('Y-m-d') <= $edate)) {
                            //판매시작일과 판매종료일이 현재일에 들어오는 경우 판매중으로 변경.
                            $data['state'] = "1";
                        }
                    }
                }
            }
        }

        //업데이트 하려는 판매 상태가 변경되었을 경우 판매상태 히스토리 추가
        if ($bState != $data['state']) {
            add_history('product', TBL_SHOP_PRODUCT . '.id', $pid, ['state' => '판매상태'], ['state' => $data['state']]);
        }

        $this->qb
            ->set($data)
            ->set('editdate', fb_now())
            ->update(TBL_SHOP_PRODUCT)
            ->where('id', $pid)
            ->exec();
    }

    /**
     * 상품정보 검색
     * @param $pid
     * @return mixed
     * @throws \Exception
     */
    protected function selectProduct($pid)
    {
        return $this->qb
            ->select('sell_priod_sdate')
            ->select('sell_priod_edate')
            ->select('state')
            ->select('pname')
            ->from(TBL_SHOP_PRODUCT)
            ->where('id', $pid)
            ->exec()
            ->getRowArray();
    }

    /**
     * 카테고리 수정
     * @param $pid
     * @param $data
     * @throws \Exception
     */
    protected function updateProductRelation($pid, $data)
    {
        if(!empty($data['cid'])) {
            $this->qb->where('cid', $data['cid']);
        }
        $this->qb
            ->set('basic', $data['basic'])
            ->set('disp', $data['disp'] ?? '1')
            ->set('insert_yn', $data['insert_yn'] ?? 'Y')
            ->set('regdate', fb_now())
            ->update(TBL_SHOP_PRODUCT_RELATION)
            ->where('pid', $pid)
            ->exec();
    }


    /**
     * 판매방식 및 카테고리 수정
     * @param $pid
     * @param $data
     * @throws \Exception
     */
    public function put(
        $pid,
        $data,
        $noticeGridData,
        $displayGridData,
        $relProductGridData,
        $file,
        $deleteFile = null,
        $optionGridData = null,
        $addOptionGridData = null,
        $relGiftProductGridData = null
    ) {
        //판매방식/카테고리
        $productData['admin'] = $data['admin'];
        $productData['product_type'] = $data['product_type'];
        $productData['is_mobile_use'] = $data['is_mobile_use'];
        $productData['md_code'] = $data['md_code'];
        $productData['is_sell_date'] = $data['is_sell_date'];
        $productData['sell_priod_sdate'] = $data['sell_priod_sdate'];
        $productData['sell_priod_edate'] = $data['sell_priod_edate'];
        $productData['state'] = $data['state'];
        $productData['disp'] = $data['disp'];

        //기본정보 수정
        $productData['pname'] = $data['pname'];
        $productData['pcode'] = $data['pcode'];
        $productData['search_keyword'] = $data['search_keyword'];
        $productData['origin'] = $data['origin'];
        $productData['brand'] = $data['brand'];
        $productData['brand_name'] = $data['brandText'] ?? '';
        $productData['surtax_yorn'] = $data['surtax_yorn'];

        //상세 및 고시정보
        $productData['shotinfo'] = $data['shotinfo'];
        $productData['basicinfo'] = $data['basicinfo'];
        if (!empty($data['m_basicinfo'])) {
            $productData['m_basicinfo'] = $data['m_basicinfo'];
        } else {
            $productData['m_basicinfo'] = '';
        }
        $productData['mandatory_use'] = $data['mandatory_use'] ?? 'N';

        //기타정보
        if (!empty($data['icons'])) {
            $productData['icons'] = implode( '|', $data['icons']);
        } else {
            $productData['icons'] = '';
        }
        $productData['is_adult'] = $data['is_adult'];
        $productData['reserve_yn'] = $data['reserve_yn'];
        $productData['reserve_rate'] = $data['reserve_rate'];
        $productData['rate_type'] = $data['rate_type'];
        $productData['one_commission'] = $data['one_commission'];
        $productData['account_type'] = $data['account_type'] ?? '';
        $productData['commission'] = $data['commission'];
        $productData['wholesale_commission'] = $data['wholesale_commission'];

        if (isset($data['disp_naver']))
        {
            $productData['disp_naver'] = $data['disp_naver'];
        }

        if (isset($data['disp_daum']))
        {
            $productData['disp_daum'] = $data['disp_daum'];
        }

        //상품별 배송 정책 설정(shop_product)
        $productData['delivery_type'] = $data['delivery_type'];

        //가격+옵션
        $productData['stock_use_yn'] = $data['stock_use_yn'];
        $productData['coprice'] = $data['coprice'];
        $productData['listprice'] = $data['listprice'];
        $productData['sellprice'] = $data['sellprice'];
        $productData['wholesale_price'] = $data['wholesale_price'];
        $productData['wholesale_sellprice'] = $data['wholesale_sellprice'];
        $productData['allow_basic_cnt'] = $data['allow_basic_cnt'];
        $productData['allow_byoneperson_cnt'] = $data['allow_byoneperson_cnt'];

        $this->updateProduct($pid, $productData);

        $relationData['cidList'] = $data['cidList'];
        $relationData['basicCid'] = $data['basicCid'];
        $this->putRelation($pid, $relationData);
        if ($noticeGridData) {
            //상품정보고시
            $this->putMandatoryInfo($pid, $noticeGridData);
        }

        //디스플레이
        if ($displayGridData) {
            $this->putDisplayInfo($pid, $displayGridData);
        }

        //관련상품 등록 및 수정
        $this->putRelProduct($pid, $relProductGridData);

        //상품사은품 등록 및 수정
        $this->putRelGiftProduct($pid, $relGiftProductGridData);

        //이미지 업로드
        $imageData['devAddImage1'] = $data['devAddImage1'];
        $imageData['devAddImage2'] = $data['devAddImage2'];
        $imageData['devAddImage3'] = $data['devAddImage3'];
        $imageData['devAddImage4'] = $data['devAddImage4'];
        $imageData['devAddImage5'] = $data['devAddImage5'];
        $this->imageUpload($pid, $file, $imageData);
        if ($deleteFile) {
            foreach ($deleteFile as $k => $v) {
                $this->imageDelete($v['file']);
            }
        }

        //상품별 배송 정책 설정(shop_product_delivery)
        $deliveryData['dt_ix'] = $data['delivery_template'];
        $deliveryData['delivery_div'] = $data['delivery_type'];
        $this->putDelivery($pid, $deliveryData);

        //옵션초기화
        $this->qb
            ->set('insert_yn', 'N')
            ->set('is_delete', '1')
            ->where('pid', $pid)
            ->update(TBL_SHOP_PRODUCT_OPTIONS)
            ->exec();

        //옵션상세 초기화
        $this->qb
            ->set('insert_yn', 'N')
            ->set('is_delete', '1')
            ->where('pid', $pid)
            ->update(TBL_SHOP_PRODUCT_OPTIONS_DETAIL)
            ->exec();

        //옵션
        if ($optionGridData) {
            $optionDataOptionName[] = $data['option_name'];
            if ($data['stock_use_yn'] != 'Y') {
                foreach ($optionGridData as $k => $v) {
                    $optionGridData[$k]['option_gid'] = '';
                    $optionGridData[$k]['option_code'] = '';
                    $optionGridData[$k]['option_barcode'] = '';
                    $optionGridData[$k]['add_option_name'] = '';
                }
            }

            $optionKind = 'b';
            $this->putOption($pid, $optionKind, $optionDataOptionName, $optionGridData, ($data['option_type'] ?? '9'));
        }

        //추가구성상품
        if ($addOptionGridData) {
            $addOptionGridDataFilter = array_values(array_filter($addOptionGridData));
            foreach ($addOptionGridDataFilter as $k => $addOptionGridDataDetail) {
                if (!empty($data['add_option_name'][$k])) {
                    $addOptionDataOptionName[$k]['add_option_opn_ix'] = $data['add_option_opn_ix'][$k];
                    $addOptionDataOptionName[$k]['add_option_name'] = $data['add_option_name'][$k];
                }
                if ($data['stock_use_yn'] != 'Y') {
                    $addOptionGridDataDetailArray[$k] = $addOptionGridDataDetail;
                }
            }

            $this->putOption($pid, 'a', $addOptionDataOptionName, $addOptionGridDataDetailArray);
        }

        //삭제된 옵션 제거
        $this->deleteOption($pid);
        $this->deleteOptionDetail($pid);
    }

    /**
     * 카테고리 수정
     * @param $pid
     * @param $data
     * @throws \Exception
     */
    public function putRelation($pid, $data)
    {
        $this->qb
            ->set('insert_yn', 'N')
            ->where('pid', $pid)
            ->update(TBL_SHOP_PRODUCT_RELATION)
            ->exec();

        foreach ($data['cidList'] as $k => $v) {
            $cateData['cid'] = $v;
            if ($data['basicCid'] == $v) {
                $cateData['basic'] = '1';
            } else {
                $cateData['basic'] = '0';
            }

            $total = $this->qb
                    ->from(TBL_SHOP_PRODUCT_RELATION)
                    ->where('pid', $pid)
                    ->where('cid', $cateData['cid'])
                    ->getCount() > 0;
            if ($total === false) {
                $this->insertProductRelation($pid, $cateData);
            } else {
                $this->updateProductRelation($pid, $cateData);
            }
        }

        $this->qb
            ->where('pid', $pid)
            ->where('insert_yn', 'N')
            ->delete(TBL_SHOP_PRODUCT_RELATION)
            ->exec();
    }

    /**
     * 상품정보고시
     * @param $id
     * @return array
     * @throws \Exception
     */
    public function getNoticeGridList($pid)
    {
        $list = $this->qb
            ->select('SUBSTRING_INDEX(pmi_code,"|",1) AS mi_ix')
            ->select('SUBSTRING_INDEX(pmi_code,"|",-1) AS detail_code')
            ->select('pmi_title AS mid_title')
            ->select('pmi_desc AS mid_desc')
            ->from(TBL_SHOP_PRODUCT_MANDATORY_INFO)
            ->where('pid', $pid)
            ->exec()
            ->getResultArray();

        return $list;
    }

    /**
     * 상품정보고시
     * @param $pid
     * @return array
     * @throws \Exception
     */
    public function getDisplayGridList($pid)
    {
        $list = $this->qb
            ->select('dp_ix')
            ->select('dp_title')
            ->select('dp_desc')
            ->from(TBL_SHOP_PRODUCT_DISPLAYINFO)
            ->where('pid', $pid)
            ->exec()
            ->getResultArray();

        return $list;
    }

    /**
     * 디스플레이 정보
     * @param $pid
     * @param $data
     * @throws \Exception
     */
    public function putDisplayInfo($pid, $data)
    {
        $this->qb
            ->set('insert_yn', 'N')
            ->where('pid', $pid)
            ->update(TBL_SHOP_PRODUCT_DISPLAYINFO)
            ->exec();

        foreach ($data as $k => $v) {
            $dp_ix = $this->selectDisplayInfo($v['dp_ix']);
            if ($dp_ix) {
                $this->updateDisplayInfo($dp_ix, $v);
            } else {
                $this->insertDisplayInfo($pid, $v);
            }
        }

        $this->qb
            ->where('pid', $pid)
            ->where('insert_yn', 'N')
            ->delete(TBL_SHOP_PRODUCT_DISPLAYINFO)
            ->exec();
    }

    /**
     * 디스플레이 검색
     * @param $dp_ix
     * @return bool
     * @throws \Exception
     */
    protected function selectDisplayInfo($dp_ix)
    {
        return $this->qb
            ->select('dp_ix')
            ->from(TBL_SHOP_PRODUCT_DISPLAYINFO)
            ->where('dp_ix', $dp_ix)
            ->exec()->getRowArray()['dp_ix'] ?? false;
    }

    /**
     * 디스플레이 등록
     * @param $pid
     * @param $data
     * @throws \Exception
     */
    protected function insertDisplayInfo($pid, $data)
    {
        $this->qb
            ->set('pid', $pid)
            ->set('dp_title', $data['dp_title'])
            ->set('dp_desc', $data['dp_desc'])
            ->set('regdate', fb_now())
            ->insert(TBL_SHOP_PRODUCT_DISPLAYINFO)
            ->exec();
    }

    /**
     * 디스플레이 수정
     * @param $dp_ix
     * @param $data
     * @throws \Exception
     */
    protected function updateDisplayInfo($dp_ix, $data)
    {
        $this->qb
            ->set('dp_title', $data['dp_title'])
            ->set('dp_desc', $data['dp_desc'])
            ->set('insert_yn', 'Y')
            ->set('regdate', fb_now())
            ->update(TBL_SHOP_PRODUCT_DISPLAYINFO)
            ->where('dp_ix', $dp_ix)
            ->exec();
    }

    /**
     * 디스플레이 삭제
     * @param $dp_ixs
     * @throws \Exception
     */
    public function deleteDisplayInfo($dp_ixs)
    {
        $this->qb
            ->whereIn('dp_ix', $dp_ixs)
            ->delete(TBL_SHOP_PRODUCT_DISPLAYINFO)
            ->exec();
    }

    /**
     * 상품정보고시 수정
     * @param $pid
     * @param $data
     * @throws \Exception
     */
    protected function putMandatoryInfo($pid, $data)
    {
        $this->qb
            ->set('insert_yn', 'N')
            ->where('pid', $pid)
            ->update(TBL_SHOP_PRODUCT_MANDATORY_INFO)
            ->exec();

        foreach ($data as $k => $v) {
            $total = $this->qb
                    ->from(TBL_SHOP_PRODUCT_MANDATORY_INFO)
                    ->where('pid', $pid)
                    ->where('pmi_code', $v['mi_ix'] . "|" . $v['detail_code'])
                    ->getCount() > 0;
            if ($total === false) {
                $this->insertProductMandatoryInfo($pid, $v);
            } else {
                $this->updateProductMandatoryInfo($pid, $v);
            }
        }
        $this->qb
            ->set('mandatory_type', $data[0]['mi_ix'] . '|1')
            ->update(TBL_SHOP_PRODUCT)
            ->where('id', $pid)
            ->exec();

        $this->qb
            ->where('pid', $pid)
            ->where('insert_yn', 'N')
            ->delete(TBL_SHOP_PRODUCT_MANDATORY_INFO)
            ->exec();
    }

    /**
     * 상세 및 고시정보(상품정보고시) 상품정보고시 등록
     * @param $pid
     * @param $data
     */
    public function insertProductMandatoryInfo($pid, $data)
    {
        if (empty($data['pmi_code'])) {
            $pmi_code = $data['mi_ix'] . '|' . $data['detail_code'];
        } else {
            $pmi_code = $data['pmi_code'];
        }
        $this->qb
            ->set('pid', $pid)
            ->set('pmi_code', $pmi_code)
            ->set('pmi_title', $data['mid_title'])
            ->set('pmi_desc', $data['mid_desc'])
            ->set('insert_yn', 'Y')
            ->set('regdate', fb_now())
            ->insert(TBL_SHOP_PRODUCT_MANDATORY_INFO)
            ->exec();
    }

    /**
     * 상세 및 고시정보(상품정보고시) 업데이트
     * @param $pid
     * @param $data
     * @throws \Exception
     */
    public function updateProductMandatoryInfo($pid, $data)
    {
        $this->qb
            ->set('pmi_title', $data['mid_title'])
            ->set('pmi_desc', $data['mid_desc'])
            ->set('insert_yn', 'Y')
            ->set('regdate', fb_now())
            ->update(TBL_SHOP_PRODUCT_MANDATORY_INFO)
            ->where('pid', $pid)
            ->where('pmi_code', $data['mi_ix'] . "|" . $data['detail_code'])
            ->exec();
    }

    /**
     * 관련상품 등록 및 수정
     * @param $pid
     * @param $data
     * @throws \Exception
     */
    public function putRelProduct($pid, $data)
    {
        $this->qb
            ->set('insert_yn', 'N')
            ->where('pid', $pid)
            ->update(TBL_SHOP_RELATION_PRODUCT)
            ->exec();

        if (is_array($data)) {
            foreach ($data as $k => $v) {
                $total = $this->qb
                        ->from(TBL_SHOP_RELATION_PRODUCT)
                        ->where('pid', $pid)
                        ->where('rp_pid', $v['id'])
                        ->getCount() > 0;
                $v['key'] = $k;
                if ($total === false) {
                    $this->insertRelProduct($pid, $v);
                } else {
                    $this->updateRelProduct($pid, $v);
                }
            }
        }

        $this->qb
            ->where('pid', $pid)
            ->where('insert_yn', 'N')
            ->delete(TBL_SHOP_RELATION_PRODUCT)
            ->exec();
    }



    /**
     * 상품사은품 등록 및 수정
     * @param $pid
     * @param $data
     * @throws \Exception
     */
    public function putRelGiftProduct($pid, $data)
    {
        $this->qb
            ->set('insert_yn', 'N')
            ->where('pid', $pid)
            ->update(TBL_SHOP_RELATION_GIFT_PRODUCT)
            ->exec();

        if (is_array($data)) {
            foreach ($data as $k => $v) {
                $total = $this->qb
                        ->from(TBL_SHOP_RELATION_GIFT_PRODUCT)
                        ->where('pid', $pid)
                        ->where('rgp_pid', $v['id'])
                        ->getCount() > 0;
                $v['key'] = $k;
                if ($total === false) {
                    $this->insertRelGiftProduct($pid, $v);
                } else {
                    $this->updateRelGiftProduct($pid, $v);
                }
            }
        }

        $this->qb
            ->where('pid', $pid)
            ->where('insert_yn', 'N')
            ->delete(TBL_SHOP_RELATION_GIFT_PRODUCT)
            ->exec();
    }

    /**
     * 관련상품 등록
     * @param $pid
     * @param $data
     * @throws \Exception
     */
    public function insertRelProduct($pid, $data)
    {
        $this->qb
            ->set('pid', $pid)
            ->set('rp_pid', $data['id'])
            ->set('vieworder', $data['key'])
            ->set('insert_yn', 'Y')
            ->set('regdate', fb_now())
            ->insert(TBL_SHOP_RELATION_PRODUCT)
            ->exec();
    }
    
    /**
     * 상품사은품 등록
     * @param $pid
     * @param $data
     * @throws \Exception
     */
    public function insertRelGiftProduct($pid, $data)
    {
        $this->qb
            ->set('pid', $pid)
            ->set('rgp_pid', $data['id'])
            ->set('vieworder', $data['key'])
            ->set('insert_yn', 'Y')
            ->set('regdate', fb_now())
            ->insert(TBL_SHOP_RELATION_GIFT_PRODUCT)
            ->exec();
    }

    /**
     * 관련상품 수정
     * @param $pid
     * @param $data
     * @throws \Exception
     */
    public function updateRelProduct($pid, $data)
    {
        $this->qb
            ->set('vieworder', $data['key'])
            ->set('insert_yn', 'Y')
            ->set('regdate', fb_now())
            ->update(TBL_SHOP_RELATION_PRODUCT)
            ->where('pid', $pid)
            ->where('rp_pid', $data['id'])
            ->exec();
    }

    /**
     * 상품사은품 수정
     * @param $pid
     * @param $data
     * @throws \Exception
     */
    public function updateRelGiftProduct($pid, $data)
    {
        $this->qb
            ->set('vieworder', $data['key'])
            ->set('insert_yn', 'Y')
            ->set('regdate', fb_now())
            ->update(TBL_SHOP_RELATION_GIFT_PRODUCT)
            ->where('pid', $pid)
            ->where('rgp_pid', $data['id'])
            ->exec();
    }

    /**
     * 전시상품 데이터
     * @param $pid
     * @return array|void
     * @throws \Exception
     */
    public function getRelProductList($pid)
    {
        $rows = $this->qb
            ->select('rp_pid')
            ->from(TBL_SHOP_RELATION_PRODUCT)
            ->where('pid', $pid)
            ->orderBy('vieworder')
            ->exec()
            ->getResultArray();

        if ($rows) {
            /* @var $choiceProductModel \CustomScm\Model\Util\ChoiceProduct */
            $choiceProductModel = $this->import('model.scm.util.choiceProduct');
            return $choiceProductModel->getList(array_column($rows, 'rp_pid'));
        } else {
            return;
        }
    }
    /**
     * 상품사은품 데이터
     * @param $pid
     * @return array|void
     * @throws \Exception
     */
    public function getRelGiftProductList($pid)
    {
        $rows = $this->qb
            ->select('rgp_pid')
            ->from(TBL_SHOP_RELATION_GIFT_PRODUCT)
            ->where('pid', $pid)
            ->exec()
            ->getResultArray();

        if ($rows) {
            /* @var $choiceProductModel \CustomScm\Model\Util\ChoiceProduct */
            $choiceProductModel = $this->import('model.scm.util.choiceProduct');
            return $choiceProductModel->getList(array_column($rows, 'rgp_pid'));
        } else {
            return;
        }
    }

    /**
     * url 로 이미지 업로드 (엑셀 등록 시에만 사용)
     * @param $pid
     * @param $basicUrl
     * @param array $addUrls
     */
    public function urlImageUpload($pid, $basicUrl, $addUrls = [])
    {
        /* @var $webContentsModel \CustomScm\Model\Util\WebContents */
        $webContentsModel = $this->import('model.scm.util.webContents');
        $webContentsModel->productUpload($pid, $basicUrl);
        if (!empty($addUrls)) {
            foreach ($addUrls as $addUrl) {
                $webContentsModel->productAddUpload($pid, $addUrl);
            }
        }
    }

    /**
     * 기본 이미지 업로드
     * @param $pid
     * @param type $file
     * @param $data
     * @throws \Exception
     */
    protected function imageUpload($pid, $file, $data)
    {
        /* @var $uploadModel \CustomScm\Model\Util\Upload */
        $uploadModel = $this->import('model.scm.util.upload');

        //넘어온것 만큼 넣음
        foreach ($file as $key => $val) {
            if ($key && $val['size'] > 0) {
                if ($key == 'basicImage') {
                    $uploadModel->productUpload($key, $pid);
                } else {
                    if (!empty($data[$key])) {
                        $adIx = $data[$key];
                        $this->qb
                            ->set('insert_yn', 'Y')
                            ->set('regdate', fb_now())
                            ->update(TBL_SHOP_ADDIMAGE)
                            ->where('id', $adIx)
                            ->where('pid', $pid)
                            ->exec();
                    } else {
                        $adIx = $this->qb
                            ->set('pid', $pid)
                            ->set('insert_yn', 'Y')
                            ->set('regdate', fb_now())
                            ->insert(TBL_SHOP_ADDIMAGE)
                            ->exec();
                    }
                    $adIx = sprintf("%08d", $adIx);
                    $uploadModel->productAddUpload($key, $pid, $adIx);
                }
            }
        }
    }

    /**
     * 추가 이미지
     * @param $pid
     * @param null $id
     * @return array
     * @throws \Exception
     */
    public function getAddImageList($pid, $id = null)
    {
        if ($id) {
            $this->qb
                ->where('id', $id);
        }

        $rows = $this->qb
            ->select('id')
            ->from(TBL_SHOP_ADDIMAGE)
            ->where('pid', $pid)
            ->exec()
            ->getResultArray();

        return $rows;
    }

    /**
     * 추가 이미지
     * @param $pid
     * @param string $sizeType
     * @return array
     * @throws \Exception
     */
    public function getAddImage($pid, $sizeType = 'basic')
    {
        $rows = $this->getAddImageList($pid);

        $basicPath = DATA_ROOT . "/images/addimg";

        foreach ($rows as $key => $val) {
            $id = zerofill($val['id'], 8);
            $pid = zerofill($pid);
            $imgDir = implode("/", str_split($pid, 2));

            $imageSrc = IMAGE_SERVER_DOMAIN . $basicPath . '/' . $imgDir . "/" . $sizeType . "_" . $id . "_add.gif?".time();

            //이미지 없을떄
//            if (!file_exists($_SERVER['DOCUMENT_ROOT'] . $imageSrc)) {
//                $imageSrc = '';
//            }

            $val['url'] = $imageSrc;
            $rows[$key] = $val;
        }

        return $rows;
    }

    /**
     * @param $url
     * @throws \Exception
     */
    public function imageDelete($url)
    {
        $filename = basename($url, strrchr($url, '.'));
        $id = substr($filename, -12, 8);
        $getStr = strrchr($url,'?');
        $url = str_replace([IMAGE_SERVER_DOMAIN, $getStr],'',$url);

        $this->qb
            ->where('id', $id)
            ->delete(TBL_SHOP_ADDIMAGE)
            ->exec();

        /* @var $uploadModel \CustomScm\Model\Util\Upload */
        $uploadModel = $this->import('model.scm.util.upload');
        $uploadModel->deleteUploadFileInfo($url);
    }

    /**
     * 배송정보수정
     * @param $pid
     * @param $data
     * @throws \Exception
     */
    public function putDelivery($pid, $data)
    {
        $pd_ix = $this->selectDelivery($pid);

        if ($pd_ix) {
            $this->updateDelivery($pd_ix, $pid, $data);
        } else {
            $this->insertDelivery($pid, $data);
        }
    }

    /**
     * 배송정보
     * @param $pid
     * @return mixed
     * @throws \Exception
     */
    protected function selectDelivery($pid)
    {
        $row = $this->qb
            ->select('pd_ix')
            ->from(TBL_SHOP_PRODUCT_DELIVERY)
            ->where('pid', $pid)
            ->where('is_wholesale', 'R')
            ->exec()
            ->getRowArray();

        return $row['pd_ix'] ?? '';
    }

    /**
     * 배송정보 등록
     * @param $pid
     * @param $data
     * @throws \Exception
     */
    public function insertDelivery($pid, $data)
    {
        /* @var $deliveryCompanyModel \CustomScm\Model\Company\DeliveryCompany */
        $deliveryCompanyModel = $this->import('model.scm.company.deliveryCompany');
        $deliveryInfo = $deliveryCompanyModel->getDeliveryInfo($data['dt_ix']);

        $this->qb
            ->set('pid', zerofill($pid, 10))
            ->set('is_wholesale', 'R')
            ->set('dt_ix', $data['dt_ix'])
            ->set('delivery_div', $data['delivery_div'])
            ->set('company_id', ($deliveryInfo['company_id'] ?? ''))
            ->set('regdate', fb_now())
            ->insert(TBL_SHOP_PRODUCT_DELIVERY)
            ->exec();
    }

    /**
     * 배송정보 수정
     * @param $pd_ix
     * @param $pid
     * @param $data
     * @throws \Exception
     */
    protected function updateDelivery($pd_ix, $pid, $data)
    {
        add_history('product', TBL_SHOP_PRODUCT_DELIVERY . '.pd_ix', $pd_ix, [
            'dt_ix' => '배송비 정책'
        ], $data, $pid);

        /* @var $deliveryCompanyModel \CustomScm\Model\Company\DeliveryCompany */
        $deliveryCompanyModel = $this->import('model.scm.company.deliveryCompany');
        $deliveryInfo = $deliveryCompanyModel->getDeliveryInfo($data['dt_ix']);

        $this->qb
            ->set('pid', $pid)
            ->set('is_wholesale', 'R')
            ->set('dt_ix', $data['dt_ix'])
            ->set('delivery_div', $data['delivery_div'])
            ->set('company_id', ($deliveryInfo['company_id'] ?? ''))
            ->set('editdate', fb_now())
            ->update(TBL_SHOP_PRODUCT_DELIVERY)
            ->where('pd_ix', $pd_ix)
            ->exec();
    }

    /**
     * 판매정보 수정
     * @param $pid
     * @param $kind
     * @param $optionData
     * @param $optionDetailDataArray
     * @throws \Exception
     */
    public function putOption($pid, $kind, $optionData, $optionDetailDataArray, $type=false)
    {
        foreach ($optionData as $key => $value) {
            if ($kind == 'a') {//추가구성상품옵션일때
                $optionDetailData = $optionDetailDataArray[$key];
                if ($value['add_option_opn_ix']) {
                    $opn_ix = $value['add_option_opn_ix'];
                } else {
                    $opn_ix = '';
                }
            } else {
                $optionDetailData = $optionDetailDataArray;
                $result = $this->selectOption($pid, $kind);
                if ($result) {
                    $opn_ix = $result[0]['opn_ix'];
                } else {
                    $opn_ix = '';
                }
            }

            if ($kind == 'a') {
                $optionData['option_name'] = $value['add_option_name'];
            } else {
                $optionData['option_name'] = $value;
            }

            if ($opn_ix) {
                //옵션 히스토리 기록
                $historyReturn = add_history('product', TBL_SHOP_PRODUCT_OPTIONS . '.opn_ix', $opn_ix, ['option_name' => '옵션명'], $optionData);

                $this->updateOption($opn_ix, $optionData['option_name'], $type );

                //옵션명이 바뀌었을때 상품 상태변경
                if(count($historyReturn) > 0) {
                    //현재 상품상태 체크
                    $state = $this->getProductState($pid);
                    if (sess_val('admininfo', 'mem_div') == 'S' && in_array($state, ['0', '1'])) {
                        //가격변동시 강제로 '수정대기'
                        $checkPriceChange = ['option_name'];
                        foreach ($historyReturn as $val) {
                            if (in_array($val, $checkPriceChange)) {
                                $data['state'] = "5";
                                break;
                            }
                        }
                    }
                    
                    $this->qb
                        ->set($data)
                        ->set('editdate', fb_now())
                        ->update(TBL_SHOP_PRODUCT)
                        ->where('id', $pid)
                        ->exec();
                }
            } else {
                $opn_ix = $this->insertOption($pid, $kind, $optionData['option_name'], $type);
            }

            if ($optionDetailData) {
                foreach ($optionDetailData as $k => $v) {
                    if ($v['id']) {
                        $this->updateOptionDetail($v['id'], $v);
                    } else {
                        $this->insertOptionDetail($pid, $opn_ix, $v);
                    }
                }
            }
        }
    }

    public function deleteOption($pid)
    {
        $this->qb
            ->where('pid', $pid)
            ->where('insert_yn', 'N')
            ->delete(TBL_SHOP_PRODUCT_OPTIONS)
            ->exec();
    }

    public function deleteOptionDetail($pid)
    {
        $this->qb
            ->where('pid', $pid)
            ->where('insert_yn', 'N')
            ->delete(TBL_SHOP_PRODUCT_OPTIONS_DETAIL)
            ->exec();
    }

    /**
     * 상품 옵션정보 검색
     * @param $pid
     * @param $kind
     * @return mixed
     * @throws \Exception
     */
    public function selectOption($pid, $kind = false)
    {
        if(!empty($kind)) {
            $this->qb->where('option_kind', $kind);
        }

        $list = $this->qb
            ->select('opn_ix')
            ->select('option_name')
            ->select('option_type')
            ->select('option_kind')
            ->from(TBL_SHOP_PRODUCT_OPTIONS)
            ->where('pid', $pid)
            ->exec()
            ->getResultArray();

        foreach ($list as $k => $v) {
            $list[$k]['detailList'] = $this->selectOptionDetail($pid, $v['opn_ix']);
        }

        return $list;
    }

    /**
     * 상품 옵션상세정보 검색
     * @param $pid
     * @param $opn_ix
     * @return array
     * @throws \Exception
     */
    public function selectOptionDetail($pid, $opn_ix)
    {
        $data = $this->qb
            ->select('id')
            ->select('option_div')
            ->select('option_coprice')
            ->select('option_listprice')
            ->select('option_price')
            ->select('option_sell_ing_cnt')
            ->select('option_stock')
            ->select('option_code')
            ->select('option_gid')
            ->select('option_soldout')
            ->select('option_barcode')
            ->select('option_wholesale_listprice')
            ->select('option_wholesale_price')
            ->select('IF(option_stock > option_sell_ing_cnt, option_stock - option_sell_ing_cnt, 0) AS stock', false)
            ->from(TBL_SHOP_PRODUCT_OPTIONS_DETAIL)
            ->where('pid', $pid)
            ->where('opn_ix', $opn_ix)
            ->where('is_delete', '0')
            ->exec()
            ->getResultArray();

        return $data;
    }

    /**
     * 상품 옵션정보 등록
     * @param $pid
     * @param $kind
     * @param $option_name
     * @return bool|\NunaResult
     * @throws \Exception
     */
    public function insertOption($pid, $kind, $option_name, $type=false)
    {
        $opn_ix = $this->qb
            ->set('pid', $pid)
            ->set('option_kind', $kind)
            ->set('option_type', $type)
            ->set('option_name', $option_name)
            ->set('regdate', fb_now())
            ->insert(TBL_SHOP_PRODUCT_OPTIONS)
            ->exec();

        return $opn_ix;
    }

    /**
     * 상품 옵션상세정보 등록
     * @param $pid
     * @param $opn_ix
     * @param $data
     * @throws \Exception
     */
    public function insertOptionDetail($pid, $opn_ix, $data)
    {
        if(!empty($data['option_soldout'])) {
            if ($data['option_soldout'] === 'true') {
                $option_soldout = 1;
            } else {
                $option_soldout = 0;
            }
        }else{
            $option_soldout = 0;
        }

        if (!empty($data['option_stock'])) {
            $this->qb->set('option_stock', $data['option_stock']);
        }
        if(!empty($data['option_div'])) {
            $this->qb->set('option_div', $data['option_div']);
        }
        if(!empty($data['option_code'])) {
            $this->qb->set('option_code', $data['option_code']);
        }
        if(!empty($data['option_gid'])) {
            $this->qb->set('option_gid', $data['option_gid']);
        }
        if(!empty($data['option_listprice'])) {
            $this->qb->set('option_listprice', $data['option_listprice']);
        }
        if(!empty($data['option_price'])) {
            $this->qb->set('option_price', $data['option_price']);
        }
        if(!empty($data['option_coprice'])) {
            $this->qb->set('option_coprice', $data['option_coprice']);
        }
        if(!empty($data['option_barcode'])) {
            $this->qb->set('option_barcode', $data['option_barcode']);
        }
        if(!empty($data['option_wholesale_listprice'])) {
            $this->qb->set('option_wholesale_listprice', $data['option_wholesale_listprice']);
        }
        if(!empty($data['option_wholesale_price'])) {
            $this->qb->set('option_wholesale_price', $data['option_wholesale_price']);
        }

        $this->qb
            ->set('pid', $pid)
            ->set('opn_ix', $opn_ix)
            ->set('option_soldout', $option_soldout)
            ->set('regdate', fb_now())
            ->set('global_odinfo', '')
            ->set('set_group', '')
            ->set('option_surtax_div', '')
            ->set('option_premiumprice', '0')
            ->set('option_sell_ing_cnt', '0')
            ->set('option_color', '')
            ->set('option_size', '')
            ->set('option_seq', '0')
            ->insert(TBL_SHOP_PRODUCT_OPTIONS_DETAIL)
            ->exec();
    }

    /**
     * 옵션수정
     * @param $opn_ix
     * @param $optionName
     * @throws \Exception
     */
    protected function updateOption($opn_ix, $optionName, $type=false)
    {
        $this->qb
            ->set('option_type', $type)
            ->set('option_name', $optionName)
            ->set('insert_yn', 'Y')
            ->set('is_delete', '0')
            ->set('regdate', fb_now())
            ->update(TBL_SHOP_PRODUCT_OPTIONS)
            ->where('opn_ix', $opn_ix)
            ->exec();
    }

    /**
     * 옵션상세수정
     * @param $id
     * @param $data
     * @throws \Exception
     */
    protected function updateOptionDetail($id, $data)
    {
         $selData = $this->qb
                    ->select('pid')
                    ->from(TBL_SHOP_PRODUCT_OPTIONS_DETAIL)
                    ->where('id', $id)
                    ->exec()
                    ->getRowArray();

        $historyReturn = add_history('product', TBL_SHOP_PRODUCT_OPTIONS_DETAIL.'.id', $id,
            [
                'option_coprice' => '옵션 구매단가',
                'option_listprice' => '판매가',
                'option_coprice' => '구매단가',
                'option_price' => '실판매가',
                'option_soldout' => '옵션 품절여부',
                'option_wholesale_listprice' => '옵션 도매가',
                'option_wholesale_price' => '옵션 도매판매가',
            ], $data, $selData['pid']);

        //가격변동시 강제로 '수정대기'


        $checkPriceChange = [
            'option_coprice',
            'option_wholesale_listprice',
            'option_wholesale_price',
            'option_listprice',
            'option_price'
        ];

        if (sess_val('admininfo', 'mem_div') == 'S') {
            foreach ($historyReturn as $val) {
                if (in_array($val, $checkPriceChange)) {
                    $productData['state'] = "5";
                    $this->updateProduct($selData['pid'], $productData);
                    break;
                }
            }
        }
        if ($data['option_soldout'] === 'true' || $data['option_soldout'] == '1') {
            $option_soldout = 1;
        } else {
            $option_soldout = 0;
        }

        if (isset($data['option_stock'])) {
            $this->qb
                ->set('option_stock', $data['option_stock']);
        }

        $this->qb
            ->set('option_div', $data['option_div'])
            ->set('option_code', $data['option_code'])
            ->set('option_gid', $data['option_gid'])
            ->set('option_listprice', $data['option_listprice'])
            ->set('option_price', $data['option_price'])
            ->set('option_coprice', $data['option_coprice'])
            ->set('option_wholesale_listprice', $data['option_wholesale_listprice'])
            ->set('option_wholesale_price', $data['option_wholesale_price'])
            ->set('option_soldout', $option_soldout)
            ->set('option_barcode', $data['option_barcode'])
            ->set('insert_yn', 'Y')
            ->set('is_delete', '0')
            ->set('regdate', fb_now())
            ->update(TBL_SHOP_PRODUCT_OPTIONS_DETAIL)
            ->where('id', $id)
            ->exec();
    }

    /**
     * 일괄 변경
     * @param $ids
     * @param $data
     * @throws \Exception
     */
    public function putBatch($ids, $data)
    {
        //카테고리 일괄변경
        if (isset($data['basicTypeBatch'])) {
            $productRelationData['basic'] = $data['basicTypeBatch'];

            foreach ($ids as $id) {
                /**
                 * 일괄카테고리 변경 시에는 기본&서브 카테고리를 모두 삭제한다.
                 * 일괄카테고리 삭제 시에는 서브 카테고리만 삭제한다.
                 */
                if ($data['basicTypeBatch'] != '1' && ($data['productRelationBatch'] == '1' || $data['productRelationBatch'] == '3')) {
                    $this->deleteProductRelation($id, $productRelationData);
                } else if($data['productRelationBatch'] == '3') {
                    $updateData['basic'] = '0';
                    $this->deleteProductRelation($id, $updateData);
                }
                if (!empty($data['filterCid'])) {
                    foreach ($data['filterCid'] as $cidVal) {

                        $productRelationData['cid'] = $cidVal;
                        if($data['basicTypeBatch'] == '1') {        //기본 카테고리 변경
                            //기존 기본 카테고리를 제거 한 후 등록
                            $delData['basic'] = '1';
                            $this->deleteProductRelation($id, $delData);

                            $selectData['cid'] = $cidVal;
                            $rid = $this->selectProductRelation($id, $selectData);

                            if(!$rid) {
                                $this->insertProductRelation($id, $productRelationData);
                            }else{

                                $productRelationData['basic'] = '1';
                                $this->updateProductRelation($id, $productRelationData);

                            }
                        } else {
                            $selectData['cid'] = $cidVal;
                            $rid = $this->selectProductRelation($id, $selectData);
                            if ($data['productRelationBatch'] == '1') { //중복카테고리 변경
                                if (!$rid) {
                                    $this->insertProductRelation($id, $productRelationData);
                                }
                            } else if($data['productRelationBatch'] == '2'){    //중복카테고리 추가
                                if (!$rid) {
                                    $this->insertProductRelation($id, $productRelationData);
                                }
                            }
                        }
                    }
                }
            }
        }

        //판매기간/상태/노출 일괄변경
        $productData = [];
        if (!empty($data['batchType'])) {
            if ($data['batchType'] == 'is_sell_date') { //판매기간
                $productData['is_sell_date'] = $data['isSellDateBatch'];

                if (strlen($data['startDateBatch']) == 10) {
                    $data['startDateBatch'] . ' 00:00:00';
                }
                if (strlen($data['endDateBatch']) == 10) {
                    $data['endDateBatch'] . ' 00:00:00';
                }
                $productData['sell_priod_sdate'] = $data['startDateBatch'];
                $productData['sell_priod_edate'] = $data['endDateBatch'];
            } else {
                if ($data['batchType'] == 'state') { //판매상태
                    $productData['state'] = $data['stateBatch'];
                } else {
                    if ($data['batchType'] == 'disp') { //노출여부
                        $productData['disp'] = $data['dispBatch'];
                    }
                }
            }

            foreach ($ids as $id) {
                $this->updateProduct($id, $productData);
            }
        }

        //배송정책 일괄변경
        if (!empty($data['batch_delivery_type'])) {
            // 상품별 배송정책 변경(shop_product)
            $productData['delivery_type'] = $data['batch_delivery_type'];
            // 상품별 배송정책 변경(shop_product_delivery)
            $deliveryData['dt_ix'] = $data['delivery_template'];
            $deliveryData['delivery_div'] = $data['batch_delivery_type'];

            foreach ($ids as $id) {
                $this->updateProduct($id, $productData);

                $pdIx = $this->selectDelivery($id);
                if ($pdIx) {
                    $this->updateDelivery($pdIx, $id, $deliveryData);
                } else {
                    $this->insertDelivery($id, $deliveryData);
                }
            }
        }

        //담당Md 일괄변경
        if (!empty($data['md_id'])) {
            $mdData['md_code'] = $data['md_id'];
            foreach ($ids as $id) {
                $this->updateProduct($id, $mdData);
            }
        }

        //수수료 일괄변경
        if (!empty($data['one_commissionBatch'])) {
            $commissionData['one_commission'] = $data['one_commissionBatch'];
            if ($commissionData['one_commission'] == 'Y') {
                $commissionData['account_type'] = $data['account_typeBatch'];
                $commissionData['commission'] = $data['commissionBatch'];
            }
            foreach ($ids as $id) {
                $this->updateProduct($id, $commissionData);
            }
        }

        //모바일상품 일괄변경
        if (!empty($data['is_mobile_useBatch'])) {
            $mobileData['is_mobile_use'] = $data['is_mobile_useBatch'];
            foreach ($ids as $id) {
                $this->updateProduct($id, $mobileData);
            }
        }
    }

    /**
     * 카테고리 삭제
     * @param $pid
     * @param $data
     * @throws \Exception
     */
    protected function deleteProductRelation($pid, $data)
    {
        if (isset($data['basic'])) {
            $this->qb->where('basic', $data['basic']);
        }
        if (isset($data['cid'])) {
            $this->qb->where('cid', $data['cid']);
        }

        $this->qb
            ->delete(TBL_SHOP_PRODUCT_RELATION)
            ->where('pid', $pid)
            ->exec();
    }

    /**
     * 카테고리 검색
     * @param $pid
     * @param $data
     * @throws \Exception
     */
    protected function selectProductRelation($pid, $data)
    {
        if (isset($data['basic'])) {
            $this->qb->where('basic', $data['basic']);
        }
        if (isset($data['cid'])) {
            $this->qb->where('cid', $data['cid']);
        }

        $row = $this->qb
            ->select('rid')
            ->from(TBL_SHOP_PRODUCT_RELATION)
            ->where('pid', $pid)
            ->exec()
            ->getRowArray();
        return $row['rid'] ?? '';
    }

    /**
     * 기본 카테고리 검색
     * @param $pid
     * @param $data
     * @throws \Exception
     */
    protected function selectProductBasicRelation($pid, $cid)
    {
        $row = $this->qb
            ->select('rid')
            ->from(TBL_SHOP_PRODUCT_RELATION)
            ->where('pid', $pid)
            ->where('cid', $cid)
            ->where('basic', '1')
            ->exec()
            ->getRowArray();
        return $row['rid'] ?? '';
    }

    /**
     * 상품 삭제
     * @param $pid
     * @return array
     * @throws \Exception
     */
    public function del($pid)
    {
        $selData = $this->selectProduct($pid);

        //판매금지 및 판매종료 일때만 삭제.
        if ($selData['state'] == '2' || $selData['state'] == '8') {
            $data['is_delete'] = '1';
            $this->updateProduct($pid, $data);

            $this->result = 'success';
        } else {
            $this->result = 'fail';
        }

        return $this->getResult();
    }

    /**
     * 재입고알림 리스트
     * @param int $page
     * @param int $max
     * @param array $where
     * @return array
     * @throws \Exception
     */
    public function getProductStockReminder($page = 1, $max = 5, $where = [])
    {
        $this->qb->startCache();

        if (isset($where['searchType']) && !empty($where['searchType']) && isset($where['searchText']) && !empty($where['searchText'])) {
            $this->qb->like('p.'.$where['searchType'], $where['searchText']);
        }

        if (isset($where['stockQty']) && $where['stockQty'] !== '') {
            $this->qb->where('od.option_stock', $where['stockQty']);
        }

        $this->qb
            ->from(TBL_SHOP_PRODUCT.' AS p')
            ->join(TBL_SHOP_PRODUCT_STOCK_REMINDER.' AS psr', 'p.id=psr.pid')
            ->join(TBL_SHOP_PRODUCT_OPTIONS_DETAIL.' AS od', 'psr.op_id=od.id')
            ->groupBy('psr.pid')
            ->groupby('psr.op_id');

        $this->qb->stopCache();

        $total = $this->qb->getCount();

        $paging = $this->qb->setTotalRows($total)->pagination($page, $max);

        $list = $this->qb
            ->select('COUNT(*) AS cnt')
            ->select('psr.pid')
            ->select('psr.op_id')
            ->select('p.state')
            ->select('p.pname')
            ->select('od.option_div')
            ->select('od.option_stock')
            ->where('status', 'N')
            ->limit($max, ($paging['offset'] ?? 0))
            ->orderBy('psr.regdate', 'DESC')
            ->exec()
            ->getResultArray();

        $this->qb->flushCache();

        //치환 처리
        foreach ($list as $key => $val) {
            //상태
            $val['stateText'] = $this->state[$val['state']];
            //알림요청 회원수
            $val['reminder']  = $val['cnt'];
            //상품이미지
            $val['pimg']      = get_product_images_src($val['pid'], 'b');

            $list[$key] = $val;
        }

        return [
            'total' => $total,
            'list' => $list,
            'paging' => $paging
        ];
    }

    /**
     * 재입고 알림 수정
     * @param array $data
     * @throws \Exception
     */
    public function putProductStockReminder($data = [])
    {
        $rows = $this->qb
            ->select('sr_ix')
            ->select('pcs')
            ->select('pid')
            ->select('user_code')
            ->select('op_id')
            ->from(TBL_SHOP_PRODUCT_STOCK_REMINDER)
            ->whereIn('pid', explode(',', $data['selectPid']))
            ->whereIn('op_id', explode(',', $data['selectOpid']))
            ->exec()
            ->getResultArray();

        /* @var $memberModel \CustomScm\Model\Member\Member */
        $memberModel = $this->import('model.scm.member.member');

        foreach ($rows as $key => $val) {

            $memData     = $memberModel->getMemberInfo($val['user_code']);
            $productData = $this->selectProduct($val['pid']);
            $optionData  = $this->selectOptionDetail($val['pid'], '', $val['op_id']);

            $tpl['고객명']    = $memData['name'];
            $tpl['브랜드명']   = $productData['brand_name'];
            $tpl['상품명']    = $productData['pname'];
            $tpl['스타일-컬러'] = $productData['prodcd'].'-'.$productData['colorcd'];
            $tpl['옵션명']    = $optionData[0]['option_div'];

            sendMessage('stock_new_1', '', $val['pcs'], $tpl);

            //발송완료처리
            $this->qb
                ->set('status', 'Y')
                ->set('reminder_date', fb_now())
                ->update(TBL_SHOP_PRODUCT_STOCK_REMINDER)
                ->where('sr_ix', $val['sr_ix'])
                ->exec();
        }
    }

    /**
     * 글로벌 코드 조회
     * @param $code
     * @return mixed
     * @throws \Exception
     */
    public function getGlobalInfo($code)
    {
        $row = $this->qb
            ->from(TBL_SYSTEM_ISO3166)
            ->where('code', $code)
            ->exec()
            ->getRowArray();

        return $row;
    }

    /**
     * 재입고알림 전송(cron)
     * @throws \Exception
     */
    public function sendStockReminder()
    {
        $list = $this->qb
            ->select('psr.sr_ix')
            ->select('psr.user_code')
            ->select('psr.user_mail')
            ->select('psr.pcs')
            ->select('psr.pid')
            ->select('psr.op_id')
            ->select('psr.status')
            ->select('psr.expiration_date')
            ->select('p.pname')
            ->select('p.state')
            ->select('p.disp')
            ->select('p.is_sell_date')
            ->select('p.sell_priod_sdate')
            ->select('p.sell_priod_edate')
            ->select('od.option_div')
            ->select('od.option_stock')
            ->select('od.option_sell_ing_cnt')
            ->select('od.option_soldout')
            ->from(TBL_SHOP_PRODUCT.' AS p')
            ->join(TBL_SHOP_PRODUCT_STOCK_REMINDER.' AS psr', 'p.id=psr.pid')
            ->join(TBL_SHOP_PRODUCT_OPTIONS_DETAIL.' AS od', 'psr.op_id=od.id')
            ->where('psr.expiration_date >= ', fb_now())
            ->where('psr.status', 'N')
            ->groupBy('psr.pid')
            ->groupby('psr.op_id')
            ->exec()
            ->getResultArray();

        /* @var $memberModel \CustomScm\Model\Member\Member */
        $memberModel = $this->import('model.scm.member.member');

        foreach ($list as $key => $val) {
            $isSend = true;
            if(($val['option_stock'] - $val['option_sell_ing_cnt']) <= 0) {
                //(실재고-판매진행재고)의 값이 0이하인 경우 미전송
                $isSend = false;
            } else if($val['option_soldout'] == 1) {
                //옵션의 soldout이 체크가 되어 있는 경우에만 미전송
                $isSend = false;
            } else if($val['state'] != '1') {
                //상품 판매상태가 판매중이 아닌 경우 미전송
                $isSend = false;
            } else if($val['disp'] == '0'){
                //노출여부
                $isSend = false;
            } else if ($val['is_sell_date'] == '1') {
                //판매기간
                if($val['sell_priod_sdate'] > fb_now() || $val['sell_priod_edate'] < fb_now()){
                    $isSend = false;
                }
            }

            if($isSend === true) {
                $memData     = $memberModel->getMemberInfo($val['user_code']);
                $data['고객명'] = $memData['data']['name'] ?? '';
                $data['product_name'] = $val['pname'];
                $data['옵션명'] = $val['option_div'];
                $data['url'] = MALL_DOMAIN.'/mypage/restockAlarm?schemeChk=1';

                sendMessage('restock_noti', '', $val['pcs'], $data);

                //발송완료처리
                $this->qb
                    ->set('status', 'Y')
                    ->set('reminder_date', fb_now())
                    ->update(TBL_SHOP_PRODUCT_STOCK_REMINDER)
                    ->where('sr_ix', $val['sr_ix'])
                    ->exec();
            }
        }
    }

    /**
     * 재입고 알림 삭제(cron)
     * @throws \Exception
     */
    public function delStockReminde()
    {
        $date = fb_now();
        $delDate = date("Y-m-d H:i:s", strtotime($date.' - 3month'));

        $list = $this->qb
            ->from(TBL_SHOP_PRODUCT_STOCK_REMINDER.' AS psr')
            ->where('psr.status', 'N')
            ->where('psr.regdate <=', $delDate)
            ->exec()
            ->getResultArray();

        $delSrIx = [];
        foreach ($list as $key => $val) {
            $delSrIx[] = $val['sr_ix'];
        }

        $this->qb
            ->delete(TBL_SHOP_PRODUCT_STOCK_REMINDER)
            ->whereIn('sr_ix', $delSrIx)
            ->exec();
    }

    public function getProductState($pid)
    {
        $row = $this->qb
            ->select('state')
            ->from(TBL_SHOP_PRODUCT)
            ->where('id', $pid)
            ->exec()
            ->getRow();

        return ($row->state ?? '');
    }

    /**
     * 통합/개별 배송정책의 개념을 제거하고, 계정의 소속 회사의 배송정책을 가져와 저장시키기 위함.
     * @param $template
     * @return string
     */
    public function getDeliveryTypeOfTemplate($template)
    {
        $templateInfo = $this->qb
            ->select('delivery_div')
            ->from(TBL_SHOP_DELIVERY_TEMPLATE)
            ->where('dt_ix', $template)
            ->exec()
            ->getRow();

        return $templateInfo->delivery_div ?? '';
    }

    /**
     * 릴라켓 제휴사 연동이 된 상품가져오기
     * @param $pid
     * @return array
     */
    public function getProductLinkerSiteMall($pid)
    {
        $rows = $this->qb
            ->select('sspi.*')
            ->select('ssi.site_code')
            ->from(TBL_SELLERTOOL_SITE_PRODUCT_INFO.' as sspi')
            ->join(TBL_SELLERTOOL_SITE_INFO.' as ssi', 'sspi.si_ix = ssi.si_ix', 'left')
            ->where('pid', $pid)
            ->where('api_use_yn', 'Y')
            ->where('api_status', 's')
            ->orderBy('si_ix', 'asc')
            ->exec()
            ->getResultArray();

        return $rows;
    }

    /**
     * 크리마 전일 상품 조회
     * @param string $date
     * @param string $type
     * @return array
     */
    public function getCremaProduct($startDate = '', $endDate = '', $type = 'add')
    {
        if (!empty($startDate) && !empty($endDate) && $type == 'add') {
            $this->qb->betweenDate('sp.regdate', $startDate, $endDate);
        } elseif (!empty($startDate) && !empty($endDate) && $type == 'put') {
            $this->qb->betweenDate('sp.editdate', $startDate, $endDate);
        }

        return $this->qb
            ->select('sp.id')
            ->select('sp.pname')
            ->select('sp.pcode')
            ->select('sp.listprice')
            ->select('sp.sellprice')
            ->select('sp.disp')
            ->select('sp.state')
            ->select("DATE_FORMAT(sp.editdate, '%Y-%m-%dT%TZ') AS editdate")
            ->select("DATE_FORMAT(sp.regdate, '%Y-%m-%dT%TZ') AS regdate")
            ->select('ccd.com_type')
            ->from(TBL_SHOP_PRODUCT. ' AS sp')
            ->join(TBL_COMMON_COMPANY_DETAIL. ' AS ccd', 'sp.admin = ccd.company_id', 'left')
            ->select(
                $this->qb->startSubQuery('total_option_stock')
                    ->selectSum('spod.option_stock')
                    ->from(TBL_SHOP_PRODUCT_OPTIONS_DETAIL.' spod')
                    ->where('sp.id = spod.pid', '', false)
                    ->endSubQuery()
                , false
            )
            ->where('sp.is_delete', '0')
            ->exec()
            ->getResultArray();
    }

    /**
     * 크리마 등록상품 조회
     * @param string $date
     * @param string $type
     * @return array
     */
    public function getCremaProductCategory($pid)
    {
        return $this->qb
            ->select('sci.cname')
            ->select('sci.cid')
            ->select('spr.disp')
            ->from(TBL_SHOP_PRODUCT_RELATION. ' AS spr')
            ->join(TBL_SHOP_CATEGORY_INFO. ' AS sci', 'spr.cid = sci.cid')
            ->where('spr.pid', $pid)
            ->where('spr.basic', 1)
            ->exec()
            ->getResultArray();
    }

    /**
     * 상품 옵션리스트 조회
     * @param $pid
     * @return array
     */
    public function getCremaProductOption($pid)
    {
        $i = 0;
        $data[] = [
            'name' => [],
            'values' => []
        ];
        $result = [];

        $optionInfo = $this->qb
            ->select('spo.option_name')
            ->select('spod.option_div')
            ->from(TBL_SHOP_PRODUCT_OPTIONS. ' AS spo')
            ->join(TBL_SHOP_PRODUCT_OPTIONS_DETAIL. ' AS spod', 'spo.opn_ix = spod.opn_ix', 'left')
            ->where('spo.pid', $pid)
            ->whereNotIn('spo.is_delete', '1')
            ->orderBy('spo.option_name')
            ->exec()
            ->getResultArray();


        foreach ($optionInfo as $key => $value) {
            if ($key != 0 && $data[$i]['name'] != $value['option_name']) $i++;

            if (!isset($data[$i]['name'][$value['option_name']])) {
                $data[$i]['name'] = $value['option_name'];
            }
            if (!isset($data[$i]['values'])) {
                $data[$i]['values'] = [$value['option_div']];
            } else {
                array_push($data[$i]['values'], $value['option_div']);
            }
        }

        foreach ($data as $key => $optionValues) {
            $result[$key]['name'] =  $optionValues['name'];
            foreach ($optionValues['values'] as $optionDetail) {
                $result[$key]['values'][] = $optionDetail;
            }
        }

        return $result;
    }

    public function getPnameById($pid)
    {
        $productData = $this->selectProduct($pid);
        return $productData['pname'];
    }
}