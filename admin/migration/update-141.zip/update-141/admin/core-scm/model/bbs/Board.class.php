<?php

namespace ForbizScm\Model\Bbs;

/**
 * 게시물 관리 모델
 *
 * @author hoksi
 */
class Board extends \ForbizModel
{
    protected $board;
    protected $bm_ix;
    protected $cur_page;
    protected $per_page;

    public function __construct()
    {
        parent::__construct();
    }

    public function setBoard($board)
    {
        $this->board = $board;
        return $this;
    }

    public function setBmix($bm_ix)
    {
        $this->bm_ix = $bm_ix;
        return $this;
    }

    /**
     * 게시판 이름 조회
     * @param string $board_ename
     * @return string
     */
    public function getName($board_ename)
    {
        $row = $this->qb
            ->select('board_name')
            ->from(TBL_BBS_MANAGE_CONFIG)
            ->where('board_ename', $board_ename)
            ->exec()
            ->getRowArray();

        return isset($row['board_name']) ? $row['board_name'] : false;
    }

    /**
     * 게시판 분류 조회
     * @param int $bm_ix
     * @return array
     */
    public function getBbsdiv($bm_ix)
    {
        return $this->qb
                ->select('div_ix')
                ->select('div_name')
                ->from(TBL_BBS_MANAGE_DIV)
                ->where('bm_ix', $bm_ix)
                ->where('div_depth', 1)
                ->where('disp', 1)
                ->orderBy('view_order')
                ->exec()
                ->getResultArray();
    }

    /**
     * 게시판 분류 이름 조회
     * @param int $div_ix
     * @return array
     */
    public function getBbsdivById($div_ix)
    {
        return $this->qb
            ->select('div_name')
            ->from(TBL_BBS_MANAGE_DIV)
            ->where('div_ix', $div_ix)
            ->limit("1")
            ->exec()
            ->getResultArray();
    }

    /**
     * 게시판 서브 분류 조회
     * @param int $bm_ix
     * @param int $parent_div_ix
     * @return array
     */
    public function getSubBbsDiv($bm_ix, $parent_div_ix = false)
    {
        if ($parent_div_ix) {
            $this->qb->where('parent_div_ix', $parent_div_ix);
        } else {
            $this->qb->where('parent_div_ix >', 0);
        }

        $this->result            = 'success';
        $this->data['subBbsDiv'] = $this->qb
            ->select('div_ix')
            ->select('div_name')
            ->from(TBL_BBS_MANAGE_DIV)
            ->where('bm_ix', $bm_ix)
            ->where('div_depth', 2)
            ->where('disp', 1)
            ->orderBy('view_order')
            ->exec()
            ->getResultArray();

        return $this->getResult();
    }

    /**
     * 처리상태 값 조회
     * @param int $bm_ix
     * @return array
     */
    public function getBbsStaus($bm_ix)
    {
        return $this->qb
                ->select('status_ix')
                ->select('status_name')
                ->from(TBL_BBS_MANAGE_STATUS)
                ->where('bm_ix', $bm_ix)
                ->orderBy('view_order')
                ->exec()
                ->getResultArray();
    }

    /**
     * 게시판 설정 값 조회
     * @param string $board_ename
     * @return array
     */
    public function getConfig($board_ename)
    {
        return $this->qb->select('bm_ix')
                ->select('board_name')
                ->select('board_ename')
                ->select('board_max_cnt')
                ->select('board_titlemax_cnt')
                ->select('design_width')
                ->select('design_new_priod')
                ->select('design_hot_limit')
                ->select('board_searchable')
                ->select('board_ip_viewable')
                ->select('board_ip_encoding')
                ->select('board_group')
                ->select('board_list_auth')
                ->select('board_read_auth')
                ->select('board_comment_auth')
                ->select('board_write_auth')
                ->select('view_check_yn')
                ->select('view_no_yn')
                ->select('view_title_yn')
                ->select('view_name_yn')
                ->select('view_file_yn')
                ->select('view_date_yn')
                ->select('view_md_name_yn')
                ->select('view_read_yn')
                ->select('view_viewcnt_yn')
                ->select('view_email_yn')
                ->select('view_sms_yn')
                ->select('image_click')
                ->select('break_autowrite')
                ->select('break_autocomment')
                ->select('board_templete_code')
                ->select('bbs_templet_dir')
                ->select('board_style')
                ->select('board_category_use_yn')
                ->select('board_qna_yn')
                ->select('board_file_yn')
                ->select('board_hidden_yn')
                ->select('board_response_yn')
                ->select('board_comment_yn')
                ->select('board_user_write_auth_yn')
                ->select('board_admin_write_auth_yn')
                ->select('recent_list_display')
                ->select('board_default_yn')
                ->select('board_recom_yn')
                ->select('view_recommend_yn')
                ->select('view_comment_yn')
                ->select('basic_comment_name')
                ->from(TBL_BBS_MANAGE_CONFIG)
                ->where('board_ename', $board_ename)
                ->exec()
                ->getRowArray();
    }

    /**
     * 담당자 조회
     * @return array
     */
    public function getAdmin()
    {
        return $this->qb
                ->decryptSelect('cmd.name')
                ->select('cu.code')
                ->from(TBL_COMMON_USER.' AS cu')
                ->join(TBL_COMMON_MEMBER_DETAIL.' AS cmd', 'cu.code = cmd.code')
                ->where('mem_div', 'D')
                ->where('mem_type', 'A')
                ->orderBy('cmd.name')
                ->exec()
                ->getResultArray();
    }

    /**
     * 게시물 리스트 조회
     * @param int $cur_page
     * @param int $per_page
     * @param array $search
     * @return array
     */
    public function getList($cur_page, $per_page, $search = [])
    {
        // 기본값 설정
        $this->result = 'success';
        $this->data   = [
            'list' => []
            , 'paging' => false
            , 'total' => 0
        ];

        // 게시판 설정 유무 확인
        if (isset($search['bm_ix']) && isset($search['board'])) {
            $this->board    = $search['board'];
            $this->bm_ix    = $search['bm_ix'];
            $this->cur_page = $cur_page;
            $this->per_page = $per_page;

            // 게시물 조회
            if ($search['board_style'] == 'faq') {
                $this->data = $this->getFaqList($search);
            } else {
                $this->data = $this->getBbsList($search);
            }
        }

        return $this->getResult();
    }

    /**
     * 게시물(FAQ포함) 등록/수정
     * @param type $data
     * @param type $board_ename
     * @param type $board_style
     * @return type
     */
    public function putBoardContent($data, $board_ename, $board_style)
    {
        $this->board    = $board_ename;
        // primary key 확인
        $data['bbs_ix'] = (isset($data['bbs_ix']) ? $data['bbs_ix'] : '');

        if ($board_style == 'faq') {
            return $this->putFaqContent($data, $board_ename);
        } else {
            return $this->putBbsContent($data, $board_ename);
        }
    }

    /**
     * 게시물(FAQ포함) 삭제
     * @param string $bbs_ix
     * @param string $board_ename
     * @return array
     */
    public function delBoardContent($bbs_ix, $board_ename)
    {
        $this->board = $board_ename;

        $this->result = 'success';

        $bbs_ix = json_decode($bbs_ix);

        if (!empty($bbs_ix)) {
            $this->deleteBoardContent($bbs_ix);
        }

        return $this->getResult();
    }

    public function putBbsContent($data)
    {
        // 등록/수정 가능 컬럼 확인
        $data = $this->qb->allowedFields($data,
            ['bbs_ix', 'bbs_div', 'sub_bbs_div', 'bbs_subject', 'bbs_name', 'status', 'bbs_hidden', 'bbs_contents', 'is_notice']);

        //공지사항 해제
        if (!isset($data['is_notice'])) {
            $data['is_notice'] = 'N';
        }

        if ($data['bbs_ix']) {
            // 수정
            $this->updateBoardContent($data);
        } else {
            // 등록

            // 컨텐츠 타입 HTML로 고정
            $data['is_html'] = 'Y';
            // 등록 IP
            $data['ip_addr'] = $this->input->ip_address();
            // 등록자
            $data['mem_ix']  = $this->adminInfo->charger_ix;

            $this->insertBoardContent($data);
        }

        return $this->getResult();
    }

    /**
     * FAQ 등록/수정
     * @param array $data
     * @return array
     */
    public function putFaqContent($data)
    {
        // 등록/수정 가능 컬럼 확인
        $data = $this->qb->allowedFields($data, ['bbs_ix', 'bbs_div', 'sub_bbs_div', 'bbs_q', 'bbs_a', 'faq_sort', 'is_best']);

        // 컨텐츠 타입 HTML로 고정
        $data['bbs_contents_type'] = '1';

        if ($data['bbs_ix']) {
            // 수정
            $this->updateBoardContent($data);
        } else {
            // 등록
            $this->insertBoardContent($data);
        }

        return $this->getResult();
    }

    /**
     * 게시물(FAQ포함) update (table)
     * @param array $data
     * @return boolean
     */
    public function updateBoardContent($data)
    {
        $boardTbl       = 'bbs_'.$this->board;
        $this->result = 'success';

        if(isset($data['mem_ix'])) {
            unset($data['mem_ix']);
        }

        $this->qb
                ->set($data)
                ->where('bbs_ix', $data['bbs_ix'])
                ->update($boardTbl)
                ->exec();

        // 파일 업로드
        $this->uploadFile($data['bbs_ix']);

        return $data['bbs_ix'];
    }

    /**
     * 게시물(FAQ포함) insert (table)
     * @param array $data
     * @return int
     */
    public function insertBoardContent($data)
    {
        $boardTbl       = 'bbs_'.$this->board;
        $this->result = 'success';

        // 등록일
        $data['regdate'] = date('Y-m-d H:i:s');

        $bbsIndex = $this->qb
            ->set($data)
            ->insert($boardTbl)
            ->exec();

        // 파일 업로드
        $this->uploadFile($bbsIndex);

        return $bbsIndex;
    }

    protected function uploadFile($bbsIndex)
    {
        if (!empty($_FILES)) {
            $boardTbl       = 'bbs_'.$this->board;
            
            /* @var $uploadModel \CustomScm\Model\Util\Upload */
            $uploadModel = $this->import('model.scm.util.upload');

            $uploadFile = [];
            foreach (array_keys($_FILES) as $fldName) {
                $upRow = $uploadModel->bbsUpload($fldName, $this->board, $bbsIndex);
                if (isset($upRow['uploadId'])) {
                    $uploadFile[$fldName] = $upRow['uploadId'];
                }
            }

            if (!empty($uploadFile)) {
                $this->qb
                    ->set($uploadFile)
                    ->update($boardTbl)
                    ->where('bbs_ix', $bbsIndex)
                    ->exec();
            }
        }

        return true;
    }

    /**
     * 게시물(FAQ포함) delete (table)
     * @param array $bbs_ix
     * @return boolean
     */
    public function deleteBoardContent($bbs_ix)
    {
        $boardTbl     = 'bbs_'.$this->board;
        $this->result = 'success';

        return $this->qb
                ->whereIn('bbs_ix', $bbs_ix)
                ->delete($boardTbl)
                ->exec();
    }

    public function getCmtList($board_ename, $bbs_ix)
    {
        $this->board = $board_ename;

        $this->result          = 'success';
        $this->data['cmtList'] = $this->selectCmtList($bbs_ix);
        $this->data['resTpl']  = $this->getResponseTpl($board_ename);

        return $this->getResult();
    }

    public function addCmt($board_ename, $data)
    {
        $this->board = $board_ename;

        // 원본글 상태 변경
        $boardData = [
            'bbs_ix' => $data['bbs_ix']
            , 'status' => $data['status']
        ];
        $this->updateBoardContent($boardData);

        $data = $this->qb->allowedFields($data, ['bbs_ix', 'cmt_name', 'cmt_contents', 'bbs_div', 'cmt_pass', 'cmt_email']);

        // 등록자 ix
        $data['mem_ix'] = $this->adminInfo->charger_ix;

        $this->data['bbs_ix'] = $data['bbs_ix'];
        $this->data['status'] = $boardData['status'];

        $this->insertCmt($data);

        //1:1 문의 게시판 메일 보내기
        if ($this->board == 'qna' && $this->data['status'] == '5') {
            $bbsData                 = $this->getBbs($this->data['bbs_ix']);
            $bbsData['oid']          = $bbsData['bbs_etc4'];
            $bbsData['cmt_contents'] = $data['cmt_contents'];
            unset($data['bbs_etc4']);
            $bbsDivData = $this->getBbsdivById($bbsData['bbs_div']);
            $bbsData['bbs_div'] = $bbsDivData[0]['div_name'];

            sendMessage('qna_reply', $bbsData['bbs_email'], $bbsData['bbs_etc1'], $bbsData);
        }

        return $this->getResult();
    }

    public function delCmt($board_ename, $data)
    {
        $this->board = $board_ename;

        $data = $this->qb->allowedFields($data, ['cmt_ix']);
        $this->deleteCmt($data);

        return $this->getResult();
    }

    public function deleteCmt($data)
    {
        $cmtTbl       = 'bbs_'.$this->board.'_comment';
        $this->result = 'success';

        return $this->qb
                ->where('cmt_ix', $data['cmt_ix'])
                ->delete($cmtTbl)
                ->exec();
    }

    public function insertCmt($data)
    {
        $cmtTbl       = 'bbs_'.$this->board.'_comment';
        $this->result = 'success';

        return $this->qb
                ->set('regdate', date('Y-m-d H:i:s'))
                ->set($data)
                ->insert($cmtTbl)
                ->exec();
    }

    public function getResponseTpl($board_ename)
    {
        $templet_div = ['', $board_ename];

        $row = $this->qb
            ->select('templet_text')
            ->select('templet_name')
            ->from(TBL_BBS_RESPONSE_TEMPLET)
            ->whereIn('templet_div', $templet_div)
            ->where('disp', 1)
            ->exec()
            ->getResultArray();

        foreach ($row as $key => $val) {
            $row[$key]['templet_text'] = nl2br($val['templet_text']);
        }

        return $row;
    }

    public function selectCmtList($bbs_ix)
    {
        $cmtTbl = 'bbs_'.$this->board.'_comment';

        return $this->qb
                ->from($cmtTbl)
                ->where('bbs_ix', $bbs_ix)
                ->orderBy('regdate', 'desc')
                ->exec()
                ->getResultArray();
    }

    public function getDownInfo($id)
    {
        $result = $this->qb
            ->select("org_file_name")
            ->select("full_path")
            ->select("url")
            ->from(TBL_SYSTEM_UPLOAD_FILE)
            ->where("system_upload_file_id", $id)
            ->limit("1")
            ->exec()
            ->getRowArray();

        return $result;
    }
    ///////////////////////// Protected ///////////////////

    /**
     * 게시판 검색 설정
     * @param array $search
     * @return \CI_Qb
     */
    protected function setSearch($search)
    {
        if (!empty($search)) {
            // 검색어
            if (!empty($search['search_word'])) {
                if ($search['type'] == 'esn') {
                    $this->qb->like('bbs_name', $search['search_word']);
                } else if ($search['type'] == 'ess') {
                    if ($search['board_style'] == 'bbs') {
                        $this->qb->like('bbs_subject', $search['search_word']);
                    } else {
                        $this->qb->like('bbs_q', $search['search_word']);
                    }
                } else if ($search['type'] == 'esc') {
                    if ($search['board_style'] == 'bbs') {
                        $this->qb->like('bbs_contents', $search['search_word']);
                    } else {
                        $this->qb->like('bbs_a', $search['search_word']);
                    }
                } else {
                    if ($search['board_style'] == 'bbs') {
                        $this->qb->groupStart()
                            ->orLike('bbs_name', $search['search_word'])
                            ->orLike('bbs_subject', $search['search_word'])
                            ->orLike('bbs_contents', $search['search_word'])
                            ->groupEnd();
                    } else {
                        $this->qb->like('bbs_a', $search['search_word']);
                    }
                }
            }

            // 담당자
            if (!empty($search['md_ix'])) {
                $this->qb->whereIn(
                    'bbs_ix',
                    $this->qb->startSubQuery()
                        ->select('bc.bbs_ix')
                        ->from('bbs_'.$this->board.'_comment'.' AS bc')
                        ->where('bc.mem_ix', $search['md_ix'])
                        ->endSubQuery()
                    , false
                );
            }

            // 처리상태
            if (!empty($search['status'])) {
                $this->qb->whereIn('status', $search['status']);
            }

            // 작성일자
            if (!empty($search['sdate']) || !empty($search['edate'])) {
                $startDate = $search['sdate'] ? $search['sdate'] : $search['edate'];
                $endDate   = $search['edate'] ? $search['edate'] : $startDate;

                $this->qb->betweenDate('bbs.regdate', $startDate, $endDate);
            }

            // 대분류
            if (!empty($search['bbs_div'])) {
                $this->qb->where('bbs_div', $search['bbs_div']);
            }

            // 중분류
            if (!empty($search['sub_bbs_div'])) {
                $this->qb->where('sub_bbs_div', $search['sub_bbs_div']);
            }

            if(!empty($search['is_member'])) {
                if($search['is_member'] == 'M') {
                    $this->qb->where('mem_ix !=', '');
                } else if($search['is_member'] == 'G') {
                    $this->qb->where('mem_ix', '');
                }
            }
        }

        return $this->qb;
    }

    /**
     * 게시판 컬럼 설정
     * @return \CI_Qb
     */
    protected function setBbsSelect()
    {
        return $this->qb
                ->select('bbs.bbs_ix')
                ->select('bbs.bbs_div')
                ->select('bbs.sub_bbs_div')
                ->select('bbs.mem_ix')
                ->select('bbs.bbs_name')
                ->select('bbs.bbs_email')
                ->select('bbs.bbs_hit')
                ->select('bbs.bbs_file_1')
                ->select('bbs.is_notice')
                ->select('bbs.regdate')
                ->select('bbs.bbs_hidden')
                ->select('bbs.bbs_contents')
                ->select('bbs.bbs_file_1')
                ->select('bbs.bbs_file_2')
                ->select('bbs.bbs_file_3')
                ->select('bbs.status')
                ->select('bbs.bbs_etc4')
                ->select("IF(LENGTH(SUBSTRING(bbs.bbs_subject, ( 40 + 1 - bbs.bbs_ix_level ), 1)) > 0, CONCAT(SUBSTRING(bbs.bbs_subject, 1, 40 - bbs.bbs_ix_level), '...'), bbs.bbs_subject) AS cut_bbs_subject",
                    false)
                ->select('bbs_subject')
                ->select("CASE WHEN bbs.regdate > DATE_SUB('" .fb_now() . "', INTERVAL 24 hour) THEN 1 ELSE 0 END  AS new", false);
    }

    /**
     * 공지 게시물 조회
     * @return array
     */
    protected function getBbsNotice()
    {
        $bbsTable = 'bbs_'.$this->board;

        $rows = $this->setBbsSelect()
            ->select("'' AS div_name")
            ->select("'' AS charger_ix")
            ->select("'' AS complete_date")
            ->from($bbsTable.' AS bbs')
            ->join(TBL_BBS_MANAGE_DIV.' AS bdiv', 'bdiv.div_ix = bbs.bbs_div', 'left')
            ->where('bbs.is_notice', 'Y')
            ->orderBy('bbs_ix_step')
            ->orderBy('regdate', 'desc')
            ->exec()
            ->getResultArray();

        return (empty($rows) ? [] : $rows);
    }

    public function getBbs($bbsIx)
    {
        $bbsTable = 'bbs_'.$this->board;
        return $this->qb
                ->select('bbs.bbs_div')
                ->select('bbs.bbs_hit')
                ->select('bbs.bbs_subject')
                ->select('bbs.bbs_email')
                ->select('bbs.bbs_name')
                ->select('bbs.bbs_contents')
                ->select('bbs.bbs_etc1')
                ->select('bbs.bbs_etc4')
                ->select('bbs.regdate')
                ->select('bbs.bbs_file_1')
                ->select('bbs.bbs_file_2')
                ->select('bbs.bbs_file_3')
                ->from($bbsTable.' AS bbs')
                ->where('bbs.bbs_ix', $bbsIx)
                ->exec()
                ->getRowArray();
    }

    /**
     * 일반 게시판 조회
     * @param array $search
     * @return array
     */
    protected function getBbsList($search = [])
    {
        $bbsTable     = 'bbs_'.$this->board;
        $commentTable = 'bbs_'.$this->board.'_comment';
        // 쿼리 캐시 시작
        $this->qb->startCache();
        // 테이블 및 조인 설정
        $this->qb
            ->from($bbsTable.' AS bbs')
            ->join(TBL_BBS_MANAGE_DIV.' AS bdiv', "bdiv.div_ix = bbs.bbs_div AND bdiv.bm_ix = {$this->bm_ix}", 'left')
            ->join(TBL_BBS_MANAGE_DIV.' AS bsdiv', "bsdiv.div_ix = bbs.sub_bbs_div AND bsdiv.bm_ix = {$this->bm_ix}", 'left')
            ->where('bbs.bbs_ix >', 0)
            ->where('bbs.is_notice !=', 'Y');

        // 검색조건 설정
        $this->setSearch($search);
        // 쿼리 캐시 끝
        $this->qb->stopCache();

        // total 산출
        $total = $this->qb->getCount();

        // 페이징 설정
        $paging = $this->qb
            ->setTotalRows($total)
            ->pagination($this->cur_page, $this->per_page);

        // limit 값 산출
        $limit  = $this->per_page;
        $offset = ($paging['offset'] ?? 0);

        // 게시물 조회
        $rows = $this->setBbsSelect()
            ->select("CASE WHEN bsdiv.div_name != '' THEN CONCAT(bdiv.div_name, ' > ', bsdiv.div_name)  ELSE bdiv.div_name END AS div_name", false)
            ->select($this->qb->startSubQuery('charger_ix')
                ->select('mem_ix')
                ->from($commentTable.' AS cmt')
                ->where('cmt.bbs_ix = bbs.bbs_ix', '', false)
                ->orderBy('cmt_ix')
                ->limit(1)
                ->endSubQuery(), false)
            ->select($this->qb->startSubQuery('complete_date')
                ->select('regdate')
                ->from($commentTable.' AS cmt')
                ->where('cmt.bbs_ix = bbs.bbs_ix', '', false)
                ->orderBy('cmt_ix', 'desc')
                ->limit(1)
                ->endSubQuery(), false)
            ->orderBy('bbs.regdate', 'desc')
            ->orderBy('bsdiv.div_ix', 'asc')
            ->limit($limit, $offset)
            ->exec()
            ->getResultArray();

        $this->qb->flushCache();

        // 공지 사항 조회
        $notice  = $this->getBbsNotice();
        $bbsList = [];

        foreach (array_merge($notice, $rows) as $row) {
            if (is_html($row['bbs_contents']) === false) {
                $row['bbs_contents'] = nl2br($row['bbs_contents']);

                $row['notNotice'] = true;
                if($row['is_notice'] == 'Y') {
                    $row['notNotice'] = false;
                }
            }
            $bbsList[] = $row;
        }

        return [
            'list' => $bbsList
            , 'paging' => $paging
            , 'total' => $total
        ];
    }

    /**
     * FAQ 게시판 조회
     * @param array $search
     * @return array
     */
    protected function getFaqList($search = [])
    {
        $bbsTable = 'bbs_'.$this->board;
        // 쿼리 캐시 시작
        $this->qb->startCache();
        // 테이블 및 조인 설정
        $this->qb
            ->from($bbsTable.' AS bbs')
            ->join(TBL_BBS_MANAGE_DIV.' AS bdiv', "bdiv.div_ix = bbs.bbs_div AND bdiv.bm_ix = {$this->bm_ix}", 'left')
            ->where('bbs.bbs_ix >', 0);

        // 검색조건 설정
        $this->setSearch($search);
        // 쿼리 캐시 끝
        $this->qb->stopCache();

        // total 산출
        $total = $this->qb->getCount();

        // 페이징 설정
        $paging = $this->qb
            ->setTotalRows($total)
            ->pagination($this->cur_page, $this->per_page);

        // limit 값 산출
        $limit  = $this->per_page;
        $offset = ($paging['offset'] ?? 0);

        // 게시물 조회
        $rows = $this->qb
            ->select('bbs.bbs_ix')
            ->select('bbs.bbs_div')
            ->select('bbs.sub_bbs_div')
            ->select('bbs.regdate')
            ->select('bdiv.div_name')
            ->select('bbs_q')
            ->select('bbs_a')
            ->select('is_best')
            ->select("CONCAT('?mode=read&board={$this->board}&bbs_ix=', bbs_ix, '&page=', '1') AS link", false)
            ->orderBy('bbs.regdate', 'desc')
            ->limit($limit, $offset)
            ->exec()
            ->getResultArray();

        $this->qb->flushCache();

        if(!empty($rows)) {
            foreach($rows as $idx => $row) {
                $rows[$idx]['is_best_txt'] = ($row['is_best'] == 1 ? '베스트' : '일반');
            }
        }

        return [
            'list' => $rows
            , 'paging' => $paging
            , 'total' => $total
        ];
    }

    /**
     * 상품문의 입력
     * @param array $res
     * @return boolean
     */
    public function insertSiteQna($res)
    {

        $row = $this->getSiteQna($res->cs_id);

        if(empty($row->sclr_ix)){
            $insertId = $this->qb->insert(TBL_SHOP_PRODUCT_QNA,
                [
                    'bbs_div' => $res->csType ?? '',
                    'pid' => $this->getMappingProduct($res->pid),
                    'pname' => $res->pname,
                    'company_id' => $res->company_id,
                    'ucode' => '',
                    'bbs_subject' => $res->cs_subject,
                    'bbs_name' => $res->cs_name,
                    'bbs_id' => '',
                    'bbs_hidden' => 0,
                    'bbs_email' => $res->cs_email,
                    'bbs_contents' => $res->cs_contents,
                    'site_code' => $res->site_code,
                    'site_id' => $res->site_id,
                    'regdate' => date('Y-m-d H:i:s')
                ])->exec();

            /* @var $siteModel \CustomScm\Model\Sellertool\Site */
            $siteModel = $this->import('model.scm.sellertool.site');

            $siteInfo = $siteModel->getSiteInfoByCode($res->site_code);

            //Mapping
            $this->qb->insert(TBL_SELLERTOOL_CUSTOMER_LINKED_RELATION,
                [
                    'si_ix' => $siteInfo['si_ix'],
                    'scs_id' => $res->cs_id,
                    'bbs_ix' => $insertId,
                    'regdate' => date('Y-m-d H:i:s')
                ])->exec();
        }
        return true;
    }

    public function getSiteQna($cs_id)
    {
        return $this->qb
            ->select()
            ->from(TBL_SELLERTOOL_CUSTOMER_LINKED_RELATION)
            ->where('scs_id', $cs_id)
            ->exec()
            ->getRow();
    }

    public function getMappingSiteQna($id)
    {
        return $this->qb
            ->select()
            ->from(TBL_SELLERTOOL_CUSTOMER_LINKED_RELATION)
            ->where('bbs_ix', $id)
            ->exec()
            ->getRow();
    }

    public function getMappingProduct($pid)
    {
        $pinfo = $this->qb
            ->select('shop_value')
            ->from(TBL_SELLERTOOL_RESPONSE)
            ->where('sellertool_value', $pid)
            ->where('shop_key', 'pid')
            ->exec()
            ->getRow();

        return $pinfo->shop_value;
    }
}