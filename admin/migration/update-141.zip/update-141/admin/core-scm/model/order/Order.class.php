<?php

namespace ForbizScm\Model\Order;

/**
 * 주문 관련 모델
 *
 * @author hoksi
 */
class Order extends \ForbizModel
{
    protected $siteCode = 'relaket';
    /**
     * 결제방법
     * @var type
     */
    protected $paymentMethod = [
        ORDER_METHOD_CARD => '카드',
        ORDER_METHOD_VBANK => '가상계좌',
        ORDER_METHOD_ASCROW => '에스크로',
        ORDER_METHOD_ICHE => '실시간계좌이체',
        ORDER_METHOD_PHONE => '휴대폰결제',
        ORDER_METHOD_BANK => '무통장',
        ORDER_METHOD_RESERVE => '마일리지',
        ORDER_METHOD_NPAY => '네이버페이',
        ORDER_METHOD_NPAY_ORDER => '네이버페이(주문형)',
        ORDER_METHOD_PAYCO => '페이코',
        ORDER_METHOD_EXIMBAY => '엑심베이',
        ORDER_METHOD_TOSS => '토스',
        ORDER_METHOD_KAKAOPAY => '카카오페이',
        ORDER_METHOD_NOPAY => '무료결제',
        ORDER_METHOD_INAPP_PAYCO => 'PG(페이코)',
        ORDER_METHOD_INAPP_KAKAOPAY => 'PG(카카오)',
        ORDER_METHOD_INAPP_SKPAY => 'PG(SK페이)',
        ORDER_METHOD_INAPP_SSPAY => 'PG(삼성페이)',
        ORDER_METHOD_INAPP_SSGPAY => 'PG(쓱페이)',
        ORDER_METHOD_INAPP_TOSS => 'PG(토스)',
        ORDER_METHOD_INAPP_LPAY => 'PG(엘페이)',
        ORDER_METHOD_INAPP_NAVERPAY => 'PG(네이버페이)',
        ORDER_METHOD_INAPP_KPAY => 'PG(케이페이)',
        ORDER_METHOD_INAPP_KBANKPAY => 'PG(케이뱅크페이)',
        ORDER_METHOD_ESCROW_ICHE => '실시간계좌이체',
        ORDER_METHOD_ESCROW_VBANK => '가상계좌',
    ];

    /**
     * 결제형태
     * @var type
     */
    protected $paymentAgentType = [
        ORDER_PAYMENT_AGENT_TYPE_WEB => 'PC',
        ORDER_PAYMENT_AGENT_TYPE_MOBILE => 'MOBILE'
    ];

    /**
     * 반품상품 발송 방법
     * @var array
     */
    protected $returnSendType = [
        '2' => '지정택배방문요청'
        , '1' => '직접발송'
    ];

    /**
     * 관리 company_id
     * @var type
     */
    protected $manageCompanyId;

    /**
     * 관리 level
     * @var type
     */
    protected $manageLevel;

    /**
     * oid
     * @var type
     */
    protected $oid;
    
    protected $nomalOrderStatus;

    public function __construct()
    {
        parent::__construct();

        //셀러일 경우
        if ($this->adminInfo->admin_level < 9) {
            $this->setManageCompanyId($this->adminInfo->company_id);
        }
        $this->manageLevel = $this->adminInfo->admin_level;

        $useNaverPg = \ForbizConfig::getMallConfig('add_sattle_module_naverpay_pg') ?? 'N';
        $usePaycoPg = \ForbizConfig::getMallConfig('add_sattle_module_payco') ?? 'N';
//        $useTossPg = \ForbizConfig::getMallConfig('add_sattle_module_toss') ?? 'N';

        if($useNaverPg == 'Y') {
            $this->paymentMethod[ORDER_METHOD_NPAY] = '네이버페이';
        }
        if($usePaycoPg == 'Y') {
            $this->paymentMethod[ORDER_METHOD_PAYCO] = '페이코';
        }
        /*if($useTossPg == 'Y') {
            $this->paymentMethod[ORDER_METHOD_TOSS] = '토스';
        }*/

        /* @var $statusModel \CustomScm\Model\Order\Status */
        $statusModel = $this->import('model.scm.order.status');
        $this->nomalOrderStatus = array_keys($statusModel->getStatus(false, 'delivery'));
        array_push($this->nomalOrderStatus,ORDER_STATUS_BUY_FINALIZED);
    }

    /**
     * set manageCompanyId
     * @param type $manageCompanyId
     */
    public function setManageCompanyId($manageCompanyId)
    {
        $this->manageCompanyId = $manageCompanyId;
    }

    /**
     * get 결제방법 (method,method -> 방법,방법)
     * @param type $string
     * @return type
     */
    public function getMultiPaymentMethodByString($string)
    {
        $list = explode(",", $string);
        foreach ($list as $key => $value) {
            $list[$key] = $this->getPaymentMethod($value);
        }
        return implode(',', $list);
    }

    /**
     * get 결제방법
     * @param type $method
     * @return type
     */
    public function getPaymentMethod($method = false)
    {
        if ($method === false) {
            return $this->paymentMethod;
        } else {
            return $this->paymentMethod[$method] ?? $method;
        }
    }

    /**
     * get 결제형태
     * @param type $paymentAgentType
     * @return type
     */
    public function getPaymentAgentType($paymentAgentType = false)
    {
        if ($paymentAgentType === false) {
            return $this->paymentAgentType;
        } else {
            return $this->paymentAgentType[$paymentAgentType] ?? $paymentAgentType;
        }
    }

    /**
     * get 반품상품 발송 방법
     * @param bool $returnSendType
     * @return array|bool|mixed
     */
    public function getReturnSendType($returnSendType = false)
    {
        if ($returnSendType === false) {
            return $this->returnSendType;
        } else {
            return $this->returnSendType[$returnSendType] ?? $returnSendType;
        }
    }

    /**
     * set Oid
     * @param type $oid
     */
    public function setOid($oid)
    {
        $this->oid = $oid;
    }

    /**
     * 권한 체크
     * @return boolean
     */
    public function checkSellerAuth()
    {
        if (empty($this->oid)) {
            return false;
        } else if ($this->manageLevel < 9) {
            $total = $this->qb
                ->from(TBL_SHOP_ORDER_DETAIL . ' od')
                ->where('od.oid', $this->oid)
                ->where('od.company_id', $this->manageCompanyId)
                ->getCount();
            return ($total > 0 ? true : false);
        } else {
            return true;
        }
    }

    /**
     * get 주문 정보
     * @return type
     */
    public function getOrder()
    {
        $row = $this->qb
            ->select('o.oid')
            ->select('o.order_date')
            ->select('o.user_code')
            ->select('o.bname')
            ->select('o.mem_group')
            ->select('o.buserid')
            ->select('o.bmobile')
            ->select('o.bmail')
            ->select('o.total_price')
            ->select('o.product_price')
            ->select('o.delivery_price')
            ->select('o.status')
            ->select($this->qb->startSubQuery()
                    ->select('co_oid')
                    ->from(TBL_SHOP_ORDER_DETAIL . ' AS od')
                    ->where('od.oid', 'o.oid', false)
                    ->limit(1)
                    ->endSubQuery() . ' AS co_oid', false)
            ->select($this->qb->startSubQuery()
                    ->select('ic_date')
                    ->from(TBL_SHOP_ORDER_DETAIL . ' AS od')
                    ->where('od.oid', 'o.oid', false)
                    ->limit(1)
                    ->endSubQuery() . ' AS ic_date', false)
            ->select($this->qb->startSubQuery()
                    ->select('order_from')
                    ->from(TBL_SHOP_ORDER_DETAIL . ' AS od')
                    ->where('od.oid', 'o.oid', false)
                    ->limit(1)
                    ->endSubQuery() . ' AS order_from', false)
            ->select('IFNULL(' . $this->qb
                    ->startSubQuery()
                    ->select('sum(dc_price)', false)
                    ->from(TBL_SHOP_ORDER_DETAIL_DISCOUNT . ' AS oddc')
                    ->join(TBL_SHOP_ORDER_DETAIL." as od",'oddc.od_ix = od.od_ix')
                    ->whereIn('od.status',$this->nomalOrderStatus)
                    ->where('oddc.oid', 'o.oid', false)
                    ->whereIn('oddc.dc_type', ['GP', 'MG', 'CP', 'SP'])
                    ->endSubQuery()
                . ', 0) AS total_dc_price')
            ->select('IFNULL(' . $this->qb
                    ->startSubQuery()
                    ->select('sum(dc_price)',false)
                    ->from(TBL_SHOP_ORDER_DETAIL_DISCOUNT . ' AS oddc')
                    ->join(TBL_SHOP_ORDER_DETAIL." as od",'oddc.od_ix = od.od_ix')
                    ->whereIn('od.status',$this->nomalOrderStatus)
                    ->where('oddc.oid', 'o.oid', false)
                    ->where('oddc.dc_type', 'GP') // 기획할인
                    ->limit(1)
                    ->endSubQuery()
                . ', 0) AS plan_dc')
            ->select('IFNULL(' . $this->qb
                    ->startSubQuery()
                    ->select('sum(dc_price)',false)
                    ->from(TBL_SHOP_ORDER_DETAIL_DISCOUNT . ' AS oddc')
                    ->join(TBL_SHOP_ORDER_DETAIL." as od",'oddc.od_ix = od.od_ix')
                    ->whereIn('od.status',$this->nomalOrderStatus)
                    ->where('oddc.oid', 'o.oid', false)
                    ->where('oddc.dc_type', 'MG') // 회원할인
                    ->limit(1)
                    ->endSubQuery()
                . ', 0) AS user_dc')

            ->select('IFNULL(' . $this->qb
                    ->startSubQuery()
                    ->select('sum(dc_price)',false)
                    ->from(TBL_SHOP_ORDER_DETAIL_DISCOUNT . ' AS oddc')
                    ->join(TBL_SHOP_ORDER_DETAIL." as od",'oddc.od_ix = od.od_ix')
                    ->whereIn('od.status',$this->nomalOrderStatus)
                    ->where('oddc.oid', 'o.oid', false)
                    ->where('oddc.dc_type', 'SP') // 특별할인
                    ->limit(1)
                    ->endSubQuery()
                . ', 0) AS special_dc')
            
            ->select('IFNULL(' . $this->qb
                    ->startSubQuery()
                    ->select('sum(dc_price)',false)
                    ->from(TBL_SHOP_ORDER_DETAIL_DISCOUNT . ' AS oddc')
                    ->join(TBL_SHOP_ORDER_DETAIL." as od",'oddc.od_ix = od.od_ix')
                    ->whereIn('od.status',$this->nomalOrderStatus)
                    ->where('oddc.oid', 'o.oid', false)
                    ->where('oddc.dc_type', 'CP') // 쿠폰할인
                    ->limit(1)
                    ->endSubQuery()
                . ', 0) AS coupon_dc')


            ->select($this->qb->startSubQuery()
                    ->select('method')
                    ->from(TBL_SHOP_ORDER_PAYMENT . ' AS op')
                    ->where('op.oid', 'o.oid', false)
                    ->limit(1)
                    ->endSubQuery() . ' AS method', false)
            ->select('IFNULL(' . $this->qb
                    ->startSubQuery()
                    ->select('sum(payment_price)',false)
                    ->from(TBL_SHOP_ORDER_PAYMENT . ' AS op')
                    ->where('op.oid', 'o.oid', false)
                    ->where('op.method', ORDER_METHOD_RESERVE)
                    ->where('op.pay_type', 'G')
                    ->where('op.pay_status', 'IC')
                    ->limit(1)
                    ->endSubQuery()
                . ', 0) AS useMileage')
            ->select('IFNULL(' . $this->qb
                    ->startSubQuery()
                    ->select('tid',false)
                    ->from(TBL_SHOP_ORDER_PAYMENT . ' AS op')
                    ->where('op.oid', 'o.oid', false)
                    ->limit(1)
                    ->endSubQuery()
                . ', 0) AS tid')
            ->select('IFNULL(' . $this->qb
                    ->startSubQuery()
                    ->select('method',false)
                    ->from(TBL_SHOP_ORDER_PAYMENT . ' AS op')
                    ->where('op.oid', 'o.oid', false)
                    ->limit(1)
                    ->endSubQuery()
                . ', 0) AS method')
            ->from(TBL_SHOP_ORDER . ' o')
            ->where('o.oid', $this->oid)
            ->exec()
            ->getRowArray();

        if ($this->manageLevel == 9) {
            /* @var $siteModel \CustomScm\Model\Sellertool\Site */
            $siteModel = $this->import('model.scm.sellertool.site');
            $row['orderFromText'] = $siteModel->getNameBySiteCode($row['order_from']);
        } else {
            $row['bname'] = convert_text_masking($row['bname']);
        }
        return $row;
    }

    /**
     * 주문 정보 수정 (주문자 정보 수정)
     * @param type $data
     */
    public function putOrder($data)
    {
        $this->qb
            ->set('bmail', $data['bmail'])
            ->set('bmobile', $data['bmobile'])
            ->update(TBL_SHOP_ORDER)
            ->where('oid', $this->oid)
            ->exec();
    }

    /**
     * 주문의 할인정보 조회
     * @return array
     * @throws \Exception
     */
    public function getOrderDiscount()
    {
        $row = $this->qb
            ->select('oddc.dc_type')
            ->select('oddc.dc_title')
            ->select('oddc.dc_rate')
            ->select('oddc.dc_price')
            ->select('oddc.dc_msg')
            ->select($this->qb->startSubQuery()
                    ->select('group_name')
                    ->from(TBL_SHOP_DISCOUNT_PRODUCT_GROUP . ' AS dpg')
                    ->where('dpg.dc_ix', 'oddc.dc_ix', false)
                    ->limit(1)
                    ->endSubQuery() . ' AS group_name', false)
            ->from(TBL_SHOP_ORDER_DETAIL_DISCOUNT . ' AS oddc')
            ->join(TBL_SHOP_ORDER_DETAIL." as od",'oddc.od_ix = od.od_ix')
            ->whereIn('od.status',$this->nomalOrderStatus)
            ->where('oddc.oid', $this->oid)
            ->whereIn('oddc.dc_type', ['GP', 'MG', 'CP', 'SP'])

            ->exec()
            ->getResultArray();

        $res = [];
        if (!empty($row)) {
            foreach ($row as $key => $val) {
                $name = '';
                if ($val['dc_type'] == 'GP') {
                    $name = $val['group_name'];
                } else if ($val['dc_type'] == 'CP') {
                    $name = $val['dc_msg'];
                } else if ($val['dc_type'] == 'MG') {
                    $name = '';
                } else if ($val['dc_type'] == 'SP') {
                    $name = $val['group_name'];
                }

                if (isset($res[$val['dc_type']])) {
                    $res[$val['dc_type']]['dc_price'] += $val['dc_price'];
                    $res[$val['dc_type']]['name'] .= empty($res[$val['dc_type']]['name']) ? $name : " | ".$name;
                }else{
                    $res[$val['dc_type']] = $val;
                    $res[$val['dc_type']]['name'] = $name;
                }

            }
        }

        return $res;
    }

    /**
     * 기본 주문 상품 리스트
     * @param array $where
     * @return type
     */
    public function getNormalProductList($where = [])
    {
        $where['status'] = $this->nomalOrderStatus;

        return $this->getProductList(function () {
            $this->qb
                ->select('odd.odd_ix')
                ->select('odd.rname')
                ->select('odd.rmobile')
                ->select('odd.rtel')
                ->select('odd.zip')
                ->select('odd.addr1')
                ->select('odd.addr2')
                ->select('odd.msg_type')
                ->select('odd.msg')
                ->select('od.oid')
                ->select('od.od_ix')
                ->select('od.status')
                ->select('od.company_name')
                ->select('od.company_id')
                ->select('od.pid')
                ->select('od.pname')
                ->select('od.option_text')
                ->select('od.brand_name')
                ->select('od.pcode')
                ->select('od.gid')
                ->select('od.dcprice')
                ->select('od.pcnt')
                ->select('od.ptprice')
                ->select('od.psprice')
                ->select('od.pt_dcprice')
                ->select('od.ode_ix')
                ->select('od.quick')
                ->select('od.invoice_no')
                ->select('od.di_date')
                ->select('od.dr_date')
                ->select('od.dc_date')
                ->select('if(od.msgbyproduct="",CONCAT(odd.msg, " ", odd.door_msg),od.msgbyproduct) as odd_msg', false)
                ->select('ode.delivery_dcprice')
                ->select('od.reserve')
                ->select('od.use_reserve')
                ->select('IFNULL(' . $this->qb
                        ->startSubQuery()
                        ->select('dc_ix')
                        ->from(TBL_SHOP_ORDER_DETAIL_DISCOUNT . ' AS oddc')
                        ->where('oddc.oid','od.oid',false)
                        ->where('oddc.od_ix','od.od_ix',false)
                        ->where('oddc.dc_type', 'CP')
                        ->limit(1)
                        ->endSubQuery()
                    . ', "") AS dc_ix')
                ->select('IFNULL(' . $this->qb
                        ->startSubQuery()
                        ->select('dc_price')
                        ->from(TBL_SHOP_ORDER_DETAIL_DISCOUNT . ' AS oddc')
                        ->where('oddc.oid','od.oid',false)
                        ->where('oddc.od_ix','od.od_ix',false)
                        ->where('oddc.dc_type', 'CP')
                        ->limit(1)
                        ->endSubQuery()
                    . ', 0) AS coupon_dc')
                ->select('IFNULL(' . $this->qb
                        ->startSubQuery()
                        ->select('dc_price')
                        ->from(TBL_SHOP_ORDER_DETAIL_DISCOUNT . ' AS oddc')
                        ->where('oddc.oid','od.oid',false)
                        ->where('oddc.od_ix','od.od_ix',false)
                        ->where('oddc.dc_type', 'GP')
                        ->limit(1)
                        ->endSubQuery()
                    . ', 0) AS plan_dc')
                ->select('IFNULL(' . $this->qb
                        ->startSubQuery()
                        ->select('dc_price')
                        ->from(TBL_SHOP_ORDER_DETAIL_DISCOUNT . ' AS oddc')
                        ->where('oddc.oid','od.oid',false)
                        ->where('oddc.od_ix','od.od_ix',false)
                        ->where('oddc.dc_type', 'SP')
                        ->limit(1)
                        ->endSubQuery()
                    . ', 0) AS special_dc')
                ->select('IFNULL(' . $this->qb
                        ->startSubQuery()
                        ->select('dc_price')
                        ->from(TBL_SHOP_ORDER_DETAIL_DISCOUNT . ' AS oddc')
                        ->where('oddc.oid','od.oid',false)
                        ->where('oddc.od_ix','od.od_ix',false)
                        ->where('oddc.dc_type', 'MG')
                        ->limit(1)
                        ->endSubQuery()
                    . ', 0) AS user_dc')
            ;
        }, $where);
    }

    /**
     * 클레임 주문 상품 정보 리스트
     * @param array $where
     * @return string
     */
    public function getClaimProductList($where = [])
    {
        /* @var $statusModel \CustomScm\Model\Order\Status */
        $statusModel = $this->import('model.scm.order.status');

        $status = [];

        $status = array_merge($status, array_keys($statusModel->getStatus(false, 'cancel')));
        $status = array_merge($status, array_keys($statusModel->getStatus(false, 'return')));
        $status = array_merge($status, array_keys($statusModel->getStatus(false, 'exchange')));

        $where['status'] = $status;

        return $this->getProductList(function () {
            $this->qb
                ->select('odd.odd_ix')
                ->select('odd.rname')
                ->select('odd.rmobile')
                ->select('odd.zip')
                ->select('odd.addr1')
                ->select('odd.addr2')
                ->select('od.od_ix')
                ->select('od.status')
                ->select('od.company_name')
                ->select('od.pid')
                ->select('od.pname')
                ->select('od.option_text')
                ->select('od.brand_name')
                ->select('od.pcode')
                ->select('od.gid')
                ->select('od.dcprice')
                ->select('od.pcnt')
                ->select('od.ptprice')
                ->select('od.psprice')
                ->select('od.pt_dcprice')
                ->select('od.use_reserve')
                ->select('od.ode_ix')
                ->select('od.quick')
                ->select('od.invoice_no')
                ->select('od.surtax_yorn')
                ->select('od.di_date')
                ->select('od.dr_date')
                ->select('od.dc_date')
                ->select('od.fc_date')
                ->select('od.refund_status')
                ->select('ode.delivery_dcprice')
                ->select('od.status as claimReason')
                ->select('(CASE SUBSTR(od.status,1,1) WHEN "E" THEN ea_date WHEN "R" THEN ra_date ELSE ca_date END) as claimApplyDate')
                ->select('od.claim_group')
                ->select('IFNULL(ocd.delivery_price, 0) as claim_delivery_price')
                ->select('if(od.msgbyproduct="",CONCAT(odd.msg, " ", odd.door_msg),od.msgbyproduct) as odd_msg', false)->select('od.reserve')
                ->select('odd.send_type AS return_send_type')
                ->select('odd.quick as turnQuickTextClaim')
                ->select('odd.invoice_no as turnInvoiceNo')
                ->select('IFNULL(' . $this->qb
                        ->startSubQuery()
                        ->select('dc_ix')
                        ->from(TBL_SHOP_ORDER_DETAIL_DISCOUNT . ' AS oddc')
                        ->where('oddc.oid','od.oid',false)
                        ->where('oddc.od_ix','od.od_ix',false)
                        ->where('oddc.dc_type', 'CP')
                        ->limit(1)
                        ->endSubQuery()
                    . ', "") AS dc_ix')
                ->select('IFNULL(' . $this->qb
                        ->startSubQuery()
                        ->select('dc_price')
                        ->from(TBL_SHOP_ORDER_DETAIL_DISCOUNT . ' AS oddc')
                        ->where('oddc.oid','od.oid',false)
                        ->where('oddc.od_ix','od.od_ix',false)
                        ->where('oddc.dc_type', 'CP')
                        ->limit(1)
                        ->endSubQuery()
                    . ', 0) AS coupon_dc')
                ->select('IFNULL(' . $this->qb
                        ->startSubQuery()
                        ->select('dc_price')
                        ->from(TBL_SHOP_ORDER_DETAIL_DISCOUNT . ' AS oddc')
                        ->where('oddc.oid','od.oid',false)
                        ->where('oddc.od_ix','od.od_ix',false)
                        ->where('oddc.dc_type', 'GP')
                        ->limit(1)
                        ->endSubQuery()
                    . ', 0) AS plan_dc')
                ->select('IFNULL(' . $this->qb
                        ->startSubQuery()
                        ->select('dc_price')
                        ->from(TBL_SHOP_ORDER_DETAIL_DISCOUNT . ' AS oddc')
                        ->where('oddc.oid','od.oid',false)
                        ->where('oddc.od_ix','od.od_ix',false)
                        ->where('oddc.dc_type', 'SP')
                        ->limit(1)
                        ->endSubQuery()
                    . ', 0) AS special_dc')
                ->select('IFNULL(' . $this->qb
                        ->startSubQuery()
                        ->select('dc_price')
                        ->from(TBL_SHOP_ORDER_DETAIL_DISCOUNT . ' AS oddc')
                        ->where('oddc.oid','od.oid',false)
                        ->where('oddc.od_ix','od.od_ix',false)
                        ->where('oddc.dc_type', 'MG')
                        ->limit(1)
                        ->endSubQuery()
                    . ', 0) AS user_dc')
                ->join(TBL_SHOP_ORDER_CLAIM_DELIVERY . ' AS ocd', 'ocd.oid=od.oid AND ocd.claim_group=od.claim_group', 'left');
        }, $where);
    }

    /**
     * get 주문 상품 조회
     * @param type $setQbFunction
     * @param type $where
     * @return string
     */
    protected function getProductList($setQbFunction, $where = [])
    {
        if (isset($where['od_ix']) && !empty($where['od_ix'])) {
            $this->qb->whereIn('od.od_ix', $where['od_ix']);
        }

        if (isset($where['status']) && !empty($where['status'])) {
            $this->qb->whereIn('od.status', $where['status']);
        }

        if (isset($where['refund_status']) && !empty($where['refund_status'])) {
            $this->qb->whereIn('od.refund_status', $where['refund_status']);
        }

        if (!empty($this->manageCompanyId)) {
            $this->qb->where('od.company_id', $this->manageCompanyId);
        }

        $this->qb
            ->from(TBL_SHOP_ORDER_DETAIL . ' AS od')
            ->join(TBL_SHOP_ORDER_DETAIL_DELIVERYINFO . ' AS odd', 'od.odd_ix = odd.odd_ix', 'left')
            ->join(TBL_SHOP_ORDER_DELIVERY . ' AS ode', 'od.ode_ix = ode.ode_ix', 'left')
            ->where('od.oid', $this->oid)
            ->whereNotIn('od.status', [ORDER_STATUS_SETTLE_READY]);

        $setQbFunction();

        $list = $this->qb
            ->orderBy('od.ode_ix')
            ->exec()
            ->getResultArray();

        //치환 처리
        /* @var $statusModel \CustomScm\Model\Order\Status */
        $statusModel = $this->import('model.scm.order.status');

        foreach ($list as $key => $val) {
            //판매상태
            if (isset($val['status'])) {
                $val['statusText'] = $statusModel->getStatus($val['status']);
            }
            //환불상태
            if (isset($val['refund_status'])) {
                $val['refundStatusText'] = $statusModel->getStatus($val['refund_status'],'return');
            }
            //상품이미지
            if (isset($val['pid'])) {
                $val['thum_image_src'] = get_product_images_src($val['pid'], 'c');
                $val['image_src'] = get_product_images_src($val['pid'], 'm');
            }
            //택배업체
            if (isset($val['quick'])) {
                $val['quickText'] = \ForbizConfig::getDeliveryCompanyInfo($val['quick'], 'name');
            }
            //수취인명 마스킹처리
            if (isset($val['rname']) && $this->manageLevel < 9) {
                $val['rname'] = convert_text_masking($val['rname']);
            }
            //클레임 사유
            if (isset($val['claimReason'])) {
                $claimReason = $statusModel->getOrderCalimReason($this->oid, $val['od_ix'], substr($val['claimReason'], 0, 1));
                $val['claimReason'] = '[' . $claimReason['type_text'] . ']' . $claimReason['detail_text'];
            }
            if (isset($val['return_send_type'])) {
                $val['returnSendTypeText'] = $this->getReturnSendType($val['return_send_type']);
            }

            if (isset($val['turnQuickTextClaim'])) {
                $val['turnQuickTextClaim'] = \ForbizConfig::getDeliveryCompanyInfo($val['turnQuickTextClaim'], 'name');
            }
            if (isset($val['turnInvoiceNo'])) {
                $val['turnInvoiceNo'] = $val['turnInvoiceNo'];
            }
            if (isset($val['dc_ix'])) {
                $val['coupon_info'] = $this->getCouponInfo($val['dc_ix']);
            }

            $list[$key] = $val;
        }

        return $list;
    }

    /**
     * 결제 방법별 요약정보
     * @return type
     */
    public function getPaymentSummary()
    {
        $rows = $this->getPaymentList();
        $list = [];
        foreach ($rows as $row) {
            if ($row['pay_status'] == ORDER_STATUS_INCOM_COMPLETE) {
                if (empty($list[$row['method']])) {
                    $data['escrow_use'] = $row['escrow_use'];
                    $data['method'] = $row['method'];
                    $data['methodText'] = $this->getMultiPaymentMethodByString($row['method']);
                    $data['payment_price'] = 0;
                    $data['payment_tax_price'] = 0;
                    $data['payment_tax_free_price'] = 0;
                    $data['refund_price'] = 0;
                    $data['refund_tax_price'] = 0;
                    $data['refund_tax_free_price'] = 0;
                    $data['remain_price'] = 0;
                    $data['remain_tax_price'] = 0;
                    $data['remain_tax_free_price'] = 0;
                    if (in_array($row['method'], [ORDER_METHOD_BANK, ORDER_METHOD_VBANK, ORDER_METHOD_ESCROW_VBANK])) {
                        if (!empty($row['bank_account_num'])) {
                            $data['etc'] = $row['bank'] . ' / ' . $row['bank_account_num'] . ' / ' . $row['bank_input_date'];
                        } else {
                            $data['etc'] = '';
                        }
                    } else {
                        $data['etc'] = $row['memo'];
                    }
                } else {
                    $data = $list[$row['method']];
                }

                //환불
                if ($row['pay_type'] == 'F') {
                    $data['refund_price'] += $row['payment_price'];
                    $data['refund_tax_price'] += $row['tax_price'];
                    $data['refund_tax_free_price'] += $row['tax_free_price'];
                    $data['remain_price'] -= $row['payment_price'];
                    $data['remain_tax_price'] -= $row['tax_price'];
                    $data['remain_tax_free_price'] -= $row['tax_free_price'];
                } else {
                    $data['payment_price'] += $row['payment_price'];
                    $data['payment_tax_price'] += $row['tax_price'];
                    $data['payment_tax_free_price'] += $row['tax_free_price'];
                    $data['remain_price'] += $row['payment_price'];
                    $data['remain_tax_price'] += $row['tax_price'];
                    $data['remain_tax_free_price'] += $row['tax_free_price'];
                }

                $list[$row['method']] = $data;
            }
        }

        return $list;
    }

    /**
     * get 결제 방법
     * @return type
     */
    public function getPaymentList()
    {
        return $this->qb
            ->select('method')
            ->select('escrow_use')
            ->select('payment_price')
            ->select('tax_price')
            ->select('tax_free_price')
            ->select('pay_type')
            ->select('pay_status')
            ->select('bank')
            ->select('bank_account_num')
            ->select('bank_input_date')
            ->select('memo')
            ->from(TBL_SHOP_ORDER_PAYMENT)
            ->where('oid', $this->oid)
            ->exec()
            ->getResultArray();
    }

    /**
     * get 배송지 정보
     * @param type $oddIx
     * @return type
     */
    public function getDeliveryInfo($oddIx)
    {
        return $this->qb
            ->select('odd_ix')
            ->select('rname')
            ->select('rmobile')
            ->select('zip')
            ->select('addr1')
            ->select('addr2')
            ->from(TBL_SHOP_ORDER_DETAIL_DELIVERYINFO)
            ->where('odd_ix', $oddIx)
            ->exec()
            ->getRowArray();
    }

    /**
     * 배송지 정보 변경
     * @param type $oddIx
     * @param type $data
     */
    public function putDeliveryInfo($oddIx, $data)
    {
        $this->qb
            ->set('rmobile', $data['rmobile'])
            ->set('zip', $data['zip'])
            ->set('addr1', $data['addr1'])
            ->set('addr2', $data['addr2'])
            ->update(TBL_SHOP_ORDER_DETAIL_DELIVERYINFO)
            ->where('odd_ix', $oddIx)
            ->exec();
    }

    /**
     * 주문 금액 등록
     * @param type $oid
     * @param type $paymentStatus
     * @param type $priceDiv
     * @param type $data
     */
    public function insertOrderPrice($oid, $paymentStatus, $priceDiv, $data)
    {
        $expect_price = ($data['expect_price'] ?? 0);
        $payment_price = ($data['payment_price'] ?? 0);
        $reserve = ($data['reserve'] ?? 0);

        $this->qb
            ->set('oid', $oid)
            ->set('od_ix', ($data['od_ix'] ?? ''))
            ->set('payment_status', $paymentStatus)
            ->set('price_div', $priceDiv)
            ->set('expect_price', $expect_price)
            ->set('payment_price', $payment_price)
            ->set('reserve', $reserve)
            ->set('claim_group', ($data['claim_group'] ?? 0))
            ->set('msg', ($data['msg'] ?? ''))
            ->set('charger', ($data['charger'] ?? ''))
            ->set('charger_ix', ($data['charger_ix'] ?? ''))
            ->set('regdate', fb_now())
            ->insert(TBL_SHOP_ORDER_PRICE_HISTORY)
            ->exec();

        $row = $this->qb
            ->select('op_ix')
            ->from(TBL_SHOP_ORDER_PRICE)
            ->where('oid', $oid)
            ->where('payment_status', $paymentStatus)
            ->exec()
            ->getRow();

        if ($priceDiv == 'D') {
            $expect_delivery_price = $expect_price;
            $delivery_price = $payment_price;
            $expect_product_price = 0;
            $product_price = 0;
        } else {
            $expect_product_price = $expect_price;
            $product_price = $payment_price;
            $expect_delivery_price = 0;
            $delivery_price = 0;
        }
        if ($this->qb->total > 0) {
            $this->qb
                ->set('expect_delivery_price', 'expect_delivery_price + ' . $expect_delivery_price, false)
                ->set('delivery_price', 'delivery_price + ' . $delivery_price, false)
                ->set('expect_product_price', 'expect_product_price + ' . $expect_product_price, false)
                ->set('product_price', 'product_price +' . $product_price, false)
                ->set('reserve', 'reserve +' . $reserve, false)
                ->update(TBL_SHOP_ORDER_PRICE)
                ->where('op_ix', $row->op_ix)
                ->exec();
        } else {
            $this->qb
                ->set('oid', $oid)
                ->set('payment_status', $paymentStatus)
                ->set('expect_delivery_price', $expect_delivery_price)
                ->set('delivery_price', $delivery_price)
                ->set('expect_product_price', $expect_product_price)
                ->set('product_price', $product_price)
                ->set('reserve', $reserve)
                ->insert(TBL_SHOP_ORDER_PRICE)
                ->exec();
        }
    }

    /**
     * 주문 결제 정보 등록
     * @param type $oid
     * @param type $payType
     * @param type $payStatus
     * @param type $method
     * @param type $paymentPrice
     * @param type $data
     */
    public function insertOrderPayment($oid, $payType, $payStatus, $method, $paymentPrice, $data)
    {
        if (isset($data['settle_module'])) {
            $this->qb->set('settle_module', $data['settle_module']);
        }
        if (isset($data['tid'])) {
            $this->qb->set('tid', $data['tid']);
        }
        if (isset($data['ic_date'])) {
            $this->qb->set('ic_date', $data['ic_date']);
        }
        $this->qb
            ->set('oid', $oid)
            ->set('pay_type', $payType)
            ->set('pay_status', $payStatus)
            ->set('method', $method)
            ->set('tax_price', ($data['tax_price'] ?? 0))
            ->set('tax_free_price', ($data['tax_free_price'] ?? 0))
            ->set('payment_price', $paymentPrice)
            ->set('regdate', date('Y-m-d H:i:s'))
            ->insert(TBL_SHOP_ORDER_PAYMENT)
            ->exec();
    }

    /**
     * insert order delivery info
     * @param $oid
     * @param $orderType
     * @param $data
     * @return bool|\NunaResult
     */
    public function insertOrderDeliveryInfo($oid, $orderType, $data)
    {
        return $this->qb->insert(TBL_SHOP_ORDER_DETAIL_DELIVERYINFO, [
            'oid' => $oid,
            'od_ix' => $data['od_ix'] ?? '',
            'order_type' => $orderType,
            'rname' => $data['rname'],
            'rmobile' => $data['rmobile'],
            'zip' => $data['zip'],
            'addr1' => $data['addr1'],
            'addr2' => $data['addr2'],
            'msg_type' => ($data['msg_type'] ?? 'D'),
            'msg' => ($data['msg'] ?? ''),
            'quick' => ($data['quick'] ?? ''),
            'invoice_no' => ($data['invoice_no'] ?? ''),
            'send_yn' => ($data['send_yn'] ?? ''),
            'send_type' => ($data['send_type'] ?? ''),
            'delivery_pay_type' => ($data['delivery_pay_type'] ?? '1'),
            'regdate' => date('Y-m-d H:i:s')
        ])->exec();
    }

    /**
     * 주문 분리
     * @param int $odIx
     * @param int $separateCnt
     * @param boolean $copyMode
     * @return type
     */
    public function orderSeparate($odIx, $separateCnt, $copyMode = false)
    {
        $datas = $this->qb
            ->select('*')
            ->from(TBL_SHOP_ORDER_DETAIL)
            ->where('od_ix', $odIx)
            ->exec()
            ->getRow(0, 'array');

        $oid = $datas["oid"];
        $originCnt = $datas["pcnt"];
        $status = $datas["status"];
        $pid = $datas["pid"];

        if ($originCnt > $separateCnt || $copyMode) {
            $changeCnt = $originCnt - $separateCnt;
            $od_colum = $this->qb
                ->exec('desc ' . TBL_SHOP_ORDER_DETAIL)
                ->getResultArray();

            $colum_str = [];
            foreach ($od_colum as $colum) {// 주문컬럼 추가 및 삭제시
                if ($colum["Extra"] != "auto_increment") {
                    $colum_str[] = $colum["Field"];
                } else {
                    $colum_str[] = "''";
                }
            }
            //shop_order_detail 생성
            $newOdIx = $this->qb
                ->exec("INSERT INTO " . TBL_SHOP_ORDER_DETAIL . " SELECT " . implode(',', $colum_str) . " FROM " . TBL_SHOP_ORDER_DETAIL . " where od_ix='" . $odIx . "'");

            //dc_type 할인타입(MC:복수구매,MG:그룹,C:카테고리,GP:기획,SP:특별,CP:쿠폰,SCP:중복쿠폰,M:모바일,E:에누리,DCP:배송쿠폰,DE:배송비에누리)
            $this->qb->exec("INSERT INTO " . TBL_SHOP_ORDER_DETAIL_DISCOUNT 
                . " SELECT oid,'" . $newOdIx . "',ode_ix,dc_type,dc_title,dc_rate,dc_price,dc_rate_admin,dc_price_admin,dc_rate_seller,dc_price_seller,dc_criterion,dc_msg,dc_ix,'" . fb_now() ."' FROM "
                . TBL_SHOP_ORDER_DETAIL_DISCOUNT
                . " WHERE od_ix = '" . $odIx . "' and dc_type not in ('DCP','SCP')");


            if (!$copyMode) {
                //분리생성된 신규 주문 할인가 업데이트
                $this->qb
                    ->exec("UPDATE " . TBL_SHOP_ORDER_DETAIL_DISCOUNT . " SET
						dc_price = (FLOOR((dc_price_admin / '" . $originCnt . "')*'" . $separateCnt . "') + FLOOR((dc_price_seller / '" . $originCnt . "')*'" . $separateCnt . "')),
						dc_price_admin = FLOOR((dc_price_admin / '" . $originCnt . "')*'" . $separateCnt . "'),
						dc_price_seller = FLOOR((dc_price_seller / '" . $originCnt . "')*'" . $separateCnt . "')
                        where od_ix='" . $newOdIx . "' and dc_type not in ('DCP', 'SCP')");

                //기존 주문 할인가 업데이트 (반올림 이슈로 기존 금액에서 분리생성된 주문 금액을 차감함)
                $this->qb
                    ->exec("UPDATE
                            " . TBL_SHOP_ORDER_DETAIL_DISCOUNT . " d
                        INNER JOIN
                            " . TBL_SHOP_ORDER_DETAIL_DISCOUNT . " d2
                        ON
                            (d.od_ix='" . $odIx . "' and d2.od_ix='" . $newOdIx . "' and d.dc_type=d2.dc_type)
                        SET
                            d.dc_price = d.dc_price - d2.dc_price,
                            d.dc_price_admin = d.dc_price_admin - d2.dc_price_admin,
                            d.dc_price_seller = d.dc_price_seller - d2.dc_price_seller
                        WHERE
                            d.od_ix='" . $odIx . "'");

                //shop_order_detail pcnt , ptprice , pt_dcprice 업데이트처리하기!
                $this->qb
                    ->exec("UPDATE " . TBL_SHOP_ORDER_DETAIL . " SET
						pcnt='" . $changeCnt . "',
						ptprice=((psprice+option_price)*" . $changeCnt . "),
						pt_dcprice=(
                            ((psprice+option_price)*" . $changeCnt . ")-ifnull((select sum(dc_price) as sum_dc_price from " . TBL_SHOP_ORDER_DETAIL_DISCOUNT . " where od_ix='" . $odIx . "' ),0)
                        ),
                        reserve=if(reserve > 0, reserve - FLOOR((reserve/{$originCnt})*{$separateCnt}), 0),
                        use_reserve=if(use_reserve > 0, use_reserve - FLOOR((use_reserve/{$originCnt})*{$separateCnt}), 0)
					where od_ix='" . $odIx . "'");

                $this->qb
                    ->exec("UPDATE " . TBL_SHOP_ORDER_DETAIL . " SET
						pcnt='" . $separateCnt . "',
						ptprice=((psprice+option_price)*" . $separateCnt . "),
						pt_dcprice=(
                            ((psprice+option_price)*" . $separateCnt . ")-ifnull((select sum(dc_price) as sum_dc_price from " . TBL_SHOP_ORDER_DETAIL_DISCOUNT . " where od_ix='" . $newOdIx . "' ),0)
                        ),
                        reserve = if(reserve > 0, if(reserve > 0, FLOOR((reserve/{$originCnt})*{$separateCnt}), 0), 0),
                        use_reserve = if(use_reserve > 0,  if(use_reserve > 0, FLOOR((use_reserve/{$originCnt})*{$separateCnt}), 0), 0)
					where od_ix='" . $newOdIx . "'");

                /* @var $statusModel \CustomScm\Model\Order\Status */
                $statusModel = $this->import('model.scm.order.status');
                $statusModel->insertOrderHistory($odIx, $status, "주문분할[수량:" . $originCnt . "->" . $changeCnt . "(" . $separateCnt . ")]");
            }
        }

        return $newOdIx;
    }

    /**
     * get 주문 상품 조회
     * @param type $setQbFunction
     * @param type $where
     * @return string
     */
    public function getProductPaymentMethodList($odIxs)
    {
        if (isset($odIxs['od_ix']) && !empty($odIxs['od_ix'])) {
            $this->qb->whereIn('od.od_ix', $odIxs['od_ix']);
        }

        $list = $this->qb
            ->distinct()
            ->select('method')
            ->from(TBL_SHOP_ORDER_DETAIL . ' AS od')
            ->join(TBL_SHOP_ORDER_PAYMENT . ' AS op', 'od.oid = op.oid', 'left')
            ->where('od.oid', $this->oid)
            ->whereNotIn('od.status', [ORDER_STATUS_SETTLE_READY])
            ->orderBy('od.ode_ix')
            ->orderBy('od.product_type')
            ->exec()
            ->getResultArray();

        $return = array_column($list, 'method');

        return $return;
    }

    /**
     * 주문시 최초 배송지 조회
     * @param $oid
     * @return mixed
     * @throws \Exception
     */
    public function getBasicOrderAddress($oid)
    {
        return $this->qb
            ->from(TBL_SHOP_ORDER_DETAIL_DELIVERYINFO)
            ->where('oid',$oid)
            ->orderBy('odd_ix')
            ->limit(1)
            ->exec()->getRowArray();
    }

    /**
     * 배송지 조회
     * @param $oddIx
     * @return mixed
     * @throws \Exception
     */
    public function getOrderDetailDeliveryInfo($oddIx)
    {
        $deliveryInfo = $this->qb
            ->from(TBL_SHOP_ORDER_DETAIL_DELIVERYINFO)
            ->where('odd_ix', $oddIx)
            ->exec()
            ->getRowArray();

        return $deliveryInfo;
    }

	/**
     * 쿠폰정보 조회
     * @param $dcIx
     * @return string
     * @throws \Exception
     */
    public function getCouponInfo($dcIx)
    {
        $couponInfo = $this->qb
            ->select('scp.publish_name')
            ->select('cp.cupon_div')
            ->from(TBL_SHOP_CUPON.' AS cp')
            ->join(TBL_SHOP_CUPON_PUBLISH.' AS scp', 'cp.cupon_ix = scp.cupon_ix')
            ->join(TBL_SHOP_CUPON_REGIST.' AS scr', 'scr.publish_ix = scp.publish_ix')
            ->where('regist_ix', $dcIx)
            ->exec()
            ->getRowArray();

        $return = '';

        if (isset($couponInfo)) {
            switch ($couponInfo['cupon_div']) {
                case 'G' :
                    $couponInfo['cupon_div'] = '상품쿠폰';
                    break;
                case 'C' :
                    $couponInfo['cupon_div'] = '장바구니쿠폰';
                    break;
            }
            $return = $couponInfo['cupon_div'] . ' / ' . $couponInfo['publish_name'];
        } elseif (!empty($dcIx)) {
            $return = '삭제된 쿠폰입니다.';
        }

        return $return ?? '';
    }    

    /**
     * 제휴사 주문 상태변경을 위해 정보가져오기
     * @param $od_ix
     * @param $status
     * @return mixed
     */
    public function getOrderDetail($od_ix, $status)
    {
        $orderInfo = $this->qb
            ->select('status_message as msg')
            ->select('reason_code')
            ->select('od.od_ix')
            ->select('od.oid')
            ->select('od.status')
            ->select('od.invoice_no')
            ->select('od.quick')
            ->select('od.co_oid')
            ->select('od.co_od_ix')
            ->from(TBL_SHOP_ORDER_DETAIL.' as od')
            ->join(TBL_SHOP_ORDER_DETAIL_DELIVERYINFO.' as odd', 'od.odd_ix = odd.odd_ix')
            ->join(TBL_SHOP_ORDER_STATUS.' as os', 'od.od_ix = os.od_ix and os.status = "'.$status.'"')
            ->where('od.od_ix', $od_ix)
            ->exec()
            ->getRow();

        //택배사 코드 맵핑정보로 교체
        if(!empty($orderInfo->quick)) {
            $orderInfo->quick = $this->checkMappingDelivery($orderInfo->quick);
        }

        return $orderInfo;
    }

    /**
     * 매핑 제휴사 택배 데이터 조회
     * @param $quick
     * @return mixed
     */
    public function checkMappingDelivery($quick)
    {
        $mapQuickInfo = $this->qb
            ->select('srd_ix')
            ->from(TBL_SELLERTOOL_DELIVERY_LINKED_RELATION)
            ->where('d_ix', $quick)
            ->exec()
            ->getRow();
        
        return $mapQuickInfo->srd_ix;
    }

    /**
     * 제휴사 주문상태 처리 프로세스
     * @param $odIx
     * @param $status
     */
    public function updateSiteOrder($odIx, $status)
    {
        if($status == ORDER_STATUS_DELIVERY_READY || $status == ORDER_STATUS_DELIVERY_ING) {
            $res = $this->putSiteOrderStatus($odIx, $status);
        }else if(
            $status == ORDER_STATUS_CANCEL_COMPLETE
            || $status == ORDER_STATUS_RETURN_ING
            || $status == ORDER_STATUS_RETURN_DENY
            || $status == ORDER_STATUS_RETURN_ACCEPT
            || $status == ORDER_STATUS_RETURN_COMPLETE
            || $status == ORDER_STATUS_EXCHANGE_ING
            || $status == ORDER_STATUS_EXCHANGE_DENY
            || $status == ORDER_STATUS_EXCHANGE_ACCEPT
            || $status == ORDER_STATUS_EXCHANGE_COMPLETE
        ){
            $res = $this->putSiteClaimOrderStatus($odIx, $status);
        }

        return $res;
    }

    /**
     * 제휴사 주문상태 업데이트
     * @param $odIx
     * @param $status
     * @return mixed
     */
    public function putSiteOrderStatus($odIx, $status)
    {
        $api = \ApiForbiz::getHandler($this->siteCode);
        return $api->setSiteOrderStatus($odIx, $status);
    }

    /**
     * 제휴사 클레임 주문상태 업데이트
     * @param $odIx
     * @param $status
     * @return mixed
     */
    public function putSiteClaimOrderStatus($odIx, $status)
    {
        $api = \ApiForbiz::getHandler($this->siteCode);
        return $api->putClaimOrderProccess($odIx, $status);
    }

    /**
     * 제휴사 취소, 교환, 반품 요청 od_ix, oid 값 가져오기
     * @param $co_od_ix
     * @return mixed
     * @throws \Exception
     */
    public function getOdIx($co_od_ix) {
        $od_ix = $this->qb
            ->select('od_ix')
            ->select('oid')
            ->from(TBL_SHOP_ORDER_DETAIL)
            ->where('co_od_ix', $co_od_ix)
            ->exec()
            ->getRowArray();

        return $od_ix;
    }

    /**
     * 제휴사 주문 상태변경전 정보가져오기
     * @param $od_ix
     * @return mixed
     */
    public function getOrderFromDetail($od_ix)
    {
        $orderFromInfo = $this->qb
            ->select('*')
            ->from(TBL_SHOP_ORDER_DETAIL)
            ->where('od_ix', $od_ix)
            ->exec()
            ->getRowArray();

        return $orderFromInfo;
    }

    /**
     * 주문번호로 주문 정보가져오기
     * @param $oid
     * @return mixed
     */
    public function getOrderFromDetailByOid($oid)
    {
        $orderFromInfo = $this->qb
            ->select('*')
            ->from(TBL_SHOP_ORDER_DETAIL)
            ->where('oid', $oid)
            ->exec()
            ->getRow();

        return $orderFromInfo;
    }

    /**
     * 네이버페이 주문번호조회
     * @param $odIx
     * @return false|mixed
     * @throws \Exception
     */
    public function getOrderDetailNpay($odIx)
    {
        // odIx를 이용해 co_od_ix & payment(method) 조회
        return $this->qb
            ->select('sod.status')
            ->select('sod.co_od_ix')
            ->from(TBL_SHOP_ORDER_DETAIL . ' AS sod')
            ->join(TBL_SHOP_ORDER_PAYMENT . ' AS sop', 'sod.oid = sop.oid')
            ->where('sod.od_ix', $odIx)
            ->where('sop.method', ORDER_METHOD_NPAY_ORDER)
            ->exec()
            ->getRowArray();
    }

    public function getOrderInfo($od_ix)
    {
        $orderInfo = $this->qb
            ->select('op.method')
            ->select('op.oid')
            ->select('op.tid')
            ->from(TBL_SHOP_ORDER_DETAIL.' as od')
            ->join(TBL_SHOP_ORDER_PAYMENT.' as op', 'od.oid = op.oid')
            ->where('od.od_ix', $od_ix)
            ->limit(1)
            ->exec()
            ->getRowArray();

        return $orderInfo;
    }

    /**
     * get TID
     * @param $method
     * @return string
     */
    public function getNpayTid()
    {
        $row = $this->qb
            ->select('tid')
            ->from(TBL_SHOP_ORDER_PAYMENT)
            ->where('oid', $this->oid)
            ->where('method', ORDER_METHOD_NPAY)
            ->orderBy('tid', 'DESC')
            ->limit(1)
            ->exec()
            ->getRowArray();

        return $row['tid'] ?? '';
    }

    public function getNpayCashAmount()
    {
        $tid = $this->getNpayTid();

        if (!empty($tid)) {
            $module = new \PgForbizNaverpayPg('W');

            $response = $module->getCashAmount([
                'paymentIds' => [$tid],
            ]);;

            if (!empty($response)) {
                return [
                    'result' => $response->code,
                    'msg' => $response->message,
                    'data' => $response->body,
                ];
            }

            return [
                'result' => 'fail',
                'msg' => "시스템 장애입니다.",
            ];
        } else {
            return [
                'result' => 'fail'
                ,'msg' => 'tid 존재하지 않습니다.'
            ];
        }
    }
}
