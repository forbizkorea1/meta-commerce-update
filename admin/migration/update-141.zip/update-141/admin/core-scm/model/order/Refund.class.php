<?php

namespace ForbizScm\Model\Order;

/**
 * 주문 환불관련 모델
 *
 * @author hoksi
 */
class Refund extends \ForbizModel
{

    /**
     * oid
     * @var type
     */
    protected $oid;

    /**
     * 환불 상태
     * @var type
     */
    protected $status = [
        ORDER_STATUS_REFUND_APPLY => '환불요청',
        ORDER_STATUS_REFUND_COMPLETE => '환불완료'
    ];

    public function __construct()
    {
        parent::__construct();
    }

    /**
     * set Oid
     * @param type $oid
     */
    public function setOid($oid)
    {
        $this->oid = $oid;
        return $this;
    }

    /**
     * get 환불 상태
     * @param type $status
     * @return type
     */
    public function getStatus($status = false)
    {
        if ($status === false) {
            return $this->status;
        } else {
            return $this->status[$status] ?? $status;
        }
    }

    /**
     * get 환불 계좌 정보
     * @return array
     */
    public function getRefundAccount()
    {
        $row = $this->qb
            ->decryptSelect('refund_bank_name')
            ->decryptSelect('refund_bank')
            ->from(TBL_SHOP_ORDER)
            ->where('oid', $this->oid)
            ->exec()
            ->getRowArray();

        $tmp = explode('|', $row['refund_bank']);
        $bankCode = $tmp[0];
        $bankNumber = ($tmp[1] ?? '');
        $bankOwner = $row['refund_bank_name'];

        if (empty($bankCode) || empty($bankNumber)) {
            $userCode = $this->getUserCode();
            if (!empty($userCode)) {
                $row = $this->qb
                    ->select('bank_code')
                    ->decryptSelect('bank_owner')
                    ->decryptSelect('bank_number')
                    ->from(TBL_SHOP_USER_BANKINFO)
                    ->where('ucode', $userCode)
                    ->where('is_basic', 1)
                    ->orderBy('regdate', 'desc')
                    ->limit(1)
                    ->exec()
                    ->getRowArray();
                if (!empty($row)) {
                    $bankOwner = $row['bank_owner'];
                    $bankNumber = $row['bank_number'];
                    $bankCode = $row['bank_code'];
                } else {
                    $bankOwner = '';
                    $bankNumber = '';
                    $bankCode = '';
                }

            }
        }

        return [
            'bankOwner' => $bankOwner
            , 'bankCode' => $bankCode
            , 'bankNumber' => $bankNumber
        ];
    }


    public function doRefund($products, $claim, $refund, $etcData)
    {
        $etcData['bankCode'] = $etcData['bankCode'] ?? '';
        $etcData['bankNumber'] = $etcData['bankNumber'] ?? '';
        $etcData['bankOwner'] = $etcData['bankOwner'] ?? '';

        /* @var $orderModel \CustomScm\Model\Order\Order */
        $orderModel = $this->import('model.scm.order.order');
        $orderModel->setOid($this->oid);
        $orderData = $orderModel->getOrder();

        //취소 처리
        foreach ($refund as $k => $d) {
            //무통장, 적립금은 PG 취소 후 처리 && 수동처리가 아니고 && 가격이 0 클때
            if (!in_array($d['method'], [ORDER_METHOD_BANK, ORDER_METHOD_RESERVE, ORDER_METHOD_NPAY_ORDER]) && $d['manual'] == 'N' && $d['apply_refund_price'] > 0) {
                /* @var $paymentGatewayModel \CustomScm\Model\Util\PaymentGateway */
                $paymentGatewayModel = $this->import('model.scm.util.paymentGateway');
                $paymentGatewayModel->init($paymentGatewayModel->getPayModuleNameByMethod($d['method']));

                //취소 데이터 생성
                /* @var $cancelData \PgForbizCancelData */
                $cancelData = new \PgForbizCancelData();
                $cancelData->isEscrow = ($d['escrow_use'] == 'Y' ? true : false);
                $cancelData->isPartial = $d['payment_price'] > $d['apply_refund_price'] ? true : false;
                $cancelData->oid = $this->oid;
                $cancelData->method = $d['method'];
                $cancelData->originAmt = $d['payment_price'];
                $cancelData->amt = $d['apply_refund_price'];
                $cancelData->taxAmt = $d['apply_refund_tax_price'];
                $cancelData->taxExAmt = $d['apply_refund_tax_free_price'];
                $cancelData->expectedRestAmt = ($d['remain_price'] - $cancelData->amt);
                $cancelData->message = '관리자 주문 환불';
                $cancelData->tid = $this->getTid($d['method']);
                $cancelData->bankCode = $etcData['bankCode'];
                $cancelData->bankNumber = $etcData['bankNumber'];
                $cancelData->bankOwner = $etcData['bankOwner'];
                $cancelData->phoneNumber = str_replace('-', '', $orderData['bmobile']);
                $cancelData->buyerEmail = $orderData['bmail'];
                $cancelData->claimGroup = $claim[0]['claim_group']; //KSNET 일련번호
                if ($cancelData->originAmt != $cancelData->amt) {
                    $cancelData->cancelType = 'PartialCancel';
                } else {
                    $cancelData->cancelType = 'Cancel';
                }

                //PG 취소
                fb_sys_log('adminCancelData', $cancelData);
                $response = $paymentGatewayModel->requestCancel($cancelData);
                fb_sys_log('adminCancelResponse', $response);

                if ($response['result']) {
                    $d['tid'] = $cancelData->tid;
                    $d['result'] = true;
                    $refund[$k] = $d;
                } else {
                    return $this->changeReturnStructure('pgCancelFail', $response['message']);
                }
            } else if ($d['method'] == ORDER_METHOD_NPAY_ORDER) {     //네이버페이 주문형 취소완료, 취소요청승인, 반품요청승인 처리
                /* @var $naverPayOrderModel \CustomScm\Model\Npay\NaverPayOrder */
                $naverPayOrderModel = $this->import('model.scm.npay.naverPayOrder');
                /* @var $naverPayModel \ForbizScm\Model\Npay */
                $naverPayModel = $this->import('model.scm.npay');

                foreach ($products as $productDetail) {

                    $orderDetailData = $orderModel->getOrderDetailNpay($productDetail['od_ix']);

                    $npayResponse = $naverPayOrderModel->getProductOrderInfoList($orderDetailData['co_od_ix']);

                    //네이버페이 주문 상태 변경
                    if ($npayResponse['ProductOrder']['ClaimStatus'] == 'CANCEL_REQUEST') {         //취소요청승인

                        $modifyOrderResponse = $naverPayModel->changeOrderStatusNpay($orderDetailData['co_od_ix'], 'ApproveCancelApplication');

                        if ($modifyOrderResponse !== TRUE) {
                            return $this->changeReturnStructure('changeOrderStatusFail', $modifyOrderResponse);
                        }

                    } elseif ($npayResponse['ProductOrder']['ClaimType'] == 'RETURN') {   //반품요청승인
                        if ($npayResponse['ReturnInfo']['ClaimDeliveryFeePayMethod'] != '환불금에서 차감') {
                            if (isset($npayResponse['ReturnInfo']['HoldbackStatus']) && $npayResponse['ReturnInfo']['HoldbackStatus'] == "HOLDBACK") { // 보류 중
                                //반품보류 해제
                                $releaseReturnHoldResponse = $naverPayModel->changeOrderStatusNpay($orderDetailData['co_od_ix'], 'ReleaseReturnHold');
                                if ($releaseReturnHoldResponse !== TRUE) {
                                    return $this->changeReturnStructure('changeOrderStatusFail', $releaseReturnHoldResponse);
                                }
                            }
                        }


                        //반품 요청 승인
                        $modifyOrderResponse = $naverPayModel->changeOrderStatusNpay($orderDetailData['co_od_ix'], 'ApproveReturnApplication');

                        if ($modifyOrderResponse !== TRUE) {
                            return $this->changeReturnStructure('changeOrderStatusFail', $modifyOrderResponse);
                        }

                    } elseif ($npayResponse['ProductOrder']['ClaimStatus'] != 'CANCEL_DONE') {      //취소완료
                        //취소 사유 조회
                        $refundData = $this->qb
                            ->select('reason_code')
                            ->select('status')
                            ->from(TBL_SHOP_ORDER_STATUS)
                            ->where('oid', $this->oid)
                            ->where('od_ix', $productDetail['od_ix'])
                            ->where('status', ORDER_STATUS_CANCEL_APPLY)
                            ->whereNotIn('reason_code', [''])
                            ->orderBy('regdate', 'DESC')
                            ->limit(1)
                            ->exec()
                            ->getRowArray();

                        if ($refundData) {
                            $modifyOrderResponse = $naverPayModel->changeOrderStatusNpay($orderDetailData['co_od_ix'], 'CancelSale', $refundData);
                            if ($modifyOrderResponse !== TRUE) {
                                return $this->changeReturnStructure('changeOrderStatusFail', $modifyOrderResponse);
                            }
                        } else {
                            return $this->changeReturnStructure('changeOrderStatusFail', '네이버페이 주문 : 네이버페이 주문상태를 확인해주세요.');
                        }

                    }
                }

                $d['result'] = false;
                $refund[$k] = $d;

            } else if (in_array($d['method'], [ORDER_METHOD_BANK, ORDER_METHOD_RESERVE]) || $d['manual'] == 'Y') {
                $d['result'] = true;
                $refund[$k] = $d;
            } else {
                //PG 취소 잘못되면 위에서 return 됨
                return false;
            }
        }

        /* @var $statusModel \CustomScm\Model\Order\Status */
        $statusModel = $this->import('model.scm.order.status');

        $userCode = $this->getUserCode();
        $nowDateTime = date('Y-m-d H:i:s');
        $addDeliveryPrice = 0;
        $applyRefundPrice = 0;
        $refundPrice = 0;

        //환불 계좌 정보 수정 처리
        if (!empty($etcData['bankCode']) && !empty($etcData['bankNumber'])) {
            $this->updateOrderRefundBank($etcData['bankCode'], $etcData['bankNumber'], $etcData['bankOwner']);
        }

        foreach ($claim as $k => $d) {
            //클레임 배송비 처리
            $this->updateOrderClaimDelivery($d['claim_group'], $d['claim_delivery_price']);

            $applyRefundPrice += $d['refund_product_price'];
            $refundPrice += $d['refund_product_price'] + $d['claim_delivery_price'];

            if ($d['claim_delivery_price'] > 0) {
                //order price 배송 금액 처리
                $orderModel->insertOrderPrice($this->oid, 'F', 'D', ['expect_price' => $d['claim_delivery_price'], 'payment_price' => $d['claim_delivery_price']]);
                $applyRefundPrice += $d['claim_delivery_price'];
            } else {
                $addDeliveryPrice += $d['claim_delivery_price'] * -1;
            }
        }


        foreach ($products as $k => $d) {
            //히스토리 등록
            $statusModel->insertOrderHistory($d['od_ix'], ORDER_STATUS_REFUND_COMPLETE, '', $this->oid);

            //order price 상품 금액 처리
            $orderModel->insertOrderPrice($this->oid, 'F', 'P', ['expect_price' => $d['pt_dcprice'], 'payment_price' => $d['pt_dcprice']]);
        }

        //환불 금액 처리
        $refundMethodText = [];
        $refundBankBool = false;
        foreach ($refund as $k => $d) {
            $paymentMethodText[] = $orderModel->getPaymentMethod($d['method']);
            if ($d['result'] == true) {
                $refundMethodText[] = $orderModel->getPaymentMethod($d['method']);
                if ($d['method'] == ORDER_METHOD_BANK || $d['method'] == ORDER_METHOD_VBANK) {
                    $refundBankBool = true;
                }

                //order payment 처리
                $orderModel->insertOrderPayment($this->oid, 'F', ORDER_STATUS_INCOM_COMPLETE, $d['method'], $d['apply_refund_price'], [
                    'ic_date' => $nowDateTime
                    , 'tax_price' => $d['apply_refund_price']
                    , 'tax_free_price' => 0
                    , 'tid' => $d['tid'] ?? ''
                ]);

                //마일리지 적립
                if ($d['method'] == ORDER_METHOD_RESERVE) {
                    /* @var $mileageModel \CustomScm\Model\Member\Mileage */
                    $mileageModel = $this->import('model.scm.member.mileage');
                    $mileageModel->setMember($userCode);
                    $mileageModel->addMileage($d['apply_refund_price'], '4', $this->oid . ' 환불', ['oid' => $this->oid]);

                    //order price 마일리지 금액 처리
                    $orderModel->insertOrderPrice($this->oid, 'F', 'P', ['reserve' => $d['apply_refund_price']]);
                }
            }
        }

        $odIxs = array_column($products, 'od_ix');

        //상품 상태 변경
        $this->doChangeStatusRefundComplete($odIxs);

        //메일보내기
        $messageData = [];
        $messageData['userCode'] = $userCode ?? '';
        $messageData['productList'] = $orderModel->getClaimProductList(['od_ix' => $odIxs]);
        $messageData['applyRefundPrice'] = $applyRefundPrice;
        $messageData['addDeliveryPrice'] = $addDeliveryPrice;
        $messageData['refundPrice'] = $refundPrice;
        $messageData['paymentMethodText'] = implode(", ", $paymentMethodText);
        $messageData['refundMethodText'] = implode(", ", $refundMethodText);
        $messageData['refundBankBool'] = $refundBankBool;
        if (!empty($etcData['bankCode']) && !empty($etcData['bankNumber'])) {
            $messageData['bankName'] = \ForbizConfig::getBankList($etcData['bankCode']);
            $messageData['bankNumber'] = $etcData['bankNumber'];
            $messageData['bankOwner'] = $etcData['bankOwner'];
        }

        $product = $messageData['productList'][0];
        $messageData['fc_date'] = $product['fc_date'] ?? $nowDateTime;
        $messageData['claimReason'] = $product['claimReason'] ?? '';
        $pname = str_cut($product['pname'], 39);
        $messageData['pnameAbbreviation'] = count($messageData['productList']) > 1 ? $pname . " 외 " . (count($messageData['productList']) - 1) . "건" : $pname;

        sendMessage('order_refund', $orderData['bmail'], $orderData['bmobile'], $messageData);

        //결과 리턴
        return $this->changeReturnStructure();
    }

    /**
     * update 환불 계좌 정보
     * @param $bankCode
     * @param $number
     * @param $owner
     */
    protected function updateOrderRefundBank($bankCode, $number, $owner)
    {
        $this->qb
            ->encryptSet('refund_bank_name', $owner)
            ->encryptSet('refund_bank', $bankCode . '|' . $number)
            ->where('oid', $this->oid)
            ->update(TBL_SHOP_ORDER)
            ->exec();
    }

    /**
     * 클레임 배송비 데이터 처리 클레임 배송비 데이터가 없는경우 생성
     * @param $claimGroup
     * @param $deliveryPrice
     */
    protected function updateOrderClaimDelivery($claimGroup, $deliveryPrice)
    {
        $this->qb
            ->from(TBL_SHOP_ORDER_CLAIM_DELIVERY)
            ->where('oid', $this->oid)
            ->where('claim_group', $claimGroup)
            ->exec();
        if ($this->qb->total) {
            $this->qb
                ->set('delivery_price', $deliveryPrice)
                ->set('ac_target_yn', 'Y')
                ->update(TBL_SHOP_ORDER_CLAIM_DELIVERY)
                ->where('oid', $this->oid)
                ->where('claim_group', $claimGroup)
                ->exec();
        } else {
            $row = $this->qb
                ->select('ode.company_id')
                ->from(TBL_SHOP_ORDER_DETAIL . ' AS od')
                ->join(TBL_SHOP_ORDER_DELIVERY . ' AS ode', 'ode.ode_ix=od.ode_ix')
                ->where('od.oid', $this->oid)
                ->where('od.claim_group', $claimGroup)
                ->limit(1)
                ->exec()
                ->getRowArray();

            $this->qb->insert(TBL_SHOP_ORDER_CLAIM_DELIVERY, [//클레임 배송비 DB 입력. 해당 값 없을 경우 환불완료로 상태변경 불가.
                'oid' => $this->oid,
                'claim_group' => $claimGroup,
                'company_id' => $row['company_id'],
                'delivery_price' => $deliveryPrice,
                'ac_target_yn' => 'Y',
                'regdate' => date('Y-m-d H:i:s')
            ])->exec();
        }
    }

    /**
     * 환불 완료 상태 변경
     * @param $odIxs
     */
    protected function doChangeStatusRefundComplete($odIxs)
    {
        $this->qb
            ->set('refund_status', ORDER_STATUS_REFUND_COMPLETE)
            ->set('fc_date', date('Y-m-d H:i:s'))
            ->update(TBL_SHOP_ORDER_DETAIL)
            ->whereIn('od_ix', $odIxs)
            ->exec();
    }

    /**
     * 환불 리턴 구조
     * @param bool $failCode
     * @param string $failMsg
     * @return array
     */
    protected function changeReturnStructure($failCode = false, $failMsg = '')
    {
        return [
            'result' => ($failCode ? 'changeOrderRefundStatusFail' : 'success')
            , 'data' => [
                'failCode' => $failCode
                , 'failMsg' => $failMsg
            ]
        ];
    }

    /**
     * get 회원코드
     * @return string
     */
    protected function getUserCode()
    {
        $row = $this->qb
            ->select('user_code')
            ->from(TBL_SHOP_ORDER)
            ->where('oid', $this->oid)
            ->exec()
            ->getRowArray();
        return $row['user_code'] ?? '';
    }

    /**
     * get TID
     * @param $method
     * @return string
     */
    protected function getTid($method)
    {
        $row = $this->qb
            ->select('tid')
            ->from(TBL_SHOP_ORDER_PAYMENT)
            ->where('oid', $this->oid)
            ->where('method', $method)
            ->orderBy('tid', 'DESC')
            ->limit(1)
            ->exec()
            ->getRowArray();
        return $row['tid'] ?? '';
    }
}
