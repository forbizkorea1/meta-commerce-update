<?php

/**
 * Description of ForbizMallCouponModel
 *
 * @author hong
 */
class ForbizMallCouponModel extends ForbizModel
{

    /**
     * 쿠폰 정책 정보
     * @var type
     */
    protected $config;

    /**
     * 사용 환경 (G: PC, M:모바일, MA:APP, P:오프라인(POS))
     * 일반적으로 W가 웹이나, 쿠폰에서는 G가 웹으로 사용됨
     * @var string
     */
    protected $agentType = 'G';

    /**
     * 회원 그룹 인덱스 (common_member_detail.gp_ix)
     * @var type
     */
    protected $memberGroupIx = 0;

    /**
     * 회원 code (common_user.code)
     * @var type
     */
    protected $userCode = '';

    /**
     * 회원그룹 쿠폰사용여부
     * @var type
     */
    protected $userGroupCouponYn = '';

    public function __construct()
    {
        parent::__construct();

        $this->config = ForbizConfig::getSharedMemory('b2c_coupon_rule');

        $this->setAgentType((is_mobile() ? (getAppType() === false ? "M" : "MA") : "G"));
        $this->setMember(sess_val('user', 'code'), sess_val('user', 'gp_ix'), sess_val('user', 'use_coupon_yn'));
    }

    /**
     * get config
     * @param type $key
     * @return type
     */
    public function getConfig($key = false)
    {
        if ($key === false) {
            return $this->config;
        } else {
            return empty($this->config[$key]) ? '' : $this->config[$key];
        }
    }

    /**
     * set 사용 환경
     * @param string $agentType
     * @return $this
     */
    public function setAgentType($agentType)
    {
        if(is_array($agentType)){
            $this->agentType = $agentType;
        }else{
            $this->agentType = strtoupper($agentType);
        }

        return $this;
    }

    /**
     * set 회원
     * @param string $userCode
     * @param int $gpIx
     * @param string $userGroupCouponYn
     * @return $this
     */
    public function setMember($userCode, $gpIx, $userGroupCouponYn)
    {
        $this->userCode = $userCode;
        $this->memberGroupIx = $gpIx;
        $this->userGroupCouponYn = $userGroupCouponYn;
        return $this;
    }

    /**
     * 쿠폰 복구
     * @param string $oid
     * @param string $status
     * @param array $odIxs shop_order_detail 키값
     * @param array $odeIxs shop_order_detail_discount 키값
     * @return type
     */
    public function returnUsedCoupon($oid, $status, $odIxs = [], $odeIxs = [])
    {
        //관리자 쿠폰설정에서 N이 복원함 이었음. 그래서 프론트가 N으로 설정되었지만, 관리자 로직에서는  Y가 복원함으로 조건이 엇갈려서 Y로 통일 한다
        switch ($status) { //상태에 따라 복구가능 시점 다름. 관리자 설정 참조.
            case ORDER_STATUS_INCOM_BEFORE_CANCEL_COMPLETE :
                $restoreConfig = $this->config['restore_cc1'];
                break;
            case ORDER_STATUS_CANCEL_COMPLETE :
                $restoreConfig = $this->config['restore_cc2'];
                break;
            case ORDER_STATUS_RETURN_COMPLETE :
                $restoreConfig = $this->config['restore_bf'];
                break;
            default :
                $restoreConfig = 'Y';
                break;
        }

        if ($restoreConfig == 'Y') {
            if (!empty($odIxs)) {
                $this->qb->whereIn('dc_ix',
                    $this->qb->startSubQuery()
                    ->select('dc_ix')
                    ->from(TBL_SHOP_ORDER_DETAIL_DISCOUNT." as odd2")
                    ->whereIn('od_ix', $odIxs)
                    ->endSubQuery(), false
                );
            }

            if (!empty($odeIxs)) {
                $this->qb->whereIn('odd.ode_ix', $odeIxs);
            }

            //쿠폰 돌려주기. 전체 취소 혹은 관련 쿠폰으로 사용된 건이 전부 취소되었을 경우 사용함.
            //취소한 쿠폰건과 동일하게 사용된 쿠폰이 있는지 discount 확인
            //해당 od_ix 들의 정상 배송 프로세스가 있는지 개수 확인. 0이면 현재 주문건이 마지막 주문이므로 복원해주고 아니면 마지막 주문건이 아니므로 복원해주지 않음.
            //전체 취소이라서 주문 전체 돌려줌.

            $rows = $this->qb
                ->select('odd.dc_ix')
                ->selectSum("CASE WHEN od.status IN ('" . implode("','", [
                        ORDER_STATUS_INCOM_COMPLETE,
                        ORDER_STATUS_DELIVERY_READY,
                        ORDER_STATUS_DELIVERY_ING,
                        ORDER_STATUS_DELIVERY_COMPLETE,
                        ORDER_STATUS_BUY_FINALIZED
                    ]) . "') THEN 1 ELSE 0 END", 'count')
                ->from(TBL_SHOP_ORDER_DETAIL . ' as od')
                ->join(TBL_SHOP_ORDER_DETAIL_DISCOUNT . ' as odd', 'od.od_ix=odd.od_ix', 'inner')
                ->where('od.oid', $oid)
                ->whereIn('odd.dc_type', ['CP'])
                ->groupBy('odd.dc_ix')
                ->exec()->getResultArray();

            $registIx = [];
            foreach ($rows as $row) {
                if ($row['count'] == 0) {
                    array_push($registIx, $row['dc_ix']);
                }
            }

            if (!empty($registIx)) {
                 return $this->qb
                    ->set('use_yn', 0)
                    ->set('use_oid', '')
                    ->set('use_pid', '')
                    ->set('usedate', '')
                    ->whereIn('regist_ix', $registIx)
                    ->where('mem_ix', $this->userCode)
                    ->update(TBL_SHOP_CUPON_REGIST)
                    ->exec();
            }

        }

        return false;
    }

    /**
     * 해당하는 쿠폰 정보 출력
     * @param int $publishIx
     * @return array
     */
    public function getCouponDatas($publishIx)
    {
        return $this->setBasicSelect()
            ->select('cp.regist_date_differ')
            ->select('cp.issue_type')
            ->from(TBL_SHOP_CUPON . ' as c')
            ->join(TBL_SHOP_CUPON_PUBLISH . ' as cp', 'on c.cupon_ix=cp.cupon_ix', 'inner')
            ->where('cp.publish_ix', $publishIx)
            ->exec()
            ->getRow(0, 'array');
    }

    /**
     * 해당 회원의 쿠폰리스트(마이페이지 > 쿠폰리스트)
     * @param boolean $useYn
     * @param int $page
     * @param int $limit
     * @param array $addSelect
     * @param array $addWhere
     * @return array
     */
    public function getUserCouponList($useYn = null, $page = '1', $limit = '10', $addSelect = [], $addWhere = [])
    {
        if($this->isUseCoupon() === false) {
            return [
                'total' => 0,
                'list' => [],
                'paging' => false
            ];
        }

        $this->qb->startCache();

        //추가 select 처리
        if (!empty($addSelect) && is_array($addSelect)) {
            foreach ($addSelect as $select) {
                $this->qb->select($select);
            }
        }

        //추가 where 처리
        if (!empty($addWhere) && is_array($addWhere)) {
            foreach ($addWhere as $key => $value) {
                if(is_array($value)) {
                    $this->qb->whereIn($key, $value);
                } else {
                    $this->qb->where($key, $value);
                }
            }
        }

        $this->qb
            ->select('use_yn')
            ->select("cr.regist_ix")
            ->select("cr.publish_ix")
            ->select("c.cupon_div")
            ->select("date_format(cr.use_sdate, '%Y-%m-%d') as regist_start, date_format(cr.use_date_limit, '%Y-%m-%d') as regist_end")
            ->from(TBL_SHOP_CUPON_REGIST . ' as cr')
            ->join(TBL_SHOP_CUPON_PUBLISH . ' as cp', 'cr.publish_ix=cp.publish_ix', 'inner')
            ->join(TBL_SHOP_CUPON . ' as c', 'c.cupon_ix=cp.cupon_ix', 'inner')
            ->where('cr.mem_ix', $this->userCode)
            ->where('cp.is_use !=', '3')
            ->whereIn('c.cupon_use_div', ['A', $this->agentType])
            ->orderBy('cr.regdate');

        if ($useYn !== null) {
            if ($useYn) { //사용완료 & 기한만료된 쿠폰
                $this->setBasicUseWhere($useYn);
            } else { //사용가능 쿠폰
                $this->setBasicUseWhere($useYn);
            }
        }

        $this->qb->stopCache();

        $total = $this->qb->limit(1)->getCount();

        if($limit != 0) {
            $paging = $this->qb->setTotalRows($total)->pagination($page, $limit);
            $offset = $paging['offset'] ?? 0;
            $this->qb->limit($limit, $offset);
        }
        $list = $this->setBasicSelect()
            ->exec()->getResultArray();

        $this->qb->flushCache();

        foreach ($list as $key => $value) {
            //쿠폰 할인액 OR 할인율 구분
            $list[$key]['cupon_sale_type_percent'] = ($value['cupon_sale_type']=='1')? true : false;
            $list[$key]['regist_start'] = change_date_format($list[$key]['regist_start']);
            $list[$key]['regist_end'] = change_date_format($list[$key]['regist_end']);
        }
        return [
            'total' => $total,
            'list' => $list,
            'paging' => $paging ?? ''
        ];
    }

    /**
     * 다운 가능한 쿠폰 리스트 노출(쇼핑몰에서 발행한 쿠폰)
     * @param string $pid
     * @return array
     */
    public function getMallCouponList($pid = '')
    {
        /* @var $fbEncryptModel CustomMallFbEncryptModel */
        $fbEncryptModel = $this->import('model.mall.fbEncrypt');

        if ($this->isUseCoupon()) {
            $useForAllProduct = $this
                ->setBasicQuery()
                ->where('cp.issue_type', '2')
                ->where('cp.issue_type_detail', '1')
                ->where('cp.use_product_type', '1')//발급 대상 상품 : 전체
                ->exec()
                ->getResultArray();

            $useForSomeCategory = $this
                ->setBasicQuery()
                ->join(TBL_SHOP_CUPON_RELATION_CATEGORY . ' as crc', 'cp.publish_ix=crc.publish_ix', 'inner')
                ->join(TBL_SHOP_PRODUCT_RELATION . ' as pr',
                    'SUBSTRING(crc.cid,1,(crc.depth+1)*3) = SUBSTRING(pr.cid,1,(crc.depth+1)*3) ' . (!empty($pid) ? 'and pr.pid="' . $pid . '"' : ''),
                    'inner')
                ->where('cp.use_product_type', '2')//발급 대상 상품 : 특정 카테고리
                ->where('cp.issue_type', '2')
                ->where('cp.issue_type_detail', '1')
                ->groupBy('cp.publish_ix')
                ->exec()
                ->getResultArray();

            $useForSomeProduct = $this
                ->setBasicQuery()
                ->join(TBL_SHOP_CUPON_RELATION_PRODUCT . ' as crp',
                    'cp.publish_ix=crp.publish_ix ' . (!empty($pid) ? 'and crp.pid="' . $pid . '"' : ''), 'inner')
                ->where('cp.use_product_type', '3')//발급 대상 상품 : 특정 상품
                ->where('cp.issue_type', '2')
                ->where('cp.issue_type_detail', '1')
                ->exec()
                ->getResultArray();

            $useForSomeBrand = $this
                ->setBasicQuery()
                ->join(TBL_SHOP_CUPON_RELATION_BRAND . ' as crb', 'on cp.publish_ix=crb.publish_ix', 'inner')
                ->join(TBL_SHOP_PRODUCT . ' as p',
                    'on p.brand=crb.b_ix ' . (!empty($pid) ? 'and p.id="' . $pid . '"' : ''), 'inner')
                ->where('cp.use_product_type', '4')//발급 대상 상품 : 특정 브랜드
                ->where('cp.issue_type', '2')
                ->where('cp.issue_type_detail', '1')
                ->exec()
                ->getResultArray();

            $useForSomeSeller = $this
                ->setBasicQuery()
                ->join(TBL_SHOP_CUPON_RELATION_SELLER . ' as crs', 'cp.publish_ix=crs.publish_ix', 'inner')
                ->join(TBL_SHOP_PRODUCT . ' as p',
                    'crs.company_id=p.admin ' . (!empty($pid) ? 'and p.id="' . $pid . '"' : ''), 'inner')
                ->where('cp.use_product_type', '5')//발급 대상 상품 : 특정 셀러
                ->where('cp.issue_type', '2')
                ->where('cp.issue_type_detail', '1')
                ->exec()
                ->getResultArray();


            // 제외 대상이 아니면 쿠폰 노출
            $useForSomeExceptProduct = $this
                ->setBasicQuery()
                ->join(TBL_SHOP_CUPON_RELATION_PRODUCT . ' as crp',
                    'cp.publish_ix=crp.publish_ix ' . (!empty($pid) ? 'and crp.pid !="' . $pid . '"' : ''), 'inner')
                ->where('cp.use_product_type', '6')//발급 대상 상품 : 특정 상품 제외
                ->where('cp.issue_type', '2')
                ->where('cp.issue_type_detail', '1')
                ->exec()
                ->getResultArray();


            $result = array_merge($useForAllProduct, $useForSomeCategory, $useForSomeProduct, $useForSomeBrand,
                $useForSomeSeller, $useForSomeExceptProduct);

            foreach ($result as $k => $v) {
                $result[$k]['isPublished'] = $this->checkPublished($v['publish_ix'], false);

                $pLink = str_replace('=','',$fbEncryptModel->encode($v['publish_ix']));
                $result[$k]['pubKey'] = $pLink;
            }

            return $result;
        } else {
            return;
        }
    }

    /**
     * 쿠폰이 이미 등록된 상태인지 확인
     * @param $publishIx
     * @param $userCode
     * @param $duplicate
     * @return bool
     * @throws \Exception
     */
    public function checkPublished($publishIx, $duplicate)
    {
        if ($duplicate === false) {
            $count = $this->qb->select('regist_ix')
                ->from(TBL_SHOP_CUPON_REGIST)
                ->where('publish_ix', $publishIx)
                ->where('mem_ix', $this->userCode)
                ->limit(1)
                ->getCount();
            if ($count > 0) {
                return true;
            } else {
                return false;
            }
        } else {
            return false;
        }
    }

    /**
     * 쿠폰 지급
     * @param int $publishIx
     * @return string
     */
    public function giveCoupon($publishIx, $duplicate = false, $issueType = false)
    {
        if (!$this->checkPublished($publishIx, $duplicate) && $this->isUseCoupon()) {
            $datas = $this->getCouponDatas($publishIx);

            if($issueType == 2 && $datas['issue_type'] != $issueType){
                return 'issuetypefail';
            }

            if ($datas['use_date_type'] == 9) { //무제한
                $use_date_limit = null;
                $use_sdate = date('Y-m-d H:i:s');
            } else {
                if ($datas['use_date_type'] == 1) { //발행일 기준
                    $use_date_limit = date('Y-m-d 23:59:59',strtotime($datas['publish_limit_date']));
                    $use_sdate = $datas['regdate'];
                } else {
                    if ($datas['use_date_type'] == 2) {//발급일 기준
                        if ($datas['regist_date_type'] == 1) {
                            $use_date_limit = date('Y-m-d H:i:s',
                                strtotime('+' . $datas['regist_date_differ'] . ' years'));
                        } else {
                            if ($datas['regist_date_type'] == 2) {
                                $use_date_limit = date('Y-m-d H:i:s',
                                    strtotime('+' . $datas['regist_date_differ'] . ' months'));
                            } else {
                                if ($datas['regist_date_type'] == 3) {
                                    $use_date_limit = date('Y-m-d H:i:s',
                                        strtotime('+' . $datas['regist_date_differ'] . ' days'));
                                }
                            }
                        }
                        $use_sdate = date('Y-m-d H:i:s');
                    } else {
                        if ($datas['use_date_type'] == 3) {//사용기간 지정
                            $use_date_limit = $datas['use_edate'];
                            $use_sdate = $datas['use_sdate'];
                        } else {
                            return 'fail';
                        }
                    }
                }
            }

            $this->qb->insert(TBL_SHOP_CUPON_REGIST, [
                'publish_ix' => $publishIx,
                'mem_ix' => $this->userCode,
                'open_yn' => 0,
                'use_yn' => 0,
                'use_sdate' => $use_sdate,
                'use_date_limit' => $use_date_limit,
                'regdate' => date('Y-m-d H:i:s')
            ])->exec();
            return 'success';
        } else {
            return 'fail';
        }
    }

    /**
     * 회원이 보유중인 쿠폰 수
     * @param string $useYn : true(사용한 & 기한만료된 쿠폰) or false(미사용한 쿠폰)
     * @return int
     */
    public function getCouponCnt($useYn = false)
    {
        $ret = 0;

        if ($this->isUseCoupon()) {
            $this->qb
                ->from(TBL_SHOP_CUPON_REGIST . ' as cr')
                ->join(TBL_SHOP_CUPON_PUBLISH . ' as cp', 'cr.publish_ix = cp.publish_ix')
                ->join(TBL_SHOP_CUPON . ' as c', 'c.cupon_ix = cp.cupon_ix')
                ->where('cr.mem_ix', $this->userCode)
                ->whereIn('c.cupon_use_div', ['A', $this->agentType]);

            if ($useYn) { //사용완료 & 기한만료된 쿠폰
                $this->setBasicUseWhere($useYn);
            } else { //사용가능 쿠폰
                $this->setBasicUseWhere($useYn);
            }
            $ret = $this->qb->getCount();
        }

        return $ret;
    }

    /**
     * 회원이 보유중인 전체 쿠폰 수 (pc app 등 모두)
     * @param string $useYn : true(사용한 & 기한만료된 쿠폰) or false(미사용한 쿠폰)
     * @return int
     */
    public function getCouponAllCnt($useYn = false)
    {
        $ret = 0;

        if ($this->isUseCoupon()) {
            $this->qb
                ->from(TBL_SHOP_CUPON_REGIST . ' as cr')
                ->join(TBL_SHOP_CUPON_PUBLISH . ' as cp', 'cr.publish_ix = cp.publish_ix')
                ->join(TBL_SHOP_CUPON . ' as c', 'c.cupon_ix = cp.cupon_ix')
                ->where('cr.mem_ix', $this->userCode);

            if ($useYn) { //사용완료 & 기한만료된 쿠폰
                $this->setBasicUseWhere($useYn);
            } else { //사용가능 쿠폰
                $this->setBasicUseWhere($useYn);
            }
            $ret = $this->qb->getCount();
        }

        return $ret;
    }

    /**
     * 해당 상품의 보유쿠폰 적용 정보 리스트
     * @param type $pid
     * @param type $unitPrice
     * @param type $paymentPrice
     * @return type
     */
    public function applyProductUserCouponList($pid, $unitPrice, $paymentPrice)
    {
        $myCouponList = $this->getUserCouponList(false, 1, 100
            , [
                'cr.regist_ix',
                'cp.use_product_type',
                'c.cupon_acnt',
                'c.haddoffice_rate',
                'c.seller_rate',
                'c.round_position',
                'c.round_type',
                'cp.publish_max',
                'cp.publish_limit_price'
            ]
            , ['c.cupon_div' => 'G'])['list'];
        foreach ($myCouponList as $key => $coupon) {
            $activeBool = $this->checkProductCouponActive($pid, $unitPrice, $coupon);
            if ($activeBool) {
                $coupon['discount_amount'] = $this->calculationDiscount($paymentPrice, $coupon)['discount_amount'];
                $coupon['total_coupon_with_dcprice'] = f_decimal($paymentPrice) - $coupon['discount_amount'];
            }
            $coupon['activeBool'] = $activeBool;
            $myCouponList[$key] = $coupon;
        }
        return $myCouponList;
    }

    /**
     * 카트에서 쿠폰 사용 리스트 처리
     * @param type $regist_ix
     * @param type $pid
     * @param type $unitPrice
     * @param type $paymentPrice
     */
    public function applyProductCoupon($regist_ix, $pid, $unitPrice, $paymentPrice)
    {
        $coupon = ($this->getUserCouponList(false, 1, 100
                , [
                    'cr.regist_ix',
                    'cp.use_product_type',
                    'c.cupon_acnt',
                    'c.haddoffice_rate',
                    'c.seller_rate',
                    'c.round_position',
                    'c.round_type',
                    'cp.publish_max',
                    'cp.publish_limit_price'
                ]
                , ['c.cupon_div' => 'G', 'cr.regist_ix' => $regist_ix])['list'][0] ?? false);

        //내 쿠폰인지 아닐경우
        if ($coupon === false) {
            return false;
        } else {
            $activeBool = $this->checkProductCouponActive($pid, $unitPrice, $coupon);
            if ($activeBool) {
                return $this->calculationDiscount($paymentPrice, $coupon);
            } else {
                return false;
            }
        }
    }

    /**
     * 쿠폰 사용 처리
     * @param type $registIx
     * @param type $oid
     * @param type $pid
     */
    public function useCoupon($registIx, $oid, $pid)
    {
        $this->qb
            ->set('use_yn', 1)
            ->set('use_oid', $oid)
            ->set('use_pid', $pid)
            ->set('usedate', date('Y-m-d H:i:s'))
            ->update(TBL_SHOP_CUPON_REGIST)
            ->where('regist_ix', $registIx)
            ->exec();
    }

    /**
     * 쿠폰 적용 대상 상품
     * @param boolean $useYn
     * @param int $page
     * @param int $limit
     * @param array $addSelect
     * @param array $addWhere
     * @return array
     */
    public function getCouponApplyProductList($registIx)
    {
        $row = $this->getCouponInfo($registIx);

        if (!empty($row)) {
            // 카테고리 상품
            if ($row['use_product_type'] == '2') {

                $row['plist'] = $this->qb
                    ->select("t3.pname, t3.id, t2.cid")
                    ->from(TBL_SHOP_CUPON_RELATION_CATEGORY . ' as t1')
                    ->join(TBL_SHOP_PRODUCT_RELATION . ' as t2', 't1.cid = t2.cid', 'inner')
                    ->join(TBL_SHOP_PRODUCT . ' as t3', 't3.id = t2.pid', 'inner')
                    ->where('t1.publish_ix', $row['publish_ix'])
                    ->orderBy('t2.cid', 'asc')
                    ->orderBy('t3.regdate', 'desc')
                    ->exec()
                    ->getResultArray();

                // 특정 상품
            } else {
                if ($row['use_product_type'] == '3') {

                    $row['plist'] = $this->qb
                        ->select("sp.pname, sp.id")
                        ->from(TBL_SHOP_CUPON_RELATION_PRODUCT . ' as cr')
                        ->join(TBL_SHOP_PRODUCT . ' as sp', 'cr.pid = sp.id', 'inner')
                        ->where('cr.publish_ix', $row['publish_ix'])
                        ->orderBy('sp.regdate', 'desc')
                        ->exec()
                        ->getResultArray();
                }
            }
        }
        return $row;
    }

    /**
     * 특정 조건 쿠폰 발급
     * @param type $issueTypeDetail 1:회원가입 완료시, 2:회원그룹 변경 시, 3:기념일(생일) 시, 4:APP 첫구매, 5:APP 푸시 수신여부 동의, 6:마케팅 수신여부 동의(SMS/이메일)
     * @param bool $duplicate
     * @param bool $gpIx
     */
    public function preferredConditionGiveCoupon($issueTypeDetail, $duplicate = false, $gpIx=false)
    {
        if ($this->isUseCoupon()) {
            if($issueTypeDetail == 2){
                $this->qb->orGroupStart();
                if($gpIx !== false){
                    $this->qb
                    ->orGroupStart()
                        ->where('cp.publish_type',4) // 특정회원그룹 발급대상
                        ->where('cpc.r_ix',$gpIx)
                    ->groupEnd();
                }
                $this->qb->orWhere('cp.publish_type',2); // 전체회원그룹 발급대상
                $this->qb->groupEnd();
            }

            $rows = $this->setBasicQuery()
                ->where('cp.issue_type_detail', $issueTypeDetail)
                ->where('cp.issue_type', '4')
                ->exec()
                ->getResultArray();

            if (!empty($rows)) {
                foreach ($rows as $row) {
                    $this->giveCoupon($row['publish_ix'], $duplicate);
                }
            }
        }
    }

    /**
     * 쿠폰 할인 금액 계산
     * @param type $paymentPrice
     * @param type $couponData
     * @return type
     */
    public function calculationDiscount($paymentPrice, $couponData)
    {
        $paymentPrice = f_decimal($paymentPrice);
        $registIx = $couponData['regist_ix'] ?? '';
        $publishName = $couponData['publish_name'];
        $cuponSaleType = $couponData['cupon_sale_type'];
        $cuponAcnt = $couponData['cupon_acnt'];
        $cuponSaleValue = f_decimal($couponData['cupon_sale_value']);
        $haddofficeRate = f_decimal($couponData['haddoffice_rate']);
        $sellerRate = f_decimal($couponData['seller_rate']);
        $roundPosition = $couponData['round_position'];
        $roundType = $couponData['round_type'];
        $publishMax = $couponData['publish_max'];
        $publishLimitPrice = f_decimal($couponData['publish_limit_price']);

        //할인부담
        if ($cuponAcnt == '1') {//본사
            $haddofficeRate = $cuponSaleValue;
            $sellerRate = 0;
        }

        if ($cuponSaleType == '1') { //정률
            $discountAmount = f_decimal($paymentPrice * $cuponSaleValue / 100);
            $headofficeDiscountAmount = f_decimal($paymentPrice * $haddofficeRate / 100);

            $discountAmount = calNumberCutting($discountAmount, $roundPosition, $roundType);
            $headofficeDiscountAmount = calNumberCutting($headofficeDiscountAmount, $roundPosition, $roundType);


            $sellerDiscountAmount = $discountAmount - $headofficeDiscountAmount;
        } else { //정액
            $discountAmount = $cuponSaleValue;
            $headofficeDiscountAmount = $haddofficeRate;
            $sellerDiscountAmount = $sellerRate;
        }

        //최대 할인금액
        if ($publishMax == 'Y' && $publishLimitPrice > 0 && $discountAmount > $publishLimitPrice) {
            $headofficeDiscountAmount = ($headofficeDiscountAmount * $publishLimitPrice / $discountAmount)->round((defined('BCSCALE') ? BCSCALE : 0));
            $discountAmount = $publishLimitPrice;
            $sellerDiscountAmount = $discountAmount - $headofficeDiscountAmount;
        }

        return [
            'sale_type' => $cuponSaleType,
            'cupon_div' => $couponData['cupon_div'],
            'round_type' => $roundType,
            'round_position' => $roundPosition,
            'sale_value' => $cuponSaleValue,
            'headoffice_sale_value' => $haddofficeRate,
            'seller_sale_value' => $sellerRate,
            'code' => $registIx,
            'commission' => 0,
            'description' => $publishName,
            'discount_amount' => $discountAmount,
            'origin_discount_amount' => $discountAmount,
            'headoffice_discount_amount' => $headofficeDiscountAmount,
            'seller_discount_amount' => $sellerDiscountAmount
        ];
    }

    /**
     * 해당 상품의 쿠폰 사용 가능 여부
     * @param type $pid
     * @param type $unitPrice
     * @param type $couponData
     * @return boolean
     */
    protected function checkProductCouponActive($pid, $unitPrice, $couponData)
    {
        $unitPrice = f_decimal($unitPrice);
        $publishIx = $couponData['publish_ix'];
        $publishMin = $couponData['publish_min'];
        $publishMax = $couponData['publish_max'];
        $cuponUseDiv = $couponData['cupon_use_div'];
        $publishConditionPrice = f_decimal($couponData['publish_condition_price']);
        $publishLimitPrice = f_decimal($couponData['publish_limit_price']);
        $useProductType = $couponData['use_product_type'];
        $saleType = $couponData['cupon_sale_type'];
        $salePrice = $couponData['cupon_sale_value'];

        $activeBool = false;

        //상품 금액이 0일면 X
        if ($unitPrice == 0) {
            return false;
        }

        //정액일때 상품 dcPrice보다 할인가가 높으면 사용 X
        if($saleType == '2') {
            //쿠폰 혜택 제한 (최대 할인금액)
            if ($publishMax == 'Y' && $salePrice > $publishLimitPrice){
                $salePrice = $publishLimitPrice;
            }

            if($unitPrice < $salePrice){ //할인가 - 쿠폰할인가
                return false;
            }
        }

        //쿠폰 혜택 제한 (최소 상품금액)
        if ($publishMin == 'Y' && $unitPrice < $publishConditionPrice) {
            return false;
        }

        // 쿠폰 사용범위 적용
        if($cuponUseDiv != 'A') {
            switch ($couponData){
                case 'G':
                    if(is_mobile()){
                        return false;
                    }
                    break;
                case 'M':
                    if(!is_mobile()){
                        return false;
                    }
                    break;
                case 'MA':
                    if(getAppType() === false){
                        return false;
                    }
                    break;
                default:

                    break;
            }
        }

        //사용기간 체크
        $couponActiveCnt = $this->qb
            ->from(TBL_SHOP_CUPON_PUBLISH . ' as cp')
            ->where('cp.publish_ix', $publishIx)
            ->groupStart()
            ->orGroupStart()
            ->where('cp.use_date_type', '9')//무기한
            ->groupEnd()
            ->orGroupStart()
            ->where('cp.use_date_type', '3')//사용기간 지정
            ->where('cp.use_sdate <=', fb_now())
            ->where('cp.use_edate >=', fb_now())
            ->groupEnd()
            ->orGroupStart()
            ->where('cp.use_date_type', '2')//발급일 기준
            ->groupEnd()
            ->orGroupStart()
            ->where('cp.use_date_type', '1')//발행일 기준
            ->where('cp.regdate <=', fb_now())
            ->where('case when publish_date_type = "1" then date_add(cp.regdate, INTERVAL cp.publish_date_differ YEAR )
                            when publish_date_type = "2" then date_add(cp.regdate, INTERVAL cp.publish_date_differ MONTH )
                            when publish_date_type = "3" then date_add(cp.regdate, INTERVAL cp.publish_date_differ DAY)
                            end >=', fb_now())
            ->groupEnd()
            ->groupEnd()
            ->getCount();
        if($couponActiveCnt <= 0) {
            return false;
        }


        //사용가능상품
        if ($useProductType == '1') {
            $activeBool = true;
        } else {
            switch ($useProductType) {
                case'2': //카테고리
                    $this->qb
                        ->select('crc.publish_ix')
                        ->from(TBL_SHOP_CUPON_RELATION_CATEGORY . ' as crc')
                        ->join(TBL_SHOP_PRODUCT_RELATION . ' as pr',
                            'SUBSTRING(crc.cid,1,(crc.depth+1)*3) = SUBSTRING(pr.cid,1,(crc.depth+1)*3)', 'inner')
                        ->where('crc.publish_ix', $publishIx)
                        ->where('pr.pid', $pid);
                    break;
                case'3': //상품
                    $this->qb
                        ->select('crp.publish_ix')
                        ->from(TBL_SHOP_CUPON_RELATION_PRODUCT . ' as crp')
                        ->where('crp.publish_ix', $publishIx)
                        ->where('crp.pid', $pid);
                    break;
                case'4': //브랜드
                    $this->qb
                        ->select('crb.publish_ix')
                        ->from(TBL_SHOP_CUPON_RELATION_BRAND . ' as crb')
                        ->join(TBL_SHOP_PRODUCT . ' as p', 'p.brand=crb.b_ix', 'inner')
                        ->where('crb.publish_ix', $publishIx)
                        ->where('p.id', $pid);
                    break;
                case'5': //셀러
                    $this->qb
                        ->select('crs.publish_ix')
                        ->from(TBL_SHOP_CUPON_RELATION_SELLER . ' as crs')
                        ->join(TBL_SHOP_PRODUCT . ' as p', 'crs.company_id=p.admin', 'inner')
                        ->where('crs.publish_ix', $publishIx)
                        ->where('p.id', $pid);
                    break;
                default :
                    return false;
                    break;
            }

            $total = $this->qb->limit(1)->getCount();
            if ($total > 0) {
                $activeBool = true;
            }
        }
        return $activeBool;
    }

    /**
     * 관리자 설정의 쿠폰 사용 여부 확인
     * @return boolean
     */
    protected function isUseCoupon()
    {
        if ($this->config['coupon_use_yn'] == 'Y' && !empty($this->userCode) && $this->userGroupCouponYn == 'Y') {
            return true;
        } else {
            return false;
        }
    }

    /**
     * 쿠폰 리스트 호출의 기본 sql문 세팅
     * @return type
     */
    protected function setBasicQuery()
    {
        if(is_array($this->agentType)){
            $this->qb->whereIn('c.cupon_use_div', $this->agentType);
        }else{
            $this->qb->whereIn('c.cupon_use_div', ['A', 'P', $this->agentType]);
        }

        return $this->setBasicSelect()
            ->from(TBL_SHOP_CUPON . ' as c')
            ->join(TBL_SHOP_CUPON_PUBLISH . ' as cp', 'on c.cupon_ix=cp.cupon_ix', 'inner')
            ->join(TBL_SHOP_CUPON_PUBLISH_CONFIG . ' as cpc ', 'cp.publish_ix=cpc.publish_ix', 'left')
            ->whereIn('c.mall_ix', ['', MALL_IX])
            ->where('cp.is_use', '1')
//            ->where('cp.disp', '1')
            ->where('cp.cupon_use_sdate <=', time())//노출기간
            ->where('cp.cupon_use_edate >=', time())//노출기간
            //사용기간 조건
            /*->groupStart()
            ->orGroupStart()
            ->where('cp.use_date_type', '9')//무기한
            ->groupEnd()
            ->orGroupStart()
            ->where('cp.use_date_type', '3')//사용기간 지정
            ->where('cp.use_sdate <=', date('Y-m-d H:i:s'))
            ->where('cp.use_edate >=', date('Y-m-d H:i:s'))
            ->groupEnd()
            ->orGroupStart()
            ->where('cp.use_date_type', '2')//발급일 기준
            ->groupEnd()
            ->orGroupStart()
            ->where('cp.use_date_type', '1')//발행일 기준
            ->where('cp.regdate <=', date('Y-m-d H:i:s'))
            ->where('case when publish_date_type = "1" then date_add(cp.regdate, INTERVAL cp.publish_date_differ YEAR )
                            when publish_date_type = "2" then date_add(cp.regdate, INTERVAL cp.publish_date_differ MONTH )
                            when publish_date_type = "3" then date_add(cp.regdate, INTERVAL cp.publish_date_differ DAY)
                            end >=', date('Y-m-d H:i:s'))
            ->groupEnd()
            ->groupEnd()*/
            //사용기간 조건
            //발급대상회원 조건
            ->groupStart()
            ->orGroupStart()
            ->where('cp.publish_type', '2')//전체회원
            ->groupEnd()
            ->orGroupStart()
            ->where('cp.publish_type', '1')//관리자 지정 회원
            ->where('cpc.r_ix', $this->userCode)
            ->groupEnd()
            ->orGroupStart()
            ->where('cp.publish_type', '4')//관리자 지정 그룹
            ->where('cpc.r_ix', $this->memberGroupIx)
            ->groupEnd()
            ->groupEnd();
        //발급대상회원 조건
    }

    /**
     *  쿠폰 리스트 호출 select문 기본 세팅. shop_cupon, shop_cupon_publish 테이블의 컬럼만 사용할것.
     */
    protected function setBasicSelect()
    {
        return $this->qb->select('(case when publish_date_type = 3 then DATE_ADD(c.regdate, INTERVAL publish_date_differ DAY)'
            . 'when publish_date_type = 2 then DATE_ADD(c.regdate, INTERVAL publish_date_differ MONTH)'
            . 'when publish_date_type = 1 then DATE_ADD(c.regdate, INTERVAL publish_date_differ YEAR) else "" end ) as publish_limit_date')//발행일 기준의 종료일
        ->select('cupon_use_div')
            ->select('use_product_type')
            ->select('use_date_type')
            ->select('publish_name')
            ->select('cupon_sale_type')
            ->select('cupon_sale_value')
            ->select('c.regdate')
            ->select('c.cupon_acnt')
            ->select('c.haddoffice_rate')
            ->select('c.seller_rate')
            ->select('c.round_position')
            ->select('c.round_type')
            ->select('c.cupon_div')
            ->select('regist_date_type')
            ->select('cp.use_sdate')
            ->select('cp.use_edate')
            ->select('publish_min')
            ->select('publish_max')
            ->select('publish_condition_price')
            ->select('publish_limit_price')
            ->select('cp.regist_date_differ')
            ->select('cp.publish_ix');
    }

    /**
     * 쿠폰 사용가능 여부 조건처리
     * @param boolean $useYn
     * @return type
     */
    protected function setBasicUseWhere($useYn)
    {
        if ($useYn) { //사용완료 & 기한만료된 쿠폰
            return $this->qb
                ->groupStart()
                ->where('cp.is_use !=', '3')
                ->where('use_yn', 1)
                ->orGroupStart()
                ->where('use_yn', 0)
                ->where("date_format(cr.use_date_limit, '%Y-%m-%d') < date_format('".fb_now()."', '%Y-%m-%d') ", null, false)
                ->where('cp.use_date_type!=', 9)
                ->groupEnd()
                ->groupEnd();
        } else { //사용가능 쿠폰
            return $this->qb
                ->where('use_yn', 0)
                ->where('cp.is_use !=', '3')
                ->groupStart()
                ->groupStart()
                ->where("date_format(cr.use_date_limit, '%Y-%m-%d') >= date_format('".fb_now()."', '%Y-%m-%d') ", null, false)
//                ->betweenColumn("date_format('".fb_now()."', '%Y-%m-%d')", "date_format(cr.use_sdate, '%Y-%m-%d')", "date_format(cr.use_date_limit, '%Y-%m-%d')")
                ->where('cp.use_date_type!=', 9)
                ->groupEnd()
                ->orGroupStart()
                ->where('cp.use_date_type', 9)
                ->groupEnd()
                ->groupEnd();
        }
    }

    /**
     * APP결제 첫 주문 체크
     * @param $status
     * @return bool
     * @throws Exception
     */
    public function getAppFirstOrderChk()
    {
        $count = $this->qb
            ->from(TBL_SHOP_ORDER . ' AS o')
            ->join(TBL_SHOP_ORDER_DETAIL . ' AS od', 'ON o.oid = od.oid')
            ->where('o.user_code', $this->userCode)
            ->where('od.status', ORDER_STATUS_BUY_FINALIZED)
            ->where('o.payment_agent_type', 'A')
            ->getCount('o.oid');
        if ($count == 1) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * 쿠폰정보 조회
     * @param $registIx
     * @return mixed
     * @throws Exception
     */
    public function getCouponInfo($registIx)
    {
        return $this->setBasicSelect()
            ->select("cr.regist_ix")
            ->select("date_format(cr.use_sdate, '%Y-%m-%d') as regist_start, date_format(cr.use_date_limit, '%Y-%m-%d') as regist_end")
            ->from(TBL_SHOP_CUPON_REGIST . ' as cr')
            ->join(TBL_SHOP_CUPON_PUBLISH . ' as cp', 'cr.publish_ix=cp.publish_ix', 'inner')
            ->join(TBL_SHOP_CUPON . ' as c', 'c.cupon_ix=cp.cupon_ix', 'inner')
            ->where('cr.mem_ix', $this->userCode)
            ->where('cr.regist_ix', $registIx)
            ->exec()->getRowArray();
    }

    /**
     * 쿠폰 적용 대상
     * use_product_type = 1: 전체상품, 2 : 카테고리, 3 : 상품, 4: 브랜드, 5: 셀러(업체)
     * @param $registIx
     * @return array
     * @throws Exception
     */
    public function getCouponApplyList($registIx)
    {
        $row = $this->getCouponInfo($registIx);

        $row['regdate'] = change_date_format($row['regdate']);
        $row['publish_limit_date'] = change_date_format($row['publish_limit_date']);
        $row['use_sdate'] = change_date_format($row['use_sdate']);
        $row['use_edate'] = change_date_format($row['use_edate']);
        $row['regist_start'] = change_date_format($row['regist_start']);
        $row['regist_end'] = change_date_format($row['regist_end']);

        if (!empty($row)) {
            if ($row['use_product_type'] == '2') {// 카테고리 상품
                $row['link'] = "/shop/goodsList";
                $categoryRes = $this->qb
                    ->select("t2.cid as id, t2.depth")
                    ->from(TBL_SHOP_CUPON_RELATION_CATEGORY . ' as t1')
                    ->join(TBL_SHOP_CATEGORY_INFO . ' as t2', 't1.cid = t2.cid', 'inner')
                    ->where('t1.publish_ix', $row['publish_ix'])
                    ->orderBy('t1.cid', 'asc')
                    ->exec()
                    ->getResultArray();
                /* @var $productModel CustomMallProductModel */
                $productModel = getForbiz()->import('model.mall.product');
                foreach ($categoryRes as $key => $category){
                    $stepCategory = $productModel->getCategoryPath($category['id'],$category['depth']);
                    $ctArray = [];
                    foreach ($stepCategory as $ct){
                        $ctArray[] = $ct['cname'];
                    }
                    $cname = implode(' > ',$ctArray);
                    $categoryRes[$key]['name'] = $cname;
                }

                $row['plist'] = $categoryRes;

            } elseif ($row['use_product_type'] == '3') {// 특정 상품
                $row['link'] = "/shop/goodsView";
                $row['plist'] = $this->qb
                    ->select("p.pname as name, p.id")
                    ->from(TBL_SHOP_CUPON_RELATION_PRODUCT . ' as cr')
                    ->join(TBL_SHOP_PRODUCT . ' as p', 'cr.pid = p.id', 'inner')
                    ->where('cr.publish_ix', $row['publish_ix'])
                    ->orderBy('p.regdate', 'desc')
                    ->exec()
                    ->getResultArray();

            } elseif ($row['use_product_type'] == '4') { // 브랜드
                $row['link'] = "/brand/brandGoods";
                $row['plist'] = $this->qb
                    ->select("b.b_ix as id")
                    ->select("b.brand_name as name")
                    ->from(TBL_SHOP_CUPON_RELATION_BRAND . ' as rb')
                    ->join(TBL_SHOP_BRAND . ' as b', 'rb.b_ix = b.b_ix', 'inner')
                    ->where('rb.publish_ix', $row['publish_ix'])
                    ->orderBy('rb.crb_ix', 'asc')
                    ->exec()
                    ->getResultArray();
            } elseif ($row['use_product_type'] == '5') { // 셀러
                $row['link'] = "/shop/goodsView";
                $row['plist'] = $this->qb
                    ->select("p.pname as name, p.id")
                    ->from(TBL_SHOP_CUPON_RELATION_SELLER . ' as rs')
                    ->join(TBL_COMMON_COMPANY_DETAIL . ' as ccd', 'rs.company_id = ccd.company_id', 'inner')
                    ->join(TBL_SHOP_PRODUCT . ' as p', 'ccd.company_id = p.admin', 'inner')
                    ->where('rs.publish_ix', $row['publish_ix'])
                    ->orderBy('ccd.regdate', 'desc')
                    ->exec()
                    ->getResultArray();
            }
        }

        return $row;
    }

    public function getCombinationCartNCoupon($products, $coupons)
    {
        $combinationArray = $this->getUseCombinationCoupon($products, $coupons); // 사용가능한 쿠폰 조합 구하기
        $combinationArray = $this->makeCombination($combinationArray); // 나올수 있는 모든 조합 구하기
        $combinationArray = $this->alignCombinationCoupon($combinationArray); // 순열 조합 배열 정리
        $combinationArray = $this->getMaxDiscountCoupon($combinationArray); // 쿠폰조합중 최고로 많이 할인받는 조합 찾기
        return $combinationArray;
    }

    /**
     * 사용가능한 일반쿠폰 조합 구하기
     * @param $products
     * @param $coupons
     * @return array
     */
    private function getUseCombinationCoupon($products, $coupons)
    {
        if(empty($coupons)) return [];

        $combinationArray = [];
        foreach ($coupons as $key2 => $coupon) {
            // 쿠폰 적용 여부
            $coupon['useDone'] = false;

            foreach ($products as $key => $prd) {
                if ($this->checkProductCouponActive($prd['id'], $prd['dcprice'], $coupon)) {
                    // 쿠폰이 한 번 적용 됐다면 적용 불가
                    if ($coupon['useDone'] != true) {
                        $cpDcAmount = $this->calculationDiscount($prd['dcprice'], $coupon)['discount_amount'];

                        if($prd['dcprice'] >= $cpDcAmount) {
                            if($coupon['cupon_sale_type'] == '1') {
                                $dcAmount = $cpDcAmount*$prd['pcount'];
                            } else {
                                $dcAmount = $cpDcAmount;
                            }

                            $combinationArray[] = [
                                'cartIx' => $prd['cart_ix']
                                ,'cupon_div' => $coupon['cupon_div'] // test
                                ,'pid' => $prd['id'] // test
                                ,'publish_name' => $coupon['publish_name'] // test
                                ,'registIx' => $coupon['regist_ix']
                                ,'discount_amount' => (int)$dcAmount
                                ,'view_price' => g_price($dcAmount) // test
                            ];
                            // 쿠폰 적용 완료
                            $coupon['useDone'] = true;
                        }
                    }
                }
            }
        }
        return $combinationArray;
    }

    /**
     * 쿠폰 짝짖기
     * @param $combinationArray
     * @return array
     */
    private function makeCombination($combinationArray, $mode='G')
    {
        if(empty($combinationArray)) return [];

        if ($mode == 'C') {
            $column = 'company_id';
        } else {
            $column = 'cartIx';
        }

        $arr = array_unique(array_column($combinationArray, $column));
        $registIx = array_unique(array_column($combinationArray, 'registIx'));

        $rows = $this->combiarray($arr, $registIx);
        $combination = [];

        foreach($rows as $row) {
            $combination[] = array_map(function($r) use ($combinationArray, $column) {
                foreach($combinationArray as $citem) {
                    if ($r[0] == $citem[$column] && $r[1] == $citem['registIx']) {
                        return $citem;
                    }
                }
            }, $row);
        }
        return $combination;
    }

    public function combiarray($arr1, $arr2)
    {
        $ret = [];
        for($i = 0; $i < count($arr1); $i++) {
            $ret[$i] = $this->cartesian([[$arr1[$i]], $arr2]);
        }
        return $this->get_diff_array($this->cartesian($ret), count($arr2));
    }

    public function cartesian($input) {
        $result = [[]];

        foreach ($input as $key => $values) {
            $append = [];

            foreach($result as $product) {
                foreach($values as $item) {
                    $product[$key] = $item;
                    $append[] = $product;
                }
            }

            $result = $append;
        }

        return $result;
    }

    public function get_diff_array($arr, $ccnt = 0)
    {
        $ret = [];
        foreach($arr as $item) {
            $icnt = count($item);
            $cnt = count(array_unique(array_column($item, 1)));

            if ($cnt == $icnt) {
                $ret[] = $item;
            } else if ($ccnt == $cnt) {
                $ret[] = $item;
            }
        }

        return $ret;
    }

    /**
     * 순열 조합 배열 정리
     * -하위 구성쿠폰 배엻형태를 잡을수 없어 별도함수에서 정리
     * @param $combinationArray
     * @return array
     */
    private function alignCombinationCoupon($combinationArray)
    {
        if(empty($combinationArray)) return [];

        $res = [];

        foreach ($combinationArray as $k => $combination) {
            $tmp = [];
            foreach ($combination as $k2 => $combi){
                if(is_array($combi) && count($combi) == 2){
                    $tmp = array_merge($tmp, $this->getChildArray($combi));
                } else {
                    $tmp[] = $combi;
                }
            }
            $res[] = $tmp;

        }

        return $res;
    }

    /**
     * 쿠폰조합중 최고로 많이 할인받는 조합 찾기
     * @param $combinationArray
     * @return array
     */
    private function getMaxDiscountCoupon($combinationArray)
    {
        if(empty($combinationArray)) return [];

        $combiRes = [];
        foreach ($combinationArray as $key => $combi) {
            $combiRes[$key] = array_sum(array_column($combi, 'discount_amount'));
        }
        $maxDiscountAmount = max($combiRes);
        $maxDiscountKey = array_search($maxDiscountAmount, $combiRes);
        return [
            'combination' => $combinationArray[$maxDiscountKey]
            ,'dcAmount' => $maxDiscountAmount
        ];

    }

    /**
     * 장바구니쿠폰중 최고할인율 쿠폰 찾기
     * @param $totalDcPrice
     * @param $cartCoupon
     * @return array
     */
    public function getMaxDiscountCartCoupon($totalDcPrice, $cartCoupon, $cartCouponExcept)
    {
        $discountInfos = $this->getCartCouponDiscountInfo($totalDcPrice, $cartCoupon, $cartCouponExcept);
        $discountInfos = $this->makeCombination($discountInfos, 'C'); // 나올수 있는 모든 조합 구하기
        $discountInfos = $this->searchMaxDiscountCartCoupon($discountInfos);
        return $discountInfos;
    }

    /**
     * 장바구니쿠폰 할인율 계산
     * @param $totalDcPrice
     * @param $cartCoupon
     * @param $cartCouponExcept
     * @return array
     */
    private function getCartCouponDiscountInfo($originTotalDcPrice, $cartCoupon, $cartCouponExcept)
    {
        if(empty($cartCoupon)) return [];

        $discountInfos = [];
        foreach ($cartCoupon as $coupon) {
            $totalDcPrice = $originTotalDcPrice - $cartCouponExcept[$coupon['regist_ix']];
            if($this->checkCartCouponActive($totalDcPrice, $coupon)){
                $cpDcAmount = $this->calculationDiscount($totalDcPrice, $coupon)['discount_amount'];
                $discount_term = (int)$totalDcPrice - (int)$cpDcAmount;
                if ($discount_term >= 0) {
                    $discountInfos[] = [
                        'publish_name' => $coupon['publish_name'] // test
                        ,'registIx' => $coupon['regist_ix']
                        ,'cupon_div' => $coupon['cupon_div']
                        ,'discount_amount' => (int)$cpDcAmount
                        ,'company_id' => ''
                        ,'cart' => 'cart'
                        ,'discount_term' => $discount_term
                        ,'view_price' => g_price($cpDcAmount) // test
                    ];
                }
            }

        }

        return $discountInfos;
    }

    /**
     * 최고 할인율 장바구니쿠폰 찾기
     * @param $cartCoupons
     * @return array
     */
    private function searchMaxDiscountCartCoupon($cartCoupons)
    {
        if(empty($cartCoupons)) return [];
        $combiRes = [];
        foreach ($cartCoupons as $key => $combi) {
            $combiRes[$key] = $combi[0]['discount_amount'];//array_sum(array_column($combi, 'discount_amount'));
        }

        $maxDiscountAmount = max($combiRes);
        $maxDiscountKey = array_search($maxDiscountAmount, $combiRes);
        return [
            'combination' =>$cartCoupons[$maxDiscountKey]
            ,'dcAmount' => $maxDiscountAmount
        ];
    }

    /**
     * 해당 장바구니 쿠폰 사용 가능 여부
     * @param type $unitPrice
     * @param type $couponData
     * @return boolean
     */
    protected function checkCartCouponActive($unitPrice, $couponData)
    {
        $unitPrice = f_decimal($unitPrice);
        $publishMin = $couponData['publish_min'];
        $publishMax = $couponData['publish_max'];
        $cuponUseDiv = $couponData['cupon_use_div'];
        $publishConditionPrice = f_decimal($couponData['publish_condition_price']);
        $publishLimitPrice = f_decimal($couponData['publish_limit_price']);

        //상품 금액이 0일면 X
        if ($unitPrice == 0) {
            return false;
        }

        //쿠폰 혜택 제한 (최소 상품금액)
        if ($publishMin == 'Y' && $unitPrice < $publishConditionPrice) {
            return false;
        }
        //쿠폰 혜택 제한 (최대 할인금액)
        /*if ($publishMax == 'Y' && $unitPrice > $publishLimitPrice) {
            return false;
        }*/

        if($cuponUseDiv != 'A') {
            if(is_mobile()) {
                if(getAppType() !== false && $cuponUseDiv != 'MA') {
                    return false;
                } elseif(getAppType() === false && $cuponUseDiv != 'M') {
                    return false;
                }
            } else {
                if($cuponUseDiv != 'G') {
                    return false;
                }
            }
        }

        return true;
    }

    /**
     * 하위배열 리턴
     */
    private function getChildArray($array)
    {
        if(empty($array)) return $array;
        $res = [];
        if(count($array[1]) == 2) {
            $res[] = $array[0];
            $res = array_merge($res, $this->getChildArray($array[1]));
        } else {
            $res = $array;
        }
        return $res;
    }

    /**
     * 하위로 조합될 쿠폰 조회
     * @param $array
     * @param $firstKey
     * @param $mode
     * @return array|null
     */
    private function getCombiChild($array, $firstKey, $mode)
    {
        if(!isset($array[$firstKey])) {
            return null;
        }

        $firstVal = $array[$firstKey];
        $combination = [];
        if($mode == 'C') {
            $field = 'company_id';
        }else {
            $field = 'cartIx';
        }
        foreach ($array as $key => $val) {
            if($val[$field] == $firstVal[$field]
                || $val['registIx'] == $firstVal['registIx']
            ) continue;

            $combination[] = $val;
        }

        $mate = $this->getCombiChild($combination, 0, $mode);
        $return = [];
        if(empty($mate)){
            $return = $firstVal;
        } else {
            array_push($return, $firstVal, $mate);
        }

        return $return;

    }

    /**
     * 해당 장바구니 쿠폰 상품 사용 가능 여부
     * @param type $pid
     * @param type $unitPrice
     * @param type $couponData
     * @return boolean
     */
    public function checkCartCouponProductActive($pid, $couponData)
    {
        $publishIx = $couponData['publish_ix'];
        $useProductType = $couponData['use_product_type'];

        $activeBool = false;

        //사용가능상품
        switch ($useProductType) {
            case'1': //전체
                $this->qb
                    ->select('p.id')
                    ->from(TBL_SHOP_PRODUCT." AS p")
                    ->where('p.id', $pid);
                break;
            case'2': //카테고리
                $this->qb
                    ->select('crc.publish_ix')
                    ->from(TBL_SHOP_CUPON_RELATION_CATEGORY . ' as crc')
                    ->join(TBL_SHOP_PRODUCT_RELATION . ' as pr', 'SUBSTRING(crc.cid,1,(crc.depth+1)*3) = SUBSTRING(pr.cid,1,(crc.depth+1)*3)', 'inner')
                    ->join(TBL_SHOP_PRODUCT." as p", 'p.id = pr.pid', 'inner')
                    ->where('crc.publish_ix', $publishIx)
                    ->where('pr.pid', $pid);
                break;
            case'3': //상품
                $this->qb
                    ->select('crp.publish_ix')
                    ->from(TBL_SHOP_CUPON_RELATION_PRODUCT . ' as crp')
                    ->join(TBL_SHOP_PRODUCT." as p", 'p.id = crp.pid', 'inner')
                    ->where('crp.publish_ix', $publishIx)
                    ->where('crp.pid', $pid);
                break;
            case'4': //브랜드
                $this->qb
                    ->select('crb.publish_ix')
                    ->from(TBL_SHOP_CUPON_RELATION_BRAND . ' as crb')
                    ->join(TBL_SHOP_PRODUCT . ' as p', 'p.brand=crb.b_ix', 'inner')
                    ->where('crb.publish_ix', $publishIx)
                    ->where('p.id', $pid);
                break;
            case'5': //셀러
                $this->qb
                    ->select('crs.publish_ix')
                    ->from(TBL_SHOP_CUPON_RELATION_SELLER . ' as crs')
                    ->join(TBL_SHOP_PRODUCT . ' as p', 'crs.company_id=p.admin', 'inner')
                    ->where('crs.publish_ix', $publishIx)
                    ->where('p.id', $pid);
                break;
            default :
                return false;
                break;
        }

        $total = $this->qb
            ->where('p.coupon_use_yn','Y') // 사용가능 쿠폰만 검색
            ->limit(1)->getCount();

        if ($total > 0) {
            $activeBool = true;
        }


        return $activeBool;
    }

    /**
     * 쿠폰자동적용 최종결과 리턴배열 만들기
     * 일반상품 할인율이 더 클경우 일반상품 할인쿠폰정보 return
     * 장바구니 할인율이 더 클경우 장바구니 쿠폰정보 return
     * @param $coupons
     * @param $cartCoupons
     * @return array
     */
    public function alignMaxCouponInfo($coupons, $cartCoupons)
    {
        if (empty($coupons) && empty($cartCoupons)){ // 모든쿠폰 없는경우
            return [];
        } elseif (!empty($coupons) && empty($cartCoupons)) { // 상품쿠폰만 있는경우
            return $this->returnMaxDiscountCoupon($coupons, $cartCoupons, 'G');
        }  elseif (empty($coupons) && !empty($cartCoupons)) { // 장바구니쿠폰만 있는경우
            return $this->returnMaxDiscountCoupon($coupons, $cartCoupons, 'C');
        } else {
            if ($coupons['dcAmount'] < $cartCoupons['dcAmount']) {
                // 장바구니할인율이 더 클 경우
                return $this->returnMaxDiscountCoupon($coupons, $cartCoupons, 'C');
            } else {
                // 상품쿠폰 할인율이 더 클 경우
                return $this->returnMaxDiscountCoupon($coupons, $cartCoupons, 'G');
            }
        }


    }

    private function returnMaxDiscountCoupon($coupons, $cartCoupons, $mode)
    {
        $tmpCoupons = [];
        if ($mode == 'C') {
            $field = 'cart';
            $couponArray = $cartCoupons;
        } else {
            $field = 'cartIx';
            $couponArray = $coupons;
        }

        foreach ($couponArray['combination'] as $cp) {
            if($cp['cupon_div'] == 'A'){
                $mode = 'A';
            }
            $tmpCoupons[$cp[$field]] = $cp['registIx'];
        }
        return [
            'type' => $mode
            ,'coupons' => $tmpCoupons
        ];
    }

    /**
     * 해당 상품의 보유쿠폰 적용 정보 리스트
     * @param $price
     * @param array $productList
     * @return array
     */
    public function applyCartUserCouponList($price, $productList = [])
    {
        $rows = $this->getUserCouponList(false, 0, 0
            ,
            ['cr.regist_ix', 'cp.use_product_type', 'c.cupon_acnt', 'c.haddoffice_rate', 'c.seller_rate', 'c.round_position', 'c.round_type', 'cp.publish_max',
                'cp.publish_limit_price', 'cp.publish_min', 'cp.publish_condition_price', 'c.cupon_div']
            , ['c.cupon_div' => ['C', 'A']])['list'];

        //$myCouponList = ($rows['list'] ?? []);
        $myCouponList = ($rows ?? []);
        $returnCouponList = [];

        if (!empty($myCouponList)) {
            $cartCouponExcept = [];
            $isUsableCoupon = false;
            foreach ($myCouponList as $key => $coupon) {
                $cartCouponExcept[$coupon['regist_ix']] = 0;
                foreach ($productList as $product) {
                    $isUsableCoupon = true;

                    $productActiveBool = $this->checkCartCouponProductActive($product['id'], $coupon);
                    if (!$productActiveBool) {
                        $cartCouponExcept[$coupon['regist_ix']] += $product['total_coupon_with_dcprice'];
                    }
                }
            }

            if($isUsableCoupon === true) {
                foreach ($myCouponList as $key => $coupon) {
                    $targetPrice = $price - $cartCouponExcept[$coupon['regist_ix']];

                    $activeBool = $this->checkCartCouponActive($targetPrice, $coupon);
                    if ($activeBool) {
                        $coupon['discount_amount'] = $this->calculationDiscount($targetPrice, $coupon)['discount_amount'];
                        $coupon['total_coupon_with_dcprice'] = $targetPrice - $coupon['discount_amount'];
                    }
                    $coupon['activeBool'] = $activeBool;
                    if(!isset($returnCouponList[$coupon['publish_ix']])){
                        $returnCouponList[$coupon['publish_ix']] = $coupon;
                    }

                }
            }
        }
        return $returnCouponList;
    }

    /**
     * 카트에서 장바구니 쿠폰 사용 리스트 처리
     * @param type $regist_ix
     * @param type $price
     * @param $productList
     * @return array|bool
     */
    public function applyCartCoupon($regist_ix, $price, $productList)
    {

        $coupon = ($this->getUserCouponList(false, 1, 100
                , [
                    'cr.regist_ix',
                    'cp.use_product_type',
                    'c.cupon_acnt',
                    'c.haddoffice_rate',
                    'c.seller_rate',
                    'c.round_position',
                    'c.round_type',
                    'cp.publish_max',
                    'cp.publish_limit_price'
                ]
                , ['c.cupon_div' => ['C', 'A'], 'cr.regist_ix' => $regist_ix])['list'][0] ?? false);

        //내 쿠폰인지 아닐경우
        if ($coupon === false) {
            return false;
        } else {
            $cartCouponExcept = f_decimal(0);
            $permitPid = [];
            $lastInfo = [];
            $productCnt= count($productList);
            foreach ($productList as $key => $product) {
                $productActiveBool = $this->checkCartCouponProductActive($product['id'], $coupon);
                if ($productActiveBool) {
                    $permitPid[] = $product['id'];
                } else {
                    $cartCouponExcept += $product['total_coupon_with_dcprice'];
                }
                if ($key == $productCnt - 1) {
                    $lastInfo['pid'] =  $product['id'];
                    $lastInfo['index'] = $key;
                }
            }

            $targetPrice = $price - $cartCouponExcept;
            $activeBool = $this->checkCartCouponActive($targetPrice, $coupon);
            if ($activeBool) {
                return array_merge($this->calculationDiscount($targetPrice, $coupon)
                    , ['targetPrice' => $targetPrice, 'permitPid' => $permitPid, 'lastInfo' => $lastInfo]);
            } else {
                return false;
            }
        }
    }

    /**
     * 해당 상품의 보유쿠폰 적용가능한 할인 정보 리스트
     * @param type $pid
     * @param type $unitPrice
     * @param type $paymentPrice
     * @return type
     */
    public function applyProductUserDiscountCouponList($pid, $dcPrice)
    {
        /* @var $productModel CustomMallProductModel */
        $productModel = $this->import('model.mall.product');

        $myCouponList = $this->getUserCouponList(false, 1, 100
            , [
                'cr.regist_ix',
                'cp.use_product_type',
                'c.cupon_acnt',
                'c.haddoffice_rate',
                'c.seller_rate',
                'c.round_position',
                'c.round_type',
                'cp.publish_max',
                'cp.publish_limit_price',
                'c.cupon_sale_type',
                'cp.publish_ix',
                'c.cupon_sale_value'
            ]
            , ['c.cupon_div' => ['G', 'A']])['list'];
        foreach ($myCouponList as $key => $coupon) {

            $coupon['activeBool'] = $this->checkProductCouponActive($pid, $dcPrice, $coupon);

            $myCouponList[$key] = $coupon;
        }

        return $myCouponList;
    }
}
