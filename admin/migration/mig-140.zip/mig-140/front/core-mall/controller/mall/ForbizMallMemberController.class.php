<?php

/**
 * Description of ForbizMallMemberController
 *
 * @author hoksi
 *
 * @property CustomMallMemberModel $memberModel 회원 관련 모델 Object
 */
class ForbizMallMemberController extends ForbizMallController
{
    protected $memberModel;

    public function __construct()
    {
        parent::__construct();

        // mall member model Load
        $this->memberModel = $this->import('model.mall.member');
        $this->snsLoginModel = $this->import('model.mall.snsLogin');

        if(defined('DEFAULT_GPIX') === false) {
            $gp_ix = $this->memberModel->getBasicGroupInfo();
            
            if(!empty($gp_ix)) {
                define('DEFAULT_GPIX', $gp_ix);
            }else {
                define('DEFAULT_GPIX', 1); // 기본회원 등급
            }
        }
    }

    /**
     * 로그인
     */
    public function login()
    {
        ////////////////////////////
        // 마스터 DB로 처리 START //
        start_master_db();
        ////////////////////////////

        if (form_validation(['userId', 'userPw'])) {
            // Login
            $result = $this->memberModel->doLogin(
                $this->input->post('userId'), $this->input->post('userPw'), $this->input->post('autoLogin'), $this->input->post('saveId'),
                $this->input->post('url', true)
            );

            if (is_array($result)) {
                $this->setResponseResult('success')->setResponseData($result);
            } else {
                $this->setResponseResult($result);
            }
        } else {
            $this->setResponseResult("fail")->setResponseData(validation_errors());
        }

        ///////////////////////////
        // 마스터 DB로 처리 END //
        end_master_db();
        ///////////////////////////
    }

    /**
     * 비회원(주문조회)
     */
    public function nonMemberLogin()
    {
        $chkField = ['buyerName', 'orderId', 'orderPassword'];

        if (form_validation($chkField)) {
            $result = $this->memberModel->doNonMemberlogin(
                $this->input->post('orderId'), $this->input->post('buyerName'), $this->input->post('orderPassword')
            );

            // 결과 확인
            if (isset($result['oid'])) {
                $this->memberModel->setNonMemberSession($result);
                $this->setResponseResult('success')->setResponseData([
                    'url' => '/mypage/orderHistory'
                ]);
            } else {
                $this->setResponseResult('fail');
            }
        } else {
            $this->setResponseResult('fail')->setResponseData(validation_errors());
        }
    }

    /**
     * 사용자 비밀번호를 확인한다.
     */
    public function validatePassword()
    {
        if (is_login()) {
            // 비밀번호 확인 요청 타입
            $reconfirmType = $this->getFlashData('passReconfirmType');

            if ($reconfirmType != '') {
                $chkFiled = ['pass'];

                if (form_validation($chkFiled)) {
                    $res = $this->memberModel->checkUserPassword(sess_val('user', 'code'), $this->input->post('pass'));

                    if ($res) {
                        $this->setFlashData('reconfirmPassMode', $reconfirmType);
                        $this->setResponseResult('success')->setResponseData($reconfirmType);
                    } else {
                        $this->setFlashData('passReconfirmType', $reconfirmType);
                        $this->setResponseResult('notMatch');
                    }
                } else {
                    $this->setResponseResult('fail')->setResponseData(validation_errors());
                }
            } else {
                $this->setResponseResult('noReconfirmType');
            }

        } else {
            $this->setResponseResult('needLogin');
        }
    }

    /**
     * 회원탈퇴를 진행한다.
     */
    public function withdraw()
    {
        if (is_login()) {
            $chkField = ['withdrawCode', 'drop_ix'];
            if (form_validation($chkField)) {
                if ($this->getFlashData('withdrawCode') == $this->input->post('withdrawCode')) {
                    // 회원탈퇴 필요정보 설정
                    $withdrawData = $this->input->post();
                    $withdrawData['code'] = sess_val('user', 'code');
                    $withdrawData['name'] = sess_val('user', 'name');
                    $withdrawData['id'] = sess_val('user', 'id');
                    $withdrawData['mail'] = sess_val('user', 'mail');
                    $withdrawData['pcs'] = sess_val('user', 'pcs');
                    $withdrawData['mem_type'] = sess_val('user', 'mem_type');

                    // 삭제전 조회
                    $member = $this->qb->from(TBL_COMMON_USER)
                        ->where('code', $withdrawData['code'])
                        ->exec()
                        ->getRowArray();

                    // 회원탈퇴
                    $ret = $this->memberModel->withdrawMember($withdrawData);

                    if ($ret == 'hasOrder') {
                        $this->setFlashData('withdrawCode', $this->input->post('withdrawCode'));
                        $this->setResponseResult('hasOrder');
                    } else {
                        // 회원탈퇴 마일리지 로그
                        $mileageModel = $this->import('model.mall.mileage');
                        if ($member) {
                            if ($member['mileage'] > 0) {
                                $mileageModel->useMileage($member['mileage'], 6, "회원 탈퇴로 인한 잔여마일리지 소멸");
                            }
                        }

                        $this->memberModel->doLogout();
                        $this->setResponseResult('success')->setResponseData($ret);
                    }
                } else {
                    $this->setResponseResult('invalidwithdrawCode');
                }
            } else {
                $this->setResponseResult('fail')->setResponseData(validation_errors());
            }
        } else {
            $this->setResponseResult('needLogin');
        }
    }

    /**
     * 사용자정보를 수정한다.
     */
    public function modifyProfile()
    {
        if (is_login()) {
            $mem_type = sess_val('user', 'mem_type');

            if ($mem_type == 'C') {
                // 업체회원
                $chkField = [
                    'com_tel1', 'com_tel2', 'com_tel3', 'com_zip', 'com_addr1', 'com_addr2',
                    'comEmail', 'com_pcs1', 'com_pcs2', 'com_pcs3',
                    'name', 'userEmail'
                ];

                if ($this->input->post('pcs1') != '') {
                    $chkField[] = 'pcs2';
                    $chkField[] = 'pcs3';
                } else {
                    $chkField[] = 'pcs';
                }
            } else {
                // 일반회원
                $chkField = ['userEmail', 'pcs1', 'pcs2', 'pcs3'];
            }

            if (form_validation($chkField)) {
                if ($mem_type == 'C') {
                    $res = $this->memberModel->doModifyProfile($this->input->post(), sess_val('user', 'company_id'));
                } else {
                    $res = $this->memberModel->doModifyProfile($this->input->post());
                }

                // 개인정보 동의 로그 이벤트 전파
                if (is_array($this->input->post('policy'))) {
                    foreach ($this->input->post('policy') as $piIx) {
                        $this->event->emmit('insertAgreementHistory',
                            [
                                'piIx' => $piIx,
                                'userCode' => sess_val('user', 'code'),
                                'userId' => sess_val('user', 'id'),
                                'name' => sess_val('user', 'name'),
                                'memType' => sess_val('user', 'mem_type')
                            ]);
                    }
                }

                $this->setResponseResult('success')->setResponseData($res);
            } else {
                $this->setResponseResult('fail')->setResponseData(validation_errors());
            }
        } else {
            $this->setResponseResult('needLogin');
        }
    }

    /**
     * 휴면회원 인증
     */
    public function nextSleepMemberReleaseAuth()
    {
        if (is_login()) {
            // Next step
            $this->setFlashData('sleepStep', 'auth');
            $this->setResponseResult('success');
        } else {
            $this->setResponseResult('needLogin');
        }
    }

    /**
     * 휴면회원 약관동의(일반)
     */
    public function nextSleepMemberReleasePolicyBasic()
    {
        if (is_login()) {
            $authData = $this->memberModel->getAuthSessionData();

            if (empty($authData['ci'])) {
                $this->setResponseResult('fail');
            } else {
                // Next step
                $this->setFlashData('sleepStep', 'policy');
                $this->setResponseResult('success');
            }
        } else {
            $this->setResponseResult('needLogin');
        }
    }

    /**
     * 휴면회원 약관동의(사업자)
     */
    public function nextSleepMemberReleasePolicyCompany()
    {
        // 로그인 확인
        if (is_login()) {
            $chkField = ['comName', 'comNumber1', 'comNumber2', 'comNumber3'];
            if (form_validation($chkField)) {
                $comNumber = $this->input->post('comNumber1') . '-' . $this->input->post('comNumber2') . '-' . $this->input->post('comNumber3');
                $comData = $this->memberModel->getCompanyData(sess_val('user', 'company_id'));

                if ($comData['com_name'] == $this->input->post('comName') && $comData['com_number'] == $comNumber) {
                    // Next step
                    $this->setFlashData('sleepStep', 'policy');

                    $this->setResponseResult('success')->setResponseData(['companyId' => sess_val('user', 'company_id')]);
                } else {
                    // 사업자 정보 맞지 않음
                    $this->setResponseResult('noMatchData');
                }
            } else {
                $this->setResponseResult('fail')->setResponseData(validation_errors());
            }
        } else {
            $this->setResponseResult('needLogin');
        }
    }

    /**
     * 휴면회원 비밀번호 변경
     */
    public function nextSleepMemberReleaseChangePassword()
    {
        if (is_login()) {
            $chkField = ['policyIx[]'];

            if (form_validation($chkField)) {
                foreach ($this->input->post('policyIx') as $ix => $val) {
                    $this->memberModel->insertAgreementHistory($ix, sess_val('user', 'code'), sess_val('user', 'id'), sess_val('user', 'name'), 'M');
                }

                //비밀번호 변경 권한 set
                $this->memberModel->setChangePasswordAccessSessionType('sleep');
                $this->memberModel->setChangePasswordAccessSessionUserCode(sess_val('user', 'code'));

                // Next step
                $this->setFlashData('sleepStep', 'password');
                $this->setResponseResult('success');
            } else {
                $this->setResponseResult('fail')->setResponseData(validation_errors());
            }
        } else {
            $this->setResponseResult('needLogin');
        }
    }

    /**
     * 가입 회원 타입을 선택한다.
     */
    public function joinSelectType()
    {
        if (form_validation(['joinType'])) {
            $result = $this->memberModel->setJoinSessionType($this->input->post('joinType', true)) ? 'success' : 'error';
            $this->setResponseResult($result);
        } else {
            $this->setResponseResult('fail');
        }
    }

    /**
     * 회원 약관 및 정보 수신 수락 선택
     */
    public function joinAgreePolicy()
    {
        if (form_validation(['policyIx[]'])) {
            $agreePolicyIxList = $this->input->post('policyIx');
            $receiveData = [
                'email' => $this->input->post('email'),
                'sms' => $this->input->post('sms')
            ];

            $setData = array();
            if (is_array($agreePolicyIxList)) {
                foreach ($agreePolicyIxList as $ix => $val) {
                    if ($val == "Y") {
                        $setData[] = $ix;
                    }
                }
            }

            $this->memberModel->setJoinSessionAgreePolicy($setData);
            $this->memberModel->setJoinSessionReceive($receiveData);

            $this->setResponseResult('success');
        } else {
            $this->setResponseResult('fail');
        }
    }

    /**
     * 회원 아이디 체크
     */
    public function userIdCheck()
    {
        ////////////////////////////
        // 마스터 DB로 처리 START //
        start_master_db();
        ////////////////////////////
        if (form_validation(['userId']) == false || $this->memberModel->checkUserId($this->input->post('userId')) === false) {
            $this->setResponseResult('fail')->setResponseData(validation_errors());
        } else {
            $this->setResponseResult('success');
        }
        ///////////////////////////
        // 마스터 DB로 처리 END //
        end_master_db();
        ///////////////////////////
    }

    /**
     * 일반회원 이메일 체크
     */
    public function emailCheck()
    {
        ////////////////////////////
        // 마스터 DB로 처리 START //
        start_master_db();
        ////////////////////////////

        $email = $this->input->post('email');
        $chk_email = preg_match("/^[_\.0-9a-zA-Z-]+@([0-9a-zA-Z][0-9a-zA-Z-]+\.)+[a-zA-Z]{2,6}$/i", $email);
        if ($chk_email) {
            if ($this->memberModel->checkEmail($email) === false) {
                $this->setResponseResult('fail');
            } else {
                $this->setResponseResult('success');
            }
        } else {
            $this->setResponseResult('wrongEmail');
        }

        ///////////////////////////
        // 마스터 DB로 처리 END //
        end_master_db();
        ///////////////////////////
    }

    /**
     * 업체회원 이메일 체크
     */
    public function companyEmailCheck()
    {
        if (form_validation(['email']) == false || $this->memberModel->checkCompanyEmail($this->input->post('email')) === false) {
            $this->setResponseResult('fail');
        } else {
            $this->setResponseResult('success');
        }
    }

    /**
     * 일반 회원 가입
     */
    public function joinInputBasic()
    {
        ////////////////////////////
        // 마스터 DB로 처리 START //
        start_master_db();
        ////////////////////////////

        // 입력 필수 항목
        $chekField = [
            'userId', 'pw', 'comparePw',
            'email',
            'pcs1', 'pcs2', 'pcs3',
        ];

        // 필수 항목 점검
        if (form_validation($chekField)) {
            $memberRegRule = ForbizConfig::getSharedMemory("member_reg_rule");

            // 인증데이타
            $authData = $this->memberModel->getAuthSessionData();
            //가입 데이터 (type, policy, receive)
            $joinData = $this->memberModel->getJoinSession();

            /*
             * 아이디 중복 체크
             * 일반 회원인지 확인
             * 인증 데이터 체크
             * 가입 데이터 (type, policy, receive) 체크
             */
            if (!$this->memberModel->checkUserId($this->input->post('userId'))) {
                $this->setResponseResult('doubleId');
            } elseif (!isset($joinData['type']) || $joinData['type'] != 'B') {
                $this->setResponseResult('sessionIssue');
            } elseif (empty($authData['ci']) && ($memberRegRule['mall_use_certify'] == 'Y' || $memberRegRule['mall_use_sso'] == 'Y')) {
                $this->setResponseResult('authIssue');
            } else {
                if(is_mobile() == 'M'){
                    $birthday1 = str_pad($this->input->post('birthday1'), 4, "0", STR_PAD_RIGHT);
                    $birthday2 = str_pad($this->input->post('birthday2'), 2, "0", STR_PAD_LEFT);
                    $birthday3 = str_pad($this->input->post('birthday3'), 2, "0", STR_PAD_LEFT);
                    $birthday = $birthday1.'-'.$birthday2.'-'.$birthday3;
                }else{
                    $birthday = $this->input->post('birthday');
                }

                if($memberRegRule['mall_use_certify'] == "Y" || $memberRegRule['mall_use_sso'] == "Y" ){
                    $name = $authData['name'];
                    $birthday = $authData['birthday'];
                    if(isset($authData['birthdayDiv']) && $authData['birthdayDiv']){
                        $birthdayDiv = $authData['birthdayDiv'];
                    }else{
                        $birthdayDiv = $this->input->post('birthdayDiv');
                    }
                    $pcs = $authData['pcs'];
                    if(isset($authData['sexDiv']) && $authData['sexDiv']){
                        $sexDiv = $authData['sexDiv'];
                    }else{
                        $sexDiv = $this->input->post('sexDiv');
                    }

                }else{
                    $name = $this->input->post('name');
                    $birthday = $birthday;
                    $birthdayDiv = $this->input->post('birthdayDiv');
                    $pcs = $this->input->post('pcs1') . '-' . $this->input->post('pcs2') . '-' . $this->input->post('pcs3');
                    $sexDiv = $this->input->post('sexDiv');
                }

                $registData['userId'] = $this->input->post('userId');
                $registData['pw'] = $this->input->post('pw');
                $registData['authorized'] = ($memberRegRule['auth_type'] != "A" ? 'N' : 'Y'); //자동 승인 여부
                $registData['agentType'] = (is_mobile() ? 'M' : 'W');
                $registData['name'] = $name;
                $registData['ci'] = (!empty($authData['ci']) ? $authData['ci'] : "");
                $registData['di'] = (!empty($authData['di']) ? $authData['di'] : "");
                $registData['birthday'] = $birthday;
                $registData['birthdayDiv'] = $birthdayDiv;
                $registData['email'] = $this->input->post('email');
                $registData['info'] = $joinData['receive']['email'];
                $registData['pcs'] = $pcs;
                $registData['sms'] = $joinData['receive']['sms'];
                $registData['tel'] = $this->input->post('tel1') . '-' . $this->input->post('tel2') . '-' . $this->input->post('tel3');
                $registData['sexDiv'] = $sexDiv;
                $registData['zip'] = $this->input->post('zip');
                $registData['addr1'] = $this->input->post('addr1');
                $registData['addr2'] = $this->input->post('addr2');
                $registData['gpIx'] = DEFAULT_GPIX;
                $registData['date'] = date('Y-m-d H:i:s');
                $registData['change_pw_date'] = date('Y-m-d H:i:s');

                // 회원 가입
                $userCode = $this->memberModel->registMember($registData);
                $registData['code'] = $userCode;

                // 각 sns 매핑는 개발서버에 배포 후 세션으로 처리 작업필요
               if (!empty(sess_val('sns_login', 'naver'))) {
                    $this->snsLoginModel->updateSnsInfo($userCode);
                }
                if (!empty(sess_val('sns_login', 'kakao'))) {
                    $this->snsLoginModel->updateSnsInfo($userCode);
                }
                if (!empty(sess_val('sns_login', 'facebook'))) {
                    $this->snsLoginModel->updateSnsInfo($userCode);
                }
                if (!empty(sess_val('sns_login', 'apple'))) {
                    $this->memberModel->registSnsMember($this->input->post('devAppleId'), 'apple', $userCode);
                }
                if (!empty(sess_val('sns_login', 'google'))) {
                    $this->memberModel->registSnsMember(sess_val('sns_login','google', 'sns_info', 'id'), 'google', $userCode);
                }

                // UserCode set
                $this->setFlashData('userCode', $userCode);

                // 세션 데이타 삭제
                $this->memberModel->resetAuthSession();
                $this->memberModel->resetJoinSession();
                $this->memberModel->resetSnsInfoSession();

                // 개인정보 동의 로그
                if (is_array($joinData['policy'])) {
                    foreach ($joinData['policy'] as $piIx) {
//                        해당 부분은 이벤트가 아닌 바로 모델로 처리 필요
//                        $this->event->emmit('insertAgreementHistory', [
//                            'piIx' => $piIx,
//                            'userCode' => $userCode,
//                            'userId' => $registData['userId'],
//                            'name' => $registData['name'],
//                            'memType' => 'M'
//                        ]);
                    }
                }

                // 자동승인 여부에 따라 로그인 처리
                if ($registData['authorized'] == 'Y') {
                    $this->setFlashData('doLoginInfo',
                        [
                            'userId' => $registData['userId'],
                            'userPw' => $registData['pw']
                        ]);
                }

                return ['user' => $registData];
            }
        } else {
            log_message('error', validation_errors());
            $this->setResponseResult('fail')->setResponseData(validation_errors());
        }
        ///////////////////////////
        // 마스터 DB로 처리 END //
        end_master_db();
        ///////////////////////////
    }

    /**
     * 사업자 인증
     */
    public function authenticationCompany()
    {
        ////////////////////////////
        // 마스터 DB로 처리 START //
        start_master_db();
        ////////////////////////////

        // 입력 필수 항목
        // 입력 필수 항목
        $chkField = ['comName', 'comNumber1', 'comNumber2', 'comNumber3'];

        // 필수 항목 점검
        if (form_validation($chkField)) {
            $comNumber = $this->input->post('comNumber1', true) . '-' . $this->input->post('comNumber2', true) . '-' . $this->input->post('comNumber3', true);

            // 등록된 사업자번호인지 확인
            if (!$this->memberModel->checkCompanyNumber($comNumber)) {
                $this->setResponseResult('doubleCompanyNumber');
            } else {
                $this->memberModel->setJoinSessionCompany([
                    'name' => $this->input->post('comName'),
                    'number' => $comNumber,
                ]);
            }
        } else {
            log_message('error', validation_errors());
            $this->setResponseResult('fail')->setResponseData(validation_errors());
        }

        ///////////////////////////
        // 마스터 DB로 처리 END //
        end_master_db();
        ///////////////////////////
    }

    /**
     * 사업자 회원 가입
     */
    public function joinInputCompany()
    {
        ////////////////////////////
        // 마스터 DB로 처리 START //
        start_master_db();
        ////////////////////////////

        $chkField = [
            'userId', 'pw', 'comparePw',
            'comPhone1', 'comPhone2', 'comPhone3',
            'comZip', 'comAddr1', 'comAddr2',
            'comCeo', 'comEmail',
            'comPcs1', 'comPcs2', 'comPcs3',
            'userName', 'email'
        ];

        // upload file 점검
        if (!isset($_FILES['businessFile']['name'])) {
            $chkField[] = 'businessFile';
        }

        if (form_validation($chkField)) {
            //인증 데이터
            $authData = $this->memberModel->getAuthSessionData();
            //가입 데이터 (type, policy, receive)
            $joinData = $this->memberModel->getJoinSession();

            $memberRegRule = ForbizConfig::getSharedMemory('member_reg_rule');

            /*
             * 아이디 중복 체크
             * 사업자 회원 체크
             * 인증 데이터 체크
             */
            if (!$this->memberModel->checkUserId($this->input->post('userId'))) {
                $this->setResponseResult('doubleId');
            } elseif (!isset($joinData['type']) || $joinData['type'] != 'C') {
                $this->setResponseResult('sessionIssue');
            } elseif (empty($authData['ci']) && ($memberRegRule['mall_use_certify'] == 'Y' || $memberRegRule['mall_use_ipin'] == 'Y')) {
                $this->setResponseResult('authIssue');
            } else {
                $memberRegRule = ForbizConfig::getSharedMemory('member_reg_rule');

                //company set
                $companyRegistData = [];
                $companyRegistData['comName'] = $joinData['company']['name'];
                $companyRegistData['comCeo'] = $this->input->post('comCeo');
                $companyRegistData['comEmail'] = $this->input->post('comEmail');
                $companyRegistData['comNumber'] = $joinData['company']['number'];
                $companyRegistData['comPhone'] = $this->input->post('comPhone1') . '-' . $this->input->post('comPhone2') . '-' . $this->input->post('comPhone3');
                $companyRegistData['comMobile'] = $this->input->post('comPcs1') . '-' . $this->input->post('comPcs2') . '-' . $this->input->post('comPcs3');
                $companyRegistData['comZip'] = $this->input->post('comZip');
                $companyRegistData['comAddr1'] = $this->input->post('comAddr1');
                $companyRegistData['comAddr2'] = $this->input->post('comAddr2');

                //사업자 가입
                $companyId = $this->memberModel->registCompany($companyRegistData);

                //user set
                $registData = [];
                $registData['companyId'] = $companyId;
                $registData['memType'] = 'C';
                $registData['requestInfo'] = 'C';
                $registData['userId'] = $this->input->post('userId');
                $registData['pw'] = $this->input->post('pw');
                $registData['authorized'] = ($memberRegRule['b2b_auth_type'] == "A" ? 'Y' : 'N');
                $registData['agentType'] = (is_mobile() ? 'M' : 'W');
                $registData['name'] = $this->input->post('userName');
                $registData['ci'] = $authData['ci'] ?? '';
                $registData['di'] = $authData['di'] ?? '';
                $registData['birthday'] = $authData['birthday'] ?? '';
                $registData['birthdayDiv'] = $authData['birthdayDiv'] ?? '';
                $registData['email'] = $this->input->post('email');
                $registData['info'] = $joinData['receive']['email'];
                $registData['pcs'] = $authData['pcs'] ?? '';
                $registData['sms'] = $joinData['receive']['sms'];
                $registData['tel'] = '';
                $registData['sexDiv'] = $authData['sexDiv'] ?? '';
                $registData['gpIx'] = DEFAULT_GPIX;
                $registData['date'] = date('Y-m-d H:i:s');

                // 회원 등록
                $userCode = $this->memberModel->registMember($registData);

                $registData['code'] = $userCode;

                // UserCode set
                $this->setFlashData('userCode', $userCode);

                // 세션 데이타 삭제
                $this->memberModel->resetAuthSession();
                $this->memberModel->resetJoinSession();

                // 개인정보 동의 로그
                if (is_array($joinData['policy'])) {
                    foreach ($joinData['policy'] as $piIx) {
//                        해당 부분은 이벤트가 아닌 바로 모델로 처리 필요
//                        $this->event->emmit('insertAgreementHistory', [
//                            'piIx' => $piIx,
//                            'userCode' => $userCode,
//                            'userId' => $registData['userId'],
//                            'name' => $registData['name'],
//                            'memType' => 'M'
//                        ]);
                    }
                }

                return [
                    'user' => $registData
                    , 'company' => $companyRegistData
                ];
            }
        } else {
            $this->setResponseResult('fail')->setResponseData(validation_errors());
        }

        ///////////////////////////
        // 마스터 DB로 처리 END //
        end_master_db();
        ///////////////////////////
    }

    /**
     * 인증으로 인한 회원 조회
     */
    public function searchUserByCertify()
    {
        $memberRegRule = ForbizConfig::getSharedMemory("member_reg_rule");
        $authData = $this->memberModel->getAuthSessionData();

        if($memberRegRule['mall_use_certify'] == 'Y' || $memberRegRule['mall_use_sso'] == 'Y'){
            //통합인증의 카카오 는 ci 값을 미제공 하기때문에 값이 없을 경우 핸드폰과 이름으로 조회 필요
            if(isset($authData['ci']) && !empty($authData['ci'])){
                $userData = $this->memberModel->getUserDataByCi($authData['ci']);
            }else{
                $userData = $this->memberModel->getUserDataByPcs($authData['pcs'], $authData['name']);
            }
        }else{
            $userData = $this->memberModel->getUserDataByPcs($authData['pcs'], $authData['name']);
        }

        if (isset($userData['code']) && $userData['code']) {
            $this->setResponseResult('success');
        } else {
            $this->setResponseResult('noSearchUser');
        }
    }

    /**
     * 이메일로 회원 조회
     * @param $companyId
     * @return mixed
     */
    public function searchUserByMail()
    {
        $userData = $this->memberModel->getUserDataByMail($this->input->post('mail'));

        if (isset($userData['id'])) {
            //인증 세션 등록
            $this->memberModel->setAuthSessionData(['mail' => $userData['mail']]);

            if($userData['name'] != $this->input->post('name')){
                $this->setResponseResult('noMatchData');
            }else{
                $this->setResponseResult('success');
            }
        } else {
            $this->setResponseResult('noSearchUser');
        }
    }
    
    /**
     * 사업자 조회
     */
    public function searchCompany()
    {
        $chkField = [
            'comName', 'comCeo', 'comNumber1', 'comNumber2', 'comNumber3'
        ];

        if (form_validation($chkField)) {
            $comNumber = $this->input->post('comNumber1') . '-' . $this->input->post('comNumber2') . '-' . $this->input->post('comNumber3');
            $comData = $this->memberModel->searchCompany($this->input->post('comName'), $comNumber, $this->input->post('comCeo'));

            if (isset($comData['company_id']) && $comData['company_id']) {
                //인증 세션 등록
                $this->memberModel->setAuthSessionData(['companyId' => $comData['company_id']]);

                $this->setResponseResult('success');
            } else {
                $this->setResponseResult('noSearchCompany');
            }
        } else {
            $this->setResponseResult('fail')->setResponseData(validation_errors());
        }
    }

    /**
     * 비밀번호 찾기에서 일반회원 조회
     */
    public function searchUserByCertifyAndUserData()
    {
        $chkField = ['userId', 'userName'];

        if (form_validation($chkField)) {
            $memberRegRule = ForbizConfig::getSharedMemory("member_reg_rule");

            if($memberRegRule['mall_use_certify'] == 'Y'){
                $authData = $this->memberModel->getAuthSessionData();
                $userData = $this->memberModel->getUserDataByCi($authData['ci']);
            }else{
                $userData = $this->memberModel->getUserDataByMail($this->input->post('mail'));
                if(isset($userData['mail'])){
                    $this->memberModel->setAuthSessionData(['mail' => $userData['mail']]);
                }
            }

            if (empty($userData['code'])) {
                $this->setResponseResult('noSearchUser');
            } elseif ($userData['id'] != $this->input->post('userId') || $userData['name'] != $this->input->post('userName')) {
                $this->setResponseResult('noMatchData');
            } else {
                //비밀번호 변경 권한 set
                $this->memberModel->setChangePasswordAccessSessionType('searchPassword');
                $this->memberModel->setChangePasswordAccessSessionUserCode($userData['code']);

                $this->setResponseResult('success');
            }
        } else {
            $this->setResponseResult('fail')->setResponseData(validation_errors());
        }
    }

    /**
     * 일반회원 비밀번호 변경
     */
    public function changePassword()
    {
        $chkField = ['pw', 'comparePw'];

        if (form_validation($chkField)) {
            // 회원코드
            $userCode = $this->memberModel->getChangePasswordAccessSessionUserCode();
            // 비밀번호 변경
            $responseData = $this->memberModel->doChangePassword($this->input->post('pw'), $this->input->post('comparePw'));
            // 결과 확인
            if(is_array($responseData)){
                // 휴면회원
                if ($responseData['changeType'] == 'sleep') {
                    $this->setFlashData('sleepStep', 'complete');
                }

                unset($responseData['changeType']);

                // userCode와 비밀번호를 사용하여 로그인
                $this->memberModel->useUserCodeLogin($userCode, $this->input->post('pw'));

                $this->setResponseResult('success')->setResponseData($responseData);

            }else{
                $this->setResponseResult($responseData);
            }
        } else {
            $this->setResponseResult('fail')->setResponseData(validation_errors());
        }
    }

    /**
     * 비밀번호 변경을 다음으로 미룬다.
     */
    public function passwordContinue()
    {
        if (is_login()) {
            $this->memberModel->doPasswordContinue(sess_val('user', 'code'));

            $this->setResponseResult('success');
        } else {
            $this->setResponseResult('needLogin');
        }
    }

    /**
     * 비밀번호 찾기에서 사업자 조회
     */
    public function searchCompanyByCertifyAndCompanyData()
    {
        $chkField = [
            'userId', 'comName', 'comNumber1', 'comNumber2', 'comNumber3'
        ];

        if (form_validation($chkField)) {
            $authData = $this->memberModel->getAuthSessionData();
            $userData = $this->memberModel->getUserDataByCi($authData['ci']);
            // 등록된 회원인지 확인
            if (empty($userData['code'])) {
                $this->setResponseResult('noSearchUser');
            } else {
                $comNumber = $this->input->post('comNumber1') . '-' . $this->input->post('comNumber2') . '-' . $this->input->post('comNumber3');
                $comData = $this->memberModel->getCompanyData($userData['company_id']);
                // 정합성 체크
                if (
                    $userData['id'] != $this->input->post('userId') ||
                    $comData['com_name'] != $this->input->post('comName') ||
                    $comData['com_number'] != $comNumber
                ) {
                    $this->setResponseResult('noMatchData');
                } else {
                    //비밀번호 변경 권한 set
                    $this->memberModel->setChangePasswordAccessSessionType('searchPassword');
                    $this->memberModel->setChangePasswordAccessSessionUserCode($userData['code']);

                    $this->setResponseResult('success');
                }
            }
        } else {
            $this->setResponseResult('fail')->setResponseData(validation_errors());
        }
    }

    /**
     * SNS 간편로그인 프로세스 진행함수
    */
    public function snsProcess($loginInfo, $sns_type) {
        $gotoUrl = ($loginInfo['gotoUrl'] ?? '/');


        if($sns_type == 'google') {
            $msg = '';
            $result = 'fail';
            if($loginInfo === 'fail' || isset($loginInfo['isJoin']) && $loginInfo['isJoin'] === false){
                $res['result'] = 'fail';
                $msg = 'SNS 매칭정보가 없거나 가입되지 않은 회원입니다. 로그인 후 회원정보수정에서 설정하시거나 신규 회원가입 해주세요.';
                $res['data']['gotoUrl'] = $gotoUrl;
            }elseif($loginInfo['isJoin'] === 'noPwUser'){
                $msg = '메일 또는 SMS로 임시비밀번호가 발행되었습니다. 확인 후 다시 로그인해주세요.';
            }else if($loginInfo['isJoin'] === 'standby') {
                $msg = 'standby';
            }else if($loginInfo['isJoin'] === 'reject') {
                $msg = 'reject';
            }else {
                $result = 'success';
            }

            $res['result'] = $result;
            $res['data']['msg'] = $msg;
            $res['data']['gotoUrl'] = $gotoUrl;

            return $res;
        }else {
            if($loginInfo === 'fail' || isset($loginInfo['isJoin']) && $loginInfo['isJoin'] === false){
                echo "<script>alert('SNS 매칭정보가 없거나 가입되지 않은 회원입니다. 로그인 후 회원정보수정에서 설정하시거나 신규 회원가입 해주세요.');</script>";

                if($sns_type == 'apple') {
                    exit("<script>
                        location.href='".$gotoUrl."';\n
                    </script>");
                } else{
                    if(is_mobile()){
                        if(getAppType()){
                            exit("<script>
                            opener.window.location.href='".$gotoUrl."';\n
                            window.close();
                        </script>");
                        }else{
                            exit("<script>
                            window.location.href='".$gotoUrl."';
                        </script>");
                        }
                    }else{
                        exit("<script>
                        window.close();\n
                        opener.window.location.href='".$gotoUrl."';
                    </script>");
                    }
                }
            }elseif($loginInfo['isJoin'] === 'noPwUser'){
                echo "<script>alert('메일 또는 SMS로 임시비밀번호가 발행되었습니다. 확인 후 다시 로그인해주세요.');</script>";
            }else if($loginInfo['isJoin'] === 'standby') {
                echo "<script>alert('stanby');</script>";
            }else if($loginInfo['isJoin'] === 'reject') {
                echo "<script>alert('reject');</script>";
            }
        }
        $appType = getAppType();
        if ($appType !== false) {
            if(empty($loginInfo['userId'])) $loginInfo['userId'] = '';
            if(empty($loginInfo['userCode'])) $loginInfo['userCode'] = '';
            echo "<script>
                    /*var obj = {};
                    obj['userId'] = '".$loginInfo['userId']."';
                    obj['userCode'] = '".$loginInfo['userCode']."';
                    obj['cookieInfo'] = {};
                    obj['cookieInfo']['connection_no'] = '".$loginInfo['loginCookie']['connection_no']."';
                    obj['cookieInfo']['auto_login'] = '".$loginInfo['loginCookie']['auto_login']."';*/
                </script>";
            if($appType == 'Android'){
                echo "<script>
                        window.JavascriptInterface.loginSuccess('".$loginInfo['userCode']."');
                        window.JavascriptInterface.loadUrl('".$gotoUrl."');
                    </script>";
            }else if($appType == 'iOS') {
                echo "<script>
                            window.webkit.messageHandlers.loginSuccess.postMessage('".$loginInfo['userCode']."');
                            window.webkit.messageHandlers.loadUrl.postMessage('".$gotoUrl."');
                        </script>";
            }

            exit("<script>window.close();</script>");

        } else {
            if(is_mobile()){
                exit("<script>
                    location.href='".$gotoUrl."';\n
                </script>");
            }else{
                exit("<script>
                    opener.window.location.href='" . $gotoUrl . "';\n
                    window.close();
                </script>");
            }
        }
    }
    /**
     * 페이스북 로그인 콜백
     */
    public function facebook($mode='login')
    {
        $sns_type = 'facebook';

        $fb = new \Facebook\Facebook([
            'app_id' => \ForbizConfig::getMallConfig('facebook_app_id'),
            'app_secret' => \ForbizConfig::getMallConfig('facebook_app_secret'),
            'default_graph_version' => 'v2.2',
        ]);

        $helper = $fb->getRedirectLoginHelper();
        $response = '';
        try {
            $accessToken = $helper->getAccessToken();
        } catch (Exception $e) {
            $response = $e->getMessage();
        }

        if (isset($accessToken)) {
            $_SESSION['sns_login'][$sns_type]['access_token'] = $accessToken->getValue();

            if ($this->getFlashData('sns_test') == $sns_type) {
                redirect('/tests/facebook.php/GetProfile');
            } else {
                $sns_info = $this->snsLoginModel->getFacebookProfile();
                // SNS 정보 조회되었나?
                if (isset($sns_info['response']['id'])) {
                    if($mode == 'join'){
                        if($this->snsLoginModel->existsSnsId('facebook',$sns_info['response']['id'])){
                            if (is_mobile()) {
                                $this->setFlashData('reconfirmPassMode', "profile");
                                exit("<script>alert('이미 가입된 정보가 존재합니다.');\nlocation.replace('/mypage/profile');</script>");
                            } else {
                                exit("<script>alert('이미 가입된 정보가 존재합니다.');\nwindow.close();</script>");
                            }
                        }else {
                            if (is_mobile()) {
                                $this->setFlashData('reconfirmPassMode', "profile");
                                $this->setFlashData('fbId', $sns_info['response']['id']);
                                exit("<script>location.replace('/mypage/profile');</script>");
                            } else {
                                exit("<script>
                                    opener.document.getElementById('devFacebookId').value='" . $sns_info['response']['id'] . "';\n
                                    opener.document.getElementById('devFBIdBtn').disabled=true;\n
                                    window.close();
                                </script>");
                            }
                        }
                    }else{
                        $loginInfo = $this->snsLoginModel->doLogin($sns_type, $sns_info);
                        $this->snsProcess($loginInfo, $sns_type);
                    }

                } else {
                    $response = json_encode($sns_info);
                }
            }
        } else {
            $_SESSION['sns_login']['error'] = $response;
        }

        // SNS Login 에러 처리
        log_message('debug', 'Facebook login Error : '.$response);
        if($mode == 'join'){
            exit("<script>alert('간편로그인에 실패했습니다.');\nwindow.close();</script>");
        }else{
            if (getAppType() !== false) {
                exit("<script>opener.document.location.replace('/member/login');\nwindow.close();</script>");
            } else {
                redirect('/member/login');
            }
        }



    }

    /**
     * 네이버 로그인 콜백
     */
    public function naver($mode='login')
    {
        $sns_type = 'naver';

        // 네이버 로그인 콜백
        $client_id      = \ForbizConfig::getMallConfig('naver_client_id');
        $client_secret  = \ForbizConfig::getMallConfig('naver_client_secret');
        $redirectURI    = \ForbizConfig::getMallConfig("naver_{$mode}_callback_url");
        $code           = $this->input->get("code");
        $state          = $this->input->get("state");

        $url            = "https://nid.naver.com/oauth2.0/token?grant_type=authorization_code&client_id=".$client_id."&client_secret=".$client_secret."&redirect_uri=".$redirectURI."&code=".$code."&state=".$state;
        $is_post        = false;
        $ch             = curl_init();

        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, $is_post);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $headers     = array();
        $response    = curl_exec($ch);
        $status_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($status_code == 200) {
            $_SESSION['sns_login'][$sns_type] = json_decode($response, true);
        } else {
            $_SESSION['sns_login']['error'] = $response;
        }

        if ($this->getFlashData('sns_test') == $sns_type) {
            redirect('/tests/naver.php/GetProfile');
        } elseif ($status_code == 200 && isset($_SESSION['sns_login'][$sns_type]['access_token'])) {
            $sns_info = $this->snsLoginModel->getNaverProfile();

            $userCheck = $sns_info['response'];
            $userCheckBool = true;

            if($userCheckBool === false){
                $this->snsLoginModel->naver_delete();
                $failUrl = "/member/joinEnd/fail";
                if (getAppType() !== false) {
                    exit("<script>opener.document.location.replace('{$failUrl}');\nwindow.close();</script>");
                } else {
                    redirect($failUrl);
                }
            }else{
                // SNS 정보 조회되었나?
                if (isset($sns_info['response']['id'])) {

                    if($mode == 'join'){
                        if($this->snsLoginModel->existsSnsId('naver',$sns_info['response']['id'])){
                            if (is_mobile()) {
                                $this->setFlashData('reconfirmPassMode', "profile");
                                exit("<script>alert('이미 가입된 정보가 존재합니다.');\nlocation.replace('/mypage/profile');</script>");
                            } else {
                                exit("<script>alert('이미 가입된 정보가 존재합니다.');\nwindow.close();</script>");
                            }
                        }else{
                            if (is_mobile()) {
                                $this->setFlashData('reconfirmPassMode', "profile");
                                $this->setFlashData('naverId', $sns_info['response']['id']);
                                exit("<script>location.replace('/mypage/profile');</script>");
                            } else {
                                exit("<script>
                                    opener.document.getElementById('devNaverId').value='".$sns_info['response']['id']."';\n
                                    opener.document.getElementById('devNaverIdBtn').disabled=true;\n
                                    window.close();
                                </script>");
                            }
                        }

                    }else{ // 로그인
                        $loginInfo = $this->snsLoginModel->doLogin($sns_type, $sns_info);
                        $this->snsProcess($loginInfo, $sns_type);
                    }


                } else {
                    $response = json_encode($sns_info);
                    // SNS Login 에러 처리
                    log_message('debug', 'Naver login Error : '.$response);
                    if($mode == 'join'){
                        exit("<script>alert('간편로그인에 실패했습니다.');\nwindow.close();</script>");
                    }else{
                        if (getAppType() !== false) {
                            exit("<script>opener.document.location.replace('/member/login');\nwindow.close();</script>");
                        } else {
                            redirect('/member/login');
                        }
                    }

                }
            }
        } else {
            if($mode == 'join'){
                exit("<script>alert('간편로그인에 실패했습니다.');\nwindow.close();</script>");
            }else{
                redirect('/member/login');
            }

        }
    }

    /**
     * 카카오 로그인 콜백
     */
    public function kakao($mode='login')
    {
        if($this->input->get("error") == 'access_denied'){
            exit("<script>alert('동의 취소하셨습니다.');document.location.replace('/member/login');</script>");
        }

        $sns_type = 'kakao';

        // 카카오 로그인 콜백
        $app_key        = \ForbizConfig::getMallConfig('kakao_app_key');
        $app_secret     = \ForbizConfig::getMallConfig('kakao_app_secret');
        $redirectURI    = \ForbizConfig::getMallConfig("kakao_{$mode}_callback_url");

        $post_data = http_build_query([
            'code' => $this->input->get("code")
            , 'grant_type' => 'authorization_code'
            , 'client_id' => $app_key
            , 'client_secret' => $app_secret
            , 'redirect_uri' => $redirectURI
        ]);

        $url     = "https://kauth.kakao.com/oauth/token";
        $is_post = true;
        $ch      = curl_init();

        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, $is_post);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $post_data);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

        $headers     = array();
        $response    = curl_exec($ch);
        $status_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($status_code == 200) {
            $_SESSION['sns_login'][$sns_type] = json_decode($response, true);
        } else {
            $_SESSION['sns_login']['error'] = $response;
        }

        if ($this->getFlashData('sns_test') == $sns_type) {
            redirect('/tests/kakao.php/GetProfile');
        } elseif ($status_code == 200 && isset($_SESSION['sns_login'][$sns_type]['access_token'])) {
            $sns_info = $this->snsLoginModel->getKakaoProfile();

            // SNS 정보 조회되었나?
            if (isset($sns_info['response']['id'])) {
                if($mode == 'join'){
                    if($this->snsLoginModel->existsSnsId('kakao',$sns_info['response']['id'])){
                        if (is_mobile()) {
                            $this->setFlashData('reconfirmPassMode', "profile");
                            exit("<script>alert('이미 가입된 정보가 존재합니다.');\nlocation.replace('/mypage/profile');</script>");
                        } else {
                            exit("<script>alert('이미 가입된 정보가 존재합니다.');\nwindow.close();</script>");
                        }
                    }else {
                        if (is_mobile()) {
                            $this->setFlashData('reconfirmPassMode', "profile");
                            $this->setFlashData('kakaoId', $sns_info['response']['id']);
                            exit("<script>location.replace('/mypage/profile');</script>");
                        } else {
                            exit("<script>
                                opener.document.getElementById('devKakaoId').value='" . $sns_info['response']['id'] . "';\n
                                opener.document.getElementById('devKakaoIdBtn').disabled=true;\n
                                window.close();
                            </script>");
                        }
                    }
                }else { // 로그인
                    $loginInfo = $this->snsLoginModel->doLogin($sns_type, $sns_info);
                    $this->snsProcess($loginInfo, $sns_type);
                }

            }else {
                // SNS Login 에러 처리
                log_message('debug', 'Kakao login Error : '.$response);
                if($mode == 'join'){
                    exit("<script>alert('간편로그인에 실패했습니다.');\nwindow.close();</script>");
                }else{
                    if (getAppType() !== false) {
                        exit("<script>opener.document.location.replace('/member/login');window.close();</script>");
                    } else {
                        redirect('/member/login');
                    }
                }
            }
        }else{
            // SNS Login 에러 처리
            echo "redirectURI : ".urldecode($redirectURI)."\n";
            echo "status_code : ".$status_code."\n";
            $response = json_decode($response);
            echo "error type : ".$response->error."\n";
            echo "error msg : ".$response->error_description."\n";

            /*if($mode == 'join'){
                exit("<script>alert('간편로그인에 실패했습니다.');\nwindow.close();</script>");
            }else{
                if (getAppType() !== false) {
                    exit("<script>opener.document.location.replace('/member/login');window.close();</script>");
                } else {
                    redirect('/member/login');
                }
            }*/
        }
    }

    /**
     * 애플 로그인 콜백
     */
    public function apple()
    {

        $sns_type = 'apple';
        $snsId = $this->input->post_get('id');
        $mode = $this->input->post_get('mode');
        $sns_info['response'] = [];
        $sns_info['response']['id'] = $snsId;

        $_SESSION['sns_login'][$sns_type] = $sns_info;

        // SNS 정보 조회되었나?
        if (isset($sns_info['response']['id'])) {
            if($mode == 'join'){
                if($this->snsLoginModel->existsSnsId($sns_type,$sns_info['response']['id'])){
                    $this->setResponseResult('existsSnsId');
                }else {
                    $this->setResponseResult('success')
                        ->setResponseData([
                            'id' => $sns_info['response']['id']
                        ]);
                }
            }else { // 로그인
                $loginInfo = $this->snsLoginModel->doLogin($sns_type, $sns_info);
                $this->snsProcess($loginInfo, $sns_type);
            }

        }else {
            // SNS Login 에러 처리
            log_message('debug', 'apple login Error : '.json_encode($this->input->post()));
            $this->setResponseResult('fail');
        }

    }

    /**
     * 구글 로그인 콜백
     */
    public function google($type='')
    {
        $sns_type = 'google';
        $googleKeyInfo = $this->snsLoginModel->setKeyConfig('google');
        $id_token = $this->input->get('id_token');

        if(!empty($id_token)) {
            $client = new Google_Client(['client_id' => $googleKeyInfo['googleClientId']]);
            $response = $client->verifyIdToken($id_token);
            $response['id'] = $response['sub'];
        }else {
            //APP일경우 client 조회 후 값이 들어옴, 우선 필요값만 받음.
            $response['sub'] = $this->input->get('id');
            $response['id'] = $this->input->get('id');
            $response['email'] = $this->input->get('email');
            $response['name'] = $this->input->get('name');
        }

        if ($response) {
            $sns_info['response'] = $response;
            if($type=='link'){
                $result = $this->memberModel->registSnsMember($response['id'], 'google', sess_val('user', 'code'));
                if($result){
                    $res['result'] = 'success';
                    $res['data']['msg'] = 'SNS 연동이 완료되었습니다.';
                }else {
                    $res['result'] = 'fail';
                    $res['data'] = '';
                }
            }else {
                $loginInfo = $this->snsLoginModel->doLogin($sns_type, $sns_info);
                $res = $this->snsProcess($loginInfo, $sns_type);
            }
            $this->setResponseResult($res['result'])->setResponseData($res['data']);
        } else {
            // Invalid ID token
            $_SESSION['sns_login']['error'] = $response;
            // SNS Login 에러 처리
            log_message('debug', 'Google login Error : '.$response);
            redirect('/member/login');
        }
    }

    /**
     * 회원 비인증 처리
     */
    public function nonCertify()
    {
        $chkForm = ['user_name', 'pcs', 'birth', 'sex_div'];
        if(form_validation($chkForm)) {
            $isExistsPcs = $this->memberModel->existsPcs($this->input->post('pcs'));

            if ($isExistsPcs === false) {
                $this->setResponseResult('success')->setResponseData(['cerity' => $this->memberModel->nonCertifySuccess($this->input->post())]);
            } else {
                $this->setResponseResult('existsPcs')->setResponseData([]);
            }
        } else {
            $this->setResponseResult('fail')->setResponseData(validation_errors());
        }
    }

}