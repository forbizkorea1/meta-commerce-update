<?php

namespace ForbizScm\Model;

/**
 * 네이버페이 관련 모델
 *
 * @author jhpark
 */
class Npay extends \ForbizModel
{

    public function __construct()
    {
        parent::__construct();
    }

    /**
     * 네이버 페이 주문 연동
     * @param $sdate
     * @param $edate
     * @param $inquiryExtraData = 최종 상품 주문 상태 코드 =>
     * PAY_WAITING-입금대기, PAYED-결제완료, DISPATCHED-발송처리, CANCEL_REQUESTED-취소요청, RETURN_REQUESTED-반품요청,
     * EXCHANGE_REQUESTED-교환요청, EXCHANGE_REDELIVERY_READY-교환 재배송 준비,
     * CANCELED-취소, RETURNED-반품, EXCHANGED-교환, PURCHASE_DECIDED-구매확정
     *
     */
    public function getOrderNpay($sdate, $edate, $inquiryExtraData = '')
    {
        /* @var $naverPayOrderModel \CustomScm\Model\Npay\NaverPayOrder */
        $naverPayOrderModel = $this->import('model.scm.npay.naverPayOrder');
        $order = $naverPayOrderModel->getChangedProductOrderList($sdate, $edate, '', $inquiryExtraData);

        if ($order->Body->GetChangedProductOrderListResponse->ChangedProductOrderInfoList) { //주문상태가 변경된 상품이 존재할 경우
            foreach ($order->Body->GetChangedProductOrderListResponse->ChangedProductOrderInfoList as $orderInfo) {
                $response = $naverPayOrderModel->getProductOrderInfoList($orderInfo->ProductOrderID);

                $data = [
                    'order_from' => 'self', // 제휴사코드
                    'company_name' => get_auth_info()['company_name'], // 업체명
                    'gid' => '',
                    'method' => ORDER_METHOD_NPAY_ORDER,
                    'bname' => $response['Order']['OrdererName'],
                    'btel' => '02--',
                    'bmobile' => add_dash($response['Order']['OrdererTel1']),
                    'co_oid' => $response['Order']['OrderID'],
                    'general_payment_amount' => $response['Order']['GeneralPaymentAmount'],
                    'order_date' => $response['Order']['OrderDate'] ?
                        date("Y-m-d\TH:i:s", strtotime($response['Order']['OrderDate'])) : '',
                    'payment_date' => $response['Order']['PaymentDate'] ?
                        date("Y-m-d\TH:i:s", strtotime($response['Order']['PaymentDate'])) : '',
                    'place_order_date' => $response['ProductOrder']['PlaceOrderDate'] ?
                        date("Y-m-d\TH:i:s", strtotime($response['ProductOrder']['PlaceOrderDate'])) : '',
                    'decision_date' => $response['ProductOrder']['DecisionDate'] ?
                        date("Y-m-d\TH:i:s", strtotime($response['ProductOrder']['DecisionDate'])) : '',
                    'payment_agent_type' => $response['Order']['PayLocationType'],
                    'bzip' => '',
                    'claim_type' => $response['ProductOrder']['ClaimType'],
                    'claim_status' => $response['ProductOrder']['ClaimStatus'],
                    'co_od_ix' => $response['ProductOrder']['ProductOrderID'],
                    'option_id' => $response['ProductOrder']['MerchantProductId'],
                    'option_text' => $response['ProductOrder']['ProductOption'],
                    'pcnt' => $response['ProductOrder']['Quantity'],
                    'pid' => $response['ProductOrder']['ProductID'],
                    'pname' => $response['ProductOrder']['ProductName'],
                    'place_order_status' => $response['ProductOrder']['PlaceOrderStatus'],
                    'product_order_status' => $response['ProductOrder']['ProductOrderStatus'],
                    'pt_dcprice' => $response['ProductOrder']['TotalPaymentAmount'],
                    'psprice' => $response['ProductOrder']['TotalPaymentAmount'],
                    'rname' => $response['ProductOrder']['ShippingAddress']['Name'],
                    'rmobile' => $response['ProductOrder']['ShippingAddress']['Tel1'],
                    'rtel' => '02--',
                    'addr1' => $response['ProductOrder']['ShippingAddress']['BaseAddress'],
                    'addr2' => $response['ProductOrder']['ShippingAddress']['DetailedAddress'],
                    'zip' => $response['ProductOrder']['ShippingAddress']['ZipCode'],
                    'shipping_memo' => $response['ProductOrder']['ShippingMemo'],
                    'is_receiver_address_changed' => (string)$orderInfo->IsReceiverAddressChanged ?? 'false'
                ];

                if (isset($response['Delivery'])) {     //배송
                    $data = $this->mergeDeliveryInfo($data, $response['Delivery'], $naverPayOrderModel);
                }
                if (isset($response['CancelInfo'])) {   //취소
                    $data = $this->mergeCancelInfo($data, $response['CancelInfo'], $naverPayOrderModel);
                }
                if (isset($response['ReturnInfo'])) {   //반품
                    $data = $this->mergeReturnInfo($data, $response['ReturnInfo'], $naverPayOrderModel);
                }
                if (isset($response['ExchangeInfo'])) {     //교환
                    $data = $this->mergeExchangeInfo($data, $response['ExchangeInfo'], $naverPayOrderModel);
                }

                /* @var $createOrderModel \CustomScm\Model\Order\CreateOrder */
                $createOrderModel = $this->import('model.scm.order.createOrder');
                $createOrderModel->putOrderByNpayAPI($data);    //주문 등록
            }
        }

        //주문상품번호개수가 1000개가 넘어가면 재귀호출
        if ($order->Body->GetChangedProductOrderListResponse->HasMoreData == 'true') {
            $sdate = $order->Body->GetChangedProductOrderListResponse->MoreDataTimeFrom;
            $inquiryExtraData = $order->Body->GetChangedProductOrderListResponse->InquiryExtraData;
            $this->getOrderNpay($sdate, $edate, '', $inquiryExtraData);
        }

        return $order;
    }

    /**
     * 교환정보 추가
     * @param $data
     * @param $response
     * @param $naverPayOrderModel
     * @return array
     */
    protected function mergeExchangeInfo($data, $response, $naverPayOrderModel)
    {
        /* @var $naverPayOrderModel \CustomScm\Model\Npay\NaverPayOrder */

        $data['exchange_claim_status'] = $response['ClaimStatus'];
        $data['exchange_claim_request_date'] = ($response['ClaimRequestDate'] ? date("Y-m-d\TH:i:s", strtotime($response['ClaimRequestDate'])) : '');
        $data['exchange_reason'] = $naverPayOrderModel->getClaimRequestReasonCode($response['ExchangeReason'], 'NpayReturn');
        $data['exchange_detailed_reason'] = $response['ExchangeDetailedReason'];
        $data['claim_delivery_fee_demand_amount'] = $response['ClaimDeliveryFeeDemandAmount'];
        $data['collect_delivery_method'] = $response['CollectDeliveryMethod'];
        $data['collect_delivery_company'] = $naverPayOrderModel->getDeliveryCompanyCode($response['CollectDeliveryCompany']);
        $data['collect_tracking_number'] = $response['CollectTrackingNumber'];
        $data['claim_delivery_fee_pay_method'] = $response['ClaimDeliveryFeePayMethod'];
        $data['cname'] = $response['CollectAddress']['Name'];
        $data['cmobile'] = $response['CollectAddress']['Tel1'];
        $data['czip'] = $response['CollectAddress']['ZipCode'];
        $data['caddr1'] = $response['CollectAddress']['BaseAddress'];
        $data['caddr2'] = $response['CollectAddress']['DetailedAddress'];
        $data['rename'] = $response['ReturnReceiveAddress']['Name'];
        $data['remobile'] = $response['ReturnReceiveAddress']['Tel1'];
        $data['rezip'] = '';
        $data['readdr1'] = $response['ReturnReceiveAddress']['BaseAddress'];
        $data['readdr2'] = $response['ReturnReceiveAddress']['DetailedAddress'];

        return $data;
    }

    /**
     * 반품정보 추가
     * @param $data
     * @param $response
     * @param $naverPayOrderModel
     * @return array
     */
    protected function mergeReturnInfo($data, $response, $naverPayOrderModel)
    {
        /* @var $naverPayOrderModel \CustomScm\Model\Npay\NaverPayOrder */

        $claim_delivery_fee_demand_amount = 0;

        if (in_array($response['ReturnReason'], ['INTENT_CHANGED', 'COLOR_AND_SIZE', 'WRONG_ORDER'])) {
            if (!empty($response['ClaimDeliveryFeeDemandAmount'])) {
                $claim_delivery_fee_demand_amount -= $response['ClaimDeliveryFeeDemandAmount'];
            }
        }

        $data['return_claim_status'] = $response['ClaimStatus'];
        $data['return_claim_request_date'] = ($response['ClaimRequestDate'] ? date("Y-m-d\TH:i:s", strtotime($response['ClaimRequestDate'])) : '');
        $data['return_reason'] = $naverPayOrderModel->getClaimRequestReasonCode($response['ReturnReason'], 'NpayReturn');
        $data['return_detailed_reason'] = $response['ReturnDetailedReason'];
        $data['claim_delivery_fee_demand_amount'] = $claim_delivery_fee_demand_amount;
        $data['collect_delivery_method'] = $response['CollectDeliveryMethod'];
        $data['collect_delivery_company'] = $naverPayOrderModel->getDeliveryCompanyCode($response['CollectDeliveryCompany']);
        $data['collect_tracking_number'] = $response['CollectTrackingNumber'];
        $data['claim_delivery_fee_pay_method'] = $response['ClaimDeliveryFeePayMethod'];
        $data['etc_fee_demand_amount'] = $response['EtcFeeDemandAmount'];
        $data['etc_fee_pay_method'] = $response['EtcFeePayMethod'];
        $data['cname'] = $response['CollectAddress']['Name'];
        $data['cmobile'] = $response['CollectAddress']['Tel1'];
        $data['czip'] = $response['CollectAddress']['ZipCode'];
        $data['caddr1'] = $response['CollectAddress']['BaseAddress'];
        $data['caddr2'] = $response['CollectAddress']['DetailedAddress'];

        return $data;
    }

    /**
     * 취소정보 추가
     * @param $data
     * @param $response
     * @param $naverPayOrderModel
     * @return array
     */
    protected function mergeCancelInfo($data, $response, $naverPayOrderModel)
    {
        /* @var $naverPayOrderModel \CustomScm\Model\Npay\NaverPayOrder */

        $data['cancel_claim_status'] = $response['ClaimStatus'];
        $data['cancel_claim_request_date'] = ($response['ClaimRequestDate'] ? date("Y-m-d\TH:i:s", strtotime($response['ClaimRequestDate'])) : '');
        $data['cancel_completed_date'] = ($response['CancelCompletedDate'] ? date("Y-m-d\TH:i:s", strtotime($response['CancelCompletedDate'])) : '');
        $data['cancel_approval_date'] = ($response['CancelApprovalDate'] ? date("Y-m-d\TH:i:s", strtotime($response['CancelApprovalDate'])) : '');
        $data['cancel_reason'] = $naverPayOrderModel->getClaimRequestReasonCode($response['CancelReason'], 'NpayCancel');
        $data['cancel_detailed_reason'] = $response['CancelDetailedReason'];
        $data['refund_request_date'] = ($response['RefundRequestDate'] ? date("Y-m-d\TH:i:s", strtotime($response['RefundRequestDate'])) : '');
        $data['refund_standby_status'] = $response['RefundStandbyStatus'];
        $data['request_channel'] = $response['RequestChannel'];
        $data['etc_fee_demand_amount'] = 0;

        return $data;
    }

    /**
     * 배송정보 추가
     * @param $data
     * @param $response
     * @param $naverPayOrderModel
     * @return array
     */
    protected function mergeDeliveryInfo($data, $response, $naverPayOrderModel)
    {
        /* @var $naverPayOrderModel \CustomScm\Model\Npay\NaverPayOrder */

        $data['delivery_status'] = $response['DeliveryStatus'];
        $data['delivery_method'] = $response['DeliveryMethod'];
        $data['delivery_company'] = $naverPayOrderModel->getDeliveryCompanyCode($response['DeliveryCompany']);
        $data['tracking_number'] = $response['TrackingNumber'];
        $data['send_date'] = ($response['SendDate'] ? date("Y-m-d\TH:i:s", strtotime($response['SendDate'])) : '');
        $data['pickup_date'] = ($response['PickupDate'] ? date("Y-m-d\TH:i:s", strtotime($response['PickupDate'])) : '');
        $data['delivered_date'] = ($response['DeliveredDate'] ? date("Y-m-d\TH:i:s", strtotime($response['DeliveredDate'])) : '');
        $data['is_wrong_tracking_number'] = $response['IsWrongTrackingNumber'];
        $data['wrong_tracking_number_registered_date'] = ($response['WrongTrackingNumberRegisteredDate'] ? date("Y-m-d\TH:i:s", strtotime($response['WrongTrackingNumberRegisteredDate'])) : '');
        $data['wrong_tracking_number_type'] = $response['WrongTrackingNumberType'];

        return $data;
    }

    /**
     * 자사몰 -> Npay 주문상태 변경
     * @param $odIx
     * @param $operation
     * @return mixed
     */
    public function changeOrderStatusNpay($coOdIx, $operation = '', $changeData = [])
    {
        /* @var $naverPayOrderModel \CustomScm\Model\Npay\NaverPayOrder */
        $naverPayOrderModel = $this->import('model.scm.npay.naverPayOrder');

        if ($operation == 'shipProductOrder') {
            $return_result = $naverPayOrderModel->shipProductOrder($coOdIx, $changeData);
        } else {
            $return_result = $naverPayOrderModel->doApproveOperation($coOdIx, $operation, $changeData);
        }
        return $return_result;
    }

    /**
     * Npay 반품 배송비 결제 정보
     * @param $odIxs
     * @return array
     * @throws \Exception
     */
    public function getNpayPaymentData($odIxs)
    {
        // odIx를 이용해 co_od_ix 조회
        $datas = $this->qb
            ->select('co_od_ix')
            ->select('claim_group')
            ->from(TBL_SHOP_ORDER_DETAIL)
            ->whereIn('od_ix', $odIxs)
            ->exec()
            ->getResultArray();

        /* @var $naverPayOrderModel \CustomScm\Model\Npay\NaverPayOrder */
        $naverPayOrderModel = $this->import('model.scm.npay.naverPayOrder');

        $npayInfo = array();
        $refundFeeRequired = array();

        foreach ($datas as $data) {
            $npayResponse = $naverPayOrderModel->getProductOrderInfoList($data['co_od_ix']);
            if (isset($npayResponse['ReturnInfo']['ClaimDeliveryFeePayMethod']) && $npayResponse['ReturnInfo']['ClaimDeliveryFeePayMethod'] != '') {
                switch ($npayResponse['ReturnInfo']['ClaimDeliveryFeePayMethod']) {
                    case '지금 결제함-추가결제':
                        $informationNum = 1;
                        break;
                    case '환불금에서 차감':
                        $informationNum = 2;
                        break;
                    case '판매자에게 직접 송금':
                        $informationNum = 3;
                        break;
                    case '상품에 동봉함':
                        $informationNum = 4;
                        break;
                }

                switch ($npayResponse['ReturnInfo']['ClaimDeliveryFeePayMethod']) {
                    case '지금 결제함-추가결제':
                        $informationText = ' 반품 비용 추가결제 완료, 전체 금액 환불 필요 (고객이 클레임 비용을 별도로 지불하였는지 확인 후 환불해주세요.)';
                        break;
                    case '환불금에서 차감':
                        $informationText = ' 반품 비용 차감 후 환불 필요';
                        break;
                    case '판매자에게 직접 송금':
                        $informationText = ' 반품 비용 판매자에게 직접 송금, 전체 금액 환불 필요 (고객이 클레임 비용을 별도로 지불하였는지 확인 후 환불해주세요.)';
                        break;
                    case '상품에 동봉함':
                        $informationText = ' 반품 비용 상품에 동봉, 전체 금액 환불 필요 (고객이 클레임 비용을 별도로 지불하였는지 확인 후 환불해주세요.)';
                        break;
                }

            } elseif (isset($npayResponse['ReturnInfo']['HoldbackStatus']) && $npayResponse['ReturnInfo']['HoldbackStatus'] == 'RELEASED') {
                $informationNum = 5;
                $informationText = ' 반품 비용 처리된 주문입니다. 네이버페이 센터에서 주문 확인 필요 (고객이 클레임 비용을 별도로 지불하였는지 확인 후 환불해주세요.)';
            } else {
                $informationNum = 6;
                $informationText = ' 취소요청 주문입니다. 전체 금액 환불 필요 (고객이 클레임 비용을 별도로 지불하였는지 확인 후 환불해주세요.)';
            }

            if (isset($informationText)) {

                if (in_array($informationNum, array_keys($npayInfo))) {
                    $npayInfo[$informationNum]['claimNum'] = $npayInfo[$informationNum]['claimNum'] . ', ' . $data['claim_group'];
                } else {
                    $npayInfo[$informationNum] = [
                        'informationText' => $informationText
                        , 'claimNum' => $data['claim_group']
                    ];
                }

                if ($informationNum == 2) {
                    array_push($refundFeeRequired, $data['claim_group']);
                }
            }
        }
        $returnText = array();
        foreach ($npayInfo as $key => $val) {
            $returnText[$key] = '네이버페이 주문 : ' . '클레임 번호 ' . $val['claimNum'] . $val['informationText'];
        }


        if (isset($returnText)) {
            return [$returnText, $refundFeeRequired];
        }
    }

    /**
     * 리뷰 조회
     *
     * @param {string} site_code 제휴사코드
     * @param {string} startDate 검색 시작일(YYYYMMDDhhmm)
     * @param {string} endDate 검색 종료일(201007210000)
     */
    public function getReviewList()
    {
        $startDate = date("Y-m-d H:00:00", strtotime("Now -1 day"));
        $endDate = date("Y-m-d H:00:00", strtotime("Now"));

        /* @var $naverPayOrderModel \CustomScm\Model\Npay\NaverPayOrder */
        $naverPayOrderModel = $this->import('model.scm.npay.naverPayOrder');
        /* @var $csBoardModel \CustomScm\Model\Cscenter\CsBoard */
        $csBoardModel = $this->import('model.scm.cscenter.csBoard');

        $result = $naverPayOrderModel->getReviewList($startDate, $endDate);
        fb_sys_log('npay_review', $result);
        if (count($result) > 0) {
            foreach ($result as $rt) {
                if (!empty($rt["pid"])) {
                    $csBoardModel->insertReviewFromNpay($rt);
                }
            }
        }
    }

    /**
     * 상품문의 가지고 오기
     *
     * @param {string} site_code 제휴사코드
     * @param {string} startDate 검색 시작일(YYYYMMDDhhmm)
     * @param {string} endDate 검색 종료일(201007210000)
     */
    public function getCustomerInquiryList()
    {
        $startDate = date("Y-m-d H:i:00", strtotime("Now -10 minutes"));
        $endDate = date("Y-m-d H:i:00", strtotime("Now"));

        /* @var $naverPayOrderModel \CustomScm\Model\Npay\NaverPayOrder */
        $naverPayOrderModel = $this->import('model.scm.npay.naverPayOrder');
        /* @var $csBoardModel \CustomScm\Model\Cscenter\CsBoard */
        $csBoardModel = $this->import('model.scm.cscenter.csBoard');

        $inquiryData = $naverPayOrderModel->getCustomerInquiryList($startDate, $endDate);
        fb_sys_log('npay_inquiry', $inquiryData);
        if (count($inquiryData) > 0) {
            foreach ($inquiryData as $data) {
                if (!empty($data["co_bbs_ix"])) {
                    $csBoardModel->insertQnaFromNpay($data);
                }
            }
        }
    }

    /**
     * 네이버페이 상품 문의 답변 등록 및 수정
     * @param $data
     * @return array|Npay\resultData
     */
    public function answerCustomerInquiry($data = [])
    {
        /* @var $naverPayOrderModel \CustomScm\Model\Npay\NaverPayOrder */
        $naverPayOrderModel = $this->import('model.scm.npay.naverPayOrder');

        //문의글 인덱스
        $inquiryData = $this->qb
            ->select('co_bbs_ix')
            ->from(TBL_SHOP_PRODUCT_QNA)
            ->where('bbs_ix', $data['bbs_ix'])
            ->exec()
            ->getRowArray();

        if ($inquiryData['co_bbs_ix']) {
            if ($data['devHideMode'] == "delete") {
                return 'delete fail';
            }

            if ($data['cmt_ix']) {
                //문의글 답변 인덱스
                $answerData = $this->qb
                    ->select('co_re_ix')
                    ->from(TBL_SHOP_PRODUCT_QNA_COMMENT)
                    ->where('cmt_ix', $data['cmt_ix'])
                    ->exec()
                    ->getRowArray();
            }

            $npayData = [
                'co_bbs_ix' => $inquiryData['co_bbs_ix']
                , 'co_re_ix' => $answerData['co_re_ix'] ?? ''
                , 'cmt_contents' => $data['cmt_contents']
            ];

            $response = $naverPayOrderModel->answerCustomerInquiry($npayData);

            return $response;
        } else {
            return TRUE;
        }
    }
}