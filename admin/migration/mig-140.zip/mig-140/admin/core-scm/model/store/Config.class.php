<?php

namespace ForbizScm\Model\Store;

/**
 * 설정 관련 모델
 *
 * @author hoksi
 */
class Config extends \ForbizModel
{

    public function __construct()
    {
        parent::__construct();
    }

    public function getIndexStoreConfig()
    {
        $result = [];
        $data = [];
        $result['status'] = 'success';

        $configKey = [
            //쇼핑몰 설정
            'mall_name',
            'mall_domain',
            'sattle_module',
            'delivery_with_coupon',
            'selling_type',
            'zipcode_type',
            'mall_use_inventory',
            'mall_inventory_category_div',
            'mall_dc_interval',
            'mall_cc_interval',
            'cart_delete_day',
            'cancel_auto_day',
            'check_order_day',
            'holiday_text',
            //간편결제
            'add_sattle_module_naverpay_pg',
            'add_sattle_module_payco',
            'add_sattle_module_toss',
            'add_sattle_module_kakaopay',
            //네이버페이(직연동)
            'naverpay_pg_service_use',
            'naverpay_pg_service_type',
            'naverpay_pg_partner_id',
            'naverpay_pg_client_id',
            'naverpay_pg_client_secret',
            //네이버페이(주문형)
            'naverpay_other_pg_service_use',
            'naverpay_other_pg_service_type',
            'naverpay_other_pg_shop_id',
            'naverpay_other_pg_button_key',
            'naverpay_other_pg_certi_key',
            'naverpay_other_pg_common_key',
            //페이코
            'payco_service_use',
            'payco_service_type',
            'payco_seller_key',
            'payco_cp_id',
            'payco_product_id',
            //토스
            'toss_service_use',
            'toss_service_type',
            'toss_api_key',
            //카카오
            'kakaopay_service_type',
            'kakaopay_api_key',
            //네이버 톡톡
            'talktalk_use_type',
            'talktalk_script',
            'talktalk_mobile_script',
            //해피톡
            'happyTalk_use_type',
            'happyTalk_script',
            'happyTalk_mobile_script',
            //채널톡
            'friendTalk_use_type',
            'friendTalk_script',
            'friendTalk_mobile_script',
            //네이버 쇼핑 EP 연동 사용 여부 설정
            'disp_naver',
            //다음 쇼핑하우 연동 사용 여부 설정
            'disp_daum',
            //크리마
            'crema_use_type',
            'crema_app_id',
            'crema_serect',
            //굿스플로
            'goodsflow_use_type',
            'goodsflow_app_key',
            'goodsflow_company_key',
            //파일 업로드 된것 4가지 체크'
            'devShopLogo',
            'devMobileLogo',
            'devMailLogo',
            'devFavicon',
            'devFaviconPng',
            //업로드 된 파일의 ID 획득 캐쉬 처리를 위한 키
            'devShopLogoId',
            'devMobileLogoId',
            'devMailLogoId',
            'devFaviconId',
            'devFaviconPngId',
            //SNS 간편 로그인 관련'
            'sns_simple_login_kakao',
            'sns_simple_login_naver',
            'sns_simple_login_facebook',
            'sns_simple_login_google',
            'sns_simple_login_apple',
            //카카오
            'kakao_app_key',
            'kakao_script_key',
            'kakao_app_secret',
            'kakao_login_callback_url',
            'kakao_join_callback_url',
            //네이버
            'naver_client_id',
            'naver_client_secret',
            'naver_login_callback_url',
            'naver_join_callback_url',
            //페이스북
            'facebook_app_id',
            'facebook_app_secret',
            'facebook_login_callback_url',
            'facebook_join_callback_url',
            //구글
            'google_client_id',
            'google_client_secret',
        ];

        foreach($configKey as $key) {
            $data[$key] = \ForbizConfig::getMallConfig($key);
        }

        // SEO 태그 설정
        $data = $this->getSeoTag($data);

        // SEO 고급 설정
        $data = $this->getSeoOgTag($data);

        // SEO 로봇 설정
        $data = $this->getSeoRobot($data);

        // SEO 사이트맵 설정
        $data = $this->getSiteMap($data);

        // 픽셀 사용 설정
        $data = $this->getPixel($data);

        // Google Analytics 설정
        $data = $this->getGoogleAnalytics($data);

        // 빅인사이트 설정
        $data = $this->getBiginsight($data);

        // 업데이트 관리 설정
        $data = $this->getSysUpdateUse($data);

        // Open API 사용 설정
        $data = $this->getOpenApiUse($data);

        $result['data'] = $data;

        return $result;
    }

    public function getSeoTag($data)
    {
        $data['mall_seo_title'] = \ForbizConfig::getMallConfig('mall_seo_title');
        $data['mall_seo_keyword'] = \ForbizConfig::getMallConfig('mall_seo_keyword');
        $data['use_seo_yn'] = \ForbizConfig::getMallConfig('use_seo_yn');
        $data['common_title'] = \ForbizConfig::getMallConfig('common_title');
        $data['common_author'] = \ForbizConfig::getMallConfig('common_author');
        $data['common_description'] = \ForbizConfig::getMallConfig('common_description');
        $data['common_keyword'] = \ForbizConfig::getMallConfig('common_keyword');

        return $data;
    }

    public function getSeoOgTag($data)
    {
        $data['og_site_name'] = \ForbizConfig::getMallConfig('og_site_name');
        $data['og_title'] = \ForbizConfig::getMallConfig('og_title');
        $data['og_description'] = \ForbizConfig::getMallConfig('og_description');
        $data['og_url'] = \ForbizConfig::getMallConfig('og_url');
        $data['og_img'] = \ForbizConfig::getMallConfig('og_img');
        $data['og_img'] = \ForbizConfig::getAdminImage('admin', 'og_img', 'url');
        return $data;
    }

    public function getSeoRobot($data)
    {
        $data['use_robot_yn'] = \ForbizConfig::getMallConfig('use_robot_yn');
        $data['robot_txt'] = \ForbizConfig::getMallConfig('robot_txt');

        return $data;
    }

    public function getSiteMap($data)
    {
        $data['use_sitemap_yn'] = \ForbizConfig::getMallConfig('use_sitemap_yn');
        $data['sitemap_route'] = \ForbizConfig::getMallConfig('sitemap_route');

        return $data;
    }

    public function getGoogleAnalytics($data)
    {
        $data['use_ga_yn'] = \ForbizConfig::getMallConfig('use_ga_yn');
        $data['ga_id'] = \ForbizConfig::getMallConfig('ga_id');

        return $data;
    }

    public function getPixel($data)
    {
        $data['use_pixel_yn'] = \ForbizConfig::getMallConfig('use_pixel_yn');
        $data['pixel_id'] = \ForbizConfig::getMallConfig('pixel_id');
        $data['pixel_cont_search_yn'] = \ForbizConfig::getMallConfig('pixel_cont_search_yn');
        $data['pixel_cart_yn'] = \ForbizConfig::getMallConfig('pixel_cart_yn');
        $data['pixel_pay_start_yn'] = \ForbizConfig::getMallConfig('pixel_pay_start_yn');
        $data['pixel_pay_end_yn'] = \ForbizConfig::getMallConfig('pixel_pay_end_yn');
        $data['pixel_goods_search_yn'] = \ForbizConfig::getMallConfig('pixel_goods_search_yn');
        $data['pixel_join_end_yn'] = \ForbizConfig::getMallConfig('pixel_join_end_yn');

        return $data;
    }

    public function getBiginsight($data)
    {
        $data['use_biginsight_yn'] = \ForbizConfig::getMallConfig('use_biginsight_yn');
        $data['biginsight_id'] = \ForbizConfig::getMallConfig('biginsight_id');

        return $data;
    }

    public function getSysUpdateUse($data)
    {
        /* @var $aclModel \ForbizScm\Model\Acl */
        $aclModel = $this->import('model.scm.acl');

        $data['sysUpdateUse'] = $aclModel->getSystemUpdateOnOff();

        return $data;
    }

    public function putSysUpdateUse($is_use)
    {
        /* @var $aclModel \ForbizScm\Model\Acl */
        $aclModel = $this->import('model.scm.acl');

        return $aclModel->systemUpdateOnOff($is_use);
    }

    public function getOpenApiUse($data)
    {
        /* @var $aclModel \ForbizScm\Model\Acl */
        $aclModel = $this->import('model.scm.acl');

        $data['openApiUse'] = $aclModel->getOpenApiOnOff();

        return $data;
    }

    public function putOpenApiUse($is_use)
    {
        /* @var $aclModel \ForbizScm\Model\Acl */
        $aclModel = $this->import('model.scm.acl');

        return $aclModel->openApiOnOff($is_use);
    }


    public function createRobotTxt($data)
    {
        if (FRONT_APPLICATION_ROOT !== false) {
            $robotTxt = FRONT_APPLICATION_ROOT . '/robot.txt';
            if ($data['use_robot_yn'] == 'Y') {
                return file_put_contents($robotTxt, $data['robot_txt']);
            } else if (file_exists($robotTxt)) {
                return unlink($robotTxt);
            }
            return true;
        }

        return false;
    }

    public function createSiteMap($data)
    {
        if (FRONT_APPLICATION_ROOT !== false) {
            $sitemap = FRONT_APPLICATION_ROOT . '/sitemap.xml';
            if ($data['use_sitemap_yn'] == 'Y') {
                return file_put_contents($sitemap, $this->getCreateSiteMap());
            } else if (file_exists($sitemap)){
                return unlink($sitemap);
            }
            return true;
        }

        return false;
    }

    public function getProductId()
    {
        set_time_limit(600);

        $products = $this->qb
            ->select('id')
            ->from(TBL_SHOP_PRODUCT)
            ->where('disp', 1)
            ->where('state', 1)
            ->exec()
            ->getResultArray();

        return $products;
    }

    public function getCreateSiteMap()
    {
        $list = $this->getProductId();

        $domain = MALL_DOMAIN . '/shop/goodsView/';

        $url = "";
        foreach ($list as $val) {
            $url .= "<url><loc>{$domain}{$val['id']}</loc></url>\n";
        }

        return implode("\n", [
            '<?xml version="1.0" encoding="UTF-8"?>',
            '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">',
            trim($url),
            '</urlset>'
        ]);
    }

    public function putMall($post = [])
    {
        $result = [];
        $data = [];
        $result['status'] = 'success';
        $result['data'] = $data;

        /* @var $uploadModel \ForbizScm\Model\Util\Upload */
        $uploadModel = $this->import('model.scm.util.upload');
        if (isset($_FILES['og_img']) && $_FILES['og_img']['size'] > 0) {
            $upImg = $uploadModel->adminUploadRealName('og_img', 'og_img', ADMIN_DIRECT_UPLOAD_PATH, 'og_img.png');
            if ($upImg['uploaded']) {
                $post['og_img'] = $upImg['url'];
            }
        }

        //트랜잭선 스타트
        $this->qb->transStart();

        foreach ($post as $key => $val) {
            if ($key == 'sns') {
                if (is_array($val)) { //거래처 유형
                    $val_sub = "";
                    foreach ($val as $sub_key => $value) {
                        if ($val_sub == '') {
                            $val_sub = $value;
                        } else {
                            $val_sub .= "|" . $value;
                        }
                    }
                }
                $val = $val_sub;
            } else if ($key == 'disp_naver') {
                $this->putSellerDetailDispEp('naver', $val);
            } else if ($key == 'disp_daum') {
                $this->putSellerDetailDispEp('daum', $val);
            }
            if ($key != "mall_ix" && $key != "ForbizCsrfTestName") {
                $sql = "REPLACE INTO " . TBL_SHOP_MALL_CONFIG . " set 
						mall_ix = ?,
						config_name = ?,
						config_value = ?  
                        ";
                if ($key == 'talktalk_script') {
                    $val = addslashes($val);
                }

                $this->qb->exec($this->qb->queryBind($sql, [MALL_IX, $key, trim($val)]));
            }
        }
        $status = $this->qb->transComplete();

        if (isset($post['use_robot_yn'])) {
            // robot.txt 만들기
            $this->createRobotTxt($post);
        }
        if (isset($post['use_sitemap_yn'])) {
            // sitemap.php 만들기
            $this->createSiteMap($post);
        }

        if (isset($post['sysUpdateUse'])) {
            $this->putSysUpdateUse($post['sysUpdateUse']);
        }

        if (isset($post['openApiUse'])) {
            $this->putOpenApiUse($post['openApiUse']);
        }


        if (!$status) {
            $result['status'] = 'fail';
            $result['error'] = 'transactions fail';
        }
        return $result;
    }

    /**
     * 쇼핑몰정보설정 네이버 & 다음 EP 사용여부
     * seller_detail(최고관리자) 수정
     */
    public function putSellerDetailDispEp($ep, $value)
    {
        if ($ep == 'naver') {
            $this->qb
                ->set('disp_naver', $value);
        } else if ($ep == 'daum') {
            $this->qb
                ->set('disp_daum', $value);
        }

        return $this->qb
            ->update(TBL_COMMON_SELLER_DETAIL)
            ->where('company_id', $this->adminInfo->company_id)
            ->exec();
    }

    /**
     * 개인정보 설정 인덱스
     */
    public function getIndexPriveConfig()
    {
        $result = [];
        $data = [];
        $data['sleep_user_yn'] = \ForbizConfig::getPrivacyConfig('sleep_user_yn');
        $data['sleep_date'] = \ForbizConfig::getPrivacyConfig('sleep_date');
        $data['sleep_user_mailing'] = \ForbizConfig::getPrivacyConfig('sleep_user_mailing');
        $data['sleep_user_mailing_day'] = \ForbizConfig::getPrivacyConfig('sleep_user_mailing_day');
        $data['change_pw_info'] = \ForbizConfig::getPrivacyConfig('change_pw_info');
        $data['change_pw_day'] = \ForbizConfig::getPrivacyConfig('change_pw_day');
        $data['change_pw_continue_day'] = \ForbizConfig::getPrivacyConfig('change_pw_continue_day');
        $data['change_admin_pw_day'] = \ForbizConfig::getPrivacyConfig('change_admin_pw_day');
        $data['secede_member_order_destruction_yn'] = \ForbizConfig::getPrivacyConfig('secede_member_order_destruction_yn');
        $data['achievement_purpose_destruction_order_memo_yn'] = \ForbizConfig::getPrivacyConfig('achievement_purpose_destruction_order_memo_yn');
        $data['achievement_purpose_destruction_order_memo_year'] = \ForbizConfig::getPrivacyConfig('achievement_purpose_destruction_order_memo_year');
        $data['achievement_purpose_destruction_order_yn'] = \ForbizConfig::getPrivacyConfig('achievement_purpose_destruction_order_yn');
        $data['achievement_purpose_destruction_order_year'] = \ForbizConfig::getPrivacyConfig('achievement_purpose_destruction_order_year');
        $data['login_history_destruction_yn'] = \ForbizConfig::getPrivacyConfig('login_history_destruction_yn');
        $data['login_history_destruction_year'] = \ForbizConfig::getPrivacyConfig('login_history_destruction_year');
        $data['secondary_authentication_use'] = \ForbizConfig::getPrivacyConfig('secondary_authentication_use');
        $data['secondary_authentication_method'] = \ForbizConfig::getPrivacyConfig('secondary_authentication_method');
        $result['data'] = $data;
        $result['status'] = 'success';
        return $result;
    }

    /**
     * 개인정보설정
     * @param type $post
     * @return string
     */
    public function putPrive($post = [])
    {
        $result = [];
        $data = [];
        $result['status'] = 'success';
        $result['data'] = $data;

        //트랜잭선 스타트
        $this->qb->transStart();
        foreach ($post as $key => $val) {
            if ($key != "mall_ix" && $key != "ForbizCsrfTestName") {
                $sql = "REPLACE INTO " . TBL_SHOP_MALL_PRIVACY_SETTING . " set 
						mall_ix = ?,
						config_name = ?,
						config_value = ?  
                        ";
                $this->qb->exec($this->qb->queryBind($sql, [MALL_IX, $key, $val]));
            }
        }
        $status = $this->qb->transComplete();

        if (!$status) {
            $result['status'] = 'fail';
            $result['error'] = 'transactions fail';
        }
        return $result;
    }

    /**
     *
     * @return string
     */
    public function getIndexMemberManage()
    {
        //디폴트 타입 선언 
        $result = [];
        $data = [];

        $member_reg_rule = \ForbizConfig::getSharedMemory('member_reg_rule');

        $result['data'] = $member_reg_rule;
        $result['status'] = 'success';
        return $result;
    }

    /**
     *
     * @return string
     */
    public function putMemberManage($post = [])
    {
        //디폴트 타입 선언
        $result = [];
        $result['status'] = 'success';
        $data = [];

        $join_type_b = $post['join_type_b'] ?? null;
        $join_type_c = $post['join_type_c'] ?? null;
        $join_type = $join_type_b . $join_type_c;
        if (!$join_type) {
            $join_type = "B";  //기본은 일반 회원
        }

        $data['mall_open_yn'] = $post['mall_open_yn'];
        $data['auth_type'] = $post['auth_type'];
        $data['b2b_auth_type'] = $post['b2b_auth_type'];
        $data['join_type'] = $join_type;
        $data['mall_deny_id'] = $post['mall_deny_id'];
        $data['mall_use_certify'] = $post['mall_use_certify'];
        $data['mall_use_ipin'] = $post['mall_use_ipin'];
        $data['mall_certify_code'] = $post['mall_certify_code'];
        $data['mall_certify_pw'] = $post['mall_certify_pw'];
        $data['mall_ipin_code'] = $post['mall_ipin_code'];
        $data['mall_ipin_pw'] = $post['mall_ipin_pw'];
        $data['mall_use_sso'] = $post['mall_use_sso'];
        $data['mall_sso_mid'] = $post['mall_sso_mid'];
        $data['mall_sso_apikey'] = $post['mall_sso_apikey'];

        $status = \ForbizConfig::setSharedMemory('member_reg_rule', $data);

        if (!$status) {
            $result['status'] = 'fail';
            $result['error'] = 'shareMemory write fail';
        }

        $result['data'] = $data;

        return $result;
    }

    public function getManageOrderBank($cur_page = 1, $limit = 20, $search = [])
    {
        $this->qb->startCache();

        // 검색 조건
        if (isset($search['searchType']) && $search['searchType'] && isset($search['searchText']) && $search['searchText']) {
            $this->qb->like($search['searchType'], $search['searchText']);
        }

        $this->qb
            ->select('bank_ix')
            ->select('bank_name')
            ->select('bank_number')
            ->select('bank_owner')
            ->select('disp')
            ->select('regdate')
            ->from(TBL_SHOP_BANKINFO);
        $this->qb->stopCache();

        $total = $this->qb->getCount();

        $paging = $this->qb
            ->setTotalRows($total)
            ->pagination($cur_page, $limit);

        $offset = ($paging['offset'] ?? 0);

        $rows = $this->qb
            ->limit($limit, $offset)
            ->exec()
            ->getResultArray();

        $this->qb->flushCache();

        return [
            'total' => $total
            , 'list' => $rows
            , 'paging' => $paging
        ];
    }

    public function putManageOrderBank($post = [])
    {
        //디폴트 타입 선언
        $result = [];
        $result['status'] = 'success';
        $data = [];

        $mode = $post['mode'] ?? null;
        $bank_ix = $post['bank_ix'] ?? null;

        if ($mode == 'update') {
            $status = $this->qb
                ->set('bank_name', $post['bank_name'])
                ->set('bank_number', $post['bank_number'])
                ->set('bank_owner', $post['bank_owner'])
                ->set('disp', $post['disp'])
                ->where('bank_ix', $bank_ix)
                ->update(TBL_SHOP_BANKINFO)
                ->exec();
        } else {
            $status = $this->qb
                ->set('regdate', date('Y-m-d H:i:s'))
                ->set('bank_name', $post['bank_name'])
                ->set('bank_number', $post['bank_number'])
                ->set('bank_owner', $post['bank_owner'])
                ->set('disp', $post['disp'])
                ->insert(TBL_SHOP_BANKINFO)
                ->exec();
        }

        if (!$status) {
            $result['status'] = 'fail';
            $result['error'] = 'qb error';
        }

        $result['data'] = $data;
        $result['data']['mode'] = $mode;

        return $result;
    }

    public function delManageOrderBank($post = [])
    {
        //디폴트 타입 선언        
        $result['status'] = 'success';
        $bank_ix = $post['bank_ix'] ?? null;
        $status = $this->qb
            ->where('bank_ix', $bank_ix)
            ->delete(TBL_SHOP_BANKINFO)
            ->exec();

        if (!$status) {
            $result['status'] = 'fail';
            $result['error'] = 'qb error';
        }
        $result['data'] = $post;
        return $result;
    }

    /**
     *
     * @param type $cur_page
     * @param type $limit
     * @param type $search
     * @return type
     */
    public function getListScmLoginLog($cur_page = 1, $limit = 20, $search = [])
    {
        $this->qb->startCache();

        // 검색 조건
        if (isset($search['searchType']) && $search['searchType'] && isset($search['searchText']) && $search['searchText']) {
            $this->qb->like($search['searchType'], $search['searchText']);
        }

        if (($search['betweenDatePickerStart'] ?? null) && ($search['betweenDatePickerEnd'] ?? null)) {
            $this->qb->betweenDate('log_date', $search['betweenDatePickerStart'], $search['betweenDatePickerEnd']);
        }


        $this->qb
            ->select('con_ix')
            ->select('con_id')
            ->select('con_name')
            ->select('ip')
            ->select('log_date')
            ->select("IF(log_div = 'I', 'login', 'logout') AS log_div", false)
            ->from(TBL_CON_LOG);
        $this->qb->stopCache();

        $total = $this->qb->getCount();

        $paging = $this->qb
            ->setTotalRows($total)
            ->pagination($cur_page, $limit);

        $offset = ($paging['offset'] ?? 0);

        $rows = $this->qb
            ->limit($limit, $offset)
            ->orderBy('log_date', 'desc')
            ->exec()
            ->getResultArray();

        $this->qb->flushCache();

        return [
            'total' => $total
            , 'list' => $rows
            , 'paging' => $paging
        ];
    }

    public function getIndexManageSellerConfig()
    {

        //디폴트 타입 선언 
        $result = [];
        $data = [];

        $basic_seller_setup = \ForbizConfig::getSharedMemory('basic_seller_setup');
        $result['data'] = $basic_seller_setup;
        $result['status'] = 'success';
        return $result;
    }

    public function putManageSellerConfig($post = [])
    {
        //디폴트 타입 선언
        $result = [];
        $result['status'] = 'success';

        $data = [];
        $data['account_type'] = $post['account_type'];
        $data['ac_delivery_type'] = $post['ac_delivery_type'];
        $data['ac_expect_date'] = $post['ac_expect_date'];
        $data['ac_term_div'] = $post['ac_term_div'];
        $data['ac_term_date1'] = ($post['ac_term_div'] == 3 ? $post['ac_term_date_week'] : $post['ac_term_date1']); // 주 1회
        $data['ac_term_date2'] = ($post['ac_term_date2'] ?? '');
        $data['commission'] = $post['commission'];
        $data['wholesale_commission'] = $post['wholesale_commission'];

        foreach ($data as $key => $val) {
            $this->sellerEditHistory($post, $key);
        }
        $status = \ForbizConfig::setSharedMemory('basic_seller_setup', $data);

        if (!$status) {
            $result['status'] = 'fail';
            $result['error'] = 'shareMemory write fail';
        }

        $result['data'] = $data;
        return $result;
    }

    /**
     * 셀러 기본 설정 히스토리
     * @param type $_bData
     * @param type $_historyData
     * @param type $col
     * @param type $columnName
     */
    protected function sellerEditHistory($post, $key)
    {
        $beforData = $this->getIndexManageSellerConfig();
        $beforData['data'][$key] = ($beforData['data'][$key] ?? '');
        if ($beforData['data'][$key] != $post[$key]) {
            $_bData = $key;
            $_historyData = $post[$key];
            $col = $key;
            switch ($col) {
                case "account_type" :
                    $columnName = "정산방식";
                    break;
                case "ac_delivery_type" :
                    $columnName = "정산예정내역타입";
                    break;
                case "ac_expect_date" :
                    $columnName = "정산예정일";
                    break;
                case "ac_term_div" :
                    $columnName = "정산확정내역 타입";
                    break;
                case "ac_term_date1" :
                    $columnName = "정산확정일";
                    break;
                case "ac_term_date2" :
                    $columnName = "정산확정일2";
                    break;
                case "commission" :
                    $columnName = "소매수수료";
                    break;
                case "wholesale_commission" :
                    $columnName = "도매수수료";
                    break;
            }
            $this->qb
                ->set('history_type', 'selleInfo')
                ->set('pkey', 'sharedMemory')
                ->set('b_data', $_bData)
                ->set('after_data', $_historyData)
                ->set('column_name', $col)
                ->set('column_text', $columnName)
                ->set('charger_ix', $this->adminInfo->charger_ix)
                ->set('charger_name', $this->adminInfo->charger)
                ->set('refurl', $this->uri->uri_string())
                ->set('regdate', date('Y-m-d H:i:s'))
                ->insert(TBL_SYSTEM_EDIT_HISTORY)
                ->exec();
        }
    }

    public function getSellerConfigEditHistory($cur_page = 1, $limit = 20, $search = [])
    {
        $this->qb->startCache();

        // 검색 조건
        if (isset($search['searchType']) && $search['searchType'] && isset($search['searchText']) && $search['searchText']) {
            $this->qb->like($search['searchType'], $search['searchText']);
        }

        $data = $this->qb
            ->select("seh_ix")
            ->select("b_data")
            ->select("after_data")
            ->select("column_name")
            ->select("column_text")
            ->select("charger_ix")
            ->select("charger_name")
            ->select("regdate")
            ->from(TBL_SYSTEM_EDIT_HISTORY)
            ->where('history_type', 'selleInfo');

        $this->qb->stopCache();

        $total = $this->qb->getCount();

        $paging = $this->qb
            ->setTotalRows($total)
            ->pagination($cur_page, $limit);

        $offset = ($paging['offset'] ?? 0);

        $rows = $this->qb
            ->limit($limit, $offset)
            ->orderBy('regdate', 'desc')
            ->exec()
            ->getResultArray();

        $this->qb->flushCache();

        return [
            'total' => $total
            , 'list' => $rows
            , 'paging' => $paging
        ];
    }

    public function getManagePolicy($cur_page = 1, $limit = 20, $search = [])
    {
        $this->qb->startCache();

        // 검색 조건
        if (isset($search['searchType']) && $search['searchType'] && isset($search['searchText']) && $search['searchText']) {
            $this->qb->like($search['searchType'], $search['searchText']);
        }


        if (($search['pi_code'] ?? null)) {
            $this->qb->where('pi_code', $search['pi_code']);
        }

        $data = $this->qb
            ->select("pi_ix")
            ->select("mall_ix")
            ->select("pi_code")
            ->select("pi_ver")
            ->select("pi_type")
            ->select("pi_contents")
            ->select("contents_type")
            ->select("disp")
            ->select("reg_id")
            ->select("reg_name")
            ->select("mod_name")
            ->select("regdate")
            ->select("moddate")
            ->select("startdate")
            ->from(TBL_SHOP_POLICY_INFO)
            ->orderBy('startdate', 'DESC');
        $this->qb->stopCache();

        $total = $this->qb->getCount();

        $paging = $this->qb
            ->setTotalRows($total)
            ->pagination($cur_page, $limit);

        $offset = ($paging['offset'] ?? 0);

        $rows = $this->qb
            ->limit($limit, $offset)
            ->exec()
            ->getResultArray();

        $this->qb->flushCache();

        return [
            'total' => $total
            , 'list' => $rows
            , 'paging' => $paging
        ];
    }

    /**
     * 약관수정
     * @param array $post
     * @return array
     * @throws \Exception
     */
    public function putManagePolicy($post = [])
    {
        //디폴트 타입 선언
        $result = [];
        $result['status'] = 'success';
        $data = [];

        $pi_ix = $post['pi_ix'] ?? null;
        $mode = $post['mode'] ?? null;

        if ($mode == 'update' && $pi_ix) {
            $status = $this->qb
                ->set('startdate', $post['startdate'])
                ->set('disp', $post['disp'])
                ->set('pi_contents', $post['policy_text'])
                ->set('pi_code', $post['pi_code'])
                ->set('mod_id', $this->adminInfo->charger_id)
                ->set('mod_name', $this->adminInfo->charger)
                ->set('moddate', date('Y-m-d H:i:s'))
                ->where('pi_ix', $pi_ix)
                ->update(TBL_SHOP_POLICY_INFO)
                ->exec();
        } else {
            $status = $this->qb
                ->set('startdate', $post['startdate'])
                ->set('disp', $post['disp'])
                ->set('pi_contents', $post['policy_text'])
                ->set('pi_code', $post['pi_code'])
                ->set('reg_id', $this->adminInfo->charger_id)
                ->set('reg_name', $this->adminInfo->charger)
                ->set('regdate', date('Y-m-d H:i:s'))
                ->insert(TBL_SHOP_POLICY_INFO)
                ->exec();
        }

        if (!$status) {
            $result['status'] = 'fail';
            $result['error'] = 'qb error';
        }

        $result['data'] = $data;

        return $result;
    }

    /**
     * 랭귀지 설정 가져오기
     */
    public function getLanguage()
    {
        return $this->qb->from(TBL_GLOBAL_LANGUAGE)->where('disp', '1')->exec()->getResultArray();
    }

    /**
     * 결제모듈 설정 가져오기
     * @param type $sattle_module
     * @return type
     */
    public function getSattleModule($sattle_module)
    {
        //디폴트 타입 선언
        $result = [];
        $result['status'] = 'success';
        $data = [];

        $rows = $this->qb
            ->select('config_name')
            ->select('config_value')
            ->from(TBL_SHOP_PAYMENT_CONFIG)
            ->where('pg_code', $sattle_module)
            ->where('mall_ix', MALL_IX)
            ->exec()
            ->getResult();

        if ($this->qb->total > 0) {
            foreach ($rows as $row) {
                $data[$row->config_name] = $row->config_value;
            }
        }

        $result['data'] = $data;
        return $result;
    }

    /**
     * 결제모듈 설정 수정
     * @param type $post
     * @return string
     */
    public function putSattleModule($post = [])
    {
        $sattleModule = $post['sattle_module'];
        unset($post['sattle_module']);
        if (is_array($post) && count($post) > 0) {
            foreach ($post as $key => $value) {
                $this->qb
                    ->from(TBL_SHOP_PAYMENT_CONFIG)
                    ->where('pg_code', $sattleModule)
                    ->where('mall_ix', MALL_IX)
                    ->where('config_name', $key)
                    ->exec();

                if ($this->qb->total > 0) {
                    $this->qb
                        ->set('config_value', $value)
                        ->where('pg_code', $sattleModule)
                        ->where('mall_ix', MALL_IX)
                        ->where('config_name', $key)
                        ->update(TBL_SHOP_PAYMENT_CONFIG)
                        ->exec();
                } else {
                    $this->qb
                        ->set('config_name', $key)
                        ->set('config_value', $value)
                        ->set('pg_code', $sattleModule)
                        ->set('mall_ix', MALL_IX)
                        ->insert(TBL_SHOP_PAYMENT_CONFIG)
                        ->exec();
                }
            }
        }
        $result['status'] = 'success';
        return $result;
    }

    public function putDeliveryServiceUseModule($data)
    {
        \ForbizConfig::setSharedMemory('deliveryServiceUse', $data);

        return [
            'status' => 'success',
            'data' => ['useYn' => $data]
        ];
    }

    /**
     * naver & daum EP 상점 상태 확인
     */
    public function checkEp($ep_type)
    {
        if ($ep_type == 'daum') {
            return \ForbizConfig::getMallConfig('disp_daum');
        } else if ($ep_type == 'naver') {
            return \ForbizConfig::getMallConfig('disp_naver');
        }
    }
}
