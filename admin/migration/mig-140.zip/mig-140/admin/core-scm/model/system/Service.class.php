<?php

namespace ForbizScm\Model\System;

/**
 * 서비스 관련 모델
 *
 * @author hoksi
 */
class Service extends \ForbizModel
{

    public function __construct()
    {
        parent::__construct();
    }

    public function getService($serviceCode)
    {
        // 상품 데이타
        $data = $this->sendPortalApi('/service/get/' . $serviceCode);
        $goodsData = $data['data'];

        $serviceOrderData = $this->sendPortalApi('/service/getServiceOrderList/'.$serviceCode, []);

        if ($serviceOrderData['result'] == 'fail') {
            $serviceOrderData['data']['list']  = [];
            $serviceOrderData['data']['total'] = 0;
        }

        if(!empty($serviceOrderData['data']['list'])) {
            foreach($serviceOrderData['data']['list'] as $key => $val) {
                $serviceOrderData['data']['list'][$key]['service_code'] = $serviceCode;
                $serviceOrderData['data']['list'][$key]['status_text'] = '-';
                $serviceOrderData['data']['list'][$key]['order_date'] = $val['payment_date'];
                $serviceOrderData['data']['list'][$key]['div_text'] = '결제';
                if($val['service_type'] == '9'){
                    $serviceOrderData['data']['list'][$key]['offer_text'] = '무기한';
                    $serviceOrderData['data']['list'][$key]['offer'] = '무기한';
                }else{
                    $serviceOrderData['data']['list'][$key]['offer'] = $val['offer'];
                    $serviceOrderData['data']['list'][$key]['offer_text'] = $val['offer'] + $val['add_offer'];
                }

                $serviceOrderData['data']['list'][$key]['ptprice_text'] = number_format($val['ptprice']);

                if($key == 0 && isset($val['cancelYn']) && $val['cancelYn'] == true && $val['ptprice'] > 0 && $val['status'] != 'CC') {
                    $serviceOrderData['data']['list'][$key]['status_text'] = '취소/환불';
                } else if ($val['status'] == 'CC') {
                    $serviceOrderData['data']['list'][$key]['status_text'] = '신청취소';
                    $serviceOrderData['data']['list'][$key]['order_date'] = $val['cancel_date'];
                    $serviceOrderData['data']['list'][$key]['div_text'] = '취소';
                }
            }
        }

        return [
            'historyList' => ($serviceOrderData['data']['list'] ?? []),
            'remainCnt' => ($serviceOrderData['data']['total'] ?? 0),
            'goodsData' => $goodsData
        ];
    }
}