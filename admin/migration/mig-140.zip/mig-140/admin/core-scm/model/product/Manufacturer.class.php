<?php
namespace ForbizScm\Model\Product;

/**
 * 제조사 관련 모델
 *
 * @author hoksi
 */
class Manufacturer extends \ForbizModel
{

    protected $disp = [
        '0' => '노출안함'
        , '1' => '노출함'
    ];

    protected $dispDiv = [
        '0' => '노출안함'
        , '1' => '노출함'
    ];

    public function __construct()
    {
        parent::__construct();
    }

    /**
     * 사용여부체크
     * @return array
     */
    public function getDispList()
    {
        return $this->disp;
    }

    /**
     * 노출상태 Text
     * @param type $disp
     * @return type
     */
    public function getDispText($disp)
    {
        return $this->disp[$disp];
    }

    /**
     * @param $c_ix
     * @return mixed
     * @throws \Exception
     */
    public function getModify($c_ix)
    {
        $row = $this->qb
            ->select('c_ix')
            ->select('company_name')
            ->select('cp_code')
            ->select('disp')
            ->select('cd_ix')
            ->select('cp_shotinfo')
            ->from(TBL_SHOP_COMPANY)
            ->where('c_ix', $c_ix)
            ->exec()
            ->getRowArray();

        return $row;
    }
    
    /**
     * 사용 리스트
     * @param type $cur_page
     * @param type $limit
     * @param array $search
     * @return type
     */
    public function getUseList($cur_page = 1, $limit = 20, $search = [])
    {
        $search['disp'] = '1';
        return $this->getList($cur_page, $limit, $search);
    }

    /**
     * get 리스트
     * @param type $cur_page
     * @param type $limit
     * @param type $search
     * @return type
     */
    public function getList($cur_page = 1, $limit = 20, $search = [])
    {
        $this->qb->startCache();

        // 검색 조건
        if (isset($search['searchType']) && $search['searchType'] && isset($search['searchText']) && $search['searchText']) {
            $this->qb->like($search['searchType'], $search['searchText']);
        }

        if (isset($search['disp']) && $search['disp'] != '') {
            $this->qb->where('a.disp', $search['disp']);
        }

        if (isset($search['cd_ix']) && $search['cd_ix'] != '') {
            $this->qb->where('a.cd_ix', $search['cd_ix']);
        }

        if (isset($search['startDate']) && $search['startDate'] && isset($search['endDate']) && $search['endDate']) {
            $this->qb->betweenDate('a.regdate', $search['startDate'], $search['endDate']);
        }

        $this->qb
            ->from(TBL_SHOP_COMPANY. ' AS a')
            ->join(TBL_SHOP_COMPANY_DIV. ' AS b', 'a.cd_ix = b.cd_ix', 'left');
        $this->qb->stopCache();

        $total = $this->qb->getCount();
        $paging = $this->qb
            ->setTotalRows($total)
            ->pagination($cur_page, $limit);

        $offset = ($paging['offset'] ?? 0);

        $rows = $this->qb
            ->select('c_ix')
            ->select('a.cd_ix')
            ->select('div_name')
            ->select('company_name')
            ->select('cp_code')
            ->select('a.disp')
            ->select('a.regdate')
            ->orderBy('a.regdate', 'DESC')
            ->limit($limit, $offset)
            ->exec()
            ->getResultArray();

        $this->qb->flushCache();

        //치환 처리
        foreach ($rows as $key => $val) {
            $val['dispText'] = $this->getDispText($val['disp']);

            $rows[$key] = $val;
        }

        return [
            'total' => $total
            , 'list' => $rows
            , 'paging' => $paging
        ];
    }

    /**
     * 원산지 저장
     * @param $data
     * @throws \Exception
     */
    public function addManufacturer($data)
    {
        $this->qb
            ->insert(TBL_SHOP_COMPANY,
                [
                    'cd_ix' => $data['cd_ix'],
                    'company_name' => $data['company_name'],
                    'cp_code' => $data['cp_code'],
                    'disp' => $data['disp'],
                    'cp_shotinfo' => $data['cp_shotinfo'],
                    'regdate' => date('Y-m-d H:i:s')
                ])
            ->exec();
    }

    public function putManufacturer($data)
    {
        $this->qb
            ->set('company_name', $data['company_name'])
            ->set('cp_code', $data['cp_code'])
            ->set('disp', $data['disp'])
            ->set('cd_ix', $data['cd_ix'])
            ->set('cp_shotinfo', $data['cp_shotinfo'])
            ->set('regdate', date('Y-m-d H:i:s'))
            ->where('c_ix', $data['c_ix'])
            ->update(TBL_SHOP_COMPANY)
            ->exec();
    }

    /**
     * 제조사 삭제
     * @param $c_ix
     * @throws \Exception
     */
    public function delManufacturer($c_ix)
    {
        $this->qb
            ->whereIn('c_ix', $c_ix)
            ->delete(TBL_SHOP_COMPANY)
            ->exec();
    }

    /**
     * 제조사 분류
     * @param int $cur_page
     * @param int $limit
     * @return array
     * @throws \Exception
     */
    public function getListDiv($cur_page = 1, $limit = 20)
    {
        $this->qb->startCache();

        $this->qb
            ->from(TBL_SHOP_COMPANY_DIV);
        $this->qb->stopCache();

        $total = $this->qb->getCount();
        $paging = $this->qb
            ->setTotalRows($total)
            ->pagination($cur_page, $limit);

        $offset = ($paging['offset'] ?? 0);

        $rows = $this->qb
            ->select('cd_ix')
            ->select('div_name')
            ->select('vieworder')
            ->select('disp')
            ->select('regdate')
            ->orderBy('vieworder', 'ASC')
            ->limit($limit, $offset)
            ->exec()
            ->getResultArray();

        $this->qb->flushCache();

        //치환 처리
        foreach ($rows as $key => $val) {
            $val['dispText'] = $this->getDivDispText($val['disp']);
            $rows[$key] = $val;
        }

        return [
            'total' => $total
            , 'list' => $rows
            , 'paging' => $paging
        ];
    }

    /**
     * 사용여부체크
     * @return array
     */
    public function getDivDispList()
    {
        return $this->dispDiv;
    }

    /**
     * 제조사 분류
     * @return array
     * @throws \Exception
     */
    public function getDivNameList()
    {
        return $this->qb
            ->select('cd_ix')
            ->select('div_name')
            ->orderBy('vieworder', 'ASC')
            ->from(TBL_SHOP_COMPANY_DIV)
            ->where('disp',1)
            ->exec()
            ->getResultArray();
    }

    /**
     * 제조사분류 노출상태 치환
     * @param type $dispDiv
     * @return type
     */
    public function getDivDispText($dispDiv)
    {
        return $this->dispDiv[$dispDiv];
    }

    /**
     * 제조사 분류 데이터 저장
     * @param $data
     * @throws \Exception
     */
    public function addCompanyDiv($data)
    {
        $this->qb
            ->insert(TBL_SHOP_COMPANY_DIV,
                [
                    'parent_cd_ix' => '0',
                    'div_name' => $data['div_name'],
                    'depth' => '1',
                    'disp' => $data['disp'],
                    'vieworder' => $data['vieworder'],
                    'regdate' => date('Y-m-d H:i:s')
                ])
            ->exec();
    }

    /**
     * 제조사 분류 데이터 수정
     * @param $post
     * @throws \Exception
     */
    public function putCompanyDiv($data)
    {
        $this->qb
            ->set('div_name', $data['div_name'])
            ->set('disp', $data['disp'])
            ->set('vieworder', $data['vieworder'])
            ->set('regdate', date('Y-m-d H:i:s'))
            ->where('cd_ix', $data['cd_ix'])
            ->update(TBL_SHOP_COMPANY_DIV)
            ->exec();
    }

    /**
     * 제조사 분류 데이터 삭제
     * @param $od_ix
     * @throws \Exception
     */
    public function delCompanyDiv($cd_ix)
    {
        $this->qb
            ->whereIn('cd_ix', $cd_ix)
            ->delete(TBL_SHOP_COMPANY_DIV)
            ->exec();
    }
}
