<?php

namespace ForbizScm\Model\Product;

/**
 * 브랜드 모델
 *
 * @author hoksi
 */
class Brand extends \ForbizModel
{

    protected $disp = [
        '0' => '노출안함'
        , '1' => '노출함'
    ];
    protected $dispDiv = [
        '0' => '노출안함'
        , '1' => '노출함'
    ];

    public function __construct()
    {
        parent::__construct();
    }

    /**
     * 사용여부체크
     * @return array
     */
    public function getDispList()
    {
        return $this->disp;
    }

    /**
     * 브랜드리스트 노출상태 치환
     * @param type $disp
     * @return type
     */
    public function getDispText($disp)
    {
        return $this->disp[$disp];
    }

    public function get($b_ix)
    {
        $row = $this->qb
            ->select('b_ix')
            ->select('brand_name')
            ->select('brand_code')
            ->select('disp')
            ->select('bd_ix')
            ->select('shotinfo')
            ->from(TBL_SHOP_BRAND)
            ->where('b_ix', $b_ix)
            ->exec()
            ->getRowArray();

        return $row;
    }

    /**
     * 사용 브랜드 리스트
     * @param type $cur_page
     * @param type $limit
     * @param array $search
     * @return type
     */
    public function getUseList($cur_page = 1, $limit = 20, $search = [])
    {
        $search['disp'] = '1';
        return $this->getList($cur_page, $limit, $search);
    }

    /**
     * 브랜드 리스트
     * @param int $cur_page
     * @param int $limit
     * @param array $search
     * @return array
     * @throws \Exception
     */
    public function getList($cur_page = 1, $limit = 20, $search = [])
    {
        $this->qb->startCache();

        // 검색 조건
        if (isset($search['searchType']) && $search['searchType'] && isset($search['searchText']) && $search['searchText']) {
            $this->qb->like($search['searchType'], $search['searchText']);
        }

        if (isset($search['disp']) && $search['disp'] != '') {
            $this->qb->where('b.disp', $search['disp']);
        }

        if (isset($search['bd_ix']) && $search['bd_ix'] != '') {
            $this->qb->where('b.bd_ix', $search['bd_ix']);
        }

        if (isset($search['b_ix']) && $search['b_ix'] != '') {
            $this->qb->whereIn('b.b_ix', $search['b_ix']);
        }

        if (isset($search['startDate']) && $search['startDate'] && isset($search['endDate']) && $search['endDate']) {
            $this->qb->betweenDate('b.regdate', $search['startDate'], $search['endDate']);
        }

        $this->qb
            ->from(TBL_SHOP_BRAND . ' AS b')
            ->join(TBL_SHOP_BRAND_DIV . ' AS d', 'b.bd_ix = d.bd_ix', 'left');
        $this->qb->stopCache();

        $total = $this->qb->getCount();
        $paging = $this->qb
            ->setTotalRows($total)
            ->pagination($cur_page, $limit);

        $offset = ($paging['offset'] ?? 0);

        $rows = $this->qb
            ->select('b_ix')
            ->select('b.bd_ix')
            ->select('div_name')
            ->select('brand_name')
            ->select('brand_code')
            ->select('b.regdate')
            ->select('b.disp')
            ->select('apply_status')
            ->orderBy('b.regdate', 'DESC')
            ->limit($limit, $offset)
            ->exec()
            ->getResultArray();

        $this->qb->flushCache();

        //치환 처리
        foreach ($rows as $key => $val) {
            $val['dispText'] = $this->getDispText($val['disp']);
            $rows[$key] = $val;
        }

        return [
            'total' => $total
            , 'list' => $rows
            , 'paging' => $paging
        ];
    }

    /**
     * 브랜드 저장
     * @param $data
     * @param $file
     * @throws \Exception
     */
    public function addBrand($data, $file)
    {
        $chkDupBrandName =
            $this->qb
                ->select('brand_name')
                ->from(TBL_SHOP_BRAND)
                ->where('brand_name',$data['brand_name'])
                ->getCount() > 0;

        if (!$chkDupBrandName) {
            $idx = $this->qb
                ->insert(TBL_SHOP_BRAND, [
                    'bd_ix' => $data['bd_ix'],
                    'brand_name' => $data['brand_name'],
                    'brand_code' => $data['brand_code'],
                    'disp' => $data['disp'],
                    'shotinfo' => $data['shotinfo'],
                    'regdate' => date('Y-m-d H:i:s')
                ])
                ->exec();

            if (!empty($file)) {
                $this->imageUpload($idx, $file);
            }
            return $idx;
        } else {
            return false;
        }

    }

    public function putBrand($data, $file)
    {
        $this->qb
            ->set('brand_name', $data['brand_name'])
            ->set('brand_code', $data['brand_code'])
            ->set('disp', $data['disp'])
            ->set('bd_ix', $data['bd_ix'])
            ->set('shotinfo', $data['shotinfo'])
            ->set('regdate', date('Y-m-d H:i:s'))
            ->where('b_ix', $data['b_ix'])
            ->update(TBL_SHOP_BRAND)
            ->exec();

        $this->imageUpload($data['b_ix'], $file);
    }

    /**
     * 브랜드 업로드
     * @param type $idx
     * @param type $file
     */
    protected function imageUpload($idx, $file)
    {
        /* @var $uploadModel \CustomScm\Model\Util\Upload */
        $uploadModel = $this->import('model.scm.util.upload');

        //넘어온것 만큼 넣음
        foreach ($file as $key => $val) {
            if ($key && $val['size'] > 0) {
                $uploadModel->brandUpload($key, $idx . $key . '.gif', $idx);
            }
        }
    }

    /**
     * 브랜드 삭제
     * @param $b_ix
     * @throws \Exception
     */
    public function delBrand($b_ix)
    {
        $this->qb
            ->whereIn('b_ix', $b_ix)
            ->delete(TBL_SHOP_BRAND)
            ->exec();
    }

    /**
     * 브랜드 분류
     * @param int $cur_page
     * @param int $limit
     * @return array
     * @throws \Exception
     */
    public function getListDiv($cur_page = 1, $limit = 20)
    {
        $this->qb->startCache();

        $this->qb
            ->from(TBL_SHOP_BRAND_DIV);
        $this->qb->stopCache();

        $total = $this->qb->getCount();
        $paging = $this->qb
            ->setTotalRows($total)
            ->pagination($cur_page, $limit);

        $offset = ($paging['offset'] ?? 0);

        $rows = $this->qb
            ->select('bd_ix')
            ->select('div_name')
            ->select('vieworder')
            ->select('disp')
            ->select('regdate')
            ->orderBy('vieworder', 'ASC')
            ->limit($limit, $offset)
            ->exec()
            ->getResultArray();

        $this->qb->flushCache();

        //치환 처리
        foreach ($rows as $key => $val) {
            $val['dispText'] = $this->getDivDispText($val['disp']);
            $rows[$key] = $val;
        }

        return [
            'total' => $total
            ,
            'list' => $rows
            ,
            'paging' => $paging
        ];
    }

    /**
     * 사용여부체크
     * @return array
     */
    public function getDivDispList()
    {
        return $this->dispDiv;
    }

    /**
     * 브랜드 분류
     * @return array
     * @throws \Exception
     */
    public function getDivNameList()
    {
        return $this->qb
            ->select('bd_ix')
            ->select('div_name')
            ->orderBy('vieworder', 'ASC')
            ->from(TBL_SHOP_BRAND_DIV)
            ->where('disp',1)
            ->exec()
            ->getResultArray();
    }

    /**
     * 브랜드분류 노출상태 치환
     * @param type $disp
     * @return type
     */
    public function getDivDispText($dispDiv)
    {
        return $this->dispDiv[$dispDiv];
    }

    /**
     * 브랜드 분류 데이터 저장
     * @param $data
     * @throws \Exception
     */
    public function addBrandDiv($data)
    {
        $this->qb
            ->insert(TBL_SHOP_BRAND_DIV, [
                'parent_bd_ix' => '0',
                'div_name' => $data['div_name'],
                'depth' => '1',
                'disp' => $data['disp'],
                'vieworder' => $data['vieworder'],
                'regdate' => date('Y-m-d H:i:s')
            ])
            ->exec();
    }

    /**
     * 브랜드 분류 데이터 수정
     * @param $post
     * @throws \Exception
     */
    public function putBrandDiv($data)
    {
        $this->qb
            ->set('div_name', $data['div_name'])
            ->set('disp', $data['disp'])
            ->set('vieworder', $data['vieworder'])
            ->set('regdate', date('Y-m-d H:i:s'))
            ->where('bd_ix', $data['bd_ix'])
            ->update(TBL_SHOP_BRAND_DIV)
            ->exec();
    }

    /**
     * 브랜드 분류 데이터 삭제
     * @param $bd_ix
     * @throws \Exception
     */
    public function delBrandDiv($bd_ix)
    {
        $this->qb
            ->whereIn('bd_ix', $bd_ix)
            ->delete(TBL_SHOP_BRAND_DIV)
            ->exec();
    }
}
