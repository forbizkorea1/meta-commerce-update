<?php

namespace ForbizScm\Controller\MyPage;

/**
 * 서비스 신청 내역
 *
 * @author hoksi
 */
class ServiceRegHistory extends \ForbizAdminController
{
    /**
     * @var \ForbizScm\Model\System\Service
     */
    protected $serviceModel;

    public function __construct()
    {
        parent::__construct();
        $this->serviceModel = $this->import('model.scm.system.service');
    }

    public function index()
    {
        // 타이틀 설정
        $this->setTitle('서비스 신청 내역');
        $this->getDeliveryProducts();

        /* @var $companyModel \CustomScm\Model\Company\Company */
        $companyModel = $this->import('model.scm.company.company');
        $companyModel->setManageCompanyId($this->adminInfo->company_id);
        $companyData = $companyModel->getManageCompany();


        /* @var $configModel \CustomScm\Model\Store\Config */
        $configModel = $this->import('model.scm.store.config');
        $dbData = $configModel->getIndexStoreConfig();

        // 주 결제 모듈
        $sattle_module = '';
        $applied = '-'; // 미신청 /신청
        $reg_date = '-'; // 신청 날짜
        $storeId = '-'; // 상점아이디
        $status = '';
        $date = '';
        $type = $dbData['data']['sattle_module'];

        switch($type)
        {
            case 'inicis':
                $sattle_module = "이니시스";
                break;
            case 'ksnet':
                $sattle_module = "KSNET";
                break;
            case 'kcp':
                $sattle_module = "KCP";
                break;
            case 'nicepay':
                $sattle_module = "나이스페이";
                break;
            default:
                break;
        }

        // 포털에서 현재 결제모듈 pg 신청 내역확인
        /* @var $model \ForbizScm\Model\Util  */
        $model = $this->import('model.scm.util');
        if ($type !== "kcp")
        {
            $result = $model->sendPortalApi('/service/getPgService', ['mall_id' => $companyData['data']['mall_id'], 'pay_type' => $type]);

            if (count($result['data']) > 0)
            {
                $applied = '신청';
                $reg_date = $result['data'][0]['regdate'];
                $storeId = $result['data'][0]['pg_id'];
            }
        }

        $this->setResponseData(['sattle_module' => [
            $sattle_module
            , $applied
            , $reg_date
            , $storeId
            ]
        ]);
    }

    public function getDeliveryProducts()
    {
        $serviceCode = $this->input->post('serviceCode');
        // 상품 데이타
        $data = $this->serviceModel->getService($serviceCode);

        $this->setResponseData([
            'goodsData' => $data['goodsData'],
            'historyList' => $data['historyList'],
            'remainCnt' => $data['remainCnt']
        ]);
    }

    public function getSsoServiceInfo()
    {
        /* @var $thirdPartyModel \CustomScm\Model\ThirdParty */
        $thirdPartyModel = $this->import('model.scm.thirdParty');

        //사업자 정보
        /* @var $companyModel \CustomScm\Model\Company\Company */
        $companyModel = $this->import('model.scm.company.company');
        $companyModel->setManageCompanyId($this->adminInfo->company_id);
        $dbData = $companyModel->getManageCompany();

        $securitySso = $thirdPartyModel->sendPortalApi('/service/getSsoInfoList', ['mall_id' => $dbData['data']['mall_id']]);
        $sso = $securitySso['data'];
        $data = $this->serviceModel->getService('sso_certification');

        $this->setResponseData([
            'sso' => $sso,
            'historyList' => $data['historyList']
        ]);
    }
}