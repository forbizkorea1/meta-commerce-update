<?php

namespace ForbizScm\Controller\MyPage;

/**
 * 서비스 이용 현황
 *
 * @author hoksi
 */
/**
 * @property \ForbizScm\Model\System\Service $serviceModel
 */
class ServiceUseStatus extends \ForbizAdminController
{
    /**
     * @var \ForbizScm\Model\System\Service
     */

    protected $serviceModel;

    public function __construct()
    {
        parent::__construct();
        $this->serviceModel = $this->import('model.scm.system.service');
    }

    public function index()
    {
        // 타이틀 설정
        $this->setTitle('서비스 이용 현황');

        /* @var $thirdPartyModel \CustomScm\Model\ThirdParty */
        $thirdPartyModel = $this->import('model.scm.thirdParty');

        //사업자 정보
        /* @var $companyModel \CustomScm\Model\Company\Company */
        $companyModel = $this->import('model.scm.company.company');
        $companyModel->setManageCompanyId($this->adminInfo->company_id);
        $dbData = $companyModel->getManageCompany();

        // 전자 결제(PG)
        $servicePG = $thirdPartyModel->sendPortalApi('/service/getPgService', ['mall_id' => $dbData['data']['mall_id']]);
        $pg = count($servicePG['data']);

        /* @var $configModel \CustomScm\Model\Store\Config */
        $configModel = $this->import('model.scm.store.config');
        $configData = $configModel->getIndexStoreConfig();

        // 주 결제 모듈
        $sattle_module = '';
        $status = '';
        $date = '';
        $type = $configData['data']['sattle_module'];

        switch($type)
        {
            case 'inicis':
                $sattle_module = "이니시스";
                break;
            case 'ksnet':
                $sattle_module = "KSNET";
                break;
            case 'kcp':
                $sattle_module = "KCP";
                break;
            case 'nicepay':
                $sattle_module = "나이스페이";
                break;
            default:
                break;
        }

        // 상품 데이터
        // 배송추적
        $lookup = $this->serviceModel->getService('delivery_tracking');

        // 자동배송완료
        $autoComplete = $this->serviceModel->getService('delivery_complete');

        // SSL 인증서
        $ssl = $this->serviceModel->getService('ssl_certification');
        $ssl_date = ($ssl['historyList'][0]['date'] ?? '');


        // KG이니시스 통합인증
        $securitySso = $thirdPartyModel->sendPortalApi('/service/getSsoInfoList', ['mall_id' => $dbData['data']['mall_id']]);
        $sso = $securitySso['data'];

        // 문자 메시지
        $sms = $this->serviceModel->getService('sms');

        // 알림톡
        $alimtalk = $this->serviceModel->getService('kakao_message');

        // 대량메일
        $mail = $this->serviceModel->getService('mail_outbound');

        // FAT
        $fat = $this->serviceModel->getService('FAT');

        // 셀러관리
        $seller = $this->serviceModel->getService('seller');

        // 마켓통합관리
        $market = $this->serviceModel->getService('market');

        // 빅인사이트
        $bigin = $this->serviceModel->getService('bigin');

        $this->setResponseData([
           'lookup' => [
               number_format(($lookup['remainCnt'] ?? 0)) // 포인트
               , (count($lookup['historyList']) > 0)   // 상태
           ],
            'autoComplete' => [
                number_format(($autoComplete['remainCnt'] ?? 0)) // 포인트
                , (count($autoComplete['historyList']) > 0)  // 상태
           ],
            'ssl' => [
                $ssl_date // 신청일
                , (count($ssl['historyList']) > 0)  // 상태
            ],
            'serviceSso' => [
                (isset($sso[0]['regdate']) ? date('Y-m-d', strtotime($sso[0]['regdate'])) : '') // 신청일
                , (count($sso) > 0)  // 상태
            ],
            'sms' => [
                number_format(($sms['remainCnt'] ?? 0)) // 포인트
                , (count($sms['historyList']) > 0)  // 상태
            ],
            'alimtalk' => [
                number_format(($alimtalk['remainCnt'] ?? 0)) // 포인트
                , (count($alimtalk['historyList']) > 0)  // 상태
            ],
            'bulkMail' => [
                number_format(($mail['remainCnt'] ?? 0)) // 포인트
                , (count($mail['historyList']) > 0)  // 상태
            ],
            'fat' => [
                number_format(($fat['remainCnt'] ?? 0)) // 포인트
                , (count($fat['historyList']) > 0)  // 상태
            ],
            'serviceSeller' => [
                number_format(($seller['remainCnt'] ?? 0)) // 포인트
                , (count($seller['historyList']) > 0)  // 상태
            ],
            'serviceMarket' => [
                number_format(($market['remainCnt'] ?? 0)) // 포인트
                , (count($market['historyList']) > 0)  // 상태
            ],
            'serviceBigin' => [
                number_format(($bigin['remainCnt'] ?? 0)) // 포인트
                , (count($bigin['historyList']) > 0)  // 상태
            ],
            'pg' => [
                $pg // 바로오픈 신천내역 조회
                , $sattle_module // 패키지 주결제 모듈
            ]
        ]);
    }
}