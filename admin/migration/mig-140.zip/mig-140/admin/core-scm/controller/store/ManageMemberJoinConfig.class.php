<?php
namespace ForbizScm\Controller\Store;

/**
 * 회원가입 설정
 *
 * @author hoksi
 */
class ManageMemberJoinConfig extends \ForbizAdminController
{

    public function __construct()
    {
        parent::__construct();
    }

    public function index()
    {
        // 타이틀 설정
        $this->setTitle('회원가입설정');
        $this->setTopBtn('저장', 'save');

        /* @var $configModel \CustomScm\Model\Store\Config */
        $configModel = $this->import('model.scm.store.config');
        $dbData = $configModel->getIndexMemberManage();
        $this->setResponseData(['config' => $dbData['data']]);
    }

    public function put()
    {
        // 검증할 컬럼 등록
        $chkField = ['mall_open_yn'];

        // 폼 검증
        if (form_validation($chkField)) {
            // 검증 성공

            //통합인증 MID 체크
            $check = true;
            $mall_use_sso = $this->input->post('mall_use_sso');
            if($mall_use_sso == 'Y'){
                $mall_sso_mid = $this->input->post('mall_sso_mid');
                if ((substr($mall_sso_mid, 0, 3) != 'FBI') && $mall_sso_mid != "INIiasTest") {
                    $check = false;
                }
            }

            if($check){
                /* @var $configModel \CustomScm\Model\Store\Config */
                $configModel = $this->import('model.scm.store.config');
                $dbData = $configModel->putMemberManage($this->input->post());
                $this->setResponseResult($dbData['status'])->setResponseData($dbData['data']);
            }else{
                $this->setResponseResult('fail')->setResponseData(['error' => 'mid']);
            }


        } else {
            // 검증 실패
            $this->setResponseResult('fail')
                ->setResponseData(validation_errors());
        }
    }
}
