<?php

namespace ForbizScm\Controller\Marketing;

/**
 * 오프라인 쿠폰 리스트
 *
 * @author hoksi
 * @property \CustomScm\Model\Marketing\Coupon $couponModel 정산 확정 내역
 */
class ListOfflineCoupon extends \ForbizAdminController
{

    protected $couponModel;

    public function __construct()
    {
        parent::__construct();

        $this->couponModel = $this->import('model.scm.marketing.coupon');
    }

    public function index()
    {
        // 타이틀 설정
        $this->setTitle('오프라인 쿠폰 리스트');

        $this->setResponseData('giftTypeList', $this->couponModel->getGiftType());
        $this->setResponseData('couponDivList', $this->couponModel->getCouponDiv());
        $this->setResponseData('couponUseDiv', $this->couponModel->getCouponUseDiv());
        $this->setResponseData('couponSaleTypeList', $this->couponModel->getCouponSaleType());
        $this->setResponseData('issueTypeList', $this->couponModel->getIssueType());
        $this->setResponseData('publishTypeList', $this->couponModel->getPublishType());
        $this->setResponseData('isUseList', $this->couponModel->getIsUse());

        /* @var $groupModel \CustomScm\Model\Member\Group */
        $groupModel = $this->import('model.scm.member.group');

        $this->setResponseData('groupList', $groupModel->useList());
    }

    public function get()
    {
        // 입력 필수 항목
        $chekField = ['page', 'max'];
        // 필수 항목 점검
        if (form_validation($chekField)) {
            $this->setResponseData(
                $this->couponModel->getListOffline(
                    $this->input->post('page')
                    , $this->input->post('max')
                    , $this->input->post()
                )
            );
        } else {
            $this->setResponseResult('fail')->setResponseData(validation_errors());
        }
    }

    public function del()
    {
        // 입력 필수 항목
        $chekField = ['gc_ix'];
        // 필수 항목 점검
        if (form_validation($chekField)) {
            $this->couponModel->delOfflineCoupon($this->input->post('gc_ix'));
        } else {
            $this->setResponseResult('fail')->setResponseData(validation_errors());
        }
    }

    public function add()
    {
        // 입력 필수 항목
        $chekField = ['gc_ix'];
        // 필수 항목 점검
        if (form_validation($chekField)) {
            $this->couponModel->copyOfflineCoupon($this->input->post('gc_ix'));
        } else {
            $this->setResponseResult('fail')->setResponseData(validation_errors());
        }
    }

    public function getOfflineRegistList()
    {
        // 입력 필수 항목
        $chekField = ['page', 'max'];
        // 필수 항목 점검
        if (form_validation($chekField)) {
            $this->setResponseData(
                $this->couponModel->getOfflineRegistList(
                    $this->input->post('page')
                    , $this->input->post('max')
                    , $this->input->post()
                )
            );
        } else {
            $this->setResponseResult('fail')->setResponseData(validation_errors());
        }
    }

    public function delOfflineRegist()
    {
        // 입력 필수 항목
        $chekField = ['gcd_ix'];
        // 필수 항목 점검
        if (form_validation($chekField)) {
            $registIxList = json_decode($this->input->post('gcd_ix'));
            foreach ($registIxList as $registIx) {
                $this->couponModel->delOfflineRegist($registIx);
            }
        } else {
            $this->setResponseResult('fail')->setResponseData(validation_errors());
        }
    }

    /**
     * 엑셀다운로드
     */
    public function dwn()
    {
        /* @var $excel \ForbizExcel */
        $excel = $this->import('lib.excel');

        $data = $this->couponModel->getOfflineRegistList( 1  , $excel->getMaxRow()  , $this->input->post() );

        // 엑셀파일명 설정 및 히스토리 기록
        $excelFileName = $this->import('model.scm.util.excelDwnHistory')->getExcelFileName();

        // Excel file download
        $excel->setTitle([
            'gift_code' => '시리얼 넘버'
            , 'useDateText' => '사용가능기간'
            , 'useText' => '상태'
            , 'member_id' => '사용자 ID'
            , 'name' => '사용자명'
            , 'use_date' => '사용일자'
        ])
            ->setData($data['list'])
            ->setDownloadType('excel')
            ->download($excelFileName);
    }
}