<?php

namespace ForbizScm\Model\LogStory;

/**
 * 레포트 관련 모델
 *
 * @author hoksi
 */
class Report extends \ForbizModel
{
    /**
     * agent type
     * @var array
     */
    protected $agentType = [
        'W' => 'PC',
        'M' => 'MOBILE',
        //'A' => 'APP'
    ];
    /**
     * 시간
     * @var array
     */
    protected $day = [];
    /**
     * 일자
     * @var array
     */
    protected $hour = [];

    public function __construct()
    {
        parent::__construct();

        //set 시간
        for ($i = 0; $i <= 23; $i++) {
            array_push($this->hour, $i);
        }

        //set 일자
        for ($i = 1; $i <= 31; $i++) {
            if (strlen($i) == 1) {
                $i = '0' . $i;
            }
            array_push($this->day, $i);
        }
    }

    /**
     * get agent type list
     * @return array
     */
    public function getAgentTypeList()
    {
        return $this->agentType;
    }

    /**
     * 페이지뷰
     * @param $reportType
     * @param $searchDateDataList
     * @return array
     */
    public function getPageView($reportType, $searchDateDataList)
    {
        $this->qb->startCache();

        if ($reportType == 'T') {
            $this->qb
                ->selectSum('nh00')
                ->selectSum('nh01')
                ->selectSum('nh02')
                ->selectSum('nh03')
                ->selectSum('nh04')
                ->selectSum('nh05')
                ->selectSum('nh06')
                ->selectSum('nh07')
                ->selectSum('nh08')
                ->selectSum('nh09')
                ->selectSum('nh10')
                ->selectSum('nh11')
                ->selectSum('nh12')
                ->selectSum('nh13')
                ->selectSum('nh14')
                ->selectSum('nh15')
                ->selectSum('nh16')
                ->selectSum('nh17')
                ->selectSum('nh18')
                ->selectSum('nh19')
                ->selectSum('nh20')
                ->selectSum('nh21')
                ->selectSum('nh22')
                ->selectSum('nh23');
        } else {
            $this->qb
                ->select("DATE_FORMAT(vdate,'%d') as day")
                ->selectSum('ncnt')
                ->groupBy("day");
        }

        $this->qb
            ->select('agent_type')
            ->from(TBL_LOGSTORY_PAGEVIEWTIME . ' AS lp')
            ->groupBy('agent_type');

        $this->qb->stopCache();

        $list = [];

        // 기간별 조회
        foreach ($searchDateDataList as $searchDateData) {

            $rows = $this->qb
                ->betweenDate('vdate', $searchDateData['startDate'], $searchDateData['endDate'])
                ->exec()
                ->getResultArray();

            $converter = $this->dataReportTypeConverterByAgentType($reportType, $rows);

            $totalCnt = $converter['total'];
            $converterData = $converter['data'];

            $returnData = [];

            foreach ($converterData as $dt) {
                $agentData = [];
                $valueSum = 0;

                foreach ($dt['agentTypeData'] as $agentTypeCode => $value) {
                    $agentData['cntAgentType' . $agentTypeCode] = $value;
                    if ($totalCnt > 0) {
                        $rate = round($value / $totalCnt * 100, 2);
                    } else {
                        $rate = 0;
                    }
                    $agentData['rateAgentType' . $agentTypeCode] = $rate;
                    $valueSum += $value;
                }

                $agentData['cntSum'] = $valueSum;
                if ($totalCnt > 0) {
                    $rate = round($valueSum / $totalCnt * 100, 2);
                } else {
                    $rate = 0;
                }
                $agentData['rateSum'] = $rate;

                $returnData[] = array_merge([$dt['targetKey'] => $dt['targetKeyValue']], $agentData);
            }

            $list[$searchDateData['key']] = $returnData;
        }

        $this->qb->flushCache();

        return $list;
    }

    /**
     * 방문횟수
     * @param $reportType
     * @param $searchDateDataList
     * @return array
     * @throws \Exception
     */
    public function getVisit($reportType, $searchDateDataList)
    {
        $this->qb->startCache();

        if ($reportType == 'T') {
            $this->qb
                ->selectSum('nh00')
                ->selectSum('nh01')
                ->selectSum('nh02')
                ->selectSum('nh03')
                ->selectSum('nh04')
                ->selectSum('nh05')
                ->selectSum('nh06')
                ->selectSum('nh07')
                ->selectSum('nh08')
                ->selectSum('nh09')
                ->selectSum('nh10')
                ->selectSum('nh11')
                ->selectSum('nh12')
                ->selectSum('nh13')
                ->selectSum('nh14')
                ->selectSum('nh15')
                ->selectSum('nh16')
                ->selectSum('nh17')
                ->selectSum('nh18')
                ->selectSum('nh19')
                ->selectSum('nh20')
                ->selectSum('nh21')
                ->selectSum('nh22')
                ->selectSum('nh23');
        } else {
            $this->qb
                ->select("DATE_FORMAT(vdate,'%d') as day")
                ->selectSum('ncnt')
                ->groupBy("day");
        }

        $this->qb
            ->select('agent_type')
            ->from(TBL_LOGSTORY_VISITTIME . ' AS lv')
            ->groupBy('agent_type');

        $this->qb->stopCache();

        $list = [];

        // 기간별 조회
        foreach ($searchDateDataList as $searchDateData) {

            $rows = $this->qb
                ->betweenDate('vdate', $searchDateData['startDate'], $searchDateData['endDate'])
                ->exec()
                ->getResultArray();

            $converter = $this->dataReportTypeConverterByAgentType($reportType, $rows);

            $totalCnt = $converter['total'];
            $converterData = $converter['data'];

            $returnData = [];

            foreach ($converterData as $dt) {
                $agentData = [];
                $valueSum = 0;

                foreach ($dt['agentTypeData'] as $agentTypeCode => $value) {
                    $agentData['cntAgentType' . $agentTypeCode] = $value;
                    if ($totalCnt > 0) {
                        $rate = round($value / $totalCnt * 100, 2);
                    } else {
                        $rate = 0;
                    }
                    $agentData['rateAgentType' . $agentTypeCode] = $rate;
                    $valueSum += $value;
                }

                $agentData['cntSum'] = $valueSum;
                if ($totalCnt > 0) {
                    $rate = round($valueSum / $totalCnt * 100, 2);
                } else {
                    $rate = 0;
                }
                $agentData['rateSum'] = $rate;

                $returnData[] = array_merge([$dt['targetKey'] => $dt['targetKeyValue']], $agentData);
            }

            $list[$searchDateData['key']] = $returnData;
        }

        $this->qb->flushCache();

        return $list;
    }

    /**
     * 순수방문자
     * @param $reportType
     * @param $searchDateDataList
     * @return array
     * @throws \Exception
     */
    public function getVisitor($reportType, $searchDateDataList)
    {
        $this->qb->startCache();

        if ($reportType == 'T') {
            $this->qb
                ->selectSum('nh00')
                ->selectSum('nh01')
                ->selectSum('nh02')
                ->selectSum('nh03')
                ->selectSum('nh04')
                ->selectSum('nh05')
                ->selectSum('nh06')
                ->selectSum('nh07')
                ->selectSum('nh08')
                ->selectSum('nh09')
                ->selectSum('nh10')
                ->selectSum('nh11')
                ->selectSum('nh12')
                ->selectSum('nh13')
                ->selectSum('nh14')
                ->selectSum('nh15')
                ->selectSum('nh16')
                ->selectSum('nh17')
                ->selectSum('nh18')
                ->selectSum('nh19')
                ->selectSum('nh20')
                ->selectSum('nh21')
                ->selectSum('nh22')
                ->selectSum('nh23');
        } else {
            $this->qb
                ->select("DATE_FORMAT(vdate,'%d') as day")
                ->selectSum('ncnt')
                ->groupBy("day");
        }

        $this->qb
            ->select('agent_type')
            ->from(TBL_LOGSTORY_VISITOR . ' AS lv')
            ->groupBy('agent_type');

        $this->qb->stopCache();

        $list = [];

        // 기간별 조회
        foreach ($searchDateDataList as $searchDateData) {

            $rows = $this->qb
                ->betweenDate('vdate', $searchDateData['startDate'], $searchDateData['endDate'])
                ->exec()
                ->getResultArray();

            $converter = $this->dataReportTypeConverterByAgentType($reportType, $rows);

            $totalCnt = $converter['total'];
            $converterData = $converter['data'];

            $returnData = [];

            foreach ($converterData as $dt) {
                $agentData = [];
                $valueSum = 0;

                foreach ($dt['agentTypeData'] as $agentTypeCode => $value) {
                    $agentData['cntAgentType' . $agentTypeCode] = $value;
                    if ($totalCnt > 0) {
                        $rate = round($value / $totalCnt * 100, 2);
                    } else {
                        $rate = 0;
                    }
                    $agentData['rateAgentType' . $agentTypeCode] = $rate;
                    $valueSum += $value;
                }

                $agentData['cntSum'] = $valueSum;
                if ($totalCnt > 0) {
                    $rate = round($valueSum / $totalCnt * 100, 2);
                } else {
                    $rate = 0;
                }
                $agentData['rateSum'] = $rate;

                $returnData[] = array_merge([$dt['targetKey'] => $dt['targetKeyValue']], $agentData);
            }

            $list[$searchDateData['key']] = $returnData;
        }

        $this->qb->flushCache();

        return $list;
    }

    /**
     * 페이지별 페이지뷰
     * @param $searchDateDataList
     * @return array
     */
    public function getPageViewByPage($searchDateDataList)
    {
        $this->qb->startCache();

        $this->qb
            ->select('lp.vurl')
            ->selectSum('lb.ncnt')
            ->selectSum('lb.nduration')
            ->from(TBL_LOGSTORY_BYPAGE . ' AS lb')
            ->join(TBL_LOGSTORY_PAGEINFO . ' AS lp', 'lp.pageid = lb.pageid')
            ->groupBy("vurl");

        $this->qb->stopCache();

        $list = [];

        // 기간별 조회
        foreach ($searchDateDataList as $searchDateData) {

            $rows = $this->qb
                ->betweenDate('lb.vdate', $searchDateData['startDate'], $searchDateData['endDate'])
                ->exec()
                ->getResultArray();

            foreach ($rows as $rowKey => $rowData) {
                if ($rowData['ncnt'] > 0) {
                    $rowData['avgNduration'] = $rowData['nduration'] / $rowData['ncnt'];
                } else {
                    $rowData['avgNduration'] = 0;
                }
                $rowData['avgNdurationText'] = $this->displayTimeFormat($rowData['avgNduration']);
                $rows[$rowKey] = $rowData;
            }

            $list[$searchDateData['key']] = $rows;
        }

        $this->qb->flushCache();

        return $list;
    }

    /**
     * 페이지뷰당 체류시간
     * @param $reportType
     * @param $searchDateDataList
     * @return array
     */
    public function getDurationByPageView($reportType, $searchDateDataList)
    {
        $this->qb->startCache();

        if ($reportType == 'T') {
            $this->qb
                ->selectSum('p.nh00', 'p00')
                ->selectSum('p.nh01', 'p01')
                ->selectSum('p.nh02', 'p02')
                ->selectSum('p.nh03', 'p03')
                ->selectSum('p.nh04', 'p04')
                ->selectSum('p.nh05', 'p05')
                ->selectSum('p.nh06', 'p06')
                ->selectSum('p.nh07', 'p07')
                ->selectSum('p.nh08', 'p08')
                ->selectSum('p.nh09', 'p09')
                ->selectSum('p.nh10', 'p10')
                ->selectSum('p.nh11', 'p11')
                ->selectSum('p.nh12', 'p12')
                ->selectSum('p.nh13', 'p13')
                ->selectSum('p.nh14', 'p14')
                ->selectSum('p.nh15', 'p15')
                ->selectSum('p.nh16', 'p16')
                ->selectSum('p.nh17', 'p17')
                ->selectSum('p.nh18', 'p18')
                ->selectSum('p.nh19', 'p19')
                ->selectSum('p.nh20', 'p20')
                ->selectSum('p.nh21', 'p21')
                ->selectSum('p.nh22', 'p22')
                ->selectSum('p.nh23', 'p23')
                ->selectSum('d.nh00', 'd00')
                ->selectSum('d.nh01', 'd01')
                ->selectSum('d.nh02', 'd02')
                ->selectSum('d.nh03', 'd03')
                ->selectSum('d.nh04', 'd04')
                ->selectSum('d.nh05', 'd05')
                ->selectSum('d.nh06', 'd06')
                ->selectSum('d.nh07', 'd07')
                ->selectSum('d.nh08', 'd08')
                ->selectSum('d.nh09', 'd09')
                ->selectSum('d.nh10', 'd10')
                ->selectSum('d.nh11', 'd11')
                ->selectSum('d.nh12', 'd12')
                ->selectSum('d.nh13', 'd13')
                ->selectSum('d.nh14', 'd14')
                ->selectSum('d.nh15', 'd15')
                ->selectSum('d.nh16', 'd16')
                ->selectSum('d.nh17', 'd17')
                ->selectSum('d.nh18', 'd18')
                ->selectSum('d.nh19', 'd19')
                ->selectSum('d.nh20', 'd20')
                ->selectSum('d.nh21', 'd21')
                ->selectSum('d.nh22', 'd22')
                ->selectSum('d.nh23', 'd23');
        } else {
            $this->qb
                ->select("DATE_FORMAT(p.vdate,'%d') as day")
                ->selectSum('p.ncnt')
                ->selectSum('d.nduration')
                ->groupBy("day");
        }

        $this->qb
            ->select('p.agent_type')
            ->from(TBL_LOGSTORY_PAGEVIEWTIME . ' AS p')
            ->join(TBL_LOGSTORY_DURATIONTIME . ' AS d', 'd.vdate=p.vdate AND d.agent_type=p.agent_type')
            ->groupBy('agent_type');

        $this->qb->stopCache();

        $list = [];

        // 기간별 조회
        foreach ($searchDateDataList as $searchDateData) {

            $rows = $this->qb
                ->betweenDate('p.vdate', $searchDateData['startDate'], $searchDateData['endDate'])
                ->exec()
                ->getResultArray();

            foreach ($rows as $rowKey => $rowData) {
                if ($reportType == 'T') {
                    foreach ($this->hour as $hour) {
                        $hour = zerofill($hour, 2);
                        if ($rowData['p' . $hour] > 0) {
                            $rowData['nh' . $hour] = round($rowData['d' . $hour] / $rowData['p' . $hour]);
                        } else {
                            $rowData['nh' . $hour] = 0;
                        }
                    }
                } else {
                    if ($rowData['ncnt'] > 0) {

                        $rowData['avgNduration'] = round($rowData['nduration'] / $rowData['ncnt']);
                    } else {
                        $rowData['avgNduration'] = 0;
                    }
                }
                $rows[$rowKey] = $rowData;
            }

            $converter = $this->dataReportTypeConverterByAgentType($reportType, $rows, 'nh', 'avgNduration');
            $converterData = $converter['data'];

            $returnData = [];

            foreach ($converterData as $dt) {
                $agentData = [];
                $valueSum = 0;

                foreach ($dt['agentTypeData'] as $agentTypeCode => $value) {
                    $agentData['avgNdurationAgentType' . $agentTypeCode] = $value;
                    $agentData['avgNdurationAgentType' . $agentTypeCode . 'Text'] = $this->displayTimeFormat($value);
                    $valueSum += $value;
                }
                $agentData['avgNdurationSum'] = $valueSum;
                $agentData['avgNdurationSumText'] = $this->displayTimeFormat($valueSum);
                $returnData[] = array_merge([$dt['targetKey'] => $dt['targetKeyValue']], $agentData);
            }

            $list[$searchDateData['key']] = $returnData;
        }

        $this->qb->flushCache();

        return $list;
    }

    public function getDurationByPageViewCompare($reportType, $compareKeyList, $searchDateDataList, $list)
    {
        $compareList = $this->getCompareDataConverter($reportType, $compareKeyList, $searchDateDataList, $list);

        foreach ($compareList as $key => $list) {
            foreach ($list['data'] as $dataKey => $data) {
                $data['avgNdurationSumTargetText'] = $this->displayTimeFormat($data['avgNdurationSumTarget']);
                foreach ($this->agentType as $agentTypeCode => $agentTypeTitle) {
                    $data['avgNdurationAgentType' . $agentTypeCode . 'TargetText'] = $this->displayTimeFormat($data['avgNdurationAgentType' . $agentTypeCode . 'Target']);
                }
                $list['data'][$dataKey] = $data;
            }
            $compareList[$key] = $list;
        }
        return $compareList;
    }

    /**
     * 방문횟수당 체류시간
     * @param $reportType
     * @param $searchDateDataList
     * @return array
     */
    public function getDurationByVisit($reportType, $searchDateDataList)
    {
        $this->qb->startCache();

        if ($reportType == 'T') {
            $this->qb
                ->selectSum('v.nh00', 'p00')
                ->selectSum('v.nh01', 'p01')
                ->selectSum('v.nh02', 'p02')
                ->selectSum('v.nh03', 'p03')
                ->selectSum('v.nh04', 'p04')
                ->selectSum('v.nh05', 'p05')
                ->selectSum('v.nh06', 'p06')
                ->selectSum('v.nh07', 'p07')
                ->selectSum('v.nh08', 'p08')
                ->selectSum('v.nh09', 'p09')
                ->selectSum('v.nh10', 'p10')
                ->selectSum('v.nh11', 'p11')
                ->selectSum('v.nh12', 'p12')
                ->selectSum('v.nh13', 'p13')
                ->selectSum('v.nh14', 'p14')
                ->selectSum('v.nh15', 'p15')
                ->selectSum('v.nh16', 'p16')
                ->selectSum('v.nh17', 'p17')
                ->selectSum('v.nh18', 'p18')
                ->selectSum('v.nh19', 'p19')
                ->selectSum('v.nh20', 'p20')
                ->selectSum('v.nh21', 'p21')
                ->selectSum('v.nh22', 'p22')
                ->selectSum('v.nh23', 'p23')
                ->selectSum('d.nh00', 'd00')
                ->selectSum('d.nh01', 'd01')
                ->selectSum('d.nh02', 'd02')
                ->selectSum('d.nh03', 'd03')
                ->selectSum('d.nh04', 'd04')
                ->selectSum('d.nh05', 'd05')
                ->selectSum('d.nh06', 'd06')
                ->selectSum('d.nh07', 'd07')
                ->selectSum('d.nh08', 'd08')
                ->selectSum('d.nh09', 'd09')
                ->selectSum('d.nh10', 'd10')
                ->selectSum('d.nh11', 'd11')
                ->selectSum('d.nh12', 'd12')
                ->selectSum('d.nh13', 'd13')
                ->selectSum('d.nh14', 'd14')
                ->selectSum('d.nh15', 'd15')
                ->selectSum('d.nh16', 'd16')
                ->selectSum('d.nh17', 'd17')
                ->selectSum('d.nh18', 'd18')
                ->selectSum('d.nh19', 'd19')
                ->selectSum('d.nh20', 'd20')
                ->selectSum('d.nh21', 'd21')
                ->selectSum('d.nh22', 'd22')
                ->selectSum('d.nh23', 'd23');
        } else {
            $this->qb
                ->select("DATE_FORMAT(v.vdate,'%d') as day")
                ->selectSum('v.ncnt')
                ->selectSum('d.nduration')
                ->groupBy("day");
        }

        $this->qb
            ->select('v.agent_type')
            ->from(TBL_LOGSTORY_VISITTIME . ' AS v')
            ->join(TBL_LOGSTORY_DURATIONTIME . ' AS d', 'd.vdate=v.vdate AND d.agent_type=v.agent_type')
            ->groupBy('agent_type');

        $this->qb->stopCache();

        $list = [];

        // 기간별 조회
        foreach ($searchDateDataList as $searchDateData) {

            $rows = $this->qb
                ->betweenDate('v.vdate', $searchDateData['startDate'], $searchDateData['endDate'])
                ->exec()
                ->getResultArray();

            foreach ($rows as $rowKey => $rowData) {
                if ($reportType == 'T') {
                    foreach ($this->hour as $hour) {
                        $hour = zerofill($hour, 2);
                        if ($rowData['p' . $hour] > 0) {
                            $rowData['nh' . $hour] = round($rowData['d' . $hour] / $rowData['p' . $hour]);
                        } else {
                            $rowData['nh' . $hour] = 0;
                        }
                    }
                } else {
                    if ($rowData['ncnt'] > 0) {

                        $rowData['avgNduration'] = round($rowData['nduration'] / $rowData['ncnt']);
                    } else {
                        $rowData['avgNduration'] = 0;
                    }
                }
                $rows[$rowKey] = $rowData;
            }

            $converter = $this->dataReportTypeConverterByAgentType($reportType, $rows, 'nh', 'avgNduration');
            $converterData = $converter['data'];

            $returnData = [];

            foreach ($converterData as $dt) {
                $agentData = [];
                $valueSum = 0;

                foreach ($dt['agentTypeData'] as $agentTypeCode => $value) {
                    $agentData['avgNdurationAgentType' . $agentTypeCode] = $value;
                    $agentData['avgNdurationAgentType' . $agentTypeCode . 'Text'] = $this->displayTimeFormat($value);
                    $valueSum += $value;
                }
                $agentData['avgNdurationSum'] = $valueSum;
                $agentData['avgNdurationSumText'] = $this->displayTimeFormat($valueSum);
                $returnData[] = array_merge([$dt['targetKey'] => $dt['targetKeyValue']], $agentData);
            }

            $list[$searchDateData['key']] = $returnData;
        }

        $this->qb->flushCache();

        return $list;
    }

    /**
     * 방문횟수당 페이지뷰
     * @param $reportType
     * @param $searchDateDataList
     * @return array
     */
    public function getPageViewByVisit($reportType, $searchDateDataList)
    {
        $this->qb->startCache();

        if ($reportType == 'T') {
            $this->qb
                ->selectSum('v.nh00', 'p00')
                ->selectSum('v.nh01', 'p01')
                ->selectSum('v.nh02', 'p02')
                ->selectSum('v.nh03', 'p03')
                ->selectSum('v.nh04', 'p04')
                ->selectSum('v.nh05', 'p05')
                ->selectSum('v.nh06', 'p06')
                ->selectSum('v.nh07', 'p07')
                ->selectSum('v.nh08', 'p08')
                ->selectSum('v.nh09', 'p09')
                ->selectSum('v.nh10', 'p10')
                ->selectSum('v.nh11', 'p11')
                ->selectSum('v.nh12', 'p12')
                ->selectSum('v.nh13', 'p13')
                ->selectSum('v.nh14', 'p14')
                ->selectSum('v.nh15', 'p15')
                ->selectSum('v.nh16', 'p16')
                ->selectSum('v.nh17', 'p17')
                ->selectSum('v.nh18', 'p18')
                ->selectSum('v.nh19', 'p19')
                ->selectSum('v.nh20', 'p20')
                ->selectSum('v.nh21', 'p21')
                ->selectSum('v.nh22', 'p22')
                ->selectSum('v.nh23', 'p23')
                ->selectSum('p.nh00', 'd00')
                ->selectSum('p.nh01', 'd01')
                ->selectSum('p.nh02', 'd02')
                ->selectSum('p.nh03', 'd03')
                ->selectSum('p.nh04', 'd04')
                ->selectSum('p.nh05', 'd05')
                ->selectSum('p.nh06', 'd06')
                ->selectSum('p.nh07', 'd07')
                ->selectSum('p.nh08', 'd08')
                ->selectSum('p.nh09', 'd09')
                ->selectSum('p.nh10', 'd10')
                ->selectSum('p.nh11', 'd11')
                ->selectSum('p.nh12', 'd12')
                ->selectSum('p.nh13', 'd13')
                ->selectSum('p.nh14', 'd14')
                ->selectSum('p.nh15', 'd15')
                ->selectSum('p.nh16', 'd16')
                ->selectSum('p.nh17', 'd17')
                ->selectSum('p.nh18', 'd18')
                ->selectSum('p.nh19', 'd19')
                ->selectSum('p.nh20', 'd20')
                ->selectSum('p.nh21', 'd21')
                ->selectSum('p.nh22', 'd22')
                ->selectSum('p.nh23', 'd23');
        } else {
            $this->qb
                ->select("DATE_FORMAT(v.vdate,'%d') as day")
                ->selectSum('v.ncnt')
                ->selectSum('p.ncnt')
                ->groupBy("day");
        }

        $this->qb
            ->select('v.agent_type')
            ->from(TBL_LOGSTORY_VISITTIME . ' AS v')
            ->join(TBL_LOGSTORY_PAGEVIEWTIME . ' AS p', 'p.vdate=v.vdate AND p.agent_type=v.agent_type')
            ->groupBy('agent_type');

        $this->qb->stopCache();

        $list = [];

        // 기간별 조회
        foreach ($searchDateDataList as $searchDateData) {

            $rows = $this->qb
                ->betweenDate('v.vdate', $searchDateData['startDate'], $searchDateData['endDate'])
                ->exec()
                ->getResultArray();

            foreach ($rows as $rowKey => $rowData) {
                if ($reportType == 'T') {
                    foreach ($this->hour as $hour) {
                        $hour = zerofill($hour, 2);
                        if ($rowData['p' . $hour] > 0) {
                            $rowData['nh' . $hour] = round($rowData['d' . $hour] / $rowData['p' . $hour]);
                        } else {
                            $rowData['nh' . $hour] = 0;
                        }
                    }
                } else {
                    if ($rowData['ncnt'] > 0) {

                        $rowData['avgNcnt'] = round($rowData['ncnt'] / $rowData['ncnt']);
                    } else {
                        $rowData['avgNcnt'] = 0;
                    }
                }
                $rows[$rowKey] = $rowData;
            }

            $converter = $this->dataReportTypeConverterByAgentType($reportType, $rows, 'nh', 'avgNcnt');
            $converterData = $converter['data'];

            $returnData = [];

            foreach ($converterData as $dt) {
                $agentData = [];
                $valueSum = 0;

                foreach ($dt['agentTypeData'] as $agentTypeCode => $value) {
                    $agentData['avgNdurationAgentType' . $agentTypeCode] = $value;
                    $agentData['avgNdurationAgentType' . $agentTypeCode . 'Text'] = $this->displayTimeFormat($value);
                    $valueSum += $value;
                }
                $agentData['avgNdurationSum'] = $valueSum;
                $agentData['avgNdurationSumText'] = $this->displayTimeFormat($valueSum);
                $returnData[] = array_merge([$dt['targetKey'] => $dt['targetKeyValue']], $agentData);
            }

            $list[$searchDateData['key']] = $returnData;
        }

        $this->qb->flushCache();

        return $list;
    }

    /**
     * 순수방문자당 페이지뷰
     * @param $reportType
     * @param $searchDateDataList
     * @return array
     */
    public function getPageViewByVisitor($reportType, $searchDateDataList)
    {
        $this->qb->startCache();

        if ($reportType == 'T') {
            $this->qb
                ->selectSum('v.nh00', 'p00')
                ->selectSum('v.nh01', 'p01')
                ->selectSum('v.nh02', 'p02')
                ->selectSum('v.nh03', 'p03')
                ->selectSum('v.nh04', 'p04')
                ->selectSum('v.nh05', 'p05')
                ->selectSum('v.nh06', 'p06')
                ->selectSum('v.nh07', 'p07')
                ->selectSum('v.nh08', 'p08')
                ->selectSum('v.nh09', 'p09')
                ->selectSum('v.nh10', 'p10')
                ->selectSum('v.nh11', 'p11')
                ->selectSum('v.nh12', 'p12')
                ->selectSum('v.nh13', 'p13')
                ->selectSum('v.nh14', 'p14')
                ->selectSum('v.nh15', 'p15')
                ->selectSum('v.nh16', 'p16')
                ->selectSum('v.nh17', 'p17')
                ->selectSum('v.nh18', 'p18')
                ->selectSum('v.nh19', 'p19')
                ->selectSum('v.nh20', 'p20')
                ->selectSum('v.nh21', 'p21')
                ->selectSum('v.nh22', 'p22')
                ->selectSum('v.nh23', 'p23')
                ->selectSum('p.nh00', 'd00')
                ->selectSum('p.nh01', 'd01')
                ->selectSum('p.nh02', 'd02')
                ->selectSum('p.nh03', 'd03')
                ->selectSum('p.nh04', 'd04')
                ->selectSum('p.nh05', 'd05')
                ->selectSum('p.nh06', 'd06')
                ->selectSum('p.nh07', 'd07')
                ->selectSum('p.nh08', 'd08')
                ->selectSum('p.nh09', 'd09')
                ->selectSum('p.nh10', 'd10')
                ->selectSum('p.nh11', 'd11')
                ->selectSum('p.nh12', 'd12')
                ->selectSum('p.nh13', 'd13')
                ->selectSum('p.nh14', 'd14')
                ->selectSum('p.nh15', 'd15')
                ->selectSum('p.nh16', 'd16')
                ->selectSum('p.nh17', 'd17')
                ->selectSum('p.nh18', 'd18')
                ->selectSum('p.nh19', 'd19')
                ->selectSum('p.nh20', 'd20')
                ->selectSum('p.nh21', 'd21')
                ->selectSum('p.nh22', 'd22')
                ->selectSum('p.nh23', 'd23');
        } else {
            $this->qb
                ->select("DATE_FORMAT(v.vdate,'%d') as day")
                ->selectSum('v.ncnt')
                ->selectSum('p.ncnt')
                ->groupBy("day");
        }

        $this->qb
            ->select('v.agent_type')
            ->from(TBL_LOGSTORY_VISITOR . ' AS v')
            ->join(TBL_LOGSTORY_PAGEVIEWTIME . ' AS p', 'p.vdate=v.vdate AND p.agent_type=v.agent_type')
            ->groupBy('agent_type');

        $this->qb->stopCache();

        $list = [];

        // 기간별 조회
        foreach ($searchDateDataList as $searchDateData) {

            $rows = $this->qb
                ->betweenDate('v.vdate', $searchDateData['startDate'], $searchDateData['endDate'])
                ->exec()
                ->getResultArray();

            foreach ($rows as $rowKey => $rowData) {
                if ($reportType == 'T') {
                    foreach ($this->hour as $hour) {
                        $hour = zerofill($hour, 2);
                        if ($rowData['p' . $hour] > 0) {
                            $rowData['nh' . $hour] = round($rowData['d' . $hour] / $rowData['p' . $hour]);
                        } else {
                            $rowData['nh' . $hour] = 0;
                        }
                    }
                } else {
                    if ($rowData['ncnt'] > 0) {

                        $rowData['avgNcnt'] = round($rowData['ncnt'] / $rowData['ncnt']);
                    } else {
                        $rowData['avgNcnt'] = 0;
                    }
                }
                $rows[$rowKey] = $rowData;
            }

            $converter = $this->dataReportTypeConverterByAgentType($reportType, $rows, 'nh', 'avgNcnt');
            $converterData = $converter['data'];

            $returnData = [];

            foreach ($converterData as $dt) {
                $agentData = [];
                $valueSum = 0;

                foreach ($dt['agentTypeData'] as $agentTypeCode => $value) {
                    $agentData['avgNdurationAgentType' . $agentTypeCode] = $value;
                    $agentData['avgNdurationAgentType' . $agentTypeCode . 'Text'] = $this->displayTimeFormat($value);
                    $valueSum += $value;
                }
                $agentData['avgNdurationSum'] = $valueSum;
                $agentData['avgNdurationSumText'] = $this->displayTimeFormat($valueSum);
                $returnData[] = array_merge([$dt['targetKey'] => $dt['targetKeyValue']], $agentData);
            }

            $list[$searchDateData['key']] = $returnData;
        }

        $this->qb->flushCache();

        return $list;
    }

    /**
     * 순수방문자당 체류시간
     * @param $reportType
     * @param $searchDateDataList
     * @return array
     */
    public function getDurationByVisitor($reportType, $searchDateDataList)
    {
        $this->qb->startCache();

        if ($reportType == 'T') {
            $this->qb
                ->selectSum('v.nh00', 'p00')
                ->selectSum('v.nh01', 'p01')
                ->selectSum('v.nh02', 'p02')
                ->selectSum('v.nh03', 'p03')
                ->selectSum('v.nh04', 'p04')
                ->selectSum('v.nh05', 'p05')
                ->selectSum('v.nh06', 'p06')
                ->selectSum('v.nh07', 'p07')
                ->selectSum('v.nh08', 'p08')
                ->selectSum('v.nh09', 'p09')
                ->selectSum('v.nh10', 'p10')
                ->selectSum('v.nh11', 'p11')
                ->selectSum('v.nh12', 'p12')
                ->selectSum('v.nh13', 'p13')
                ->selectSum('v.nh14', 'p14')
                ->selectSum('v.nh15', 'p15')
                ->selectSum('v.nh16', 'p16')
                ->selectSum('v.nh17', 'p17')
                ->selectSum('v.nh18', 'p18')
                ->selectSum('v.nh19', 'p19')
                ->selectSum('v.nh20', 'p20')
                ->selectSum('v.nh21', 'p21')
                ->selectSum('v.nh22', 'p22')
                ->selectSum('v.nh23', 'p23')
                ->selectSum('d.nh00', 'd00')
                ->selectSum('d.nh01', 'd01')
                ->selectSum('d.nh02', 'd02')
                ->selectSum('d.nh03', 'd03')
                ->selectSum('d.nh04', 'd04')
                ->selectSum('d.nh05', 'd05')
                ->selectSum('d.nh06', 'd06')
                ->selectSum('d.nh07', 'd07')
                ->selectSum('d.nh08', 'd08')
                ->selectSum('d.nh09', 'd09')
                ->selectSum('d.nh10', 'd10')
                ->selectSum('d.nh11', 'd11')
                ->selectSum('d.nh12', 'd12')
                ->selectSum('d.nh13', 'd13')
                ->selectSum('d.nh14', 'd14')
                ->selectSum('d.nh15', 'd15')
                ->selectSum('d.nh16', 'd16')
                ->selectSum('d.nh17', 'd17')
                ->selectSum('d.nh18', 'd18')
                ->selectSum('d.nh19', 'd19')
                ->selectSum('d.nh20', 'd20')
                ->selectSum('d.nh21', 'd21')
                ->selectSum('d.nh22', 'd22')
                ->selectSum('d.nh23', 'd23');
        } else {
            $this->qb
                ->select("DATE_FORMAT(v.vdate,'%d') as day")
                ->selectSum('v.ncnt')
                ->selectSum('d.nduration')
                ->groupBy("day");
        }

        $this->qb
            ->select('v.agent_type')
            ->from(TBL_LOGSTORY_VISITOR . ' AS v')
            ->join(TBL_LOGSTORY_DURATIONTIME . ' AS d', 'd.vdate=v.vdate AND d.agent_type=v.agent_type')
            ->groupBy('agent_type');

        $this->qb->stopCache();

        $list = [];

        // 기간별 조회
        foreach ($searchDateDataList as $searchDateData) {

            $rows = $this->qb
                ->betweenDate('v.vdate', $searchDateData['startDate'], $searchDateData['endDate'])
                ->exec()
                ->getResultArray();

            foreach ($rows as $rowKey => $rowData) {
                if ($reportType == 'T') {
                    foreach ($this->hour as $hour) {
                        $hour = zerofill($hour, 2);
                        if ($rowData['p' . $hour] > 0) {
                            $rowData['nh' . $hour] = round($rowData['d' . $hour] / $rowData['p' . $hour]);
                        } else {
                            $rowData['nh' . $hour] = 0;
                        }
                    }
                } else {
                    if ($rowData['ncnt'] > 0) {

                        $rowData['avgNduration'] = round($rowData['nduration'] / $rowData['ncnt']);
                    } else {
                        $rowData['avgNduration'] = 0;
                    }
                }
                $rows[$rowKey] = $rowData;
            }

            $converter = $this->dataReportTypeConverterByAgentType($reportType, $rows, 'nh', 'avgNduration');
            $converterData = $converter['data'];

            $returnData = [];

            foreach ($converterData as $dt) {
                $agentData = [];
                $valueSum = 0;

                foreach ($dt['agentTypeData'] as $agentTypeCode => $value) {
                    $agentData['avgNdurationAgentType' . $agentTypeCode] = $value;
                    $agentData['avgNdurationAgentType' . $agentTypeCode . 'Text'] = $this->displayTimeFormat($value);
                    $valueSum += $value;
                }
                $agentData['avgNdurationSum'] = $valueSum;
                $agentData['avgNdurationSumText'] = $this->displayTimeFormat($valueSum);
                $returnData[] = array_merge([$dt['targetKey'] => $dt['targetKeyValue']], $agentData);
            }

            $list[$searchDateData['key']] = $returnData;
        }

        $this->qb->flushCache();

        return $list;
    }

    /**
     * 재방문횟수
     * @param $reportType
     * @param $searchDateDataList
     * @return array
     * @throws \Exception
     */
    public function getRevisit($reportType, $searchDateDataList)
    {
        $this->qb->startCache();

        if ($reportType == 'T') {
            $this->qb
                ->selectSum('nh00')
                ->selectSum('nh01')
                ->selectSum('nh02')
                ->selectSum('nh03')
                ->selectSum('nh04')
                ->selectSum('nh05')
                ->selectSum('nh06')
                ->selectSum('nh07')
                ->selectSum('nh08')
                ->selectSum('nh09')
                ->selectSum('nh10')
                ->selectSum('nh11')
                ->selectSum('nh12')
                ->selectSum('nh13')
                ->selectSum('nh14')
                ->selectSum('nh15')
                ->selectSum('nh16')
                ->selectSum('nh17')
                ->selectSum('nh18')
                ->selectSum('nh19')
                ->selectSum('nh20')
                ->selectSum('nh21')
                ->selectSum('nh22')
                ->selectSum('nh23');
        } else {
            $this->qb
                ->select("DATE_FORMAT(vdate,'%d') as day")
                ->selectSum('ncnt')
                ->groupBy("day");
        }

        $this->qb
            ->select('agent_type')
            ->from(TBL_LOGSTORY_REVISITTIME . ' AS lv')
            ->groupBy('agent_type');

        $this->qb->stopCache();

        $list = [];

        // 기간별 조회
        foreach ($searchDateDataList as $searchDateData) {

            $rows = $this->qb
                ->betweenDate('vdate', $searchDateData['startDate'], $searchDateData['endDate'])
                ->exec()
                ->getResultArray();

            $converter = $this->dataReportTypeConverterByAgentType($reportType, $rows);

            $totalCnt = $converter['total'];
            $converterData = $converter['data'];

            $returnData = [];

            foreach ($converterData as $dt) {
                $agentData = [];
                $valueSum = 0;

                foreach ($dt['agentTypeData'] as $agentTypeCode => $value) {
                    $agentData['cntAgentType' . $agentTypeCode] = $value;
                    if ($totalCnt > 0) {
                        $rate = round($value / $totalCnt * 100, 2);
                    } else {
                        $rate = 0;
                    }
                    $agentData['rateAgentType' . $agentTypeCode] = $rate;
                    $valueSum += $value;
                }

                $agentData['cntSum'] = $valueSum;
                if ($totalCnt > 0) {
                    $rate = round($valueSum / $totalCnt * 100, 2);
                } else {
                    $rate = 0;
                }
                $agentData['rateSum'] = $rate;

                $returnData[] = array_merge([$dt['targetKey'] => $dt['targetKeyValue']], $agentData);
            }

            $list[$searchDateData['key']] = $returnData;
        }

        $this->qb->flushCache();

        return $list;
    }

    /**
     * 초를 한글로 표기 63 -> 1분 3초
     * @param $seconds
     * @return string
     */
    public function displayTimeFormat($seconds)
    {
        $days = floor($seconds / 60 / 60 / 24);
        $hours = $seconds / 60 / 60 % 24;
        $mins = $seconds / 60 % 60;
        $secs = $seconds % 60;

        $text = '';
        if ($days > 0) {
            $text .= $days . "일";
        }
        if ($hours > 0) {
            $text .= " " . $hours . "시간";
        }
        if ($mins > 0) {
            $text .= " " . $mins . "분";
        }
        if ($secs > 0) {
            $text .= " " . $secs . "초";
        }

        $text = trim($text);
        if ($text == '') {
            $text = '-';
        }   //1 초이내

        return $text;
    }

    /**
     * 보고서 타입에 따른 기준컬럼 정보
     * @param $reportType
     * @return array
     */
    public function getBasicColumnInfoByReportType($reportType)
    {
        if ($reportType == 'T') { //시간
            $key = 'hour';
            $name = '시간';
        } else {
            if ($reportType == 'D') { //일자
                $key = 'day';
                $name = '일자';
            } else {
                if ($reportType == 'VURL') { //페이지
                    $key = 'vurl';
                    $name = '페이지';
                } else {
                    $key = 'day';
                    $name = '일자';
                }
            }
        }
        return [
            'key' => $key,
            'name' => $name
        ];
    }

    /**
     * 데이타 리스트를 받아 비교 데이터로 반들어 주는 함수
     * @param $reportType
     * @param $compareKeyList
     * @param $searchDateDataList
     * @param $dataList
     * @return array
     */
    public function getCompareDataConverter($reportType, $compareKeyList, $searchDateDataList, $dataList)
    {
        $compareList = [];
        $listCnt = count($dataList);
        if ($listCnt > 1) {
            //첫번째 데이터를 기준 데이터로 처리
            $basicData = array_shift($dataList);
            foreach ($dataList as $key => $data) {
                $compareList[] = [
                    'key' => 'compare' . $key
                    ,
                    'titleList' => [
                        'basic' => $searchDateDataList[0]['title']
                        ,
                        'target' => $searchDateDataList[($key + 1)]['title']
                    ]
                    ,
                    'title' => $searchDateDataList[0]['title'] . ' <->' . $searchDateDataList[($key + 1)]['title']
                    ,
                    'data' => count($basicData) > 0 ? $this->compareDataConverter($reportType, $compareKeyList,
                        $basicData, $data) : []
                ];
            }
        }
        return $compareList;
    }

    /**
     * 데이터를 비교하여 일정한 규칙으로 데이터 리턴
     * @param $reportType
     * @param $compareKeyList
     * @param $basicData
     * @param $compareData
     * @return array
     */
    protected function compareDataConverter($reportType, $compareKeyList, $basicData, $compareData)
    {
        $pkey = $this->getBasicColumnInfoByReportType($reportType)['key'];

        $keys = array_keys($basicData[0]);
        foreach ($keys as $kk => $kv) {
            if ($kv == $pkey) {
                unset($keys[$kk]);
                continue;
            }
            if (!in_array($kv, $compareKeyList)) {
                unset($keys[$kk]);
            }
        }
        $defaultCompareColumns = $this->getCompareColumns($keys);

        //배열키를 비교하여 각각 없는 컬럼 추출
        $basicPvalues = array_column($basicData, $pkey);
        $comparePvalues = array_column($compareData, $pkey);

        //비교 대상에만 데이터가 있을때
        $onlyComparePvalues = array_values(array_diff($comparePvalues, $basicPvalues));

        foreach ($basicData as $data) {
            $pValue = $data[$pkey];
            $compareList[$pValue] = array_merge($data, $defaultCompareColumns);
        }

        foreach ($compareData as $data) {
            $pValue = $data[$pkey];
            if (in_array($pValue, $onlyComparePvalues)) {
                //target 데이터 생성
                foreach ($data as $key => $value) {
                    if ($pkey != $key) {
                        $data[$key . 'Target'] = $data[$key];
                    }
                }
                //baisc 테이터 없어서 생성
                $compareList[$pValue] = array_merge($data, $this->getCompareColumns($keys, '', 0, -100));
            } else {
                $setData = $compareList[$pValue];
                foreach ($keys as $key) {
                    $basicKeyValue = $setData[$key];
                    $compareKeyValue = $data[$key];
                    $setData[$key . 'Target'] = $compareKeyValue;
                    $setData[$key . 'Compare'] = ($compareKeyValue > 0 ? round((($basicKeyValue / $compareKeyValue) - 1) * 100,
                        1) : 0);
                }
                $compareList[$pValue] = $setData;
            }
        }
        ksort($compareList);

        $i = 0;
        $returnData = [];
        foreach ($compareList as $compareCata) {
            $returnData[$i] = $compareCata;
            $i++;
        }
        unset($compareList);

        return $returnData;
    }

    /**
     * 비교 컬럼 정보
     * @param $keys
     * @param string $type
     * @param bool $defaultTypeValue
     * @param bool $defaultCompareValue
     * @return array
     */
    protected function getCompareColumns(
        $keys,
        $type = 'Target',
        $defaultTypeValue = false,
        $defaultCompareValue = false
    ) {
        $data = [];
        foreach ($keys as $key) {
            $data[$key . $type] = $defaultTypeValue !== false ? $defaultTypeValue : 0;
            $data[$key . 'Compare'] = $defaultCompareValue !== false ? $defaultCompareValue : 0;
        }
        return $data;
    }

    /**
     * 디비에서 추출한 데이터를 보고서 타입별로 동일한 데이터로 리턴
     * @param $reportType
     * @param $rows
     * @return array
     */
    protected function dataReportTypeConverterByAgentType($reportType, $rows, $timeKey = 'nh', $dayKey = 'ncnt')
    {
        $data = [];
        $defaultAgentTypeData = array_fill_keys(array_keys($this->agentType), 0);

        $targetKey = $this->getBasicColumnInfoByReportType($reportType)['key'];

        $totalCnt = 0;
        if ($reportType == 'T') { //시간별
            foreach ($this->hour as $hour) {
                $data[$hour] = [
                    'targetKey' => $targetKey,
                    'targetKeyValue' => $hour,
                    'agentTypeData' => $defaultAgentTypeData
                ];
            }
            foreach ($rows as $row) {
                foreach ($this->hour as $hour) {
                    $cnt = $row[$timeKey . zerofill($hour, 2)];
                    $data[$hour]['agentTypeData'][$row['agent_type']] += $cnt;
                    $totalCnt += $cnt;
                }
            }
        } else { //일자별
            foreach ($this->day as $day) {
                $data[$day] = [
                    'targetKey' => $targetKey,
                    'targetKeyValue' => $day,
                    'agentTypeData' => $defaultAgentTypeData
                ];
            }
            foreach ($rows as $row) {
                $cnt = $row[$dayKey];
                $data[$row['day']]['agentTypeData'][$row['agent_type']] += $cnt;
                $totalCnt += $cnt;
            }
        }

        return ['total' => $totalCnt, 'data' => $data];
    }
}