<?php

namespace ForbizScm\Model;

/**
 * 모바일 관련 모델
 *
 * @author hoksi
 */
class Member extends \ForbizModel
{

    public function __construct()
    {
        parent::__construct();
    }

    /**
     * 크론 - 생일
     */
    public function cronBirthday()
    {
        $list = $this->qb
            ->select('cu.code')
            ->select('cmd.gp_ix')
            ->from(TBL_COMMON_USER . ' AS cu')
            ->join(TBL_COMMON_MEMBER_DETAIL . ' AS cmd', 'cu.code=cmd.code')
            ->where('right(birthday,6)', "date_format(NOW(),'-%m-%d')", false)
            ->exec()
            ->getResultArray();

        if ($this->qb->total > 0) {
            /* @var $couponModel \CustomScm\Model\Marketing\Coupon */
            $couponModel = $this->import('model.scm.marketing.coupon');

            foreach ($list as $key => $val) {
                //생일쿠폰 지급
                $couponModel->preferredConditionGiveCoupon('3', $val['code'], true, $val['gp_ix']);
            }
        }
    }

    /**
     * 크론 - 회원 등급 변경
     */
    public function cronChangeGroup()
    {
        $groupinfo = $this->qb
            ->select('gp_name')
            ->select('gp_ix')
            ->select('ed_order_price')
            ->select('order_price')
            ->from(TBL_SHOP_GROUPINFO)
            ->where('is_delete',0)
            ->where('disp', 1)//노출되고
            ->where('all_disp', 1)//자동전환 사용하는것
            ->exec()
            ->getResultArray();

        $member = $this->qb
            ->select('cmd.code')
            ->select('cmd.gp_ix')
            ->from(TBL_COMMON_USER . ' as cu')
            ->join(TBL_COMMON_MEMBER_DETAIL . ' as cmd', 'cu.code=cmd.code')
            ->join(TBL_SHOP_GROUPINFO . ' as sg', 'sg.gp_ix=cmd.gp_ix', 'left')
            ->where('sg.disp', 1)//노출되고
            ->where('sg.all_disp', 1)//자동전환 사용하는것
            ->exec()
            ->getResultArray();

        if (count($member) > 0) {
            /* @var $couponModel \CustomScm\Model\Marketing\Coupon */
            $couponModel = $this->import('model.scm.marketing.coupon');

            foreach ($member as $key => $val) {
                $first_day = date('Y-m-01', strtotime('-1 month'));  //산정기간의 첫날
                $last_day = date('Y-m-t', strtotime($first_day)); //산정기간의 마지막 날
                //상태값 관계없이 dc_date 주문완료 기준으로 + 매출액을 가져오고 fc_date 환불완료일을 기준으로 - 환불금액을 차감
                $query = "SELECT 
                        SUM(total_price) AS total_price
                        FROM (
                                SELECT pt_dcprice AS total_price
                                FROM `shop_order_detail` AS `sod`
                                JOIN `shop_order` AS `so` ON `sod`.`oid` = `so`.`oid`
                                WHERE 
                                    `so`.`user_code` = '" . $val['code'] . "' 
                                    AND `sod`.`dc_date` BETWEEN '" . $first_day . "' AND '" . $last_day . "'
                                    AND `sod`.`fc_date` IS NULL 
                        UNION ALL
                                SELECT (pt_dcprice * -1) AS total_price
                                FROM `shop_order_detail` AS `sod`
                                JOIN `shop_order` AS `so` ON `sod`.`oid` = `so`.`oid`
                                WHERE 
                                     `so`.`user_code` = '" . $val['code'] . "'  
                                     AND `sod`.`fc_date` BETWEEN '" . $first_day . "' AND '" . $last_day . "'
                        ) t";
                $db = $this->qb->exec($query)->getRowArray();
                $total_price = $db['total_price'];

                if (empty($total_price)) {
                    $total_price = 0;
                }
                //그룹 정보에서 설정된 금액이 해당 유저의 토탈 금액보다 높으면 그룹 체인지
                foreach ($groupinfo as $gKey => $gVal) {
                    if ($gVal['order_price'] <= $total_price && $total_price > $gVal['ed_order_price']) {
                        //그룹이 서로 다르다면
                        if ($val['gp_ix'] != $gVal['gp_ix']) {
                            add_history('member', TBL_COMMON_MEMBER_DETAIL . '.code', $val['code'], [
                                'gp_ix' => '회원그룹 [' . $gVal['gp_name'] . '] 으로 변경'
                            ], ['gp_ix' => $gVal['gp_ix']]);

                            $this->qb->update(TBL_COMMON_MEMBER_DETAIL,
                                ['gp_ix' => $gVal['gp_ix'], 'gp_change_date' => date('Y-m-d')],
                                ['code' => $val['code']])->exec();

                            $couponModel->preferredConditionGiveCoupon('2', $val['code'], true, $gVal['gp_ix']);
                        }
                    }
                }
            }
        }
    }

    /**
     * 크론 - 광고성 정보 수신동의 여부 확인 안내
     */
    public function cronInformationAgreement()
    {
        get_auth_info();
        $now = strtotime("-2 year", time());
        $date = date('Y-m-d H:i:s', $now);

        //email_agree_date에서 smsdate 참조하는 이유는 mypage에서 email 또는 sms 수정 시 변경일자가 함께 업데이트 되기 때문
        $list = $this->qb
            ->select('cmd.code')
            ->select('cmd.info as email_agree')
            ->select('date_format(cmd.smsdate, "%Y-%m-%d") as email_agree_date')
            ->select('cmd.sms as sms_agree')
            ->select('date_format(cmd.smsdate, "%Y-%m-%d") as sms_agree_date')
            ->select('ps.is_allowable AS push_agree')
            ->select('date_format(ps.allow_date, "%Y-%m-%d") AS push_agree_date')
            ->decryptSelect('cmd.mail')
            ->decryptSelect('cmd.pcs')
            ->from(TBL_COMMON_MEMBER_DETAIL . ' AS cmd')
            ->join(TBL_MOBILE_PUSH_SERVICE . ' AS ps', 'cmd.code = ps.user_code', 'left')
            ->groupStart()
            ->orWhere('info', '1')
            ->orWhere('sms', '1')
            ->groupEnd()
            ->groupStart()
            ->orWhere('if ( isnull(cmd.agree_infodate), cmd.date, cmd.agree_infodate ) < ', $date)
            ->orWhere('if ( isnull(cmd.smsdate), cmd.date, cmd.smsdate ) < ', $date)
            ->groupEnd()
            ->exec()
            ->getResultArray();

        foreach ($list as $key => $val) {
            $tpl['email_agree'] = ($val["email_agree"] == '1') ? '수신동의' : '수신거부';
            $tpl['email_agree_date'] = $val['email_agree_date'];
            $tpl['sms_agree'] = ($val["sms_agree"] == '1') ? '수신동의' : '수신거부';
            $tpl['sms_agree_date'] = ($val["sms_agree_date"] == '') ? $val["email_agree_date"] : $val["sms_agree_date"];
            $tpl['push_agree'] = ($val["push_agree"] == '1') ? '수신동의' : '수신거부';
            $tpl['push_agree_date'] = $val["push_agree_date"];
            sendMessage('information_agreement', $val['mail'], $val['pcs'], $tpl);

            $this->qb
                ->set('agree_infodate', date("Y-m-d H:i:s"))
                ->update(TBL_COMMON_MEMBER_DETAIL)
                ->where('code', $val['code'])
                ->exec();
        }
    }

    /**
     * 크론 - 휴면회원 안내 메일
     */
    public function cronInformationSleep()
    {
        get_auth_info();
        $sleepDate = \ForbizConfig::getPrivacyConfig('sleep_date');
        $sleepUserMailing = \ForbizConfig::getPrivacyConfig('sleep_user_mailing');
        $sleepUserMailingDay = \ForbizConfig::getPrivacyConfig('sleep_user_mailing_day'); //휴면전환 처리 전 안내메일 보낼 날짜
        $sleep_date = date('Ymd', strtotime("-" . $sleepDate . " year")); //휴먼상태 적용 날짜
        //휴면안내 메일 전송 사용일때
        if ($sleepUserMailing == 'Y') {
            $sleep_mail_date = date('Y-m-d',
                strtotime("+" . $sleepUserMailingDay . " days", strtotime($sleep_date))); //휴면전환 처리일로부터의 마지막 로그인
            $sleepDDay = date('Y년 m월 d일', strtotime("+" . $sleepUserMailingDay . " days")); //휴면전환일

            $member = $this->qb
                ->select('cu.id')
                ->decryptSelect('cmd.name')
                ->decryptSelect('cmd.mail')
                ->decryptSelect('cmd.pcs')
                ->from(TBL_COMMON_USER . ' AS cu')
                ->join(TBL_COMMON_MEMBER_DETAIL . ' AS cmd', 'cu.code = cmd.code', 'left')
                ->where('cu.mem_type', 'M')
                ->betweenDate('cu.last', $sleep_mail_date, $sleep_mail_date)
                ->exec()
                ->getResultArray();

            if ($this->qb->total > 0) {
                foreach ($member as $key => $val) {
                    $tpl['mem_name'] = $val['name'];
                    $tpl['mem_mail'] = $val['mail'];
                    $tpl['mem_id'] = $val['id'];
                    $tpl['mem_mobile'] = $val['pcs'];
                    $tpl['sleepDate'] = $sleepDate;
                    $tpl['noti_date'] = $sleepUserMailingDay;
                    $tpl['sleepDDay'] = $sleepDDay;
                    sendMessage('member_exit_sleep', $val['mail'], $val['pcs'], $tpl);
                }
            }
        }
        //휴면안내 메일 전송 사용일때 끝
    }

    /**
     * 크론 - 휴면회원 전환
     */
    public function cronTransactionSleep()
    {
        $sleepDate = \ForbizConfig::getPrivacyConfig('sleep_date');

        $sleep_date = date('Ymd', strtotime("-" . $sleepDate . " year")); //휴먼상태 적용 날짜
        //일반회원->휴면회원처리
        $data['update_type'] = '1';
        $data['not_mem_type'] = ['A'];
        $data['sleepDate'] = $sleep_date;

        /* @var $memberModel \CustomScm\Model\Member\Member */
        $memberModel = $this->import('model.scm.member.member');
        $memberModel->putManageSleepMemberNomal($data);
    }

    /**
     * 크론 - 마일리지 소멸 안내
     */
    public function cronInformationExtinctionMileage()
    {
        $date = date('Y-m-d');
        get_auth_info();
        $cancelDateStart = date('Y-m-01', strtotime('+1 month'));
        $cancelDateEnd = date('Y-m-t', strtotime('+1 month'));

        $list = $this->qb
            ->select('sum(ifnull(am_mileage,0)) as am_mileage')
            ->select('IFNULL(' .
                $this->qb
                    ->startSubQuery()
                    ->select('sum(ifnull(rm.rm_mileage,0))')
                    ->from(TBL_SHOP_REMOVE_MILEAGE . ' as rm')
                    ->whereIn(
                        'rm.am_ix',
                        $this->qb->startSubQuery()
                            ->select('am1.am_ix')
                            ->from(TBL_SHOP_ADD_MILEAGE . ' AS am1')
                            ->where('am1.uid = am.uid')
                            ->betweenDate('am1.extinction_date', $cancelDateStart, $cancelDateEnd)
                            ->endSubQuery(), false
                    )
                    ->endSubQuery()
                . ', 0) AS remove_mileage', false)
            ->select('cu.mileage as user_mileage')
            ->decryptSelect('cmd.mail')
            ->decryptSelect('cmd.pcs')
            ->decryptSelect('cmd.name')
            ->from(TBL_SHOP_ADD_MILEAGE . ' as am')
            ->join(TBL_COMMON_MEMBER_DETAIL . ' as cmd', 'cmd.code = am.uid')
            ->join(TBL_COMMON_USER." as cu", 'cu.code = cmd.code', 'inner')
            ->betweenDate('am.extinction_date', $cancelDateStart, $cancelDateEnd)
            ->groupBy('am.uid')
            ->having('am_mileage > remove_mileage')
            ->orderBy('am.am_ix')
            ->exec()
            ->getResultArray();

        foreach ($list as $key => $val) {
            $first_day = date('Y-m-01');  //산정기간의 첫날
            $last_day = date('Y-m-t', strtotime($first_day)); //산정기간의 마지막 날
            $mileageRule = \ForbizConfig::getSharedMemory('b2c_mileage_rule');

            $tpl['am_mileage'] = g_price($val['am_mileage']);
            $tpl['firstDay'] = $first_day;
            $tpl['lastDay'] = $last_day;
            if($mileageRule['cancel_year'] > 0) {
                $tpl['extinctionYear'] = $mileageRule['cancel_year'] . '년 ' . $mileageRule['cancel_month'] . '개월'; //소멸기준연도
            } else {
                $tpl['extinctionYear'] = $mileageRule['cancel_month'] . '개월'; //소멸기준연도
            }
            $extinction_mileage = $val['am_mileage'] - $val['remove_mileage'];
            $tpl['mileage'] = g_price($extinction_mileage);
            $tpl['nowDate'] = date("Y-m-d");
            sendMessage('mileage_delete', $val['mail'], $val['pcs'], $tpl);
        }
    }

    /**
     * 크론 - 마일리지 삭제 처리
     * 미사용정책
     * @throws \Exception
     */
    public function cronExtinctionMileage()
    {
        $date = date('Y-m-d');
        //마일리지 소멸 대상자 찾기
        $list = $this->qb
            ->select('sum(ifnull(am_mileage,0)) as am_mileage')
            ->select('IFNULL(' .
                $this->qb->startSubQuery()
                    ->select('sum(ifnull(rm.rm_mileage,0))')
                    ->from(TBL_SHOP_REMOVE_MILEAGE . ' as rm')
                    ->whereIn(
                        'rm.am_ix',
                        $this->qb->startSubQuery()
                            ->select('am1.am_ix')
                            ->from(TBL_SHOP_ADD_MILEAGE . ' AS am1')
                            ->where('am1.uid = am.uid')
                            ->where('am1.extinction_date', $date)
                            ->endSubQuery(), false
                    )
                    ->endSubQuery()
                . ', 0) AS remove_mileage', false)
            ->select('am.uid')
            ->from(TBL_SHOP_ADD_MILEAGE . ' as am')
            ->where('am.extinction_date', $date)
            ->groupBy('am.uid')
            ->having('am_mileage > remove_mileage')
            ->orderBy('am.am_ix')
            ->exec()
            ->getResultArray();

        if ($this->qb->total > 0) {
            /* @var $mileageModel \CustomScm\Model\Member\Mileage */
            $mileageModel = $this->import('model.scm.member.mileage');

            foreach ($list as $key => $val) {
                $extinction_mileage = $val['am_mileage'] - $val['remove_mileage'];
                $message = '사용 만료에 따른 소멸';
                $mileageModel
                    ->setMember($val['uid'])
                    ->useMileage($extinction_mileage, '5', $message);
            }
        }
    }

    /**
    * 크론 - 포인트 소멸 안내
    * 미사용정책
    */
    public function cronInformationExtinctionPoint()
    {
        get_auth_info();
        $cancelDateStart = date('Y-m-01', strtotime('+1 month'));
        $cancelDateEnd = date('Y-m-t', strtotime('+1 month'));

        $list = $this->qb
            ->select('sum(ifnull(rp_point,0)) as remove_point')
            ->select('ap_point')
            ->decryptSelect('cmd.mail')
            ->decryptSelect('cmd.pcs')
            ->from(TBL_SHOP_ADD_POINT . ' as ap')
            ->join(TBL_COMMON_MEMBER_DETAIL . ' as cmd', 'cmd.code = ap.uid')
            ->join(TBL_SHOP_REMOVE_POINT . ' as rp', 'rp.ap_ix = ap.ap_ix','left')
            ->betweenDate('ap.extinction_date', $cancelDateStart, $cancelDateEnd)
            ->groupBy('ap.ap_ix')
            ->having('ap_point > remove_point')
            ->orderBy('ap.ap_ix')
            ->exec()
            ->getResultArray();
        $pointRule = \ForbizConfig::getSharedMemory('b2c_point_rule');
        $first_day = date('Y-m-01');  //산정기간의 첫날
        $last_day = date('Y-m-t', strtotime($first_day)); //산정기간의 마지막 날

        foreach ($list as $key => $val) {
            $extinction_mileage = $val['ap_point'] - $val['remove_point'];

            $tpl['ap_point'] = g_price($val['ap_point']);
            $tpl['firstDay'] = $first_day;
            $tpl['lastDay'] = $last_day;
            $tpl['extinctionYear'] = $pointRule['cancel_year'] . '년 ' . $pointRule['cancel_month'] . '개월'; //소멸기준연도
            $tpl['point'] = g_price($extinction_mileage);
            $tpl['nowDate'] = date("Y-m-d");
            sendMessage('point_delete', $val['mail'], $val['pcs'], $tpl);
        }
    }

    /**
     * 크론 - 포인트 삭제 처리
     * @throws \Exception
     */
    public function cronExtinctionPoint()
    {
        //마일리지 소멸 대상자 찾기
        $list = $this->qb
            ->select('sum(ifnull(rp_point,0)) as remove_point')
            ->select('ap.ap_point')
            ->select('ap.uid')
            ->from(TBL_SHOP_ADD_POINT . ' as ap')
            ->join(TBL_SHOP_REMOVE_POINT . ' as rp', 'rp.ap_ix=ap.ap_ix','left')
            ->where('ap.extinction_date', date('Y-m-d'))
            ->orderBy('ap.ap_ix')
            ->groupBy('ap.ap_ix')
            ->having('ap_point > remove_point')//적립마일리지가 차감마일리지보다 크다면
            ->exec()
            ->getResultArray();

        if ($this->qb->total > 0) {
            /* @var $pointModel \CustomScm\Model\Member\Point */
            $pointModel = $this->import('model.scm.member.point');

            foreach ($list as $key => $val) {
                $extinction_point = $val['ap_point'] - $val['remove_point'];
                $message = '사용 만료에 따른 자동 소멸';
                $pointModel
                    ->setMember($val['uid'])
                    ->usePoint($extinction_point, '7', $message);
            }
        }
    }
}