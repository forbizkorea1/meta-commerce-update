<?php

namespace ForbizScm\Model\Product;

use ForbizConfig;

/**
 * 상품리스트
 *
 * @author hoksi
 *
 * @property \CustomScm\Model\Product\Product $productModel 상품모델
 */
class ProductList extends \ForbizModel
{
    /**
     * 상품별 할인정보 데이터
     * @var array
     */
    protected $discountData = [];

    /**
     * 할인 단위 자리수 (1:일, 2:십, 3:백)
     * @var int
     */
    protected $discoutRoundPosition = 1;

    /**
     * 할인 절삭 타입 (floor:내림, ceil:올림)
     * @var string
     */
    protected $discoutRoundType = 'floor';

    /**
     * 회원 그룹 인덱스 (common_member_detail.gp_ix)
     * @var type
     */
    protected $discoutMemberGroupIx = 0;

    /**
     * 회원 그룹 할인율
     * @var int
     */
    protected $discoutMemberGroupSaleRate = 0;

    /**
     * App 할인율
     * @var int
     */
    protected $discoutAppSaleRate = 0;

    /**
     * 사용 환경 (W: PC, M:모바일)
     * @var string
     */
    protected $agentType = 'W';

    /**
     * 관리 company_id
     * @var type
     */
    protected $manageCompanyId;
    protected $productModel;

    public function __construct()
    {
        parent::__construct();

        $this->productModel = $this->import('model.scm.product.product');

        //셀러일 경우
        if ($this->adminInfo->admin_level < 9) {
            $this->setManageCompanyId($this->adminInfo->company_id);
        }
    }

    /**
     * set manageCompanyId
     * @param type $manageCompanyId
     */
    public function setManageCompanyId($manageCompanyId)
    {
        $this->manageCompanyId = $manageCompanyId;
    }

    /**
     * @param $ep_type
     * @param array $sellers
     * @param array $cids
     * @return array|false
     * @throws \Exception
     */
    public function getProductEpList($ep_type, $sellers = [], $cids = [])
    {
        // 셀러 지정
        if (!empty($sellers)) {
            $this->qb->whereIn('p.admin', $sellers);
        }

        // 카테고리 지정
        if (!empty($cids)) {
            $this->qb->whereIn('spr.cid', $cids);
        }

        // EP 타임
        if ($ep_type == 'daum') {
            $this->qb->where('p.disp_daum', 1);
        } else if ($ep_type == 'naver') {
            $this->qb->where('p.disp_naver', 1);
        }

        $rows = $this->qb
            ->select('p.id')
            ->from(TBL_SHOP_PRODUCT. ' AS p')
            ->join(TBL_SHOP_PRODUCT_RELATION. ' AS spr', "p.id=spr.pid")
            ->where('p.is_delete', 0)
            ->where('p.disp', '1')
            ->where("(p.state = '1' OR p.state = '0')")
            ->where("if(p.is_sell_date = '1',p.sell_priod_sdate <= '".date('Y-m-d H:i:s')."' and p.sell_priod_edate >= '".date('Y:m:d H:i:s')."','1=1')",
                '', false)
            ->exec()
            ->getResultArray();

        return (!empty($rows) ? array_column($rows, 'id') : []);
    }

    /**
     * 네이버 ep 용 데이터
     */
    public function getNaverEpList($page, $max, $where = [], $ep = [])
    {
        static $sellerId = [];
        //as가 없는 컬럼은 다른곳에서도 쓰이기때문에 수정하면 안됨.
        $data = $this->getEpList(function () {
            $this->qb
                ->select('p.id')
                ->select('p.admin')
                ->select('p.state')
                ->select('p.disp')
                ->select('p.reserve_yn')
                ->select('p.rate_type')
                ->select('p.reserve_rate')
                ->select('p.reserve')
                ->select('p.is_adult')
                ->select('p.company AS maker')
                ->select('p.pcode AS manufacture_define_number')
                ->select('p.allow_basic_cnt AS minimum_purchase_quantity')
                ->select('p.listprice')
                ->select('p.sellprice')
                ->select('p.pname AS title')
                ->select('p.sellprice AS dcprice')
                ->select('p.after_cnt AS review_count')
                ->select('p.origin')
                ->select('p.brand_name')
                ->select('d.dt_ix')
                ->select('dt.template_name')
                ->select('dt.delivery_region_use')
                ->select('dt.delivery_region_area')
                ->select('dt.delivery_jeju_price')
                ->select('dt.delivery_except_price')
                ->join(TBL_SHOP_PRODUCT_DELIVERY . ' AS d', "d.pid=p.id AND d.is_wholesale='R'")
                ->join(TBL_SHOP_DELIVERY_TEMPLATE . ' AS dt', "d.dt_ix=dt.dt_ix")
                ->where('p.disp_naver', 1);
        }, $page, $max, $where, $ep);

        if ($data['total'] > 0) {
            //할인 정보 반영
            $list = $this->discount($data['list']);

            /* @var $statusModel \CustomScm\Model\Order\Status */
            $statusModel = $this->import('model.scm.order.status');
            /* @var $mileageModel \CustomScm\Model\Member\Mileage */
            $mileageModel = $this->import('model.scm.member.mileage');

            //셀러id 수집
            $sellerList = array_unique(array_column($data['list'], 'admin'));
            $diffResult = array_diff($sellerList, $sellerId);
            if (!empty($diffResult)) {
                $rows = $this->qb
                    ->select('cu.company_id')
                    ->select('cu.id')
                    ->from(TBL_COMMON_USER . ' as cu')
                    ->where('cu.mem_type', 'C')
                    ->where('cu.mem_div', 'S')
                    ->whereIn('cu.company_id', $diffResult)
                    ->orderBy('cu.DATE', 'ASC')
                    ->limit('1')
                    ->exec()
                    ->getResult();

                foreach ($rows as $row) {
                    $sellerId[$row->company_id] = $row->id;
                }
            }

            //상품 데이터 만들기
            foreach ($list as $key => $val) {
                // 기획할인 존재시
                $val['special_price'] = $val['dcprice'];

                //카테고리 뎁스
                if (isset($val['categoryPathText'])) {
                    $categoryExp = explode('>', $val['categoryPathText']);
                    $val['category_name1'] = (isset($categoryExp[0])) ? $categoryExp[0] : '';
                    $val['category_name2'] = (isset($categoryExp[1])) ? $categoryExp[1] : '';
                    $val['category_name3'] = (isset($categoryExp[2])) ? $categoryExp[2] : '';
                    $val['category_name4'] = (isset($categoryExp[3])) ? $categoryExp[3] : '';
                }

                //셀러id
                if (isset($sellerId[$val['admin']])) {
                    $val['seller_id'] = $sellerId[$val['admin']];
                }

                //옵션구성
                $optionsDetail = [];
                $options = $this->qb
                    ->select('od.option_div')
                    ->select('od.option_price')
                    ->from(TBL_SHOP_PRODUCT_OPTIONS . ' as o')
                    ->join(TBL_SHOP_PRODUCT_OPTIONS_DETAIL . ' as od', 'o.opn_ix=od.opn_ix')
                    ->where('o.pid', $val['id'])
                    ->where('o.option_type', 'b')
                    ->where('od.is_delete', '0')
                    ->where('od.option_stock > 0')
                    ->where('od.option_soldout != ', '1')
                    ->exec()
                    ->getResultArray();
                foreach ($options as $optionsVal) {
                    $optionsDetail[] = $optionsVal['option_div'] . '^' . $optionsVal['option_price'];
                }
                $val['option_detail'] = implode('|', $optionsDetail);

                //상품이미지
                $val['image_link'] = get_product_images_src($val['id']);

                //추가 이미지
                $addImageList = $this->getAddImagesSrc($val['id'], $val['is_adult']); //추가이미지
                if (!empty($addImageList)) {
                    $val['add_image_link'] = implode('|', array_column($addImageList, 'bigImg'));
                }

                //배송비
                $shippingInfo = $statusModel->getDeliveryInfo($val['dt_ix'], ['price' => $val['dcprice'], 'qty' => 1]);
                $val['shipping'] = $shippingInfo['sumPrice'];

                //포인트
                $val['point'] = $mileageModel->getSaveMileage(
                    $val['reserve_yn'],
                    $val['rate_type'],
                    ($val['rate_type'] == '1' ? $val['reserve_rate'] : $val['reserve']),
                    $val['admin'],
                    $val['listprice'],
                    $val['dcprice'],
                    $val['dcprice']
                );

                //ep class (신규I, 업데이트U, 품절D)
                if ($val['state'] != '1' || $val['disp'] != '1') {
                    $val['class'] = 'D';
                } else {
                    if ($val['editdate'] == $val['regdate']) {
                        $val['class'] = 'I';
                    } else {
                        $val['class'] = 'U';
                    }
                }

                //naver ep 컬럼명과 동일하게 치환
                $val['adult'] = ($val['is_adult'] == '1') ? 'Y' : 'N';
                $val['link'] = MALL_DOMAIN . '/shop/goodsView/' . $val['id'];
                $val['mobile_link'] = MALL_DOMAIN . '/shop/goodsView/' . $val['id'];
                $val['update_time'] = $val['editdate'];
                $data['list'][$key] = $val;
            }
        }

        return $data;
    }
    /**
     * 다음 ep 용 데이터
     */
    public function getDaumEpList($page, $max, $where = [], $ep = [])
    {
        static $sellerId = [];
        //as가 없는 컬럼은 다른곳에서도 쓰이기때문에 수정하면 안됨.
        $data = $this->getEpList(function () {
            $this->qb
                ->select('p.id')
                ->select('p.admin')
                ->select('p.state')
                ->select('p.disp')
                ->select('p.reserve_yn')
                ->select('p.rate_type')
                ->select('p.reserve_rate')
                ->select('p.reserve')
                ->select('p.is_adult')
                ->select('p.company AS maker')
                ->select('p.pcode AS manufacture_define_number')
                ->select('p.allow_basic_cnt AS minimum_purchase_quantity')
                ->select('p.listprice')
                ->select('p.sellprice')
                ->select('p.brand_name')
                ->select('p.search_keyword')
                ->select('p.pname AS title')
                ->select('p.sellprice AS dcprice')
                ->select('p.after_cnt AS review_count')
                ->select('d.dt_ix')
                ->select('dt.delivery_region_use')
                ->select('dt.delivery_region_area')
                ->select('dt.delivery_jeju_price')
                ->select('dt.delivery_except_price')
                ->select("(select ifnull(cid, '') from ".TBL_SHOP_PRODUCT_RELATION." as pr where p.id = pr.pid and pr.disp = 1 and pr.basic = 1 limit 1) AS cid")
                ->join(TBL_SHOP_PRODUCT_DELIVERY . ' AS d', "d.pid=p.id AND d.is_wholesale='R'")
                ->join(TBL_SHOP_DELIVERY_TEMPLATE . ' AS dt', "d.dt_ix=dt.dt_ix")
                ->where('p.disp_daum', 1);
        }, $page, $max, $where, $ep);

        if (!empty($data['list']) > 0) {
            //할인 정보 반영
            $list = $this->discount($data['list']);

            /* @var $statusModel \CustomScm\Model\Order\Status */
            $statusModel = $this->import('model.scm.order.status');
            /* @var $mileageModel \CustomScm\Model\Member\Mileage */
            $mileageModel = $this->import('model.scm.member.mileage');

            //셀러id 수집
            $sellerList = array_unique(array_column($data['list'], 'admin'));
            $diffResult = array_diff($sellerList, $sellerId);
            if (!empty($diffResult)) {
                $rows = $this->qb
                    ->select('cu.company_id')
                    ->select('cu.id')
                    ->from(TBL_COMMON_USER . ' as cu')
                    ->where('cu.mem_type', 'C')
                    ->where('cu.mem_div', 'S')
                    ->whereIn('cu.company_id', $diffResult)
                    ->orderBy('cu.DATE', 'ASC')
                    ->limit('1')
                    ->exec()
                    ->getResult();

                foreach ($rows as $row) {
                    $sellerId[$row->company_id] = $row->id;
                }
            }

            //상품 데이터 만들기
            foreach ($list as $key => $val) {
                // 기획할인 존재시
                $val['special_price'] = $val['dcprice'];

                //카테고리 뎁스
                if (isset($val['categoryPathText'])) {
                    $categoryExp = explode('>', $val['categoryPathText']);
                    $val['category_name1'] = (isset($categoryExp[0])) ? $categoryExp[0] : '';
                    $val['category_name2'] = (isset($categoryExp[1])) ? $categoryExp[1] : '';
                    $val['category_name3'] = (isset($categoryExp[2])) ? $categoryExp[2] : '';
                    $val['category_name4'] = (isset($categoryExp[3])) ? $categoryExp[3] : '';
                }

                //셀러id
                if (isset($sellerId[$val['admin']])) {
                    $val['seller_id'] = $sellerId[$val['admin']];
                }

                //옵션구성
                $optionsDetail = [];
                $options = $this->qb
                    ->select('od.option_div')
                    ->select('od.option_price')
                    ->from(TBL_SHOP_PRODUCT_OPTIONS . ' as o')
                    ->join(TBL_SHOP_PRODUCT_OPTIONS_DETAIL . ' as od', 'o.opn_ix=od.opn_ix')
                    ->where('o.pid', $val['id'])
                    ->where('o.option_type', 'b')
                    ->where('od.is_delete', '0')
                    ->where('od.option_stock > 0')
                    ->where('od.option_soldout != ', '1')
                    ->exec()
                    ->getResultArray();
                foreach ($options as $optionsVal) {
                    $optionsDetail[] = $optionsVal['option_div'] . '^' . $optionsVal['option_price'];
                }
                $val['option_detail'] = implode('|', $optionsDetail);

                //상품이미지
                $val['image_link'] = get_product_images_src($val['id']);

                //추가 이미지
                /*$addImageList = $this->getAddImagesSrc($val['id'], $val['is_adult']); //추가이미지
                if (!empty($addImageList)) {
                    $imgArray = array_column($addImageList, 'bigImg');
                    if(!empty($imgArray)){
                        $val['image_link'] = MALL_DOMAIN.$imgArray[0];
                    }
                }*/

                //배송비
                $shippingInfo = $statusModel->getDeliveryInfo($val['dt_ix'], ['price' => $val['dcprice'], 'qty' => 1]);
                $val['deliv'] = $shippingInfo['sumPrice'];
                $val['dlvdt'] = $shippingInfo['addPrice'] > 0 ? $shippingInfo['regionText'] : '';

                //포인트
                $val['point'] = $mileageModel->getSaveMileage(
                    $val['reserve_yn'],
                    $val['rate_type'],
                    ($val['rate_type'] == '1' ? $val['reserve_rate'] : $val['reserve']),
                    $val['admin'],
                    $val['listprice'],
                    $val['dcprice'],
                    $val['dcprice']
                );

                //ep class (신규I, 업데이트U, 품절D)
                if ($val['state'] != '1' || $val['disp'] != '1') {
                    $val['class'] = 'D';
                } else {
                    if ($val['editdate'] == $val['regdate']) {
                        $val['class'] = 'I';
                    } else {
                        $val['class'] = 'U';
                    }
                }

                //daum ep 컬럼명과 동일하게 치환
                $val['adult'] = ($val['is_adult'] == '1') ? 'Y' : '';
                $val['link'] = MALL_DOMAIN . '/shop/goodsView/' . $val['id'];
                $val['mobile_link'] = MALL_DOMAIN . '/shop/goodsView/' . $val['id'];
                $val['update_time'] = str_replace(['-',' ', ':'],'',$val['editdate']);
                $val['adminkeyword'] = str_replace(',', '|', $val['search_keyword']);

                $val['pubdate'] = str_replace('-', '', substr($val['regdate'], 0, 10));
                $data['list'][$key] = $val;
            }
        }

        return $data;
    }

    /**
     * 카테고리 분리
     * @param $cid
     * @return mixed
     */
    public function getSeparatorCid($cid)
    {
        $padLen = 15;
        $padStr = '0';
        $cidArray[0] = str_pad(substr($cid,0,3), $padLen, $padStr, STR_PAD_RIGHT);
        $cidArray[1] = str_pad(substr($cid,0,6), $padLen, $padStr, STR_PAD_RIGHT);
        $cidArray[2] = str_pad(substr($cid,0,9), $padLen, $padStr, STR_PAD_RIGHT);
        $cidArray[3] = str_pad(substr($cid,0,12), $padLen, $padStr, STR_PAD_RIGHT);
        $cidArray[4] = $cid;

        return $cidArray;
    }


    /**
     * 할인 정보
     * @param type $productList
     */
    protected function discount($productList)
    {
        //메모리 초기화
        if (count($this->discountData) > 300) {
            $this->discountData = [];
        }

        $ids = array_column($productList, 'id');
        $saveIds = array_keys($this->discountData);

        // 현재 할인된 상품 리스트에서 조회
        $noIds = array_diff($ids, $saveIds); // $ids - $saveIds
        //discountData 에 상품의 할인 정보가 없다면, 없는 id 들만 추려서 setDiscountData 처리

        if (!empty($noIds)) {
            $noIds = array_unique($noIds);
            $this->setDiscountData($noIds);
        }

        foreach ($productList as $productKey => $product) {
            $productList[$productKey] = array_merge($product,
                $this->discountCalculation($product['id'], $product['listprice'], $product['dcprice']));
        }

        return $productList;
    }

    /**
     * set discountData
     * @param array $ids
     */
    protected function setDiscountData($ids)
    {

        foreach ($ids as $id) {
            $this->discountData[$id] = [];
        }

        //그룹(MG)
        if ($this->discoutMemberGroupSaleRate > 0) {
            foreach ($ids as $id) {
                $this->discountData[$id][] = $this->structureDiscountData('MG', 1, $this->discoutMemberGroupSaleRate,
                    $this->discoutMemberGroupSaleRate, 0, $this->discoutMemberGroupIx);
            }
        }

        //기획&특별&모바일(GP:기획,SP:특별,M:모바일)
        if ($this->discoutMemberGroupIx > 0) {
            $this->qb
                ->join(TBL_SHOP_DISCOUNT_DISPLAY_RELATION . ' as ddr',
                    "d.dc_ix = ddr.dc_ix and ddr.relation_type = 'G'", 'left')
                ->groupStart()
                ->where('member_target', 'A')
                ->orGroupStart()
                ->where('member_target', 'G')
                ->where('ddr.r_ix', $this->discoutMemberGroupIx)
                ->groupEnd()
                ->groupEnd();
        } else {
            $this->qb->where('member_target', 'A');
        }

        //모바일 구분 #'모바일 상품 기획/특별할인 적용되지 않음'이슈로 주석처리 (프론트 포인트 모델과 동기화 처리
        /*if ($this->agentType == 'M') {
            $this->qb->where('d.discount_type', 'M');
        } else {
            $this->qb->where('d.discount_type !=', 'M');
        }*/
        $rows = $this->qb
            ->select('dpr.pid')
            ->select('d.discount_type')
            ->select('dpg.dpg_ix')
            ->select('dpg.discount_sale_type')
            ->select('dpg.sale_rate')
            ->select('dpg.headoffice_rate')
            ->select('dpg.seller_rate')
            ->select('dpg.commission')
            ->from(TBL_SHOP_DISCOUNT . ' as d')
            ->join(TBL_SHOP_DISCOUNT_PRODUCT_GROUP . ' as dpg', 'd.dc_ix = dpg.dc_ix')
            ->join(TBL_SHOP_DISCOUNT_PRODUCT_RELATION . ' as dpr',
                'd.dc_ix = dpr.dc_ix and dpg.group_code = dpr.group_code')
            ->where('discount_use_sdate <=', time(), false)
            ->where('discount_use_edate >=', time(), false)
            ->where('d.is_use', '1')
            ->where('dpg.is_display', 'Y')
            ->whereIn('dpr.pid', $ids)
            ->orderBy('dpr.pid')
            ->orderBy('d.discount_type')
            ->orderBy('dpg.sale_rate', 'desc')
            ->exec()->getResultArray();

        //group by 가 안되서 for 문으로 처리 ※정렬 중요!!
        //pid, discount_type, discount_sale_type 별로 각가 등록 (원,% 중 실제 할인 금액이 큰건 계산해봐야 알수 있음)
        if (!empty($rows)) {
            $tmp = [];
            foreach ($rows as $row) {
                if (empty($tmp[$row['pid']][$row['discount_type']][$row['discount_sale_type']])) {
                    $this->discountData[$row['pid']][] = $this->structureDiscountData(
                        $row['discount_type'], $row['discount_sale_type'],
                        $row['sale_rate'],
                        $row['headoffice_rate'],
                        $row['seller_rate'],
                        $row['dpg_ix'],
                        $row['commission']
                    );
                    $tmp[$row['pid']][$row['discount_type']][$row['discount_sale_type']] = true;
                }
            }
            unset($tmp);
            unset($rows);
        }

        //APP(APP)
        if ($this->discoutAppSaleRate > 0) {
            foreach ($ids as $id) {
                $this->discountData[$id][] = $this->structureDiscountData('APP', 1, $this->discoutAppSaleRate,
                    $this->discoutAppSaleRate, 0, '');
            }
        }
    }

    /**
     * discountData 구조체
     * @param string $type
     * @param int $saleType 1:%, 2:원
     * @param int $saleValue
     * @param int $headOfficeSaleValue
     * @param int $sellerSaleValue
     * @param string $code
     * @param int $commission
     * @return type
     */
    protected function structureDiscountData(
        $type,
        $saleType,
        $saleValue,
        $headOfficeSaleValue,
        $sellerSaleValue,
        $code,
        $commission = 0,
        $description = ''
    ) {
        return [
            'type' => $type,
            'sale_type' => $saleType,
            'sale_value' => $saleValue,
            'headoffice_sale_value' => $headOfficeSaleValue,
            'seller_sale_value' => $sellerSaleValue,
            'code' => $code,
            'commission' => $commission,
            'description' => $description
        ];
    }

    /**
     * discountData 데이터에 있는 기준으로 계산
     * @param int $id
     * @param int $listPrice
     * @param int $dcPrice
     * @return array
     */
    protected function discountCalculation($id, $listPrice, $dcPrice)
    {
        $listPrice = f_decimal($listPrice);
        $dcPrice = f_decimal($dcPrice);

        $discountList = [];

        //즉시 할인
        if ($listPrice > $dcPrice) {
            $discountList[] = [
                'type' => 'IN',
                'title' => ForbizConfig::getDiscount('IN'),
                'discount_amount' => ($listPrice - $dcPrice)
            ];
        }

        // 상품에 관한 할인 정보(멀티)가 있으면, 적용해서 각각의 값을 보유하고 최종적으로
        // 할인 정책중 가장 할인률이 높은 하나를 적용해 준다.
        if (!empty($this->discountData[$id])) {
            $beforeDcPrice = f_decimal(0);
            $__dcPrice = f_decimal(0);
            foreach ($this->discountData[$id] as $discountKey => $data) {

                $lastDiscount = ($discountList[(count($discountList) - 1)] ?? ['type' => '']);

                $data['title'] = ForbizConfig::getDiscount($data['type']);


                if (in_array($data['type'], ['GP', 'SP', 'M']) && $lastDiscount['type'] == $data['type']) {
                    $_dcPrice = $beforeDcPrice;
                } else {
                    $_dcPrice = $dcPrice;
                }


                // 할인률 할인
                if ($data['sale_type'] == '1') { // %
                    $dcPrice = $this->round($_dcPrice * f_decimal((100 - $data['sale_value']) / 100));
                    $_headofficeDcPrice = $this->round($_dcPrice * f_decimal((100 - $data['headoffice_sale_value']) / 100));

                    // 정액 할인
                } elseif ($data['sale_type'] == '2') { // 원
                    $dcPrice = (($_dcPrice - f_decimal($data['sale_value'])) > 0 ? $_dcPrice - f_decimal($data['sale_value']) : f_decimal(0));
                    $_headofficeDcPrice = (($_dcPrice - f_decimal($data['headoffice_sale_value'])) > 0 ? $_dcPrice - f_decimal($data['headoffice_sale_value']) : f_decimal(0));
                }


                $beforeDcPrice = $_dcPrice;

                $_discountAmount = $_dcPrice - $dcPrice;
                $_headofficeDiscountAmount = $_dcPrice - $_headofficeDcPrice;

                $data['discount_amount'] = $_discountAmount;
                $data['headoffice_discount_amount'] = $_headofficeDiscountAmount;
                $data['seller_discount_amount'] = $_discountAmount - $_headofficeDiscountAmount;


                //기획&특별&모바일은 %,원 금액중 가장 큰금액으로 할인해 줘야 함
                if (in_array($data['type'], ['GP', 'SP', 'M']) && $lastDiscount['type'] == $data['type']) {
                    if ($lastDiscount['discount_amount'] < $data['discount_amount']) {
                        $discountList[(count($discountList) - 1)] = $data;
                        $__dcPrice = $dcPrice;
                    } else {
                        $dcPrice = $__dcPrice;
                    }
                } else {
                    $discountList[] = $data;
                    $__dcPrice = $dcPrice;
                }
            }
        }

        return [
            'dcprice' => $dcPrice,
            'discount_amount' => $listPrice - $dcPrice,
            'discount_rate' => ($listPrice > 0 ? f_decimal(($listPrice - $dcPrice) / $listPrice * 100, 0, 'round') : 0),
            'discountList' => $discountList
        ];
    }

    /**
     * 상품 정보 리스트
     * @param type $page
     * @param type $max
     * @param type $where
     * @return type
     */
    protected function getEpList($setQbFunction, $page = 1, $max = 5, $where = [], $ep = [])
    {
        $this->qb->startCache();

        $this->setWhere($where)
            ->select('p.id')
            ->from(TBL_SHOP_PRODUCT . ' p')
            ->where('p.is_delete', '0');

        if(!empty($ep)) {
            $this->qb->whereIn('p.id', $ep);
        }

        $this->qb->stopCache();

        $total = $this->qb->getCount();

        $paging = $this->qb->setTotalRows($total)->pagination($page, $max);

        if($total > 0) {
            $list = $this->basicOrderBy($where)
                ->limit($max, ($paging['offset'] ?? 0))
                ->exec()
                ->getResultArray();
        } else {
            $list = [];
        }

        $this->qb->flushCache();

        return [
            'total' => $total,
            'list' => $this->getListById($setQbFunction, array_column($list, 'id')),
            'paging' => $paging
        ];
    }

    /**
     * 상품 정보 리스트
     * @param type $page
     * @param type $max
     * @param type $where
     * @return type
     */
    protected function getList($setQbFunction, $page = 1, $max = 5, $where = [])
    {
        $this->qb->startCache();

        $this->setWhere($where)
            ->select('p.id')
            ->where('p.is_delete', '0')
            ->from(TBL_SHOP_PRODUCT . ' p');

        $this->qb->stopCache();

        $total = $this->qb->getCount();

        $paging = $this->qb->setTotalRows($total)->pagination($page, $max);

        if($total > 0) {
            $list = $this->basicOrderBy($where)
                ->limit($max, ($paging['offset'] ?? 0))
                ->exec()
                ->getResultArray();
        } else {
            $list = [];
        }

        $this->qb->flushCache();

        return [
            'total' => $total,
            'list' => $this->getListById($setQbFunction, array_column($list, 'id')),
            'paging' => $paging
        ];
    }

    /**
     * where 세팅
     * @param array $where
     * @return
     */
    protected function setWhere($where)
    {
        if (!empty($this->manageCompanyId)) {
            $this->qb->where('p.admin', $this->manageCompanyId);
        }
        if (isset($where['epStartDate']) && $where['epStartDate'] && isset($where['epEndDate']) && $where['epEndDate']) {
            $this->qb->betweenDate('p.editdate', $where['epStartDate'], $where['epEndDate']);
        }
        if (isset($where['admin']) && $where['admin']) {
            $this->qb->where('p.admin', $where['admin']);
        }
        if (isset($where['dateType']) && $where['dateType'] && isset($where['startDate']) && $where['startDate'] && isset($where['endDate']) && $where['endDate']) {
            if ($where['dateType'] == 'sellDate') { //상품일괄관리 판매기간/상태/노출 메뉴에 판매기간 타입 추가
                $this->qb->where('p.sell_priod_sdate >= "' . $where['startDate'] . '"');
                $this->qb->where('p.sell_priod_edate <= "' . $where['endDate'] . '"');
            } else {
                $this->qb->betweenDate('p.' . $where['dateType'], $where['startDate'], $where['endDate']);
            }
        }
        if (isset($where['state']) && $where['state']) {
            $this->qb->whereIn('p.state', $where['state']);
        }
        if (isset($where['is_mobile_use']) && $where['is_mobile_use']) {
            if ($where['is_mobile_use'] != 'A') {
                $this->qb->where('p.is_mobile_use', $where['is_mobile_use']);
            }
        }
        if (isset($where['delivery_type']) && $where['delivery_type']) {
            $this->qb->whereIn('p.delivery_type', $where['delivery_type']);
        }
        if (isset($where['product_type']) && $where['product_type']) {
            $this->qb->whereIn('p.product_type', $where['product_type']);
        } else {
            $this->qb->where('p.product_type != ', PRODUCT_TYPE_GIFT); // 일반 상품검색 시 사은품 제외 검색
        }
        if (isset($where['disp'])) {
            $this->qb->whereIn('p.disp', $where['disp']);
        }
        if (isset($where['md_id']) && $where['md_id']) {
            $this->qb->where('p.md_code', $where['md_id']);
        }
        if (isset($where['brand_ix']) && $where['brand_ix']) {
            $this->qb->where('p.brand', $where['brand_ix']);
        }
        if (isset($where['erp_year']) && $where['erp_year']) {
            $this->qb->where('p.erp_year', $where['erp_year']);
        }
        if (isset($where['erp_quarter']) && $where['erp_quarter']) {
            $this->qb->where('p.erp_quarter', $where['erp_quarter']);
        }
        if (isset($where['bimg']) && $where['bimg']) {
            if ($where['bimg'] == 'Y') {
                $this->qb->where("p.bimg != ''");
            } else {
                $this->qb->where("p.bimg = ''");
            }
        }
        if (isset($where['coupon_use_yn']) && $where['coupon_use_yn']) {
            $this->qb->where('p.coupon_use_yn', $where['coupon_use_yn']);
        }
        if (isset($where['soldout_yn']) && $where['soldout_yn']) {
            $soldoutYn = ($where['soldout_yn'] == 'Y') ? '1' : '0';
            $this->qb->join(TBL_SHOP_PRODUCT_OPTIONS_DETAIL . ' AS pod', 'pod.pid=p.id');
            $this->qb->where('pod.option_soldout', $soldoutYn);
        }
        if (isset($where['store_product_remove']) && $where['store_product_remove']) {
            if ($where['store_product_remove'] == 'Y') {
                $this->qb->join(TBL_SHOP_STORE_PRODUCT_REMOVE . ' AS spr', 'spr.pid=p.id');
            }
        }
        if (isset($where['always_dc_yn']) && $where['always_dc_yn']) {
            $this->qb->where('p.always_dc_yn', $where['always_dc_yn']);
        }
        if (isset($where['erp_price_yn']) && $where['erp_price_yn']) {
            $this->qb->where('p.erp_price_yn', $where['erp_price_yn']);
        }

        if (isset($where['filterCid']) && !empty($where['filterCid'])) {
            /* @var $categoryModel \CustomScm\Model\Product\Category */
            $categoryModel = $this->import('model.scm.product.category');

            $this->qb->join(TBL_SHOP_PRODUCT_RELATION . ' AS r', 'r.pid=p.id');

            if (is_array($where['filterCid'])) {
                if (count($where['filterCid']) > 0) {
                    $this->qb->groupStart();
                    foreach ($where['filterCid'] as $cid) {
                        $depth = $categoryModel->getDepth($cid);
                        $this->qb->orLike('r.cid', substr($cid, 0, 3 * ($depth + 1)), 'after');
                    }
                    $this->qb->groupEnd();
                }
            } else {
                $depth = $categoryModel->getDepth($where['filterCid']);
                $this->qb->like('r.cid', substr($where['filterCid'], 0, 3 * ($depth + 1)), 'after');
            }
        }

        if (isset($where['filterType']) && $where['filterType'] && isset($where['filterText']) && $where['filterText']) {
            $multipleSearchText = convert_multiple_search_text_list($where['filterText']);
            if($where['filterType'] == 'pname') {
                $this->qb->groupStart();
                foreach ($multipleSearchText as $multipleSearchTextVal) {
                    $this->qb->groupStart('', 'OR');
                    $this->qb->like('pname', $multipleSearchTextVal);
                    $this->qb->groupEnd();
                }
                $this->qb->groupEnd();
            } else {
                if (count($multipleSearchText) > 1) {
                    $this->qb->whereIn($where['filterType'], $multipleSearchText);
                } else {
                    $this->qb->like($where['filterType'], $multipleSearchText[0]);
                }
            }
        }

        return $this->qb;
    }

    /**
     * order by 세팅
     * @param type $where
     * @return type
     */
    protected function basicOrderBy($where)
    {
        if (isset($where['filterType']) && !empty($where['filterType']) && isset($where['filterText']) && !empty($where['filterText'])) {
            $multipleSearchText = convert_multiple_search_text_list($where['filterText']);
            if (count($multipleSearchText) > 1) {
                $orderByLsit = [];
                foreach ($multipleSearchText as $key => $text) {
                    $orderByLsit[] = ' WHEN "' . $text . '" THEN ' . $key;
                }
                return $this->qb->orderBy('(CASE ' . $where['filterType'] . ' ' . implode('',
                        $orderByLsit) . ' ELSE 999 END)');
            }
        }
        return $this->qb->orderBy('p.regdate', 'DESC');
    }

    /**
     * get 상품아이디로 상품정보 리턴
     * @param type $ids
     * @param type $imageSizeType
     * @param type $addSelect
     * @return type
     */
    public function getListById($setQbFunction, $ids = [])
    {
        if (empty($ids)) {
            return [];
        }

        $setQbFunction();

        $list = $this->qb
            ->select('c.com_name')
            ->select('b.brand_name')
            ->select('cu.id as mds_id')
            ->decryptSelect('cmd.name','mds_name')
            ->select('p.id')
            ->select('p.editdate')
            ->select('p.regdate')
            ->from(TBL_SHOP_PRODUCT . ' as p')
            ->join(TBL_SHOP_BRAND . ' as b', 'p.brand != "" and b.b_ix=brand', 'left')
            ->join(TBL_COMMON_COMPANY_DETAIL . ' AS c', 'c.company_id=admin', 'left')
            ->join(TBL_COMMON_USER . ' AS cu', 'cu.code = p.md_code', 'left')
            ->join(TBL_COMMON_MEMBER_DETAIL . ' AS cmd', 'cu.code = cmd.code', 'left')
            ->whereIn('p.id', $ids)
            ->where('is_delete', '0')
            ->exec()
            ->getResultArray();

        if (!empty($list)) {
            //ids 에 넘긴 순서대로 정렬
            $list = $this->sortList($ids, $list, 'id');

            /* @var $categoryModel \CustomScm\Model\Product\Category */
            $categoryModel = $this->import('model.scm.product.category');

            //카테고리
            $cateList = array_filter(array_column($list, 'id'));
            $ctList = [];
            if (!empty($cateList)) {
                $rows = $this->qb
                    ->select('r.cid')
                    ->select('depth')
                    ->select('r.pid')
                    ->from(TBL_SHOP_PRODUCT_RELATION . ' AS r')
                    ->join(TBL_SHOP_CATEGORY_INFO . ' AS ci', 'ci.cid=r.cid')
                    ->whereIn('pid', $cateList)
                    ->where('basic', '1')
                    ->exec()
                    ->getResultArray();

                foreach ($rows as $key => $val) {
                    $ctList[$val['pid']]['cid'] = $val['cid'];
                    $ctList[$val['pid']]['depth'] = $val['depth'];
                }
            }

            //상품 데이터 처리
            foreach ($list as $key => $val) {
                //이미지
                $val['thum_image_src'] = get_product_images_src($val['id'], 'c');
                $val['image_src'] = get_product_images_src($val['id'], 'm');

                //판매상태
                if (isset($val['state'])) {
                    $val['stateText'] = $this->productModel->getState($val['state']);
                }

                //노출여부
                if (isset($val['disp'])) {
                    $val['dispText'] = $this->productModel->getDisp($val['disp']);
                }

                //카테고리
                if (!empty($ctList[$val['id']]['cid'])) {
                    $cateList = $categoryModel->getCategoryPath($ctList[$val['id']]['cid'], $ctList[$val['id']]['depth']);
                    $val['categoryPathText'] = implode('>', array_column($cateList, 'cname'));
                }

                //판매기간/상태/노출
                if (isset($val['sell_priod_sdate']) && isset($val['sell_priod_edate'])) {
                    $val['sellDate'] = substr($val['sell_priod_sdate'], 0,
                            10) . ' ~ ' . substr($val['sell_priod_edate'], 0, 10);
                }

                //배송정책
                if (isset($val['delivery_type'])) {
                    if ($val['delivery_type'] == 1) {
                        $val['deliveryTypeText'] = "통합배송";
                    } elseif ($val['delivery_type'] == 2) {
                        $val['deliveryTypeText'] = "개별배송";
                    } else {
                        $val['deliveryTypeText'] = "없음";
                    }
                }

                //담당MD
                if (!empty($val['mds_id']) && !empty($val['mds_name'])) {
                    $val['mdText'] = $val['mds_id'] . '/' . $val['mds_name'];
                }

                //담당상품별 수수료
                if (isset($val['commission'])) {
                    $val['commissionText'] = $val['commission'] . '%';
                }

                //모바일상품
                if (isset($val['is_mobile_use'])) {
                    if ($val['is_mobile_use'] == 'A') {
                        $mobileText = "전체";
                    } elseif ($val['is_mobile_use'] == 'W') {
                        $mobileText = "웹";
                    } elseif ($val['is_mobile_use'] == 'M') {
                        $mobileText = "모바일";
                    } else {
                        $mobileText = "없음";
                    }
                    $val['mobileText'] = $mobileText;
                }

                //브랜드명
                if (isset($val['brand_name'])) {
                    $val['brandText'] = $val['brand_name'] ?? '';
                }

                //셀러업체
                if (isset($val['com_name'])) {
                    $val['sellerText'] = $val['com_name'] ?? '';
                }

                $list[$key] = $val;
            }
        }

        return $list;
    }

    /**
     * 추가이미지 호출
     * @param string $id
     * @param boolean $isAdult
     * @return array
     */
    protected function getAddImagesSrc($id, $isAdult = false)
    {
        $addIds = $this->qb
            ->select('*')
            ->from(TBL_SHOP_ADDIMAGE)
            ->where('pid', $id)
            ->exec()->getResultArray();

        $basicPath = DATA_ROOT . "/images/product";
        $basicAddPath = DATA_ROOT . "/images/addimg";

        $addImgs = array();
        foreach ($addIds as $k => $v) {

            //19세 상품일때
            if ($isAdult) {
                $addImgs[] = IMAGE_SERVER_DOMAIN . $basicPath . '/product_19_200.gif';
                continue;
            }

            $imgDir = implode("/", str_split(zerofill($id), 2));
            $imageBigSrc = $basicAddPath . '/' . $imgDir . "/b_" . zerofill($v['id'], 8) . "_add.gif";
            $imageSmallSrc = $basicAddPath . '/' . $imgDir . "/m_" . zerofill($v['id'], 8) . "_add.gif";

            //이미지 없을떄
            if (!file_exists($_SERVER['DOCUMENT_ROOT'] . $imageBigSrc)) {
                $addImgs[] = array(
                    'bigImg' => $basicPath . "/shop/noimg.gif",
                    'smallImg' => $basicPath . "/shop/noimg.gif"
                );
            } else {
                $addImgs[] = array('bigImg' => $imageBigSrc, 'smallImg' => $imageSmallSrc);
            }
        }

        return $addImgs;
    }

    /**
     * $standardArray 기준으로 $targetArray 정렬
     * @param array $standardArray
     * @param array $targetArray
     * @param string $targetKey
     * @return array
     */
    public function sortList($standardArray, $targetArray, $targetKey)
    {
        $return = [];
        foreach ($standardArray as $value) {
            $searchKey = array_search($value, array_column($targetArray, $targetKey));
            if($searchKey !== false) {
                $return[] = $targetArray[$searchKey];
            }
        }
        return $return;
    }

    /**
     * get 엑셀 다운로드 title
     * @param bool $alias
     * @return array
     */
    public function getExcelTitle($alias = false)
    {
        $data = [
            ['alias' => 'CUSTOM', 'column' => 'thum_image_src', 'title' => '상품이미지'],
            ['alias' => 'p', 'column' => 'brand_name', 'title' => '브랜드명'],
            ['alias' => 'p', 'column' => 'pname', 'title' => '상품명'],
            ['alias' => 'p', 'column' => 'id', 'title' => '상품코드'],
            ['alias' => 'p', 'column' => 'pcode', 'title' => '상품관리코드'],
            ['alias' => 'p', 'column' => 'listprice', 'title' => '정가'],
            ['alias' => 'p', 'column' => 'sellprice', 'title' => '판매가'],
            ['alias' => 'p', 'column' => 'coprice', 'title' => '공급가'],
            ['alias' => 'p', 'column' => 'state', 'title' => '판매상태'],
            ['alias' => 'p', 'column' => 'disp', 'title' => '노출여부'],
            ['alias' => 'p', 'column' => 'regdate', 'title' => '등록/수정일']
        ];

        if ($alias === false) {
            $return = [];
            foreach ($data as $d) {
                $return[$d['column']] = $d['title'];
            }
            return $return;
        } else {
            return $data;
        }
    }

    /**
     * get 엑셀 다운로드 formatColumn
     * @return array
     */
    public function getExcelMoneyFormatColumn()
    {
        return ['thum_image_src', 'brand_name', 'pname', 'id', 'pcode', 'listprice', 'sellprice', 'coprice','stateText', 'dispText', 'regdate'];
    }

    /**
     * 상품리스트 엑셀 다운로드
     * @param type $page
     * @param type $max
     * @param type $where
     * @return type
     */
    public function getExcelList($page = 1, $max = 5, $where = [])
    {
        $data = $this->getList(function () {
            //CUSTOM
            $this->qb
                ->select("p.id")
                ->select("p.state")
                ->select("p.disp")
                ->select("p.sell_priod_sdate")
                ->select("p.sell_priod_edate")
                ->select("p.is_adult")
                ->select("ccd.com_name")
                ->select("(CASE p.one_commission WHEN 'Y' THEN p.account_type ELSE csd.account_type END) AS account_type")
                ->select("(CASE p.one_commission WHEN 'Y' THEN p.commission ELSE csd.commission END) AS commission")
                ->join(TBL_COMMON_COMPANY_DETAIL . ' AS ccd', 'ccd.company_id=p.admin')
                ->join(TBL_COMMON_SELLER_DELIVERY . ' AS csd', 'csd.company_id=p.admin');

            foreach ($this->getExcelTitle(true) as $key => $value) {
                if ($value['alias'] != 'CUSTOM') {
                    $this->qb->select($value['alias'] . '.' . $value['column']);
                }
            }
        }, $page, $max, $where, true);

        /* @var $originModel \CustomScm\Model\Product\Origin */
        $originModel = $this->import('model.scm.product.origin');

        //데이터 변경
        foreach ($data['list'] as $key => $val) {

            //카테고리
            $rows = $this->qb
                ->select('CONCAT(" ", pr.cid) AS cid')
                ->from(TBL_SHOP_PRODUCT_RELATION . ' AS pr')
                ->where('pr.pid', $val['id'])
                ->exec()
                ->getResultArray();

            $val['cid'] = array_column($rows, 'cid');

            //옵션
            $rows = $this->qb
                ->select("option_div")
                ->select("option_coprice")
                ->select("option_listprice")
                ->select("option_price")
                ->select("option_stock")
                ->select("IF(option_soldout=1,'Y','N') AS option_soldout")
                ->from(TBL_SHOP_PRODUCT_OPTIONS . ' AS o')
                ->join(TBL_SHOP_PRODUCT_OPTIONS_DETAIL . ' AS od', 'o.opn_ix=od.opn_ix')
                ->where('o.option_kind', 'b')
                ->where('o.pid', $val['id'])
                ->exec()
                ->getResultArray();

            $val['option_div'] = array_column($rows, 'option_div');
            $val['option_coprice'] = array_column($rows, 'option_coprice');
            $val['option_listprice'] = array_column($rows, 'option_listprice');
            $val['option_price'] = array_column($rows, 'option_price');
            $val['option_stock'] = array_column($rows, 'option_stock');
            $val['option_soldout'] = array_column($rows, 'option_soldout');

            //고시 정보
            $rows = $this->qb
                ->select("pmi_code")
                ->select("pmi_desc")
                ->from(TBL_SHOP_PRODUCT_MANDATORY_INFO . ' AS mi')
                ->where('mi.pid', $val['id'])
                ->exec()
                ->getResultArray();

            $val['pmi_code'] = array_column($rows, 'pmi_code');
            $val['pmi_desc'] = array_column($rows, 'pmi_desc');

            //판매 시간
            $val['sell_priod_sdate'] = date('Ymd', strtotime($val['sell_priod_sdate']));
            $val['sell_priod_edate'] = date('Ymd', strtotime($val['sell_priod_edate']));
            if (!($val['sell_priod_sdate'] > 0)) {
                $val['sell_priod_sdate'] = '';
            }
            if (!($val['sell_priod_edate'] > 0)) {
                $val['sell_priod_edate'] = '';
            }

            //19금 여부
            if ($val['is_adult'] == '1') {
                $val['is_adult'] = 'Y';
            } else {
                $val['is_adult'] = 'N';
            }

            //추가 이미지
            $val['addImage'] = array_column($this->productModel->getAddImage($val['id']), 'url');

            //원산지
            if (!empty($val['origin'])) {
                $originData = $originModel->getByName($val['origin']);
                $val['origin'] = $originData['og_ix'] ?? '';
            }

            //판매상태
            if (isset($val['state'])) {
                $val['state'] = $this->productModel->getState($val['state']);
            }

            //노출여부
            if (isset($val['disp'])) {
                $val['disp'] = $this->productModel->getDisp($val['disp']);
            }

            //정산 방식
            $val['accountTypeText'] = $this->productModel->getAccountType($val['account_type']);

            //배송비 정책 명
            $val['deliveryTemplateText'] = $this->productModel->getDeliveryTemplate($val['id'])['template_name'] ?? '';

            $data['list'][$key] = $val;
        }

        return $data;
    }

    /**
     * 상품리스트 조회
     * @param type $page
     * @param type $max
     * @param type $where
     * @return type
     */
    public function getBasicList($page = 1, $max = 5, $where = [])
    {
        return $this->getList(function () {
            $this->qb
                ->select('p.id')
                ->select('p.admin')
                ->select('p.pname')
                ->select('p.pcode')
                ->select('p.brand')
                ->select('p.listprice')
                ->select('p.sellprice')
                ->select('p.coprice')
                ->select('p.wholesale_price')
                ->select('p.wholesale_sellprice')
                ->select('p.state')
                ->select('p.is_mobile_use')
                ->select('p.disp')
                ->select('p.brand_name')
                ->select('p.editdate')
                ->select('p.regdate')
                ->select('sell_priod_sdate')
                ->select('sell_priod_edate')
                ->select('delivery_type')
                ->select('IFNULL(' . $this->qb
                        ->startSubQuery()
                        ->select('template_name')
                        ->from(TBL_SHOP_PRODUCT_DELIVERY . ' AS d')
                        ->join(TBL_SHOP_DELIVERY_TEMPLATE . ' AS t', 'd.dt_ix = t.dt_ix')
                        ->where('pid=p.id')
                        ->limit(1)
                        ->endSubQuery()
                    . ', 0) AS deliveryTemplateText')
                ->select('md_code')
                ->select('if(one_commission="Y",commission,0) as commission');
        }, $page, $max, $where);
    }

    /**
     * 제휴사연동 상품리스트 조회
     * @param type $page
     * @param type $max
     * @param type $where
     * @return type
     */
    public function getSellertoolList($page = 1, $max = 5, $where = [])
    {
        $data = $this->getList(function () {
            $this->qb
                ->select('p.id')
                ->select('p.pname')
                ->select('p.pcode')
                ->select('p.brand')
                ->select('p.state')
                ->select('p.disp')
                ->select('p.editdate')
                ->select('p.regdate');
        }, $page, $max, $where);

        if (!empty($data['list']) > 0) {
            $pidList = array_column($data['list'], 'id');

            $siteProductInfoList = $this->qb
                ->select('sspi.si_ix')
                ->select('sspi.pid')
                ->select('sspi.api_use_yn')
                ->from(TBL_SELLERTOOL_SITE_PRODUCT_INFO . ' as sspi')
                ->whereIn('sspi.pid', $pidList)
                ->exec()
                ->getResultArray();

            $siteProduct = [];
            foreach ($siteProductInfoList as $siteProductInfi) {
                if ($siteProductInfi['api_use_yn'] == 'Y') {
                    if (!isset($siteProduct[$siteProductInfi['pid']])) {
                        $siteProduct[$siteProductInfi['pid']] = [];
                    }
                    $siteProduct[$siteProductInfi['pid']][] = $siteProductInfi['si_ix'];
                }
            }

            foreach ($data['list'] as $key => $li) {
                if (!empty($siteProduct[$li['id']])) {
                    foreach ($siteProduct[$li['id']] as $si_ix) {
                        $li['api_use_yn_' . $si_ix] = 'Y';
                    }
                }

                $data['list'][$key] = $li;
            }
        }

        return $data;
    }

    /**
     * 매장별 재고 현황
     * @param int $cur_page
     * @param int $per_page
     * @param array $search
     * @return array
     */
    public function getStockData($cur_page, $per_page, $search = [])
    {
        // 쿼리 캐시 시작
        $this->qb->startCache();
        $this->qb
            ->from(TBL_SHOP_PRODUCT_OPTIONS_DETAIL);

        // 검색 조건 설정
        if (($search['id'] ?? false)) {
            $this->qb->where('pid', $search['id']);
        }

        // 쿼리 캐시 끝
        $this->qb->stopCache();

        // total 산출
        $total = $this->qb->getCount();

        // 페이징 설정
        $paging = $this->qb
            ->setTotalRows($total)
            ->pagination($cur_page, $per_page);

        // limit 값 산출
        $limit = $per_page;
        $offset = ($paging['offset'] ?? 0);

        $rows = $this->qb
            ->limit($limit, $offset)
            ->exec()
            ->getResultArray();

        $this->qb->flushCache();

        $this->result = 'success';
        $this->data = [
            'list' => $rows
            ,
            'paging' => $paging
            ,
            'total' => $total
        ];


        return $this->getResult();
    }

    /**
     * 사이즈 현황
     * @param int $cur_page
     * @param int $per_page
     * @param array $search
     * @return array
     */
    public function getSizeData($cur_page, $per_page, $search = [])
    {
        // 쿼리 캐시 시작
        $this->qb->startCache();
        $this->qb
            ->from(TBL_SHOP_PRODUCT_OPTIONS_DETAIL);

        // 검색 조건 설정
        if (($search['id'] ?? false)) {
            $this->qb->where('pid', $search['id']);
        }

        // 쿼리 캐시 끝
        $this->qb->stopCache();

        // total 산출
        $total = $this->qb->getCount();

        // 페이징 설정
        $paging = $this->qb
            ->setTotalRows($total)
            ->pagination($cur_page, $per_page);

        // limit 값 산출
        $limit = $per_page;
        $offset = ($paging['offset'] ?? 0);

        $rows = $this->qb
            ->limit($limit, $offset)
            ->exec()
            ->getResultArray();

        $this->qb->flushCache();

        $this->result = 'success';
        $this->data = [
            'list' => $rows
            ,
            'paging' => $paging
            ,
            'total' => $total
        ];


        return $this->getResult();
    }

    /**
     * 묶음상품리스트 조회
     * @param type $page
     * @param type $max
     * @param type $where
     * @return type
     */
    public function getProductBundleList($page = 1, $max = 5, $where = [])
    {
        $this->qb->startCache();

        $this->setWhere($where)
            ->select('DISTINCT(bp.pid) as id')
            ->select('bp.regdate')
            ->select('p.pname')
            ->select('p.brand')
            ->from(TBL_SHOP_PRODUCT . ' p')
            ->join(TBL_SHOP_BUNDLE_PRODUCT . ' AS bp', 'bp.pid = p.id');

        $this->qb->stopCache();

        $total = $this->qb->getCount();

        $paging = $this->qb->setTotalRows($total)->pagination($page, $max);

        $list = $this->qb
            ->limit($max, ($paging['offset'] ?? 0))
            ->exec()
            ->getResultArray();

        $this->qb->flushCache();

        return [
            'total' => $total,
            'list' => $list,
            'paging' => $paging
        ];
    }

    /**
     * 묶음상품리스트 조회
     * @param type $page
     * @param type $max
     * @param type $where
     * @return type
     */
    public function delProductBundleList($pid)
    {
        $this->result = 'success';

        return $this->qb
                ->where('pid', $pid)
                ->delete(TBL_SHOP_BUNDLE_PRODUCT)
                ->exec();
    }

    /**
     * 절사
     * @param int $price
     * @return int
     */
    protected function round($price)
    {
        $price = f_decimal($price);
        if ($this->discoutRoundPosition > 0) {
            $pow = pow(10, $this->discoutRoundPosition);
            switch ($this->discoutRoundType) {
                case 'floor':
                    $price = f_decimal($price / $pow,0 ,'floor') * $pow;
                    break;
                case 'ceil';
                    $price = f_decimal($price / $pow, 0, 'ceil') * $pow;
                    break;
                default :
                    $price = f_decimal($price / $pow, 0, 'round') * $pow;
                    break;
            }
            $price = f_decimal($price);
        } else {
            $places = $this->discoutRoundPosition * -1;
            switch ($this->discoutRoundType) {
                case 'floor':
                    $price = $price->round($places, $price::ROUND_FLOOR);
                    break;
                case 'ceil';
                    $price = $price->round($places, $price::ROUND_CEILING);
                    break;
                default :
                    $price = $price->round($places);
                    break;
            }
        }
        return $price;
    }
}