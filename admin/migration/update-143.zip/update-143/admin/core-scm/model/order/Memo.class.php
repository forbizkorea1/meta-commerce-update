<?php
namespace ForbizScm\Model\Order;

/**
 * 주문 메모 관련 
 *
 * @author hoksi
 */
class Memo extends \ForbizModel
{

    /**
     * 분류
     * @var type
     */
    protected $div = [
        '1' => '주문'
        , '2' => '배송'
        , '3' => '취소'
        , '4' => '반품'
        , '5' => '교환'
        , '6' => 'SYSTEM'
    ];

    /**
     * 상태
     * @var type 
     */
    protected $state = [
        '1' => '접수완료'
        , '2' => '처리중'
        , '3' => '처리지연'
        , '4' => '처리완료'
    ];

    public function __construct()
    {
        parent::__construct();
    }

    /**
     * get 분류 리스트
     * @return type
     */
    public function getDivList()
    {
        return $this->div;
    }

    /**
     * get 분류명
     * @param type $div
     * @return type
     */
    public function getDivText($div)
    {
        return $this->div[$div] ?? $div;
    }

    /**
     * get 상태 리스트
     * @return type
     */
    public function getStateList()
    {
        return $this->state;
    }

    /**
     * get 상태명
     * @param type $state
     * @return type
     */
    public function getStateText($state)
    {
        return $this->state[$state] ?? $state;
    }

    /**
     * 메모 리스트
     * @param int $cur_page
     * @param int $limit
     * @param array $search
     * @return array
     * @throws \Exception
     */
    public function getList($cur_page = 1, $limit = 20, $search = [])
    {
        $this->qb->startCache();

        // 검색 조건
        if (isset($search['searchType']) && $search['searchType'] && isset($search['searchText']) && $search['searchText']) {
            $this->qb->like($search['searchType'], $search['searchText']);
        }
        if (isset($search['startDate']) && $search['startDate'] && isset($search['endDate']) && $search['endDate']) {
            $this->qb->betweenDate($search['searchDateType'], $search['startDate'], $search['endDate']);
        }
        if (isset($search['div']) && !empty($search['div'])) {
            $this->qb->whereIn('om.memo_div', $search['div']);
        }
        if (isset($search['state']) && !empty($search['state'])) {
            $this->qb->whereIn('om.memo_state', $search['state']);
        }
        if (isset($search['oid']) && !empty($search['oid'])) {
            $this->qb->where('om.oid', $search['oid']);
        }

        $this->qb
            ->from(TBL_SHOP_ORDER_MEMO . ' AS om');
        $this->qb->stopCache();

        $total = $this->qb->getCount();
        $paging = $this->qb
            ->setTotalRows($total)
            ->pagination($cur_page, $limit);

        $offset = ($paging['offset'] ?? 0);

        $rows = $this->qb
            ->select('om.om_ix')
            ->select('om.oid')
            ->select('om.memo')
            ->select('om.counselor')
            ->select('om.memo_div')
            ->select('om.memo_state')
            ->select('om.regdate')
            ->orderBy('om.regdate', 'DESC')
            ->limit($limit, $offset)
            ->exec()
            ->getResultArray();

        $this->qb->flushCache();

        //치환 처리
        foreach ($rows as $key => $val) {
            $val['memoDivText'] = $this->getDivText($val['memo_div']);
            $val['memoStateText'] = $this->getStateText($val['memo_state']);
            $rows[$key] = $val;
        }

        return [
            'total' => $total
            , 'list' => $rows
            , 'paging' => $paging
        ];
    }

    /**
     * get 메모 정보
     * @param type $omIx
     * @return type
     */
    public function get($omIx)
    {
        return $this->qb
                ->select('om_ix')
                ->select('memo')
                ->select('memo_div')
                ->select('memo_state')
                ->from(TBL_SHOP_ORDER_MEMO)
                ->where('om_ix', $omIx)
                ->exec()
                ->getRowArray();
    }

    /**
     * add 메모
     * @param type $oid
     * @param type $data
     */
    public function add($oid, $data)
    {
        $row = $this->qb
            ->select('o.order_date')
            ->select('o.user_code')
            ->from(TBL_SHOP_ORDER . ' o')
            ->where('o.oid', $oid)
            ->exec()
            ->getRowArray();

        $this->qb
            ->insert(TBL_SHOP_ORDER_MEMO, [
                'ucode' => $row['user_code'],
                'oid' => $oid,
                'order_date' => $row['order_date'],
                'memo' => $data['memo'],
                'counselor' => $data['counselor'],
                'counselor_ix' => $data['counselor_ix'],
                'memo_div' => $data['memo_div'],
                'memo_state' => $data['memo_state'],
                'regdate' => date('Y-m-d H:i:s')
            ])
            ->exec();
    }

    /**
     * 메모 수정
     * @param type $omIx
     * @param type $data
     */
    public function put($omIx, $data)
    {
        $this->qb
            ->set('memo', $data['memo'])
            ->set('memo_div', $data['memo_div'])
            ->set('memo_state', $data['memo_state'])
            ->update(TBL_SHOP_ORDER_MEMO)
            ->where('om_ix', $omIx)
            ->exec();
    }
}
