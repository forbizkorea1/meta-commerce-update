<?php

namespace ForbizScm\Model\Promotion;

/**
 * 통합배너 관리모델
 *
 * @author hoksi
 */
class BannerDisplay extends \ForbizModel
{

    public function __construct()
    {
        parent::__construct();
    }

    /**
     * 배너 리스트
     * @param int $page
     * @param int $max
     * @param array $where
     * @return array
     * @throws \Exception
     */
    public function getList($page = 1, $max = 5, $where = [])
    {
        $this->qb->startCache();

        $this->setWhere($where)
            ->select('b.banner_ix')
            ->select('div.div_name')
            ->select('bp.bp_name')
            ->select('b.banner_name')
            ->select('b.banner_kind')
            ->select('b.agent_type')
            ->select('b.banner_img')
            ->select('b.disp')
            ->select('b.use_sdate')
            ->select('b.use_edate')
            ->select('b.regdate')
            ->select('b.banner_position')
            ->from(TBL_SHOP_BANNERINFO . ' AS b')
            ->join(TBL_SHOP_BANNER_DIV . ' AS div', 'on  b.banner_page = div.div_ix', 'left')
            ->join(TBL_SHOP_BANNER_POSITION . ' AS bp', 'on b.banner_position = bp.bp_ix', 'left');
        $this->qb->stopCache();

        $total = $this->qb->getCount();

        $paging = $this->qb->setTotalRows($total)->pagination($page, $max);

        $list = $this->qb->limit($max, ($paging['offset'] ?? 0))
            ->orderBy('div.div_name')
            ->orderBy('b.banner_ix')
            ->exec()
            ->getResultArray();

        $this->qb->flushCache();

        //치환 처리
        foreach ($list as $key => $val) {
            //전시여부
            if (isset($val['disp'])) {
                if ($val['disp'] == '1') {
                    $val['disp_text'] = '노출함';
                } else if ($val['disp'] == '0') {
                    $val['disp_text'] = '노출안함';
                }
            }

            if (isset($val['agent_type'])) {
                if ($val['agent_type'] == 'W') {
                    $val['agent_type_text'] = '웹';
                } else if ($val['agent_type'] == 'M') {
                    $val['agent_type_text'] = '모바일';
                }
            }

            //스케줄 치환함수
            if (isset($val['banner_position'])) {
                $val['getScheduleBanner'] = $val['banner_position'];
            }

            //배너종류
            if (isset($val['banner_kind'])) {
                if ($val['banner_kind'] == '1') {
                    $val['banner_kind_text'] = '일반배너';
                } else if ($val['banner_kind'] == '2') {
                    $val['banner_kind_text'] = '플래쉬형 배너';
                } else if ($val['banner_kind'] == '3') {
                    $val['banner_kind_text'] = '슬라이드형 배너';
                } else if ($val['banner_kind'] == '4') {
                    $val['banner_kind_text'] = '동영상 배너';
                } else if ($val['banner_kind'] == '5') {
                    $val['banner_kind_text'] = '사용자지정 배너';
                }
            }

            //배너이미지
            $data = $this->getGroupList($val['banner_ix']);
            foreach ($data as $k => $v) {
                $thum_image_src = $v['groupImageSrc'];
            }

            if (!empty($thum_image_src)) {
                $val['thum_image_src'] = $thum_image_src;
            }

            $list[$key] = $val;
        }

        return [
            'total' => $total,
            'list' => $list,
            'paging' => $paging
        ];
    }

    /**
     * * where 세팅
     * @param $where
     * @return \CI_Qb
     */
    protected function setWhere($where)
    {
        /* @var $categoryModel \CustomScm\Model\Product\Category */
        $categoryModel = $this->import('model.scm.product.category');

        if (isset($where['filterCid']) && $where['filterCid'] != '') {
            if (is_array($where['filterCid'])) {
                if (count($where['filterCid']) > 0) {
                    $this->qb->groupStart();
                    foreach ($where['filterCid'] as $cid) {
                        $depth = $categoryModel->getDepth($cid);
                        $this->qb->orLike('b.display_cid', substr($cid, 0, 3 * ($depth + 1)), 'after');
                    }
                    $this->qb->groupEnd();
                }
            } else {
                $depth = $categoryModel->getDepth($where['filterCid']);
                $this->qb->like('b.display_cid', substr($where['filterCid'], 0, 3 * ($depth + 1)), 'after');
            }
        }
        if (isset($where['div_ix']) && $where['div_ix'] != '') {
            $this->qb->where('div.div_ix', $where['div_ix']);
        }
        if (isset($where['bp_ix']) && $where['bp_ix'] != '') {
            $this->qb->where('bp.bp_ix', $where['bp_ix']);
        }
        if (isset($where['dispInfo']) && $where['dispInfo'] != '') {
            $this->qb->where('b.disp', $where['dispInfo']);
        }
        if (isset($where['dispDiv']) && $where['dispDiv'] != '') {
            $this->qb->where('div.disp', $where['dispDiv']);
        }
        if (isset($where['dispPosition']) && $where['dispPosition'] != '') {
            $this->qb->where('bp.disp', $where['dispPosition']);
        }
        if (isset($where['agent_type']) && $where['agent_type'] != '') {
            $this->qb->where('b.agent_type', $where['agent_type']);
        }
        if (isset($where['startDate']) && $where['startDate'] && isset($where['endDate']) && $where['endDate']) {
            $this->qb->betweenDate($where['dateType'], $where['startDate'], $where['endDate']);
        }
        if (isset($where['filterText']) && $where['filterText']) {
            $this->qb->like('banner_name', $where['filterText']);
        }

        return $this->qb;
    }

    /**
     * 배너 삭제
     * @param $ix
     * @throws \Exception
     */
    public function del($ix)
    {
        $this->qb
            ->where('banner_ix', $ix)
            ->delete(TBL_SHOP_BANNERINFO)
            ->exec();
    }

    /**
     * 배너분류
     * @return array
     * @throws \Exception
     */
    public function getDivList()
    {
        return $this->qb
            ->select('div_ix')
            ->select('div_name')
            ->from(TBL_SHOP_BANNER_DIV)
            ->exec()
            ->getResultArray();
    }

    /**
     * 배너위치
     * @return array
     * @throws \Exception
     */
    public function getPositionList($divIx = '')
    {
        if ($divIx) {
            $this->qb->where('div_ix', $divIx);
        }

        return $this->qb
            ->select('bp_ix')
            ->select('bp_name')
            ->from(TBL_SHOP_BANNER_POSITION)
            ->exec()
            ->getResultArray();
    }

    /**
     * 통합배너 분류 리스트
     * @return array
     * @throws \Exception
     */
    public function getGoodsCategoryList()
    {
        $this->qb->startCache();
        $this->qb->select('div.div_ix')
            ->select('div.div_name')
            ->select('div.agent_type')
            ->select('div.disp')
            ->select('div.regdate')
            ->select('(SELECT count(*) FROM shop_bannerinfo WHERE banner_page = div.div_ix) AS div_cnt')
            ->from(TBL_SHOP_BANNER_DIV . ' as div');
        $this->qb->stopCache();

        $total = $this->qb->getCount();

        $list = $this->qb->exec()
            ->getResultArray();

        $this->qb->flushCache();

        //치환 처리
        foreach ($list as $key => $val) {
            //노출여부
            if (isset($val['disp'])) {
                if ($val['disp'] == '1') {
                    $val['disp_text'] = '사용';
                } else {
                    $val['disp_text'] = '사용하지않음';
                }
            }
            //노출여부
            if (isset($val['agent_type'])) {
                if ($val['agent_type'] == 'W') {
                    $val['agent_text'] = '웹';
                } else {
                    $val['agent_text'] = '모바일';
                }
            }

            $list[$key] = $val;
        }

        $this->data = [
            'total' => $total,
            'list' => $list
        ];
        $this->result = 'success';

        return $this->getResult();
    }

    /**
     * 통합배너 분류 등록/수정
     * @param $data
     * @return array
     * @throws \Exception
     */
    public function putGoodsCategory($data)
    {
        $allowedData = $this->qb->allowedFields($data, ['div_ix', 'div_name', 'dispDiv', 'agent_type'], ['div_ix' => '']);
        $allowedData['disp'] = $allowedData['dispDiv'];
        unset($allowedData['dispDiv']);

        if (!empty($allowedData['div_ix'])) {
            $this->data = $this->updateGoodsCategory($allowedData);
        } else {
            $this->data = $this->insertGoodsCategory($allowedData);
        }

        $this->result = 'success';

        return $this->getResult();
    }

    /**
     * 통합배너 분류 삭제
     * @param $data
     * @return array
     * @throws \Exception
     */
    public function delGoodsCategory($data)
    {
        $this->deleteGoodsCategory($data);
        $this->result = 'success';

        return $this->getResult();
    }

    /**
     * 통합배너 분류 insert(table)
     * @param $data
     * @return bool|\NunaResult
     * @throws \Exception
     */
    public function insertGoodsCategory($data)
    {
        return $this->qb
            ->set($data)
            ->set('regdate', date('Y-m-d H:i:s'))
            ->insert(TBL_SHOP_BANNER_DIV)
            ->exec();
    }

    /**
     * 통합배너 분류 update(table)
     * @param $data
     * @return bool|\NunaResult
     * @throws \Exception
     */
    public function updateGoodsCategory($data)
    {
        return $this->qb
            ->set($data)
            ->set('regdate', date('Y-m-d H:i:s'))
            ->where('div_ix', $data['div_ix'])
            ->update(TBL_SHOP_BANNER_DIV)
            ->exec();
    }

    /**
     * 통합배너 분류 delete(table)
     * @param $data
     * @return bool|\NunaResult
     * @throws \Exception
     */
    public function deleteGoodsCategory($data)
    {
        return $this->qb
            ->where('div_ix', $data['div_ix'])
            ->delete(TBL_SHOP_BANNER_DIV)
            ->exec();
    }

    /**
     * 통합배너 위치 리스트
     * @return array
     * @throws \Exception
     */
    public function getGoodsCategoryPositionList()
    {
        $this->qb->startCache();
        $this->qb
            ->select('bp.bp_ix')
            ->select('bp.div_ix')
            ->select('bp.bp_name')
            ->select('bp.disp')
            ->select('bp.vieworder')
            ->select('bp.regdate')
            ->select('(SELECT div_name FROM shop_banner_div WHERE div_ix = bp.div_ix) AS div_name')
            ->from(TBL_SHOP_BANNER_POSITION . ' as bp');
        $this->qb->stopCache();

        $total = $this->qb->getCount();

        $list = $this->qb->exec()
            ->getResultArray();

        $this->qb->flushCache();

        //치환 처리
        foreach ($list as $key => $val) {

            //노출여부
            if (isset($val['disp'])) {
                if ($val['disp'] == '1') {
                    $val['disp_text'] = '사용';
                } else {
                    $val['disp_text'] = '사용하지않음';
                }
            }

            $list[$key] = $val;
        }

        $this->data = [
            'total' => $total,
            'list' => $list
        ];
        $this->result = 'success';

        return $this->getResult();
    }

    /**
     * 통합배너 위치 등록/수정
     * @param $data
     * @return array
     * @throws \Exception
     */
    public function putGoodsCategoryPosition($data)
    {
        $allowedData = $this->qb->allowedFields($data, ['bp_ix', 'div_ix', 'bp_name', 'vieworder', 'dispPosition'], ['bp_ix' => '']);
        $allowedData['disp'] = $allowedData['dispPosition'];
        unset($allowedData['dispPosition']);

        if (!empty($allowedData['bp_ix'])) {
            $this->data = $this->updateGoodsCategoryPosition($allowedData);
        } else {
            $this->data = $this->insertGoodsCategoryPosition($allowedData);
        }

        $this->result = 'success';

        return $this->getResult();
    }

    /**
     * 통합배너 위치 삭제
     * @param $data
     * @return array
     * @throws \Exception
     */
    public function delGoodsCategoryPosition($data)
    {
        $this->deleteGoodsCategoryPosition($data);
        $this->result = 'success';

        return $this->getResult();
    }

    /**
     * 통합배너 위치관리 insert(table)
     * @param $data
     * @return bool|\NunaResult
     * @throws \Exception
     */
    public function insertGoodsCategoryPosition($data)
    {
        return $this->qb
            ->set($data)
            ->set('regdate', date('Y-m-d H:i:s'))
            ->insert(TBL_SHOP_BANNER_POSITION)
            ->exec();
    }

    /**
     * 통합배너 위치관리 update(table)
     * @param $data
     * @return bool|\NunaResult
     * @throws \Exception
     */
    public function updateGoodsCategoryPosition($data)
    {
        return $this->qb
            ->set($data)
            ->set('regdate', date('Y-m-d H:i:s'))
            ->where('bp_ix', $data['bp_ix'])
            ->update(TBL_SHOP_BANNER_POSITION)
            ->exec();
    }

    /**
     * 통합배너 위치관리 delete(table)
     * @param $data
     * @return bool|\NunaResult
     * @throws \Exception
     */
    public function deleteGoodsCategoryPosition($data)
    {
        return $this->qb
            ->where('bp_ix', $data['bp_ix'])
            ->delete(TBL_SHOP_BANNER_POSITION)
            ->exec();
    }

    /**
     * 통합배너 관리
     * @param $ix
     * @return mixed
     * @throws \Exception
     */
    public function getBannerList($ix)
    {
        $list = $this->qb
            ->select('b.display_cid')
            ->select('b.banner_name')
            ->select('b.banner_ix')
            ->select('b.disp')
            ->select('b.agent_type')
            ->select('b.banner_page')
            ->select('b.banner_position')
            ->select('b.banner_width')
            ->select('b.banner_height')
            ->select('b.banner_desc')
            ->select('use_sdate')
            ->select('use_edate')
            ->from(TBL_SHOP_BANNERINFO . ' AS b')
            ->where('b.banner_ix', $ix)
            ->exec()
            ->getRowArray();

        return $list;
    }

    /**
     * * set 통합배너 그룹
     * @param $ix
     * @return array
     * @throws \Exception
     */
    public function getGroupList($ix)
    {
        $list = $this->qb
            ->select('bd.bd_ix')
            ->select('bd.banner_ix')
            ->select('bd.bd_file')
            ->select('bd.bd_title')
            ->select('bd.bd_link')
            ->select('bd.vieworder')
            ->from(TBL_SHOP_BANNERINFO_DETAIL . ' AS bd')
            ->where('bd.banner_ix', $ix)
            ->orderBy('bd_ix', 'ASC')
            ->exec()
            ->getResultArray();

        foreach ($list as $k => $v) {
            //그룹 이미지
            $list[$k]['groupImageSrc'] = get_banner_images_src($v['banner_ix'], $v['bd_file']);
        }

        return $list;
    }

    /**
     * 통합배너 등록
     * @param $data
     * @param null $relProductGridData
     * @throws \Exception
     */
    public function addManageDisplay($data, $file, $groupData = null)
    {
        $bannerData = $this->qb->allowedFields($data, ['banner_page', 'banner_position', 'disp', 'cidList', 'banner_name', 'agent_type', 'use_sdate', 'use_edate', 'banner_width', 'banner_height', 'banner_desc']);
        $bannerData['display_cid'] = $bannerData['cidList'][0] ?? '';
        unset($bannerData['cidList']);
        $bannerData['regdate'] = date('Y-m-d H:i:s');
        $ix = $this->insertBanner($bannerData);

        //이미지 업로드
        if ($file) {
            $imageData = $this->imageUpload($ix, $file);
        }

        foreach ($groupData as $k => $v) {
            $groupListData = $this->qb->allowedFields($v, ['bd_title', 'bd_link', 'vieworder']);
            $groupListData['banner_ix'] = $ix;
            $groupListData['regdate'] = date('Y-m-d H:i:s');
            if (!empty($imageData) && $k + 1 == $v['group_code']) {
                $groupImage = 'groupImage' . $v['group_code'];
                $groupListData['bd_file'] = str_replace(' ','_',$imageData[$groupImage]['name'].$imageData[$groupImage]['extension']);
            }
            $this->insertGroup($groupListData);
        }

        return $ix;
    }

    /**
     * 이미지 업로드
     * @param type $ix
     * @param type $file
     */
    protected function imageUpload($ix, $file)
    {
        /* @var $uploadModel \CustomScm\Model\Util\Upload */
        $uploadModel = $this->import('model.scm.util.upload');

        foreach ($file as $key => $val) {
            if ($key && $val['size'] > 0) {
                $fileNameMd5 = md5($val['name']);
                $file[$key]['name'] = $fileNameMd5;
                $fileInfo = pathinfo($val['name']);
                $file[$key]['extension'] = $fileInfo['dirname'].$fileInfo['extension'];
                $uploadModel->bannerUpload($key, $ix, $fileNameMd5);
            }
        }

        return $file;
    }

    /**
     * 통합배너 분류 insert(table)
     * @param $data
     * @return bool|\NunaResult
     * @throws \Exception
     */
    protected function insertBanner($data)
    {
        return $this->qb
            ->set($data)
            ->insert(TBL_SHOP_BANNERINFO)
            ->exec();
    }

    /**
     * 통합배너 그룹 추가
     * @param $data
     * @throws \Exception
     */
    public function insertGroup($data)
    {
        $this->qb
            ->set($data)
            ->insert(TBL_SHOP_BANNERINFO_DETAIL)
            ->exec();
    }

    /**
     * 통합배너 수정
     * @param $data
     * @param null $relProductGridData
     * @throws \Exception
     */
    public function putManageDisplay($ix, $data, $file, $groupData = null)
    {
        $bannerData = $this->qb->allowedFields($data, ['banner_page', 'banner_type', 'banner_position', 'disp', 'cidList', 'banner_name', 'agent_type', 'use_sdate', 'use_edate', 'banner_width', 'banner_height', 'banner_desc']);
        $bannerData['display_cid'] = $bannerData['cidList'][0] ?? '';
        $bannerData['banner_kind'] = $bannerData['banner_kind'][0] ?? '5';
        unset($bannerData['cidList']);
        $bannerData['regdate'] = date('Y-m-d H:i:s');
        $this->updateBanner($ix, $bannerData); //상품그룹 수정

        //이미지 업로드
        if ($file) {
            $imageData = $this->imageUpload($ix, $file);

            foreach ($file as $key => $val) {
                $fileKey[] = substr($key, -1, 1);
            }
        }

        if ($groupData) {
            $groupListData['tmp_update'] = '0';
            $this->updateGroup($ix, $groupListData);
            foreach ($groupData as $k => $v) {
                $num = $k + 1;
                $groupListData = $this->qb->allowedFields($v, ['bd_ix']);
                $selData = $this->selectGroup($ix, $groupListData);
                $groupListData = $this->qb->allowedFields($v, ['bd_title', 'bd_link', 'vieworder']);
                $groupListData['tmp_update'] = '1';
                $groupListData['regdate'] = date('Y-m-d H:i:s');

                $groupImage = 'groupImage' . $num;
                if (isset($imageData[$groupImage])) {
                    $groupListData['bd_file'] = str_replace(' ', '_', $imageData[$groupImage]['name'] . $imageData[$groupImage]['extension']);
                }

                if (!empty($selData['bd_ix'])) {//존재하는지 체크
                    $groupListData['bd_ix'] = $selData['bd_ix'];
                    $this->updateGroup($ix, $groupListData);
                } else {
                    $groupListData['banner_ix'] = $ix;
                    $this->insertGroup($groupListData);
                }
            }
            $this->deleteGroup($ix);
        }
    }

    /**
     * 통합배너 수정 update(table)
     * @param $data
     * @return bool|\NunaResult
     * @throws \Exception
     */
    public function updateBanner($ix, $data)
    {
        $this->qb
            ->set($data)
            ->where('banner_ix', $ix)
            ->update(TBL_SHOP_BANNERINFO)
            ->exec();
    }

    /**
     * 통합배너 그룹 수정
     * @param $ix
     * @param $data
     * @throws \Exception
     */
    public function updateGroup($ix, $data)
    {
        if (!empty($data['bd_ix'])) {
            $this->qb
                ->where('bd_ix', $data['bd_ix']);
        }

        $this->qb
            ->set($data)
            ->update(TBL_SHOP_BANNERINFO_DETAIL)
            ->where('banner_ix', $ix)
            ->exec();
    }

    /**
     * 통합배너 그룹 검색
     * @param $ix
     * @return bool|\NunaResult
     * @throws \Exception
     */
    public function selectGroup($ix, $data)
    {
        return $this->qb
            ->select('bd_ix')
            ->from(TBL_SHOP_BANNERINFO_DETAIL)
            ->where('banner_ix', $ix)
            ->where($data)
            ->exec()
            ->getRowArray();
    }

    /**
     * 통합배너 그룹 삭제
     * @param $ix
     * @throws \Exception
     */
    public function deleteGroup($ix)
    {
        $this->qb
            ->where('banner_ix', $ix)
            ->where('tmp_update', '0')
            ->delete(TBL_SHOP_BANNERINFO_DETAIL)
            ->exec();
    }
}