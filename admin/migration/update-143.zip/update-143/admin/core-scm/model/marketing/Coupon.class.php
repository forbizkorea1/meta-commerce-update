<?php

namespace ForbizScm\Model\Marketing;

/**
 * 쿠폰 관련 모델
 *
 * @author hoksi
 */
class Coupon extends \ForbizModel
{

    /**
     * b2c config key
     * @var string
     */
    protected $configKey = 'b2c_coupon_rule';

    /**
     * 쿠폰 정책 정보
     * @var type
     */
    protected $config;

    /**
     * 쿠폰 종류
     * @var array
     */
    protected $couponDiv = [
        'G' => '상품쿠폰'
        ,'C' => '장바구니 쿠폰'
    ];

    /**
     * 쿠폰 사용 범위
     * @var array
     */
    protected $couponUseDiv = [
        'A' => '전체',
        'G' => 'PC',
        'M' => 'Mobile',
        'MA' => 'App'
    ];

    /**
     * 쿠폰 사용 여부
     * @var array
     */
    protected $isUse = [
        '1' => '사용',
        '0' => '사용(발급불가)',
        '3' => '사용불가'
    ];

    /**
     * 할인 설정
     * @var array
     */
    protected $couponSaleType = [
        '1' => '정률할인(%)',
        '2' => '정액할인(원)'
    ];

    /**
     * 할인 부담
     * @var array
     */
    protected $couponAcnt = [
        '1' => '본사',
        '2' => '본사 + 셀러'
    ];

    /**
     * 최소 상품 금액 설정
     * @var array
     */
    protected $publishMin = [
        'N' => '제한 없음',
        'Y' => '제한 있음'
    ];

    /**
     * 최대 할인 금액 설정
     * @var array
     */
    protected $publishMax = [
        'N' => '제한 없음',
        'Y' => '제한 있음'
    ];

    /**
     * 사용가능상품
     * @var array
     */
    protected $useProductType = [
        '1' => '전체',
        '4' => '브랜드',
        '2' => '카테고리',
        '5' => '셀러',
        '3' => '상품'
    ];

    /**
     * 쿠폰 발급 방식
     * @var array
     */
    protected $issueType = [
        '1' => '관리자 수동 발급',
        '4' => '특정 조건 자동 발급',
        '2' => '고객 다운로드',
        '5' => '오프라인 상품권 발급'
    ];

    /**
     * 쿠폰 발급 방식 - 특정 조건
     * @var array
     */
    protected $issueTypeDetail = [
        '1' => '회원가입 완료시',
        '2' => '회원그룹 변경 시',
        '3' => '생일',
        //'4' => 'APP 첫구매',
        '5' => 'APP 푸시 수신여부 동의'
        //'6' => '마케팅 수신여부 동의(SMS/이메일)'
    ];

    /**
     * 쿠폰 발급 방식 - 고객 다운로드
     * @var array
     */
    protected $issueTypeDetailDownload = [
        '1' => '상품 상세에 쿠폰 노출',
        '2' => '상품 상세에 쿠폰 미노출'
    ];

    /**
     * 쿠폰 발급 대상
     * @var array
     */
    protected $publishType = [
        '2' => '전체 회원',
        '4' => '회원 그룹'
//        ,'1' => '관리자 지정 회원'
    ];

    /**
     * 쿠폰 사용 기간
     * @var array
     */
    protected $useDateType = [
        '3' => '사용기간 지정',
        '1' => '발행일 기준',
        '2' => '발급일 기준',
        '9' => '제한 없음(무기한)'
    ];

    protected $dateType = [
        '3' => '일',
        '2' => '개월',
        '1' => '년'
    ];

    public function __construct()
    {
        parent::__construct();

        $this->config = \ForbizConfig::getSharedMemory($this->configKey);
    }

    /**
     * get 쿠폰 정책
     * @return type|mixed
     */
    public function getConfig()
    {
        return $this->config;
    }

    /**
     * set 쿠폰 정책
     * @param $data
     * @return bool
     */
    public function setConfig($data)
    {
        return \ForbizConfig::setSharedMemory($this->configKey, $data);
    }

    /**
     * get 쿠폰 종류
     * @param bool $couponDiv
     * @return array|bool
     */
    public function getCouponDiv($couponDiv = false)
    {
        if ($couponDiv === false) {
            return $this->couponDiv;
        } else {
            return $this->couponDiv[$couponDiv] ?? $couponDiv;
        }
    }

    /**
     * get 쿠폰 사용 범위
     * @param bool $couponUseDiv
     * @return array|bool|mixed
     */
    public function getCouponUseDiv($couponUseDiv = false)
    {
        if ($couponUseDiv === false) {
            return $this->couponUseDiv;
        } else {
            return $this->couponUseDiv[$couponUseDiv] ?? $couponUseDiv;
        }
    }

    /**
     * get 쿠폰 사용 여부
     * @param bool $isUse
     * @return bool
     */
    public function getIsUse($isUse = false)
    {
        if ($isUse === false) {
            return $this->isUse;
        } else {
            return $this->isUse[$isUse] ?? $isUse;
        }
    }

    /**
     * get 쿠폰 할인 설정
     * @param bool $couponSaleType
     * @return array|bool|mixed
     */
    public function getCouponSaleType($couponSaleType = false)
    {
        if ($couponSaleType === false) {
            return $this->couponSaleType;
        } else {
            return $this->couponSaleType[$couponSaleType] ?? $couponSaleType;
        }
    }

    /**
     * get 쿠폰 할인 부담
     * @param bool $couponAcnt
     * @return bool
     */
    public function getCouponAcnt($couponAcnt = false)
    {
        if ($couponAcnt === false) {
            return $this->couponAcnt;
        } else {
            return $this->couponAcnt[$couponAcnt] ?? $couponAcnt;
        }
    }

    /**
     * get 최소 상품 금액 설정
     * @param bool $publishMin
     * @return array|bool|mixed
     */
    public function getPublishMin($publishMin = false)
    {
        if ($publishMin === false) {
            return $this->publishMin;
        } else {
            return $this->publishMin[$publishMin] ?? $publishMin;
        }
    }

    /**
     * get 최대 상품 금액 설정
     * @param bool $publishMax
     * @return array|bool|mixed
     */
    public function getPublishMax($publishMax = false)
    {
        if ($publishMax === false) {
            return $this->publishMax;
        } else {
            return $this->publishMax[$publishMax] ?? $publishMax;
        }
    }

    /**
     * get 사용가능상품
     * @param bool $useProductType
     * @return array|bool|mixed
     */
    public function getUseProductType($useProductType = false)
    {
        if ($useProductType === false) {
            return $this->useProductType;
        } else {
            return $this->useProductType[$useProductType] ?? $useProductType;
        }
    }

    /**
     * get 쿠폰 발급 방식
     * @param bool $issueType
     * @return bool
     */
    public function getIssueType($issueType = false)
    {
        if ($issueType === false) {
            return $this->issueType;
        } else {
            return $this->issueType[$issueType] ?? $issueType;
        }
    }

    /**
     * get 특정 쿠폰 발급 방식
     * @param bool $issueTypeDetail
     * @return array|bool|mixed
     */
    public function getIssueTypeDetail($issueType = '4', $issueTypeDetail = false)
    {
        if ($issueType == '4') {
            if ($issueTypeDetail === false) {
                return $this->issueTypeDetail;
            } else {
                return $this->issueTypeDetail[$issueTypeDetail] ?? $issueTypeDetail;
            }
        } else {
            if ($issueTypeDetail === false) {
                return $this->issueTypeDetailDownload;
            } else {
                return $this->issueTypeDetailDownload[$issueTypeDetail] ?? $issueTypeDetail;
            }
        }
    }

    /**
     * get 쿠폰 발급 대상
     * @param bool $publishType
     * @return array|bool|mixed
     */
    public function getPublishType($publishType = false)
    {
        if ($publishType === false) {
            return $this->publishType;
        } else {
            return $this->publishType[$publishType] ?? $publishType;
        }
    }

    /**
     * get 쿠폰 사용 기간
     * @param bool $useDateType
     * @return bool
     */
    public function getUseDateType($useDateType = false)
    {
        if ($useDateType === false) {
            return $this->useDateType;
        } else {
            return $this->useDateType[$useDateType] ?? $useDateType;
        }
    }

    public function getDateType($dateType = false)
    {
        if ($dateType === false) {
            return $this->dateType;
        } else {
            return $this->dateType[$dateType] ?? $dateType;
        }
    }

    /**
     * 오프라인 쿠폰 발급 방식
     * @var array
     */
    protected $giftType = [
        'R' => '마일리지 지급 상품권',
        'C' => '쿠폰 지급 상품권(랜덤 시리얼 넘버)',
        'U' => '쿠폰 지급 상품권(동일 시리얼 넘버)'
    ];

    /**
     * 오프라인 쿠폰 발급 유형
     * @param bool $issueType
     * @return bool
     */
    public function getGiftType($giftType = false)
    {
        if ($giftType === false) {
            return $this->giftType;
        } else {
            return $this->giftType[$giftType] ?? $giftType;
        }
    }

    /**
     * get 쿠폰 정보
     * @param $publishIx
     * @return mixed
     */
    public function get($publishIx)
    {
        $row = $this->qb
            ->select('cp.publish_ix')
            ->select('cp.publish_name')
            ->select('cp.publish_desc')
            ->select('cp.is_use')
            ->select('cp.publish_min')
            ->select('cp.publish_max')
            ->select('cp.publish_condition_price')
            ->select('cp.publish_limit_price')
            ->select('cp.use_product_type')
            ->select('cp.issue_type')
            ->select('cp.issue_type_detail')
            ->select('cp.publish_type')
            ->select('cp.use_date_type')
            ->select('cp.use_sdate')
            ->select('cp.use_edate')
            ->select('cp.publish_date_differ')
            ->select('cp.publish_date_type')
            ->select('cp.regist_date_differ')
            ->select('cp.regist_date_type')
            ->select('cp.cupon_use_sdate')
            ->select('cp.cupon_use_edate')
            ->select('cp.regdate')
            ->select('c.cupon_div')
            ->select('c.cupon_use_div')
            ->select('c.cupon_sale_type')
            ->select('c.cupon_acnt')
            ->select('c.haddoffice_rate')
            ->select('c.seller_rate')
            ->select('c.cupon_sale_value')
            ->select('c.round_position')
            ->select('c.round_type')
            ->from(TBL_SHOP_CUPON_PUBLISH . ' AS cp')
            ->join(TBL_SHOP_CUPON . ' AS c', 'c.cupon_ix=cp.cupon_ix')
            ->where('cp.publish_ix', $publishIx)
            ->exec()
            ->getRowArray();

        if ($this->qb->total) {
            $row['cupon_use_sdate'] = date('Y-m-d H:i:s', $row['cupon_use_sdate']);
            $row['cupon_use_edate'] = date('Y-m-d H:i:s', $row['cupon_use_edate']);
        }

        return $row;
    }

    /**
     * 쿠폰 리스트
     * @param int $page
     * @param int $max
     * @param array $where
     * @return array
     */
    public function getList($page = 1, $max = 5, $where = [])
    {
        $this->qb->startCache();

        if (isset($where['searchType']) && !empty($where['searchType']) && isset($where['searchText']) && !empty($where['searchText'])) {
            $this->qb->like($where['searchType'], trim($where['searchText']));
        }

        if (isset($where['startDate']) && !empty($where['startDate']) && isset($where['endDate']) && !empty($where['endDate'])) {
            $this->qb->betweenDate('cp.regdate', $where['startDate'], $where['endDate']);
        }

        if (isset($where['cupon_div']) && !empty($where['cupon_div'])) {
            $this->qb->whereIn('c.cupon_div', $where['cupon_div']);
        }

        if (isset($where['cupon_use_div']) && !empty($where['cupon_use_div'])) {
            $this->qb->whereIn('c.cupon_use_div', $where['cupon_use_div']);
        }

        if (isset($where['cupon_sale_type']) && !empty($where['cupon_sale_type'])) {
            $this->qb->whereIn('c.cupon_sale_type', $where['cupon_sale_type']);
        }

        if (isset($where['issue_type']) && !empty($where['issue_type'])) {
            $this->qb->whereIn('cp.issue_type', $where['issue_type']);
        }

        if (isset($where['publish_type']) && !empty($where['publish_type'])) {
            $this->qb->whereIn('cp.publish_type', $where['publish_type']);
        }

        if (isset($where['is_use']) && !empty($where['is_use'])) {
            $this->qb->whereIn('cp.is_use', $where['is_use']);
        }

        if (isset($where['isUsableCoupon']) && $where['isUsableCoupon'] == 'Y') {
            $this->qb
                ->groupStart()
                ->orGroupStart()
                ->where('cp.use_date_type', '9')//무기한
                ->groupEnd()
                ->orGroupStart()
                ->where('cp.use_date_type', '3')//사용기간 지정
                ->where('cp.use_sdate <=', date('Y-m-d H:i:s'))
                ->where('cp.use_edate >=', date('Y-m-d H:i:s'))
                ->groupEnd()
                ->orGroupStart()
                ->where('cp.use_date_type', '2')//발급일 기준
                ->groupEnd()
                ->orGroupStart()
                ->where('cp.use_date_type', '1')//발행일 기준
                ->where('cp.regdate <=', date('Y-m-d H:i:s'))
                ->where('case when publish_date_type = "1" then date_add(cp.regdate, INTERVAL cp.publish_date_differ YEAR )
                            when publish_date_type = "2" then date_add(cp.regdate, INTERVAL cp.publish_date_differ MONTH )
                            when publish_date_type = "3" then date_add(cp.regdate, INTERVAL cp.publish_date_differ DAY)
                            end >=', date('Y-m-d H:i:s'))
                ->groupEnd()
                ->groupEnd();
        }

        $this->qb
            ->from(TBL_SHOP_CUPON_PUBLISH . ' AS cp')
            ->join(TBL_SHOP_CUPON . ' AS c', 'c.cupon_ix=cp.cupon_ix');

        $this->qb->stopCache();

        $total = $this->qb->getCount();

        $paging = $this->qb->setTotalRows($total)->pagination($page, $max);

        $rows = $this->qb
            ->select('cp.publish_ix')
            ->select('cp.publish_name')
            ->select('cp.cupon_no')
            ->select('cp.publish_desc')
            ->select('cp.is_use')
            ->select('cp.issue_type')
            ->select('cp.publish_type')
            ->select('cp.use_date_type')
            ->select('cp.use_sdate')
            ->select('cp.use_edate')
            ->select('cp.publish_date_differ')
            ->select('cp.publish_date_type')
            ->select('cp.regist_date_differ')
            ->select('cp.regist_date_type')
            ->select('cp.cupon_use_sdate')
            ->select('cp.cupon_use_edate')
            ->select('c.cupon_use_div')
            ->select('c.cupon_sale_type')
            ->select('c.cupon_acnt')
            ->select('c.cupon_sale_value')
            ->select('c.cupon_sale_value')
            ->select($this->qb->startSubQuery('registCount')
                ->select('COUNT(*)')
                ->from(TBL_SHOP_CUPON_REGIST . ' AS cr')
                ->where('cr.publish_ix', 'cp.publish_ix', false)
                ->endSubQuery(), false)
            ->limit($max, ($paging['offset'] ?? 0))
            ->orderBy('cp.regdate', 'DESC')
            ->exec()
            ->getResultArray();

        $this->qb->flushCache();

        //치환 처리
        foreach ($rows as $key => $val) {
            // 발행일 날짜 타입
            $val['publishDateTypeText'] = $this->getDateType($val['publish_date_type']);
            // 발급일 날짜 타입
            $val['registDateTypeText'] = $this->getDateType($val['regist_date_type']);
            // 사용여부
            $val['isUseText'] = $this->getIsUse($val['is_use']);
            // 사용범위
            $val['couponUseDivText'] = $this->getCouponUseDiv($val['cupon_use_div']);
            // 발급 방식
            $val['issueTypeText'] = $this->getIssueType($val['issue_type']);
            // 발급 대상
            $val['publishTypeText'] = $this->getPublishType($val['publish_type']);
            // 할인 타입
            $val['couponSaleTypeText'] = $this->getCouponSaleType($val['cupon_sale_type']);
            // 할인 부담
            $val['couponAcntText'] = $this->getCouponAcnt($val['cupon_acnt']);
            // 발급 기간
            $val['cupon_use_sdate'] = date('Y-m-d H:i:s', $val['cupon_use_sdate']);
            $val['cupon_use_edate'] = date('Y-m-d H:i:s', $val['cupon_use_edate']);

            $rows[$key] = $val;
        }

        return [
            'total' => $total,
            'list' => $rows,
            'paging' => $paging
        ];
    }

    /**
     * get 오프라인 쿠폰 정보
     * @param $publishIx
     * @return mixed
     */
    public function getOffline($gc_ix)
    {
        $row = $this->qb
            ->select('gc.gc_ix')
            ->select('gc.gift_certificate_name')
            ->select('gc.memo')
            ->select('gc.gift_type')
            ->select('gc.gift_way')
            ->select('gc.gift_prefix_code')
            ->select('gc.create_cnt')
            ->select('gc.gift_amount')
            ->select('gc.gift_start_date')
            ->select('gc.gift_end_date')
            ->from(TBL_SHOP_GIFT_CERTIFICATE . ' AS gc')
            ->where('gc.gc_ix', $gc_ix)
            ->exec()
            ->getRowArray();

        return $row;
    }

    /**
     * 오프라인 쿠폰 리스트
     * @param int $page
     * @param int $max
     * @param array $where
     * @return array
     */
    public function getListOffline($page = 1, $max = 5, $where = [])
    {
        $this->qb->startCache();

        if (isset($where['gift_change_state']) && !empty($where['gift_change_state'])) {
            $this->qb->where('gc.gift_change_state', $where['gift_change_state']);
        }

        if (isset($where['gift_type']) && !empty($where['gift_type'])) {
            if ($where['gift_type'] != 'on') {
                $this->qb->where('gc.gift_type', $where['gift_type']);
            }
        }

        if (isset($where['searchText']) && !empty($where['searchText'])) {
            if (isset($where['searchType']) && !empty($where['searchType'])) {
                $this->qb->like($where['searchType'], $where['searchText']);
            } else {
                $this->qb->like($where['searchType'], $where['searchText']);
            }
        }

        if (isset($where['gift_start_date']) && !empty($where['gift_start_date']) && isset($where['gift_end_date']) && !empty($where['gift_end_date'])) {
            $this->qb->where("gc.gift_start_date >= '" . $where['gift_start_date'] . "' and gc.gift_end_date <= '" . $where['gift_end_date'] . "'");
        }

        if (isset($where['startDate']) && !empty($where['startDate']) && isset($where['endDate']) && !empty($where['endDate'])) {
            $this->qb->where("gc.regdate between '" . $where['startDate'] . " 00:00:00' and '" . $where['endDate'] . " 23:59:59'");
        }

        $this->qb
            ->select()
            ->from(TBL_SHOP_GIFT_CERTIFICATE . ' AS gc')
            ->join(TBL_COMMON_MEMBER_DETAIL . ' AS m', 'gc.reg_mem_ix = m.code', 'left')
            ->where('gc.gc_ix <> 0');

        $this->qb->stopCache();

        $total = $this->qb->getCount();

        $paging = $this->qb->setTotalRows($total)->pagination($page, $max);

        $rows = $this->qb
            ->select('gc.*')
            ->select('m.code')
            ->select('IFNULL(m.name, "-") as name')
            ->limit($max, ($paging['offset'] ?? 0))
            ->orderBy('gc_ix', 'DESC')
            ->exec()
            ->getResultArray();

        $this->qb->flushCache();

        //치환 처리
        foreach ($rows as $key => $val) {
            // 발급 방식
            if ($this->getIssueType($val['gift_type']) == 'R') {
                $val['gift_type_text'] = '마일리지 지급 상품권';
            } else {
                if ($this->getIssueType($val['gift_type']) == 'C') {
                    $val['gift_type_text'] = '쿠폰 지급 상품권(랜덤 시리얼 넘버)';
                } else {
                    if ($this->getIssueType($val['gift_type']) == 'U') {
                        $val['gift_type_text'] = '쿠폰 지급 상품권(동일 시리얼 넘버)';
                    }
                }
            }

            if ($this->getIssueType($val['gift_type']) == 'U') {
                $val['create_cnt'] = '무제한';
            }

            $use_cnt = $this->qb
                ->select('count(*) as use_cnt')
                ->from(TBL_SHOP_GIFT_CERTIFICATE_DETAIL)
                ->where('gc_ix', $val['gc_ix'])
                ->where('gift_change_state', '1')
                ->exec()
                ->getRowArray();
            $val['use_cnt'] = $use_cnt['use_cnt'];

            $rows[$key] = $val;
        }

        return [
            'total' => $total,
            'list' => $rows,
            'paging' => $paging
        ];
    }

    /**
     * 쿠폰 발급 리스트
     * @param int $page
     * @param int $max
     * @param array $where
     * @return array
     */
    public function getRegistList($page = 1, $max = 5, $where = [])
    {
        $this->qb->startCache();

        $this->qb->whereIn('cr.publish_ix', $where['publish_ix']);

        // 검색 조건
        if (isset($where['searchType']) && $where['searchType'] && isset($where['searchText']) && $where['searchText']) {
            if (in_array($where['searchType'], ['name', 'mail', 'pcs'])) {
                $this->qb->like($this->qb->decrypt($where['searchType']), $where['searchText']);
            } else {
                $this->qb->like($where['searchType'], $where['searchText']);
            }
        }

        //회원 그룹
        if (isset($where['gp_ix']) && !empty($where['gp_ix'])) {
            $this->qb->whereIn('cmd.gp_ix', $where['gp_ix']);
        }

        $this->qb
            ->from(TBL_SHOP_CUPON_REGIST . ' AS cr')
            ->join(TBL_SHOP_CUPON_PUBLISH.' AS cp','cp.publish_ix = cr.publish_ix')
            ->join(TBL_COMMON_USER . ' AS cu', 'cu.code=cr.mem_ix')
            ->join(TBL_COMMON_MEMBER_DETAIL . ' as cmd', 'cu.code=cmd.code');
        $this->qb->stopCache();

        $total = $this->qb->getCount();
        $paging = $this->qb
            ->setTotalRows($total)
            ->pagination($page, $max);

        $offset = ($paging['offset'] ?? 0);

        $rows = $this->qb
            ->select('cu.code')
            ->select('cu.id')
            ->select('cp.use_date_type')
            ->decryptSelect('cmd.name')
            ->select('cr.regist_ix')
            ->select('cr.use_sdate')
            ->select("IFNULL(cr.use_date_limit, '9999-12-31') use_date_limit", false)
            ->select('cr.use_yn')
            ->select('cr.regdate')
            ->orderBy('cr.regdate', 'DESC')
            ->limit($max, $offset)
            ->exec()
            ->getResultArray();

        $this->qb->flushCache();

        //치환 처리
        foreach ($rows as $key => $val) {

            $rows[$key] = $val;
        }

        return [
            'total' => $total,
            'list' => $rows,
            'paging' => $paging
        ];
    }

    /**
     * get 적용 브랜드 리스트
     * @param $publishIx
     * @return array
     */
    public function getRelationBrand($publishIx)
    {
        $rows = $this->qb
            ->select('b_ix')
            ->from(TBL_SHOP_CUPON_RELATION_BRAND)
            ->where('publish_ix', $publishIx)
            ->exec()
            ->getResultArray();

        $bIxs = array_column($rows, 'b_ix');

        if (count($bIxs) > 0) {
            /* @var $brandModel \CustomScm\Model\Product\Brand */
            $brandModel = $this->import('model.scm.product.brand');
            return $brandModel->getList(1, 9999, ['b_ix' => $bIxs])['list'];
        } else {
            return [];
        }
    }

    /**
     * get 적용 카테고리 리스트
     * @param $publishIx
     * @return array
     */
    public function getRelationCategory($publishIx)
    {
        $rows = $this->qb
            ->select('cid')
            ->from(TBL_SHOP_CUPON_RELATION_CATEGORY)
            ->where('publish_ix', $publishIx)
            ->exec()
            ->getResultArray();

        $cids = array_column($rows, 'cid');

        if (count($cids) > 0) {
            /* @var $categoryModel \CustomScm\Model\Product\Category */
            $categoryModel = $this->import('model.scm.product.category');
            return $categoryModel->getListByCid($cids);
        } else {
            return [];
        }
    }

    /**
     * get 적용 업체 리스트
     * @param $publishIx
     * @return array
     */
    public function getRelationCompany($publishIx)
    {
        $rows = $this->qb
            ->select('company_id')
            ->from(TBL_SHOP_CUPON_RELATION_SELLER)
            ->where('publish_ix', $publishIx)
            ->exec()
            ->getResultArray();

        $companyIds = array_column($rows, 'company_id');

        if (count($companyIds) > 0) {
            /* @var $companyModel \CustomScm\Model\Company\Company */
            $companyModel = $this->import('model.scm.company.company');
            return $companyModel->getListSeller(1, 9999, ['company_id' => $companyIds])['list'];
        } else {
            return [];
        }
    }

    /**
     * get 적용 상품 리스트
     * @param $publishIx
     * @return array
     */
    public function getRelationProduct($publishIx)
    {
        $rows = $this->qb
            ->select('pid')
            ->from(TBL_SHOP_CUPON_RELATION_PRODUCT)
            ->where('publish_ix', $publishIx)
            ->exec()
            ->getResultArray();

        $pIds = array_column($rows, 'pid');

        if (count($pIds) > 0) {
            /* @var $choiceProductModel \CustomScm\Model\Util\ChoiceProduct */
            $choiceProductModel = $this->import('model.scm.util.choiceProduct');
            return $choiceProductModel->getList($pIds);
        } else {
            return [];
        }
    }

    /**
     * get 적용 상품 리스트
     * @param $publishIx
     * @return array
     */
    public function getTargetGroup($publishIx)
    {
        return $this->getPublishConfig('4', $publishIx);
    }

    /**
     * get 발행 설정
     * @param $publishType
     * @return array
     */
    protected function getPublishConfig($publishType, $publishIx)
    {
        $rows = $this->qb
            ->select('r_ix')
            ->from(TBL_SHOP_CUPON_PUBLISH_CONFIG)
            ->where('publish_ix', $publishIx)
            ->where('publish_type', $publishType)
            ->orderBy('vieworder')
            ->exec()
            ->getResultArray();

        return array_column($rows, 'r_ix');
    }

    /**
     * 발행 등록
     * @param $couponData
     * @return bool|\NunaResult
     */
    public function addPublish($couponData)
    {
        $couponData['seller_rate'] = (!empty($couponData['seller_rate']) ? $couponData['seller_rate'] : 0);
        $couponData['cupon_sale_value'] = $couponData['haddoffice_rate'] + $couponData['seller_rate'];
        $couponData['cupon_use_sdate'] = strtotime($couponData['cupon_use_sdate']);
        $couponData['cupon_use_edate'] = strtotime($couponData['cupon_use_edate']);
        if ($couponData['issue_type'] == '2') {
            $couponData['issue_type_detail'] = $couponData['issue_type_detail_download'];
        }
        $publishIx = $this->insertCouponPublish($couponData);

        if ($couponData['use_product_type'] == '4') {//브랜드
            $this->insertCouponRelationBrand($publishIx, json_decode($couponData['relationBrandList'], true));
        } elseif ($couponData['use_product_type'] == '2') {//카테고리
            $this->insertCouponRelationCategory($publishIx, json_decode($couponData['relationCategoryList'], true));
        } elseif ($couponData['use_product_type'] == '5') {//업체
            $this->insertCouponRelationCompany($publishIx,
                json_decode($couponData['relationCompanyList'], true));
        } elseif ($couponData['use_product_type'] == '3') {//상품
            $this->insertCouponRelationProduct($publishIx,
                json_decode($couponData['relationProductList'], true));
        }

        if ($couponData['publish_type'] == '4') { //회원 그룹별
            $this->insertCouponTargetPublishConfig($publishIx, $couponData['publish_type'], $couponData['gp_ix']);
        }

        return $publishIx;
    }

    /**
     *
     * @param $couponData
     * @return bool|\NunaResult
     */
    /**
     * 발행 수정
     * @param $publishIx
     * @param $couponData
     */
    public function putPublish($publishIx, $couponData)
    {
        $couponData['cupon_use_sdate'] = strtotime($couponData['cupon_use_sdate']);
        $couponData['cupon_use_edate'] = strtotime($couponData['cupon_use_edate']);
        $this->updateCouponPublish($publishIx, $couponData);

        $cData = $this->get($publishIx);

        if ($cData['use_product_type'] == '4') {//브랜드
            $this->updateCouponRelationBrand($publishIx, json_decode($couponData['relationBrandList'], true));
        } else {
            if ($cData['use_product_type'] == '2') {//카테고리
                $this->updateCouponRelationCategory($publishIx, json_decode($couponData['relationCategoryList'], true));
            } else {
                if ($cData['use_product_type'] == '5') {//업체
                    $this->updateCouponRelationCompany($publishIx,
                        json_decode($couponData['relationCompanyList'], true));
                } else {
                    if ($cData['use_product_type'] == '3') {//상품
                        $this->updateCouponRelationProduct($publishIx,
                            json_decode($couponData['relationProductList'], true));
                    }
                }
            }
        }

        if ($cData['publish_type'] == '4') { //회원 그룹별
            $this->updateCouponTargetPublishConfig($publishIx, $cData['publish_type'], $couponData['gp_ix']);
        }
    }

    /**
     * 발행 삭제
     * @param $publishIx
     */
    public function delPublish($publishIx)
    {
        $row = $this->qb
            ->select('cupon_ix')
            ->from(TBL_SHOP_CUPON_PUBLISH)
            ->where('publish_ix', $publishIx)
            ->exec()
            ->getRowArray();

        $cuponIx = $row['cupon_ix'];

        $this->qb->delete(TBL_SHOP_CUPON)->where('cupon_ix', $cuponIx)->exec();
        $this->qb->delete(TBL_SHOP_CUPON_PUBLISH)->where('publish_ix', $publishIx)->exec();
        $this->qb->delete(TBL_SHOP_CUPON_PUBLISH_CONFIG)->where('publish_ix', $publishIx)->exec();
        $this->qb->delete(TBL_SHOP_CUPON_REGIST)->where('publish_ix', $publishIx)->exec();
        $this->qb->delete(TBL_SHOP_CUPON_RELATION_BRAND)->where('publish_ix', $publishIx)->exec();
        $this->qb->delete(TBL_SHOP_CUPON_RELATION_CATEGORY)->where('publish_ix', $publishIx)->exec();
        $this->qb->delete(TBL_SHOP_CUPON_RELATION_PRODUCT)->where('publish_ix', $publishIx)->exec();
        $this->qb->delete(TBL_SHOP_CUPON_RELATION_SELLER)->where('publish_ix', $publishIx)->exec();
    }

    /**
     * 쿠폰지급
     * @param $publishIx
     * @param $userCode
     * @param bool $duplicate
     * @param bool $userGroupIx
     * @return bool
     */
    public function giveCoupon($publishIx, $userCode, $duplicate = false, $userGroupIx = false)
    {
        if ($userGroupIx === false) {
            $userGroupIx = $this->getUserGroupIx($userCode);
        }

        if ($this->isGroupUseCouponYn($userGroupIx) && !$this->checkPublished($publishIx, $userCode, $duplicate)) {

            $data = $this->get($publishIx);

            if ($data['use_date_type'] == 9) { //무제한
                $use_date_limit = null;
                $use_sdate = date('Y-m-d H:i:s');
            } else {
                if ($data['use_date_type'] == 1) { //발행일 기준

                    //밣행일
                    $publishedDate = $data['regdate'];

                    if ($data['publish_date_type'] == 1) {
                        $use_date_limit = date('Y-m-d H:i:s', strtotime($publishedDate.'+' . $data['publish_date_differ'] . ' years'));
                    } else {
                        if ($data['publish_date_type'] == 2) {
                            $use_date_limit = date('Y-m-d H:i:s',
                                strtotime($publishedDate.'+' . $data['publish_date_differ'] . ' months'));
                        } else {
                            if ($data['publish_date_type'] == 3) {
                                $use_date_limit = date('Y-m-d H:i:s',
                                    strtotime($publishedDate.'+' . $data['publish_date_differ'] . ' days'));
                            }
                        }
                    }
                    $use_sdate = $data['regdate'];
                    $use_date_limit = date('Y-m-d 23:59:59',strtotime($use_date_limit));

                } else {
                    if ($data['use_date_type'] == 2) {//발급일 기준
                        if ($data['regist_date_type'] == 1) {
                            $use_date_limit = date('Y-m-d H:i:s',
                                strtotime('+' . $data['regist_date_differ'] . ' years'));
                        } else {
                            if ($data['regist_date_type'] == 2) {
                                $use_date_limit = date('Y-m-d H:i:s',
                                    strtotime('+' . $data['regist_date_differ'] . ' months'));
                            } else {
                                if ($data['regist_date_type'] == 3) {
                                    $use_date_limit = date('Y-m-d H:i:s',
                                        strtotime('+' . $data['regist_date_differ'] . ' days'));
                                }
                            }
                        }
                        $use_sdate = date('Y-m-d H:i:s');
                    } else {
                        if ($data['use_date_type'] == 3) {//사용기간 지정
                            $use_date_limit = $data['use_edate'];
                            $use_sdate = $data['use_sdate'];
                        } else {
                            return false;
                        }
                    }
                }
            }

            $this->qb->insert(TBL_SHOP_CUPON_REGIST, [
                'publish_ix' => $publishIx,
                'mem_ix' => $userCode,
                'open_yn' => 0,
                'use_yn' => 0,
                'use_sdate' => $use_sdate,
                'use_date_limit' => $use_date_limit,
                'regdate' => date('Y-m-d H:i:s')
            ])->exec();
            return true;
        } else {
            return false;
        }
    }

    /**
     * 발급 취소
     * @param $registIx
     * @param $userCode
     */
    public function cancelGiveCoupon($registIx)
    {
        $this->qb
            ->delete(TBL_SHOP_CUPON_REGIST)
            ->where('regist_ix', $registIx)
            ->exec();
    }

    /**
     * 특정 조건 쿠폰 발급
     * @param type $issueTypeDetail 1:회원가입 완료시, 2:회원그룹 변경 시, 3:기념일(생일) 시, 4:APP 첫구매, 5:APP 푸시 수신여부 동의, 6:마케팅 수신여부 동의(SMS/이메일)
     */
    public function preferredConditionGiveCoupon($issueTypeDetail, $userCode, $duplicate = false, $userGroupIx = false)
    {
        if ($userGroupIx === false) {
            $userGroupIx = $this->getUserGroupIx($userCode);
        }

        if ($this->isGroupUseCouponYn($userGroupIx)) {
            $rows = $this->setBasicQuery($userCode, $userGroupIx)
                ->where('cp.issue_type_detail', $issueTypeDetail)
                ->where('cp.issue_type', '4')
                ->exec()
                ->getResultArray();

            if (!empty($rows)) {
                foreach ($rows as $row) {
                    $this->giveCoupon($row['publish_ix'], $userCode, $duplicate, $userGroupIx);
                }
            }
        }
    }

    /**
     * get user group ix
     * @param $userCode
     * @return mixed
     */
    protected function getUserGroupIx($userCode)
    {
        $row = $this->qb
            ->select('gp_ix')
            ->from(TBL_COMMON_MEMBER_DETAIL)
            ->where('code', $userCode)
            ->exec()
            ->getRow();
        return $row->gp_ix;
    }

    /**
     * 그룹 쿠폰 사용 가능 여부
     * @param $userGroupIx
     */
    protected function isGroupUseCouponYn($userGroupIx)
    {
        static $data = [];

        if (!isset($data[$userGroupIx])) {
            $total = $this->qb
                ->from(TBL_SHOP_GROUPINFO)
                ->where('gp_ix', $userGroupIx)
                ->where('use_coupon_yn', 'Y')
                ->where('is_delete','0')
                ->getCount();
            $data[$userGroupIx] = ($total > 0 ? true : false);
        }

        return $data[$userGroupIx];
    }

    /**
     * 쿠폰 리스트 호출의 기본 sql문 세팅
     * @return type
     */
    protected function setBasicQuery($userCode, $userGroupIx)
    {
        return $this->qb
            ->select('cp.publish_ix')
            ->from(TBL_SHOP_CUPON . ' as c')
            ->join(TBL_SHOP_CUPON_PUBLISH . ' as cp', 'on c.cupon_ix=cp.cupon_ix', 'inner')
            ->join(TBL_SHOP_CUPON_PUBLISH_CONFIG . ' as cpc ', 'cp.publish_ix=cpc.publish_ix', 'left')
            ->whereIn('c.mall_ix', ['', MALL_IX])
//            ->whereIn('c.cupon_use_div', ['A', $this->agentType])
            ->where('cp.is_use', '1')
//            ->where('cp.disp', '1')
            ->where('cp.cupon_use_sdate <=', time())//노출기간
            ->where('cp.cupon_use_edate >=', time())//노출기간
            //사용기간 조건
            /*->groupStart()
            ->orGroupStart()
            ->where('cp.use_date_type', '9')//무기한
            ->groupEnd()
            ->orGroupStart()
            ->where('cp.use_date_type', '3')//사용기간 지정
            ->where('cp.use_sdate <=', date('Y-m-d H:i:s'))
            ->where('cp.use_edate >=', date('Y-m-d H:i:s'))
            ->groupEnd()
            ->orGroupStart()
            ->where('cp.use_date_type', '2')//발급일 기준
            ->groupEnd()
            ->orGroupStart()
            ->where('cp.use_date_type', '1')//발행일 기준
            ->where('cp.regdate <=', date('Y-m-d H:i:s'))
            ->where('case when publish_date_type = "1" then date_add(cp.regdate, INTERVAL cp.publish_date_differ YEAR )
                            when publish_date_type = "2" then date_add(cp.regdate, INTERVAL cp.publish_date_differ MONTH )
                            when publish_date_type = "3" then date_add(cp.regdate, INTERVAL cp.publish_date_differ DAY)
                            end >=', date('Y-m-d H:i:s'))
            ->groupEnd()
            ->groupEnd()*/
            //사용기간 조건
            //발급대상회원 조건
            ->groupStart()
            ->orGroupStart()
            ->where('cp.publish_type', '2')//전체회원
            ->groupEnd()
            ->orGroupStart()
            ->where('cp.publish_type', '1')//관리자 지정 회원
            ->where('cpc.r_ix', $userCode)
            ->groupEnd()
            ->orGroupStart()
            ->where('cp.publish_type', '4')//관리자 지정 그룹
            ->where('cpc.r_ix', $userGroupIx)
            ->groupEnd()
            ->groupEnd();
        //발급대상회원 조건
    }

    /**
     * 쿠폰이 이미 등록된 상태인지 확인
     * @param $publishIx
     * @param $userCode
     * @param $duplicate
     * @return bool
     * @throws \Exception
     */
    protected function checkPublished($publishIx, $userCode, $duplicate)
    {
        if ($duplicate === false) {
            $count = $this->qb->select('regist_ix')
                ->from(TBL_SHOP_CUPON_REGIST)
                ->where('publish_ix', $publishIx)
                ->where('mem_ix', $userCode)
                ->limit(1)
                ->getCount();
            if ($count > 0) {
                return true;
            } else {
                return false;
            }
        } else {
            return false;
        }
    }

    /**
     * 발급 대상
     * @param $publishIx
     * @param $publishType
     * @param $datas
     */
    protected function updateCouponTargetPublishConfig($publishIx, $publishType, $datas)
    {
        if (is_array($datas)) {
            //포함 안된 데이터 삭제
            $this->qb
                ->delete(TBL_SHOP_CUPON_PUBLISH_CONFIG)
                ->where('publish_ix', $publishIx)
                ->where('publish_type', $publishType)
                ->whereNotIn('r_ix', $datas)
                ->exec();

            //get 디비에 저장된 데이터
            $rows = $this->qb
                ->select('r_ix')
                ->from(TBL_SHOP_CUPON_PUBLISH_CONFIG)
                ->where('publish_ix', $publishIx)
                ->where('publish_type', $publishType)
                ->whereIn('r_ix', $datas)
                ->exec()
                ->getResultArray();

            $datasDB = array_column($rows, 'r_ix');

            //DB에 있고 insert 해야할 컬람만 추출
            $_datas = array_diff($datas, $datasDB);

            $this->insertCouponTargetPublishConfig($publishIx, $publishType, $_datas);
        }
    }

    /**
     * 할인 적용가능상품 - 상품
     * @param $publishIx
     * @param $pids
     */
    protected function updateCouponRelationProduct($publishIx, $pids)
    {
        if (is_array($pids)) {
            //포함 안된 데이터 삭제
            $this->qb
                ->delete(TBL_SHOP_CUPON_RELATION_PRODUCT)
                ->where('publish_ix', $publishIx)
                ->whereNotIn('pid', $pids)
                ->exec();

            //get 디비에 저장된 데이터
            $rows = $this->qb
                ->select('pid')
                ->from(TBL_SHOP_CUPON_RELATION_PRODUCT)
                ->where('publish_ix', $publishIx)
                ->whereIn('pid', $pids)
                ->exec()
                ->getResultArray();

            $pidsDB = array_column($rows, 'pid');

            //DB에 있고 insert 해야할 컬람만 추출
            $_pids = array_diff($pids, $pidsDB);

            $this->insertCouponRelationProduct($publishIx, $_pids);
        }
    }

    /**
     * 할인 적용가능상품 - 업체
     * @param $publishIx
     * @param $companyIds
     */
    protected function updateCouponRelationCompany($publishIx, $companyIds)
    {
        if (is_array($companyIds)) {
            //포함 안된 데이터 삭제
            $this->qb
                ->delete(TBL_SHOP_CUPON_RELATION_SELLER)
                ->where('publish_ix', $publishIx)
                ->whereNotIn('company_id', $companyIds)
                ->exec();

            //get 디비에 저장된 데이터
            $rows = $this->qb
                ->select('company_id')
                ->from(TBL_SHOP_CUPON_RELATION_SELLER)
                ->where('publish_ix', $publishIx)
                ->whereIn('company_id', $companyIds)
                ->exec()
                ->getResultArray();

            $companyIdsDB = array_column($rows, 'company_id');

            //DB에 있고 insert 해야할 컬람만 추출
            $_companyIds = array_diff($companyIds, $companyIdsDB);

            $this->insertCouponRelationCompany($publishIx, $_companyIds);
        }
    }

    /**
     * 할인 적용가능상품 - 카테고리
     * @param $publishIx
     * @param $cids
     */
    protected function updateCouponRelationCategory($publishIx, $cids)
    {
        if (is_array($cids)) {
            //포함 안된 데이터 삭제
            $this->qb
                ->delete(TBL_SHOP_CUPON_RELATION_CATEGORY)
                ->where('publish_ix', $publishIx)
                ->whereNotIn('cid', $cids)
                ->exec();

            //get 디비에 저장된 데이터
            $rows = $this->qb
                ->select('cid')
                ->from(TBL_SHOP_CUPON_RELATION_CATEGORY)
                ->where('publish_ix', $publishIx)
                ->whereIn('cid', $cids)
                ->exec()
                ->getResultArray();

            $cidsDB = array_column($rows, 'cid');

            //DB에 있고 insert 해야할 컬람만 추출
            $_cids = array_diff($cids, $cidsDB);

            $this->insertCouponRelationCategory($publishIx, $_cids);
        }
    }

    /**
     * 할인 적용가능상품 - 브랜드
     * @param $publishIx
     * @param $bIxs
     */
    protected function updateCouponRelationBrand($publishIx, $bIxs)
    {
        if (is_array($bIxs)) {
            //포함 안된 데이터 삭제
            $this->qb
                ->delete(TBL_SHOP_CUPON_RELATION_BRAND)
                ->where('publish_ix', $publishIx)
                ->whereNotIn('b_ix', $bIxs)
                ->exec();

            //get 디비에 저장된 데이터
            $rows = $this->qb
                ->select('b_ix')
                ->from(TBL_SHOP_CUPON_RELATION_BRAND)
                ->where('publish_ix', $publishIx)
                ->whereIn('b_ix', $bIxs)
                ->exec()
                ->getResultArray();

            $bIxsDB = array_column($rows, 'b_ix');

            //DB에 있고 insert 해야할 컬람만 추출
            $_bIxs = array_diff($bIxs, $bIxsDB);

            $this->insertCouponRelationBrand($publishIx, $_bIxs);
        }
    }

    /**
     * update coupon publish
     * @param $publishIx
     * @param $data
     * @return bool|\NunaResult
     */
    protected function updateCouponPublish($publishIx, $data)
    {
        $data = $this->qb->allowedFields($data, ['publish_name', 'is_use', 'cupon_use_sdate', 'cupon_use_edate','publish_desc']);

        return $this->qb
            ->set($data)
            ->update(TBL_SHOP_CUPON_PUBLISH)
            ->where('publish_ix', $publishIx)
            ->exec();
    }
    /**
     * 발급 대상
     * @param $publishIx
     * @param $publishType
     * @param $datas
     */
    protected function insertCouponTargetPublishConfig($publishIx, $publishType, $datas)
    {
        if (is_array($datas)) {
            foreach ($datas as $data) {
                $this->qb
                    ->set('publish_ix', $publishIx)
                    ->set('publish_type', $publishType)
                    ->set('r_ix', $data)
                    ->set('regdate', date('Y-m-d H:i:s'))
                    ->insert(TBL_SHOP_CUPON_PUBLISH_CONFIG)
                    ->exec();
            }
        }
    }

    /**
     * 할인 적용가능상품 - 상품
     * @param $publishIx
     * @param $pids
     */
    protected function insertCouponRelationProduct($publishIx, $pids)
    {
        if (is_array($pids)) {
            foreach ($pids as $pid) {
                $this->qb
                    ->set('publish_ix', $publishIx)
                    ->set('pid', $pid)
                    ->set('regdate', date('Y-m-d H:i:s'))
                    ->insert(TBL_SHOP_CUPON_RELATION_PRODUCT)
                    ->exec();
            }
        }
    }

    /**
     * 할인 적용가능상품 - 업체
     * @param $publishIx
     * @param $companyIds
     */
    protected function insertCouponRelationCompany($publishIx, $companyIds)
    {
        if (is_array($companyIds)) {
            foreach ($companyIds as $companyId) {
                $this->qb
                    ->set('publish_ix', $publishIx)
                    ->set('company_id', $companyId)
                    ->set('regdate', date('Y-m-d H:i:s'))
                    ->insert(TBL_SHOP_CUPON_RELATION_SELLER)
                    ->exec();
            }
        }
    }

    /**
     * 할인 적용가능상품 - 카테고리
     * @param $publishIx
     * @param $cids
     */
    protected function insertCouponRelationCategory($publishIx, $cids)
    {
        if (is_array($cids)) {
            /* @var $categoryModel \CustomScm\Model\Product\Category */
            $categoryModel = $this->import('model.scm.product.category');
            foreach ($cids as $cid) {
                $this->qb
                    ->set('publish_ix', $publishIx)
                    ->set('cid', $cid)
                    ->set('depth', $categoryModel->getDepth($cid))
                    ->set('regdate', date('Y-m-d H:i:s'))
                    ->insert(TBL_SHOP_CUPON_RELATION_CATEGORY)
                    ->exec();
            }
        }
    }

    /**
     * 할인 적용가능상품 - 브랜드
     * @param $publishIx
     * @param $bIxs
     */
    protected function insertCouponRelationBrand($publishIx, $bIxs)
    {
        if (is_array($bIxs)) {
            foreach ($bIxs as $bIx) {
                $this->qb
                    ->set('publish_ix', $publishIx)
                    ->set('b_ix', $bIx)
                    ->set('regdate', date('Y-m-d H:i:s'))
                    ->insert(TBL_SHOP_CUPON_RELATION_BRAND)
                    ->exec();
            }
        }
    }

    /**
     * insert coupon publish
     * @param $data
     * @return bool|\NunaResult
     */
    protected function insertCouponPublish($data)
    {
        $couponData = $this->qb->allowedFields($data, [
            'cupon_div',
            'cupon_use_div',
            'cupon_sale_type',
            'cupon_acnt',
            'haddoffice_rate',
            'seller_rate',
            'cupon_sale_value',
            'round_position',
            'round_type'
        ]);

        $couponIx = $this->qb
            ->set($couponData)
            ->set('is_use', '1')
            ->set('regdate', date('Y-m-d H:i:s'))
            ->insert(TBL_SHOP_CUPON)
            ->exec();

        $publishData = $this->qb->allowedFields($data, [
            'publish_name',
            'publish_desc',
            'is_use',
            'publish_min',
            'publish_max',
            'publish_condition_price',
            'publish_limit_price',
            'use_product_type',
            'issue_type',
            'issue_type',
            'issue_type_detail',
            'publish_type',
            'use_date_type',
            'use_sdate',
            'use_edate',
            'publish_date_differ',
            'publish_date_type',
            'regist_date_differ',
            'regist_date_type',
            'cupon_use_sdate',
            'cupon_use_edate'
        ]);

        // 시작 날짜 디폴트 세팅
        $publishData['use_sdate'] = $publishData['use_sdate'].' 00:00:00';
        // 종료 날짜 디폴트 세팅
        $publishData['use_edate'] = $publishData['use_edate'].' 23:59:59';

        return $this->qb
            ->set($publishData)
            ->set('cupon_ix', $couponIx)
            ->set('cupon_no', $this->makeCouponNumber())
            ->set('regdate', date('Y-m-d H:i:s'))
            ->insert(TBL_SHOP_CUPON_PUBLISH)
            ->exec();
    }

    /**
     * 쿠폰 넘버 생성
     * @return string
     */
    protected function makeCouponNumber()
    {
        $couponNumber = "MSCP" . date("ymd") . rand(1000000, 9999999);

        $this->qb
            ->from(TBL_SHOP_CUPON_PUBLISH)
            ->where('cupon_no', $couponNumber)
            ->exec();

        If ($this->qb->total > 0) {
            $this->makeCouponNumber();
        } else {
            return $couponNumber;
        }
    }

    /**
     * 쿠폰 복구
     * @param type $status
     * @param type $registIx
     */
    public function returnUsedCoupon($status, $registIx = [])
    {
        switch ($status) { //상태에 따라 복구가능 시점 다름. 관리자 설정 참조.
            case ORDER_STATUS_INCOM_BEFORE_CANCEL_COMPLETE :
                $restoreConfig = $this->config['restore_cc1'];
                break;
            case ORDER_STATUS_CANCEL_COMPLETE :
                $restoreConfig = $this->config['restore_cc2'];
                break;
            case ORDER_STATUS_RETURN_COMPLETE :
                $restoreConfig = $this->config['restore_bf'];
                break;
            default :
                $restoreConfig = 'N';
                break;
        }

        if ($restoreConfig == 'Y') {
            if (!empty($registIx)) {
                $this->qb
                    ->set('use_yn', 0)
                    ->set('use_oid', '')
                    ->set('use_pid', '')
                    ->set('usedate', '')
                    ->whereIn('regist_ix', $registIx)
                    ->update(TBL_SHOP_CUPON_REGIST)
                    ->exec();
            }
        }
    }

    /**
     * 쿠폰 일괄 지급
     */
    public function addBatchChangeMemberGroup($search = [])
    {
        $data_set = [];
        if ($search['update_type'] == 1) {
            //검색 회원            
            if (isset($search['searchType']) && $search['searchType'] && isset($search['searchText']) && $search['searchText']) {
                $this->qb->like($search['searchType'], $search['searchText']);
            }

            //회원 그룹
            if (isset($search['gp_ix']) && !empty($search['gp_ix'])) {
                $this->qb->whereIn('cmd.gp_ix', $search['gp_ix']);
            }

            //회원구분
            if (isset($search['mem_div']) && !empty($search['mem_div'])) {
                $this->qb->whereIn('cu.mem_div', $search['mem_div']);
            }

            //날짜검색
            if (($search['betweenDatePickerStart'] ?? null) && ($search['betweenDatePickerEnd'] ?? null)) {
                $this->qb->betweenDate('cmd.date', $search['betweenDatePickerStart'], $search['betweenDatePickerEnd']);
            }

            //일괄 회원구분
            if (isset($search['chk_mem_div']) && !empty($search['chk_mem_div'])) {
                $this->qb->whereIn('mem_div', $search['chk_mem_div']);
            }

            //일괄 성별 검색
            if (isset($search['chk_sex_div']) && !empty($search['chk_sex_div'])) {
                $this->qb->whereIn('sex_div', $search['chk_sex_div']);
            }
            //일괄 sms 동의 검색
            if (isset($search['smssend_yn']) && !empty($search['smssend_yn'])) {
                $this->qb->whereIn('sms', $search['smssend_yn']);
            }
            //일괄 메일수신 동의 검색
            if (isset($search['mailsend_yn']) && !empty($search['mailsend_yn'])) {
                $this->qb->whereIn('info', $search['mailsend_yn']);
            }
            //일괄 회원그룹 검색
            if (isset($search['memberGroupBath']) && !empty($search['memberGroupBath'])) {
                $this->qb->whereIn('cmd.gp_ix', $search['memberGroupBath']);
            }

            //해당 검색 조건으로 맴버를 검색한 다음에 쿠폰 발급
            $userArr = $this->qb
                ->select('cu.code')
                ->select('cmd.gp_ix')
                ->from(TBL_COMMON_USER . ' as cu')
                ->join(TBL_COMMON_MEMBER_DETAIL . ' as cmd', 'cu.code=cmd.code')
                ->exec()
                ->getResultArray();

        } else {
            //선택 회원
            $this->qb->whereIn('code', explode(",", $search['selectCode']));

            $userArr = $this->qb
                ->select('code')
                ->select('gp_ix')
                ->from(TBL_COMMON_MEMBER_DETAIL)
                ->exec()
                ->getResultArray();
        }

        foreach ($userArr as $key => $val) {
            $this->giveCoupon($search['update_ix'], $val['code'], false, $val['gp_ix']);
        }

        $result['data'] = $search;
        $result['status'] = 'success';
        return $result;


        //$publishIx, $userCode, $duplicate = false

    }

    /**
     * 발행 등록
     *
     *
     **/
    public function addOfflineCoupon($couponData)
    {
        $publishIx = $this->insertOfflineCoupon($couponData);

        return $publishIx;
    }

    /**
     * 발행 수정
     * @param $gc_ix
     * @param $couponData
     */
    public function putOfflineCoupon($gc_ix, $couponData)
    {
        $this->updateGcProcess($couponData, $gc_ix);

    }

    /**
     * 오프라인 쿠폰데이타 업데이트
     * @param $couponData
     * @param $gc_ix
     * @throws \Exception
     */
    protected function updateGcProcess($couponData, $gc_ix)
    {
        $this->qb
            ->set('gift_certificate_name', $couponData['gift_certificate_name'])
            ->set('gift_start_date', $couponData['gift_start_date'])
            ->set('gift_end_date', $couponData['gift_end_date'])
            ->set('memo', $couponData['memo'])
            ->update(TBL_SHOP_GIFT_CERTIFICATE)
            ->where('gc_ix', $gc_ix)
            ->exec();
    }

    /**
     * 발행 삭제
     * @param $gc_ix
     */
    public function delOfflineCoupon($gc_ix)
    {
        $this->qb
            ->delete(TBL_SHOP_GIFT_CERTIFICATE)
            ->where('gc_ix', $gc_ix)
            ->exec();

        $this->qb
            ->delete(TBL_SHOP_GIFT_CERTIFICATE_DETAIL)
            ->where('gc_ix', $gc_ix)
            ->exec();

        $this->qb
            ->delete(TBL_SHOP_GIFT_CERTIFICATE_CUPON)
            ->where('gc_ix', $gc_ix)
            ->exec();
    }

    /**
     * 오프라인 쿠폰 복사
     * @param $gc_ix
     */
    public function copyOfflineCoupon($gc_ix)
    {
        $row = $this->qb
            ->select('gift_way')
            ->select('gift_type')
            ->select('gift_prefix_code')
            ->select('create_cnt')
            ->from(TBL_SHOP_GIFT_CERTIFICATE)
            ->where('gc_ix', $gc_ix)
            ->exec()
            ->getRowArray();
        $gift_way = $row['gift_way'];
        $gift_type = $row['gift_type'];
        $gift_prefix_code = $row['gift_prefix_code'];
        $create_cnt = $row['create_cnt'];
        $b_gc_ix = $gc_ix;

        $cpData = $this->createPattern($gift_way, $gift_type, $gift_prefix_code);

        $gcData = $this->qb
            ->select('gift_certificate_name')
            ->select('gift_prefix_code')
            ->select('gift_amount')
            ->select('create_cnt')
            ->select('gift_start_date')
            ->select('gift_end_date')
            ->select('gift_type')
            ->select('reg_cnt')
            ->select('reg_mem_ix')
            ->select('regdate')
            ->select('memo')
            ->select('gift_way')
            ->from(TBL_SHOP_GIFT_CERTIFICATE)
            ->where('gc_ix', $b_gc_ix)
            ->exec()
            ->getRowArray();

        $gc_ix = $this->insertGcProcess($gcData);

        if ($gift_type == "C" || $gift_type == "U") {
            $c_list = $this->qb
                ->select('gcc_ix')
                ->from(TBL_SHOP_GIFT_CERTIFICATE_CUPON)
                ->where('gc_ix', $b_gc_ix)
                ->exec()
                ->getResultArray();

            for ($i = 0; $i < count($c_list); $i++) {
                $gccData = $this->qb
                    ->select('gc_ix')
                    ->select('gift_cupon_ix')
                    ->select('insert_yn')
                    ->select('regdate')
                    ->from(TBL_SHOP_GIFT_CERTIFICATE_CUPON)
                    ->where('gcc_ix', $c_list[$i]['gcc_ix'])
                    ->exec()
                    ->getRowArray();

                $gccData['gc_ix'] = $gc_ix;
                $this->qb
                    ->set($gccData)
                    ->insert(TBL_SHOP_GIFT_CERTIFICATE_CUPON)
                    ->exec();
            }
        }

        if ($gift_type != "U") {
            $this->gcdProcess('copy', $create_cnt, $cpData['length'], $cpData['gift_prefix_code'], $gc_ix);
        }
    }

    /**
     * insertOfflineCoupon
     * @param $data
     */
    protected function insertOfflineCoupon($data)
    {
        $couponData = $this->qb->allowedFields($data, [
            'gift_certificate_name',
            'gift_prefix_code',
            'gift_amount',
            'create_cnt',
            'gift_start_date',
            'gift_end_date',
            'gift_type',
            'reg_cnt',
            'reg_mem_ix',
            'regdate',
            'memo',
            'gift_way'
        ]);

        $cpData = $this->createPattern($couponData['gift_way'], $couponData['gift_type'], $data['gift_prefix_code']);

        if ($couponData['gift_type'] == "U") {
            $this->qb
                ->select('*')
                ->from(TBL_SHOP_GIFT_CERTIFICATE)
                ->where('gift_type', 'U')
                ->where('gift_prefix_code', trim($cpData['gift_prefix_code']))
                ->exec();

            if ($this->qb->total > 0) {
                return 'duplicate';
            }
        }

        $couponData['gift_prefix_code'] = trim($cpData['gift_prefix_code']);
        $gc_ix = $this->insertGcProcess($couponData, fb_now());

        if ($couponData['gift_type'] == "C" || $couponData['gift_type'] == "U") {
            $this->gccProcess($data['appoint_publish_ix'], $gc_ix);
        }

        if ($couponData['gift_type'] != "U") {
            $cnt = $this->qb
                ->select('create_cnt')
                ->from(TBL_SHOP_GIFT_CERTIFICATE)
                ->where('gc_ix', $gc_ix)
                ->exec()
                ->getRowArray();

            $this->gcdProcess('insert', $cnt['create_cnt'], $cpData['length'], $cpData['gift_prefix_code'], $gc_ix);
        }
    }

    /**
     * 오프라인 쿠폰 insert
     * @param $data
     * @param string $regdate
     * @return bool|\NunaResult
     * @throws \Exception
     */
    protected function insertGcProcess($data, $regdate = '')
    {
        if ($regdate) {
            $this->qb
                ->set('regdate', $regdate);
        }

        $gc_ix = $this->qb
            ->set($data)
            ->insert(TBL_SHOP_GIFT_CERTIFICATE)
            ->exec();

        return $gc_ix;
    }

    /**
     * giftCouponRuleSelectBox
     * @return string
     * @throws \Exception
     */
    public function giftCouponRuleSelectBox()
    {

        $arr_couponList = array();

        $data = $this->qb
            ->select('cp.*')
            ->select('c.cupon_kind')
            ->from(TBL_SHOP_CUPON . ' AS c')
            ->join(TBL_SHOP_CUPON_PUBLISH . ' AS cp', 'on on c.cupon_ix = cp.cupon_ix', 'left')
            ->where('issue_type', '5')
            ->where('c.cupon_ix > 0')
            ->where('cp.is_use', '1')
            ->orderBy('cp.regdate', 'desc')
            ->exec()
            ->getResultArray();

        foreach ($data as $key => $val) {
            $arr_couponList[] = $val;
        }

        $arr_dateType = array(1 => '년', '개월', '일');

        if (is_array($arr_couponList)) {
            foreach ($arr_couponList as $_key => $_val) {
                switch ($_val['use_date_type']) {
                    case 1:
                        $use_date_type = '발행일';
                        $priod_str = $use_date_type . "로부터 " . $_val['publish_date_differ'] . " " . $arr_dateType[$_val['publish_date_type']] . "건";
                        break;
                    case 2:
                        $use_date_type = '등록일';
                        $priod_str = $use_date_type . "로부터 " . $_val['regist_date_differ'] . " " . $arr_dateType[$_val['regist_date_type']] . "간";
                        break;
                    case 3:
                        $use_date_type = '사용기간';
                        $priod_str = $use_date_type . " : " . date("Y-m-d",
                                strtotime($_val['use_sdate'])) . " ~ " . date("Y-m-d",
                                strtotime($_val['use_edate'])) . " ";
                        break;
                }

                $mstring[$_key]['publish_ix'] = $_val['publish_ix'];
                $mstring[$_key]['cupon_no'] = $_val['cupon_no'];
                $mstring[$_key]['publish_name'] = $_val['publish_name'];
            }
        }

        return (!empty($mstring)) ? $mstring : '';
    }

    /**
     * 오프라인 쿠폰 수정 시 지급 쿠폰 목록
     * @param $gc_ix
     * @return mixed
     * @throws \Exception
     */
    public function giftCertificateCuponList($gc_ix)
    {
        $arr_appoint_publish_selected = [];
        $result = [];

        $data = $this->qb
            ->select('gift_cupon_ix')
            ->from(TBL_SHOP_GIFT_CERTIFICATE_CUPON)
            ->where('gc_ix', $gc_ix)
            ->exec()
            ->getResultArray();

        foreach ($data as $key => $val) {
            $arr_appoint_publish_selected[] = $val;
        }

        if (is_array($arr_appoint_publish_selected)) {
            foreach ($arr_appoint_publish_selected as $key => $val) {
                $result[$key]['gift_cupon_ix'] = $val['gift_cupon_ix'];
                $result[$key]['select'] = $this->giftCouponRuleSelectBox();
            }
        }

        return $result;
    }

    /**
     * 패턴생성
     * @param $gift_way
     * @param $gift_type
     * @return mixed
     */
    protected function createPattern($gift_way, $gift_type, $gift_prefix_code)
    {
        if ($gift_way == 1) {
            $length = 12;
        } else {
            $length = 16;

            if ($gift_type == "U") {
                $gift_prefix_code = '';
                $pattern = "1234567890ABCDEFGHIJKLMNOPQRSTUVWXYZ";
                for ($i = 0; $i < $length; $i++) {
                    $gift_prefix_code .= $pattern[rand(0, 35)];
                }
            }
        }

        $cpData['length'] = $length;
        $cpData['gift_prefix_code'] = $gift_prefix_code;

        return $cpData;
    }

    /**
     * 오프라인 쿠폰 상세 등록/복사 처리
     * @param $mode
     * @param $create_cnt
     * @param $length
     * @param $gift_prefix_code
     * @param $gc_ix
     * @throws \Exception
     */
    protected function gcdProcess($mode, $create_cnt, $length, $gift_prefix_code, $gc_ix)
    {
        $pattern = "1234567890ABCDEFGHIJKLMNOPQRSTUVWXYZ";

        $key = '';
        for ($Loop = 0; $Loop < $create_cnt; $Loop++) {
            for ($i = 0; $i < $length; $i++) {
                $key .= $pattern[rand(0, 35)];
            }

            if ($mode == 'insert') {
                $this->qb
                    ->select('gcd_ix')
                    ->from(TBL_SHOP_GIFT_CERTIFICATE_DETAIL)
                    ->where('gift_code', trim($gift_prefix_code . $key))
                    ->exec();

                if ($this->qb->total == 0) {
                    if (trim($key) != "") {
                        $this->insertGcdProcess($gc_ix, $gift_prefix_code, $key);
                    }
                }
            } else {
                $this->qb
                    ->select('*')
                    ->from(TBL_SHOP_GIFT_CERTIFICATE_DETAIL)
                    ->where('gift_code', trim($gift_prefix_code . $key))
                    ->exec()
                    ->getResultArray();

                if (!$this->qb->total) {
                    if (trim($key) != "") {
                        $this->insertGcdProcess($gc_ix, $gift_prefix_code, $key);
                    }
                }
            }

            $key = '';
        }
    }

    /**
     * 오프라인 쿠폰 상세 등록 처리
     * @param $gc_ix
     * @param $gift_prefix_code
     * @param $key
     * @throws \Exception
     */
    protected function insertGcdProcess($gc_ix, $gift_prefix_code, $key)
    {
        $this->qb
            ->set('gc_ix', $gc_ix)
            ->set('gift_code', trim($gift_prefix_code) . $key)
            ->set('gift_change_state', '0')
            ->insert(TBL_SHOP_GIFT_CERTIFICATE_DETAIL)
            ->exec();
    }

    /**
     * 오프라인 쿠폰 등록/수정 처리
     * @param $appoint_publish_ix
     * @param $gc_ix
     * @throws \Exception
     */
    protected function gccProcess($appoint_publish_ix, $gc_ix)
    {
        if (is_array($appoint_publish_ix)) {
            $this->qb
                ->set('insert_yn', 'N')
                ->update(TBL_SHOP_GIFT_CERTIFICATE_CUPON)
                ->where('gc_ix', $gc_ix)
                ->exec();

            foreach ($appoint_publish_ix as $cupon_ix) {
                if ($cupon_ix != '') {
                    $this->qb
                        ->select('*')
                        ->from(TBL_SHOP_GIFT_CERTIFICATE_CUPON)
                        ->where('gc_ix', $gc_ix)
                        ->where('gcc_ix', $cupon_ix)
                        ->exec();

                    if ($this->qb->total) {
                        $this->qb
                            ->set('insert_yn', 'Y')
                            ->update(TBL_SHOP_GIFT_CERTIFICATE_CUPON)
                            ->where('gcc_ix', $cupon_ix)
                            ->exec();
                    } else {
                        $this->qb
                            ->set('gc_ix', $gc_ix)
                            ->set('gift_cupon_ix', $cupon_ix)
                            ->set('insert_yn', 'Y')
                            ->set('regdate', date('Y-m-d H:i:s'))
                            ->insert(TBL_SHOP_GIFT_CERTIFICATE_CUPON)
                            ->exec();
                    }
                }
            }

            $this->qb
                ->delete(TBL_SHOP_GIFT_CERTIFICATE_CUPON)
                ->where('insert_yn', 'N')
                ->where('gc_ix', $gc_ix)
                ->exec();
        }
    }

    /**
     * 쿠폰 발급 리스트
     * @param int $page
     * @param int $max
     * @param array $where
     * @return array
     */
    public function getOfflineRegistList($page = 1, $max = 5, $where = [])
    {
        $this->qb->startCache();

        $this->qb->whereIn('cd.gc_ix', $where['gc_ix']);

        // 검색 조건
        if (isset($where['searchType']) && $where['searchType'] && isset($where['searchText']) && $where['searchText']) {
            if (in_array($where['searchType'], ['name', 'mail', 'pcs'])) {
                $this->qb->like($this->qb->decrypt($where['searchType']), $where['searchText']);
            } else {
                $this->qb->like($where['searchType'], $where['searchText']);
            }
        }

        //상태
        if (isset($where['giftChangeState']) && $where['giftChangeState'] != '') {
            $this->qb->whereIn('cd.gift_change_state', $where['giftChangeState']);
        }

        //사용일자
        if (isset($where['useDateStart']) && !empty($where['useDateStart']) && isset($where['useDateEnd']) && !empty($where['useDateEnd'])) {
            $this->qb->where('cd.use_date >= "' . $where['useDateStart'] . '"');
            $this->qb->where('cd.use_date <= "' . $where['useDateEnd'] . '"');
        }

        $this->qb
            ->from(TBL_SHOP_GIFT_CERTIFICATE_DETAIL . ' AS cd')
            ->join(TBL_SHOP_GIFT_CERTIFICATE . ' as gc', 'cd.gc_ix=gc.gc_ix')
            ->join(TBL_COMMON_USER . ' AS cu', 'cu.id=cd.member_id', 'left')
            ->join(TBL_COMMON_MEMBER_DETAIL . ' as cmd', 'cu.code=cmd.code', 'left');
        $this->qb->stopCache();

        $total = $this->qb->getCount();
        $paging = $this->qb
            ->setTotalRows($total)
            ->pagination($page, $max);

        $offset = ($paging['offset'] ?? 0);

        $rows = $this->qb
            ->select('cd.gcd_ix')
            ->select('cd.gc_ix')
            ->select('cd.gift_code')
            ->select('cd.gift_change_state')
            ->select('cd.member_id')
            ->select('cd.use_date')
            ->select('cu.code')
            ->select('cu.id')
            ->select('gc.gift_start_date')
            ->select('gc.gift_end_date')
            ->decryptSelect('cmd.name')
            ->orderBy('cd.gcd_ix', 'ASC')
            ->limit($max, $offset)
            ->exec()
            ->getResultArray();

        $this->qb->flushCache();

        //치환 처리
        foreach ($rows as $key => $val) {
            $val['useDateText'] = $val['gift_start_date'] . " ~ " . $val['gift_end_date'];
            $val['useText'] = $val['gift_change_state'] == '1' ? '사용완료' : '사용전';

            $rows[$key] = $val;
        }

        return [
            'total' => $total,
            'list' => $rows,
            'paging' => $paging
        ];
    }

    /**
     * 발행된 시리얼 넘버 삭제
     * @param $registIx
     * @param $userCode
     */
    public function delOfflineRegist($gcdIx)
    {
        $this->qb
            ->delete(TBL_SHOP_GIFT_CERTIFICATE_DETAIL)
            ->where('gcd_ix', $gcdIx)
            ->exec();
    }

    /**
     * APP결제 첫 주문 체크
     * @param $userCode
     * @return bool
     * @throws \Exception
     */
    public function getAppFirstOrderChk($userCode)
    {
        $count = $this->qb
            ->from(TBL_SHOP_ORDER . ' AS o')
            ->join(TBL_SHOP_ORDER_DETAIL . ' AS od', 'ON o.oid = od.oid')
            ->where('o.user_code', $userCode)
            ->where('od.status', ORDER_STATUS_BUY_FINALIZED)
            ->where('o.payment_agent_type', 'A')
            ->getCount('o.oid');
        if ($count == 1) {
            return true;
        } else {
            return false;
        }
    }
}