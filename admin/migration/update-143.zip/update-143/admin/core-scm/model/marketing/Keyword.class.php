<?php

namespace ForbizScm\Model\Marketing;

/**
 * 키워드 관련 모델
 *
 * @author hoksi
 */
class Keyword extends \ForbizModel
{
    protected $is_ing = [
        '' => '전체',
        '1' => '진행중',
        '0' => '진행완료'
    ];

    protected $disp = [
        '' => '전체',
        '1' => '사용',
        '0' => '미사용'
    ];

    protected $st_type = [
        '' => '전체',
        '1' => '텍스트',
        '2' => '이미지'
    ];

    public function __construct()
    {
        parent::__construct();
    }

    /**
     * 진행여부
     * @param bool $key
     * @return array|mixed|string
     */
    public function getIsIng($key = false)
    {
        if ($key === false) {
            return $this->is_ing;
        } else {
            return $this->is_ing[$key] ?? '';
        }
    }

    /**
     * 사용여부
     * @param bool $key
     * @return array|mixed|string
     */
    public function getDisp($key = false, $type = false)
    {
        if ($key === false) {
            return $this->disp;
        } elseif ($type == 'notAll') {
            $emptyArray = array("전체");
            return array_diff($this->disp, $emptyArray);
        } else {
            return $this->disp[$key] ?? '';
        }
    }

    /**
     * 노출타입
     * @param bool $key
     * @return array|mixed|string
     */
    public function getStType($key = false, $type = false)
    {
        if ($key === false) {
            return $this->st_type;
        } elseif ($type == 'notAll') {
            $emptyArray = array("전체");
            return array_diff($this->st_type, $emptyArray);
        } else {
            return $this->st_type[$key] ?? '';
        }
    }

    /**
     * 검색창 키워드 관리 리스트
     * @param int $page
     * @param int $max
     * @param array $where
     * @return array
     * @throws \Exception
     */
    public function getList($page = 1, $max = 5, $where = [])
    {
        $this->qb->startCache();

        $this->setWhere($where)
            ->select('st.st_ix')
            ->select('st.st_text')
            ->select('st.st_sdate')
            ->select('st.st_edate')
            ->select('st.st_type')
            ->select('st.disp')
            ->select('st.regdate')
            ->select('sk.searchcnt')
            ->from(TBL_SHOP_SEARCH_TEXT . ' AS st')
            ->join(TBL_SHOP_SEARCH_KEYWORD . ' AS sk', '(st.st_text=sk.keyword and sk.disp=1)', 'left');

        $this->qb->stopCache();

        $total = $this->qb->getCount();

        $paging = $this->qb->setTotalRows($total)->pagination($page, $max);

        $list = $this->qb->orderBy('st.regdate', 'DESC')
            ->limit($max, ($paging['offset'] ?? 0))
            ->exec()
            ->getResultArray();

        $this->qb->flushCache();

        //치환 처리
        foreach ($list as $key => $val) {
            //진행여부
            if (isset($val['disp'])) {
                if ($val['disp'] == '1') {
                    $val['disp_text'] = '사용';
                } else if ($val['disp'] == '0') {
                    $val['disp_text'] = '미사용';
                }
            }
            //전시타입
            if (isset($val['st_edate'])) {
                if ($val['st_edate'] >= time()) {
                    $val['is_ing_text'] = '진행중';
                } else {
                    $val['is_ing_text'] = '진행완료';
                }
            }
            //전시타입
            if (isset($val['st_type'])) {
                if ($val['st_type'] == '1') {
                    $val['st_type_text'] = '텍스트';
                } else if ($val['st_type'] == '2') {
                    $val['st_type_text'] = '이미지';
                }
            }
            //시작일
            if (isset($val['st_sdate'])) {
                $val['st_sdate_text'] = date("Y-m-d H:i:s", $val['st_sdate']);
            }
            //종료일
            if (isset($val['st_edate'])) {
                $val['st_edate_text'] = date("Y-m-d H:i:s", $val['st_edate']);
            }

            $list[$key] = $val;
        }

        return [
            'total' => $total,
            'list' => $list,
            'paging' => $paging
        ];
    }

    /**
     * * where 세팅
     * @param $where
     * @return \CI_Qb
     */
    protected function setWhere($where)
    {
        if (isset($where['startDate']) && $where['startDate'] && isset($where['endDate']) && $where['endDate']) {
            $this->qb->betweenDate('st.st_sdate', strtotime($where['startDate']), strtotime($where['endDate']));
        }
        if (isset($where['startDate2']) && $where['startDate2'] && isset($where['endDate2']) && $where['endDate2']) {
            $this->qb->betweenDate('st.st_edate', strtotime($where['startDate2']), strtotime($where['endDate2']));
        }
        if (isset($where['is_ing']) && $where['is_ing'] != '') {
            if ($where['is_ing'] == '1') {
                $this->qb->where('st.st_edate >= ' . time());
            } else if ($where['is_ing'] == '0') {
                $this->qb->where('st.st_edate < ' . time());
            }
        }
        if (isset($where['disp']) && $where['disp'] != '') {
            $this->qb->where('st.disp', $where['disp']);
        }
        if (isset($where['st_type']) && $where['st_type'] != '') {
            $this->qb->where('st.st_type', $where['st_type']);
        }
        if (isset($where['search_text']) && $where['search_text']) {
            $this->qb->like($where['filterType'], $where['search_text']);
        }

        return $this->qb;
    }

    /**
     * 등록
     * @param $data
     * @param null $relProductGridData
     * @throws \Exception
     */
    public function addManage($data, $file = null)
    {
        //master
        $goodsData = $this->qb->allowedFields($data, ['st_text', 'st_sdate', 'st_edate', 'st_type', 'disp', 'st_title', 'st_url', 'display_position']);
        $goodsData['st_sdate'] = strtotime($goodsData['st_sdate']);
        $goodsData['st_edate'] = strtotime($goodsData['st_edate']);
        $ix = $this->insertGoods($goodsData);

        //노출위치 카테고리
        $displayRelation = $this->qb->allowedFields($data, ['cidList']);
        if (!empty($displayRelation['cidList'])) {
            foreach ($displayRelation['cidList'] as $drKey => $drVal) {
                $displayRelationData['cid'] = $drVal;
                $displayRelationData['vieworder'] = $drKey + 1;
                $displayRelationData['insert_yn'] = 'Y';

                $displayRelationData['st_ix'] = $ix;
                $this->insertRelation($displayRelationData);
            }//end foreach
        }

        //이미지 업로드
        if ($file) {
            $this->imageUpload($ix, $file);
        }

        return $ix;
    }

    /**
     * insert(table)
     * @param $data
     * @return bool|\NunaResult
     * @throws \Exception
     */
    public function insertGoods($data)
    {
        return $this->qb
            ->set($data)
            ->set('regdate', date('Y-m-d H:i:s'))
            ->insert(TBL_SHOP_SEARCH_TEXT)
            ->exec();
    }

    /**
     * 이미지 업로드
     * @param type $idx
     * @param type $file
     */
    protected function imageUpload($ix, $file)
    {
        /* @var $uploadModel \CustomScm\Model\Util\Upload */
        $uploadModel = $this->import('model.scm.util.upload');

        foreach ($file as $key => $val) {
            if ($key && $val['size'] > 0) {
                $uploadModel->keywordUpload($key, $ix);
            }
        }
    }

    /**
     * get 데이터
     * @param $ix
     * @return mixed
     * @throws \Exception
     */
    public function getPutList($ix)
    {
        $list = $this->qb
            ->select('st.st_ix')
            ->select('st.st_text')
            ->select('FROM_UNIXTIME(st.st_sdate) AS st_sdate')
            ->select('FROM_UNIXTIME(st.st_edate) AS st_edate')
            ->select('st.st_type')
            ->select('st.st_title')
            ->select('st.st_url')
            ->select('st.display_position')
            ->select('st.disp')
            ->select('st.regdate')
            ->from(TBL_SHOP_SEARCH_TEXT . ' AS st')
            ->where('st.st_ix', $ix)
            ->exec()
            ->getRowArray();

        return $list;
    }

    /**
     * 수정
     * @param $data
     * @param null $relProductGridData
     * @throws \Exception
     */
    public function putManage($ix, $data, $file = null)
    {
        //master
        $goodsData = $this->qb->allowedFields($data, ['st_text', 'st_sdate', 'st_edate', 'st_type', 'disp', 'st_title', 'st_url', 'display_position']);

        $goodsData['st_sdate'] = strtotime($goodsData['st_sdate']);
        $goodsData['st_edate'] = strtotime($goodsData['st_edate']);
        $this->updateGoods($ix, $goodsData); //상품그룹 수정

        //노출위치 카테고리
        $displayRelation = $this->qb->allowedFields($data, ['cidList']);
        if (!empty($displayRelation['cidList'])) {
            $updateDisplayRelation['insert_yn'] = 'N';
            $this->updateRelation($ix, $updateDisplayRelation);
            foreach ($displayRelation['cidList'] as $drKey => $drVal) {
                $selDisplayRelationData['cid'] = $drVal;
                $scrData = $this->selectRelation($ix, $selDisplayRelationData);

                $displayRelationData['cid'] = $drVal;
                $displayRelationData['vieworder'] = $drKey + 1;
                $displayRelationData['insert_yn'] = 'Y';
                if ($scrData['scr_ix']) {//존재하는지 체크
                    $this->updateRelation($ix, $displayRelationData);
                } else {
                    $displayRelationData['st_ix'] = $ix;
                    $this->insertRelation($displayRelationData);
                }
            }//end foreach
        }
        $this->deleteRelation($ix);

        //이미지 업로드
        if ($file) {
            $this->imageUpload($ix, $file);
        }
    }

    /**
     * 수정 업데이트
     * @param $data
     * @return bool|\NunaResult
     * @throws \Exception
     */
    public function updateGoods($ix, $data)
    {
        $this->qb
            ->set('regdate', date('Y-m-d H:i:s'))
            ->set($data)
            ->update(TBL_SHOP_SEARCH_TEXT)
            ->where('st_ix', $ix)
            ->exec();
    }

    /**
     * 노출카테고리 검색
     * @param $dp_ix
     * @throws \Exception
     */
    protected function selectRelation($ix, $data)
    {
        return $this->qb
            ->select('scr_ix')
            ->from(TBL_SHOP_SEARCH_CATEGORY_RELATION)
            ->where('st_ix', $ix)
            ->where($data)
            ->exec()
            ->getRowArray();
    }

    /**
     * 노출카테고리 등록
     * @param $pid
     * @param $data
     * @throws \Exception
     */
    protected function insertRelation($data)
    {
        $this->qb
            ->set($data)
            ->set('regdate', date('Y-m-d H:i:s'))
            ->insert(TBL_SHOP_SEARCH_CATEGORY_RELATION)
            ->exec();
    }

    /**
     * 노출카테고리 업데이트
     * @param $dp_ix
     * @param $data
     * @throws \Exception
     */
    protected function updateRelation($ix, $data)
    {
        if (!empty($data['cid'])) {
            $this->qb
                ->where('cid', $data['cid']);
        }

        $this->qb
            ->set($data)
            ->set('regdate', date('Y-m-d H:i:s'))
            ->update(TBL_SHOP_SEARCH_CATEGORY_RELATION)
            ->where('st_ix', $ix)
            ->exec();
    }

    /**
     * 노출카테고리 삭제
     * @param $dp_ixs
     * @throws \Exception
     */
    public function deleteRelation($ix)
    {
        $this->qb
            ->delete(TBL_SHOP_SEARCH_CATEGORY_RELATION)
            ->where('st_ix', $ix)
            ->where('insert_yn', 'N')
            ->exec();
    }

    /**
     * 카테고리 상세
     * @param $ix
     * @return array
     * @throws \Exception
     */
    public function categoryRelation($ix)
    {
        /* @var $categoryModel \CustomScm\Model\Product\Category */
        $categoryModel = $this->import('model.scm.product.category');

        $rows = $this->qb
            ->select('scr.cid')
            ->select('ci.depth')
            ->from(TBL_SHOP_SEARCH_CATEGORY_RELATION . ' as scr')
            ->join(TBL_SHOP_CATEGORY_INFO . ' as ci', 'scr.cid=ci.cid', 'left')
            ->whereIn('st_ix', $ix)
            ->exec()
            ->getResultArray();

        foreach ($rows as $key => $row) {
            $row['path'] = implode(" > ", array_column($categoryModel->getCategoryPath($row['cid'], $row['depth']), 'cname'));
            $rows[$key] = $row;
        }

        return $rows;
    }

    /**
     * 검색창 키워드 삭제
     * @param $ix
     * @throws \Exception
     */
    public function del($ix)
    {
        $this->qb
            ->whereIn('st_ix', $ix)
            ->delete(TBL_SHOP_SEARCH_TEXT)
            ->exec();

        $this->qb
            ->whereIn('st_ix', $ix)
            ->delete(TBL_SHOP_SEARCH_CATEGORY_RELATION)
            ->exec();

        return true;
    }

    /**
     * 인기검색어 관리 리스트
     * @param int $page
     * @param int $max
     * @param array $where
     * @return array
     * @throws \Exception
     */
    public function getKeywordList($page = 1, $max = 5)
    {
        $this->qb->startCache();

        $this->qb
            ->from(TBL_SHOP_SEARCH_KEYWORD . ' AS k');

        $this->qb->stopCache();

        $total = $this->qb->getCount();

        $paging = $this->qb->setTotalRows($total)->pagination($page, $max);

        $list = $this->qb
            ->orderBy('ISNULL(k.sort), k.sort', 'ASC')
            ->orderBy('regdate', 'ASC')
            ->limit($max, ($paging['offset'] ?? 0))
            ->exec()
            ->getResultArray();

        $this->qb->flushCache();

        return [
            'total' => $total,
            'list' => $list,
            'paging' => $paging
        ];
    }

    /**
     * 인기검색어 삭제
     * @param $ix
     * @throws \Exception
     */
    public function delKeyword($ix)
    {
        $this->qb
            ->where('k_ix', $ix)
            ->delete(TBL_SHOP_SEARCH_KEYWORD)
            ->exec();
    }

    /**
     * 인기검색어 insert(table)
     * @param $data
     * @return bool|\NunaResult
     * @throws \Exception
     */
    public function insertKeyword($data)
    {
        $maxSort = $this->selectKeywordSortMax();

        return $this->qb
            ->set($data)
            ->set('sort', $maxSort['sort'])
            ->set('recommend', '0')
            ->set('disp', '1')
            ->set('regdate', date('Y-m-d H:i:s'))
            ->insert(TBL_SHOP_SEARCH_KEYWORD)
            ->exec();
    }

    /**
     * sort Max값
     * @return mixed
     * @throws \Exception
     */
    protected function selectKeywordSortMax()
    {
        return $this->qb
            ->select('MAX(sort + 1) AS sort')
            ->from(TBL_SHOP_SEARCH_KEYWORD)
            ->exec()
            ->getRowArray();
    }

    /**
     * 인기검색어 등록/수정
     * @param $data
     */
    public function putKeyword($data)
    {
        $keywordData = $this->qb->allowedFields($data, ['k_ix', 'keyword'], ['k_ix' => '']);

        if ($keywordData['k_ix']) {
            $this->updateKeyword($keywordData['k_ix'], $keywordData);
        } else {
            $this->insertKeyword($keywordData);
        }
    }

    /**
     * 인기검색어 update(table)
     * @param $ix
     * @param $data
     * @return bool|\NunaResult
     * @throws \Exception
     */
    public function updateKeyword($ix, $data)
    {
        return $this->qb
            ->set($data)
            ->update(TBL_SHOP_SEARCH_KEYWORD)
            ->where('k_ix', $ix)
            ->exec();
    }

    /**
     * 인기검색어 순서변경
     * @param $data
     * @throws \Exception
     */
    public function rank($data)
    {
        if (!empty($data['orgIdx']) && !empty($data['newIdx'])) {
            //순서변경
            $orgIdxSort = $this->selectKeywordRank($data['orgIdx']);
            $newIdxSort = $this->selectKeywordRank($data['newIdx']);

            $this->updateKeyword($data['newIdx'], $orgIdxSort);
            $this->updateKeyword($data['orgIdx'], $newIdxSort);
        } else {
            //위치이동
            foreach ($data['data']['data'] as $k => $v) {
                $updateData['sort'] = $v['__index'] + 1;
                $this->updateKeyword($v['k_ix'], $updateData);
            }
        }
    }

    /**
     * 검색어 조회수 리스트
     * @param int $page
     * @param int $max
     * @param array $where
     * @return array
     * @throws \Exception
     */
    public function getLogList($page = 1, $max = 5, $where = [])
    {
        $this->qb->startCache();

        $this->qb
            ->from(TBL_SHOP_SEARCH_KEYWORD_LOG)
            ->betweenDate('regdate', $where['startDate'], $where['endDate']);

        $this->qb->stopCache();

        $total = $this->qb->getCount('distinct keyword');

        $paging = $this->qb->setTotalRows($total)->pagination($page, $max);

        $list = $this->qb
            ->select('keyword')
            ->select('COUNT(*) AS views')
            ->groupBy('keyword')
            ->orderBy('views', 'DESC')
            ->orderBy('keyword', 'ASC')
            ->limit($max, ($paging['offset'] ?? 0))
            ->exec()
            ->getResultArray();

        $this->qb->flushCache();

        return [
            'total' => $total,
            'list' => $list,
            'paging' => $paging
        ];
    }

    /**
     * 인기검색어 순서
     * @param $ix
     * @return mixed
     * @throws \Exception
     */
    protected function selectKeywordRank($ix)
    {
        return $this->qb
            ->select('sort')
            ->from(TBL_SHOP_SEARCH_KEYWORD)
            ->where('k_ix', $ix)
            ->exec()
            ->getRowArray();
    }
}