<?php

/**
 * Description of ForbizMallEventController
 *
 * @author hong
 * @property CustomMallEventModel $eventModel
 */
class ForbizMallEventController extends ForbizMallController
{
    /**
     * 이벤트 모델
     */
    public $eventModel;
    
    public function __construct()
    {
        parent::__construct();
        $this->eventModel = $this->import('model.mall.event');
    }

    /**
     * 이벤트 리스트 출력
     */
    public function getEventList()
    {
        $res = $this->input->post();
        $orderBy = $res['orderBy'];
        $orderByType = $res['orderByType'];
        $page = $res['page'];
        $max = $res['max'];
        $erIx = $res['er_ix'] ?? '';
        $ingType = $res['ingType'] ?? 'ing';
        $where = [];
        if($ingType == 'ing'){
            $where['event_use_edate >='] = time() ;
        } elseif ($ingType == 'end') {
            $thirtyDays =  date('Y-m-d H:i:s', strtotime("-30 days") );
            $where['event_use_edate >='] = strtotime($thirtyDays);
            $where['event_use_edate <'] = time() ;
        }

        if(!empty($erIx)){
            $where['er_ix'] = $erIx;
        }

        $responseData = $this->eventModel->getEventList('E', $orderBy, $orderByType, $page, $max, $where);

        $this->setResponseResult('success')->setResponseData($responseData);
    }

    /**
     * 기획전 리스트 출력
     */
    public function getPromotionList()
    {
        $res = $this->input->post();
        $orderBy = $res['orderBy'];
        $orderByType = $res['orderByType'];
        $page = $res['page'];
        $max = $res['max'];
        $where = [];


        $responseData = $this->eventModel->getEventList('P', $orderBy, $orderByType, $page, $max, $where);

        $this->setResponseResult('success')->setResponseData($responseData);
    }

    /**
     * 이벤트 상세 댓글 출력
     */
    public function getCommentList()
    {
        $res = $this->input->post();
        $event_ix = $res['event_ix'];
        $orderBy = $res['orderBy'];
        $orderByType = $res['orderByType'];
        $page = $res['page'];
        $max = $res['max'];

        $responseData = $this->eventModel->getCommentList($event_ix, sess_val('user','code'), $orderBy, $orderByType, $page, $max);

        $this->setResponseResult('success')->setResponseData($responseData);
    }

    /**
     * 이벤트 댓글 등록 (유저당 하나의 댓글)
     */
    public function addCommentByUser()
    {
        $res = $this->input->post(null, true);
        $res['hp'] = sess_val('user', 'pcs');
        $event_ix = $res['event_ix'];
        $comment = $res['comment'];

        if (is_login()) {
            $userCode = sess_val('user', 'code');
            /* @var $bbsModel CustomMallBbsModel */
            $bbsModel = $this->import('model.mall.bbs');
            if ($bbsModel->spamCheck($res['comment'])) {
                return $this->setResponseResult('spam');
            }

            if ($this->eventModel->isUserComment($event_ix, $userCode)) {
                $this->setResponseResult('preAdd');
            } else {
                $this->eventModel->addParticipate($res, $userCode); //이벤트 참가
                $this->eventModel->addComment($event_ix, $userCode, $comment);  //댓글 등록
            }
        } else { //댓글 작성시 로그인
            $this->setResponseResult('loginFail');
        }
    }

    /**
     * 이벤트 댓글 등록
     */
    public function addComment()
    {
        $res = $this->input->post();
        $event_ix = $res['event_ix'];
        $comment = $res['comment'];

        /* @var $bbsModel CustomMallBbsModel */
        $bbsModel = $this->import('model.mall.bbs');
        if ($bbsModel->spamCheck($this->input->post('comment'))) {
            return $this->setResponseResult('spam');
        }

        if (is_login()) {
            $this->eventModel->addComment($event_ix, sess_val('user', 'code'), $comment);
        } else { //댓글 작성시 로그인
            $this->setResponseResult('loginFail');
        }
    }

    /**
     * 댓글 수정
     * @throws Exception
     */
    public function commentModify()
    {
        $res = $this->input->post();
        $event_ix = $res['event_ix'];
        $ec_ix = $res['ec_ix'];
        $comment = $res['comment'];

        /* @var $bbsModel CustomMallBbsModel */
        $bbsModel = $this->import('model.mall.bbs');
        if ($bbsModel->spamCheck($this->input->post('comment'))) {
            return $this->setResponseResult('spam');
        }

        $code = sess_val('user', 'code');

        $responseData = $this->eventModel->setCommentModify($event_ix, $code, $comment, $ec_ix);

        $this->setResponseResult('success')->setResponseData($responseData);
    }

    /**
     * 댓글 삭제
     */
    public function delComment()
    {
        $res = $this->input->post();
        $ec_ix = $res['ec_ix'];

        $responseData = $this->eventModel->delComment($ec_ix, sess_val('user', 'code'));
        $this->setResponseResult('success')->setResponseData($responseData);
    }

    /**
     * 이벤트 상세 댓글 출력
     */
    public function eventCommentList()
    {
        $res = $this->input->post();
        $event_ix = $res['event_ix'];
        $orderBy = $res['orderBy'];
        $orderByType = $res['orderByType'];
        $page = $res['page'];
        $max = $res['max'];

        $responseData = $this->eventModel->getEventCommentListAll($orderBy, $orderByType, $page, $max, $event_ix);
        $this->setResponseResult('success')->setResponseData($responseData);
    }

    /**
     * 이벤트 당첨여부
     */
    public function getUserPrize()
    {
        $post = $this->input->post();
        $event_ix = $post['event_ix'];

        if (is_login()) {
            $userCode = sess_val('user', 'code');

            $res = $this->eventModel->isUserPrize($event_ix, $userCode);

            if ($res === true) {
                $this->setResponseResult('success');
            } else if ($res == 'notApply') {
                $this->setResponseResult('notApply');
            } else {
                $this->setResponseResult('fail');
            }
        } else {
            $this->setResponseResult('loginFail');
        }
    }

}
