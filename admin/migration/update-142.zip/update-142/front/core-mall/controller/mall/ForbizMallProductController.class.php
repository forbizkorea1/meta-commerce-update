<?php

/**
 * Description of ForbizMallProductController
 *
 * @author hoksi
 */
class ForbizMallProductController extends ForbizMallController
{

    public function __construct()
    {
        parent::__construct();
    }

    public function getGoodsList()
    {
        /* 기본 필터 */
        $max = $this->input->post('max');
        $page = $this->input->post('page');
        $orderBy = $this->input->post('orderBy');

        /* 추가 필터 */
        $filter['filterCid'] = $this->input->post('filterCid');
        $filter['filterBrands'] = $this->input->post('filterBrands');
        $filter['filterDeliveryFree'] = $this->input->post('filterDeliveryFree');
        $filter['filterInsideText'] = $this->input->post('filterInsideText');
        $filter['filterText'] = $this->input->post('filterText');

        /* @var $productModel CustomMallProductModel */
        $productModel = $this->import('model.mall.product');

        $responseData = $productModel->getList($filter, $page, $max, $orderBy);
        if (!empty($responseData['list'])) {
            foreach ($responseData['list'] as $key => $row) {

                $row['isDiscount'] = ($row['listprice'] > $row['dcprice']) ? true : false;
                $row['listprice'] = g_price($row['listprice']);
                $row['dcprice'] = g_price($row['dcprice']);
                $row['sellprice'] = g_price($row['sellprice']);
                $row['status_soldout'] = ($row['status'] == 'soldout') ? true : false;
                $responseData['list'][$key] = $row;
            }
        }
        $responseData['filterInsideText'] = $filter['filterInsideText'];
        $this->setResponseResult('success')->setResponseData($responseData);
    }

    public function getGoodsSearchList()
    {
        /* 기본 필터 */
        $max = $this->input->post('max');
        $page = $this->input->post('page');
        $orderBy = $this->input->post('orderBy');

        /* 추가 필터 */
        $filter['filterCid'] = $this->input->post('filterCid');
        $filter['filterBrands'] = $this->input->post('filterBrands');
        $filter['filterDeliveryFree'] = $this->input->post('filterDeliveryFree');
        $filter['filterInsideText'] = $this->input->post('filterInsideText');
        $filter['filterText'] = $this->input->post('filterText');

        /* @var $productModel CustomMallProductModel */
        $productModel = $this->import('model.mall.product');

        $esConfig = ForbizConfig::getConfig('elasticsearch');
        if ($esConfig !== false && $esConfig['elasticsearch_use']) {
            $responseData = $productModel->getSearchList($filter, $page, $max, $orderBy);
        } else {
            $responseData = $productModel->getList($filter, $page, $max, $orderBy);
        }
        if (!empty($responseData['list'])) {
            foreach ($responseData['list'] as $key => $row) {

                $row['isDiscount'] = ($row['listprice'] > $row['dcprice']) ? true : false;
                $row['listprice'] = g_price($row['listprice']);
                $row['dcprice'] = g_price($row['dcprice']);
                $row['sellprice'] = g_price($row['sellprice']);
                $row['status_soldout'] = ($row['status'] == 'soldout') ? true : false;
                $responseData['list'][$key] = $row;
            }
        }
        $responseData['filterInsideText'] = $filter['filterInsideText'];
        $this->setResponseResult('success')->setResponseData($responseData);
    }

    public function getAutoSearchList()
    {
        /* @var $productModel CustomMallProductModel */
        $productModel = $this->import('model.mall.product');
        $responseData = $productModel->getAutoSearchList($this->input->post('searchText'));
        $this->setResponseResult('success')->setResponseData($responseData);
    }

    public function getCategorySubList()
    {
        $cid = $this->input->post('cid');

        /* @var $productModel CustomMallProductModel */
        $productModel = $this->import('model.mall.product');

        $responseData = $productModel->getCategorySubList($cid, true);
        $this->setResponseResult('success')->setResponseData($responseData);
    }

    /**
     * 미니카트에 사용할 옵션 데이터 호출
     * @param string $pid
     */
    public function loadOptionDatas($pid = null)
    {

        if ($pid) {
            $this->setResponseType('js'); //js 로 리턴

            /* @var $productModel CustomMallProductModel */
            $productModel = $this->import('model.mall.product');

            $productModel->setProductDiscount([$pid]);
            $options = $productModel->getOption($pid); //옵션 데이터 호출
            $buyCountCondition = $productModel->getBuyCountCondition($pid, sess_val('user', 'code')); //구매가능 조건(수량) 호출

            echo "var devOptionData = " . json_encode($options) . ";\n"
                . "var allow_basic_cnt = " . $buyCountCondition['allow_basic_cnt'] . ";\n" //구매허용 수량
                . "var allow_byoneperson_config_cnt = " . ($buyCountCondition['allow_byoneperson_cnt']) . ";\n" //인당 최대구매 수량. 옵션일 경우 계산하기 애매함. PM 협의필요.
                . "var allow_byoneperson_cnt = " . ($buyCountCondition['allow_byoneperson_cnt'] - $buyCountCondition['user_buy_cnt']) . ";\n"; //실제 구매가능한 인당 최대구매 수량. 옵션일 경우 계산하기 애매함. PM 협의필요.
        }
    }

    /**
     * 관심상품 추가, 삭제 기능
     */
    public function wish()
    {
        $chkField = ['pid'];

        if (form_validation($chkField)) {
            $pid = $this->input->post('pid');

            if ($pid == '') {
                $pid = $this->input->get('pid');
            }

            /* @var $wishModel CustomMallWishModel */
            $wishModel = $this->import('model.mall.wish');

            if ($wishModel->checkAlreadyWish($pid)) {
                $wishModel->deleteWish(array($pid));
                $this->setResponseResult('delete'); //삭제
            } else {
                $wishModel->insertWish($pid);
                $this->setResponseResult('insert'); //추가
            }
        } else {
            $this->setResponseResult('fail')->setResponseData(validation_errors());
        }
    }

    /**
     * 상품리뷰 리스트 출력
     */
    public function reviewLists()
    {
        $res = $this->input->post(); //데이터가 많아 배열로 넘김
        $res['pageType'] = 'prd';

        /* @var $reviewModel CustomMallProductReviewModel */
        $reviewModel = $this->import('model.mall.productReview');
        $responseData = $reviewModel->getReviewList($res);

        $this->setResponseResult('success')->setResponseData($responseData);
    }

    public function bestReviewLists()
    {
        $res = $this->input->post(); //데이터가 많아 배열로 넘김
        $res['pageType'] = 'bestReview';

        /* @var $reviewModel CustomMallProductReviewModel */
        $reviewModel = $this->import('model.mall.productReview');
        $responseData = $reviewModel->getReviewList($res);

        $this->setResponseResult('success')->setResponseData($responseData);
    }

    public function qnaCount()
    {
        $chkField = ['qnaDiv'];

        if (form_validation($chkField)) {
            /* @var $qnaModel CustomMallProductQnaModel */
            $qnaModel = $this->import('model.mall.productQna');
            $responseData = $qnaModel->getCount($this->input->post('id'), $this->input->post('qnaDiv'));

            $this->setResponseResult('success')->setResponseData($responseData);
        } else {
            $this->setResponseResult('fail')->setResponseData(validation_errors());
        }
    }

    /**
     * 상품문의 리스트 출력
     */
    public function qnaLists()
    {
        $chkField = ['id', 'qnaType', 'qnaDiv', 'max', 'page'];

        if (form_validation($chkField)) {
            $id = $this->input->post('id');
            $type = $this->input->post('qnaType'); //전체문의, 내문의
            $bbsDiv = $this->input->post('qnaDiv'); //문의분류
            $max = $this->input->post('max');
            $curPage = $this->input->post('page');

            /* @var $qnaModel CustomMallProductQnaModel */
            $qnaModel = $this->import('model.mall.productQna');
            $responseData = $qnaModel->getList($id, $type, $bbsDiv, $max, $curPage);

            $this->setResponseResult('success')->setResponseData($responseData);
        } else {
            $this->setResponseResult('fail')->setResponseData(validation_errors());
        }
    }

    /**
     * 상품문의 작성
     */
    public function qnaWrite()
    {
        $chkField = ['pid', 'subject', 'contents'];
        $productQnaSetting = ForbizConfig::getSharedMemory('product_qna');
        if ($productQnaSetting['use_div'] == 'Y') {
            $chkField[] = 'div';
        }

        if (form_validation($chkField)) {
            $res = $this->input->post(null, true); //데이터가 많아 배열로 넘김

            /* @var $bbsModel CustomMallBbsModel */
            $bbsModel = $this->import('model.mall.bbs');
            if ($bbsModel->spamCheck($res['subject']) ||
                $bbsModel->spamCheck($res['contents'])
            ) {
                return $this->setResponseResult('spam');
            }

            /* @var $qnaModel CustomMallProductQnaModel */
            $qnaModel = $this->import('model.mall.productQna');
            $responseData = $qnaModel->insertQna($res);

            if ($responseData) {
                $this->setResponseResult('success');
            } else {
                $this->setResponseResult('fail');
            }
        } else {
            $this->setResponseResult('fail')->setResponseData(validation_errors());
        }
    }

    public function downCoupon()
    {
        /* @var $fbEncryptModel CustomMallFbEncryptModel */
        $fbEncryptModel = $this->import('model.mall.fbEncrypt');
        /* @var $couponModel CustomMallCouponModel */
        $couponModel = $this->import('model.mall.coupon');

        $chkField = ['publishIx'];

        if (form_validation($chkField)) {
            $pid = $this->input->post('pid');
            $publishIx = $this->input->post('publishIx');
            $publishIx = $fbEncryptModel->decode($publishIx);

            //쿠폰 변조가 발생 할경우 자리수 체크
            if(strlen($publishIx) != 4){
                $this->setResponseResult('nonexistent');
            }else{
                //유효 쿠폰 체크
                $couponList = $couponModel->getMallCouponList($pid);
                $publishIxlist = array_column($couponList, 'publish_ix');
                $publishedCheck = array_column($couponList, 'isPublished', 'publish_ix');

                if(isset($publishIxlist) && isset($publishIx)){
                    if(in_array($publishIx, $publishIxlist)){
                        if(isset($publishedCheck[$publishIx])) {
                            if($publishedCheck[$publishIx]){
                                $this->setResponseResult('published');
                            }else{
                                $result = $couponModel->giveCoupon($publishIx, false, 2);
                                $this->setResponseResult($result);
                            }
                        }else{
                            $this->setResponseResult('checkpublishedfail');
                        }
                    }else{
                        $this->setResponseResult('invalid');
                    }
                }else{
                    $this->setResponseResult('checkvalidfail');
                }
            }
        } else {
            $this->setResponseResult('fail')->setResponseData(validation_errors());
        }
    }

    public function deleteRecentKeyword()
    {
        /* @var $productModel CustomMallProductModel */
        $productModel = $this->import('model.mall.product');
        $searchText = $this->input->post('searchText');
        $result = $productModel->deleteRecentKeyword($searchText);
        $this->setResponseResult($result);
    }

    public function deleteAllRecentKeyword()
    {
        /* @var $productModel CustomMallProductModel */
        $productModel = $this->import('model.mall.product');
        $result = $productModel->deleteAllRecentKeyword();
        $this->setResponseResult($result);
    }

    public function getPhotoReviewList()
    {
        $chkField = ['id'];

        if(form_validation($chkField)) {
            /* @var $reviewModel CustomMallProductReviewModel */
            $reviewModel = $this->import('model.mall.productReview');

            $responseData = $reviewModel->getPhotoReviewList($this->input->post(), $this->input->post('limit'));

            $this->setResponseResult('success')->setResponseData($responseData);
        } else {
            $this->setResponseResult('fail')->setResponseData(validation_errors());
        }
    }

    public function getReviewDetail()
    {
        $chkField = ['bbsIx'];

        if(form_validation($chkField)) {
            /* @var $reviewModel CustomMallProductReviewModel */
            $reviewModel = $this->import('model.mall.productReview');
            $res = $reviewModel->getReviewDetail($this->input->post('bbsIx'));

            $this->setResponseResult('success')->setResponseData($res);
        }else {
            $this->setResponseResult('fail')->setResponseData(validation_errors());
        }
    }
}