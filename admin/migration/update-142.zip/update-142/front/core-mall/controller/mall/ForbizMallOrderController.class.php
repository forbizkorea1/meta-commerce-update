<?php

/**
 * Description of ForbizMallOrderController
 *
 * @author hoksi
 */
class ForbizMallOrderController extends ForbizMallController
{

    public function __construct()
    {
        parent::__construct();
    }

    /**
     * 주문 배송지 조회
     */
    public function addressList()
    {
        /* @var $orderModel CustomMallOrderModel */
        $orderModel = $this->import('model.mall.order');
        $type = false;
        if($this->input->post('type')) {
            $type = $this->input->post('type');
        }
        $list = $orderModel->getAddressList(sess_val('user', 'code'), $type);

        $this->setResponseData(['list' => $list]);
    }

    /**
     * get 변동 주문 데이터
     */
    public function getChangeOrderData()
    {
        ////////////////////////////
        // 마스터 DB로 처리 START //
        start_master_db();
        ////////////////////////////
        $chkList = ['recipientList[]', 'payment[]'];

        if (form_validation($chkList)) {
            $recipientList = $this->input->post('recipientList');
            $coupon = $this->input->post('coupon');
            $couponType = $this->input->post('couponType');
            $payment = $this->input->post('payment');

            /* @var $cartModel CustomMallCartModel */
            $cartModel = $this->import('model.mall.cart');
            /* @var $couponModel CustomMallCouponModel */
            $couponModel = $this->import('model.mall.coupon');

            $summary = false;

            //주문 배송지별 상품 정보 등록
            foreach ($recipientList as $recipient) {
                //get 배송지별 상품 정보
                $zip = $recipient['zipcode'];
                $reGetCartBool = false;

                $cartRegistIx = ($coupon['cart'] ?? 0);
                if (is_array($coupon)) {
                    foreach ($coupon as $cartIx => $registIx) {
                        if (substr_count($cartIx, '|') > 0) {
                            $coupon[str_replace("|", ",", $cartIx)] = $registIx;
                            unset($coupon[$cartIx]);
                        }
                        if(empty($registIx)) {
                            unset($coupon[$cartIx]);
                        }
                    }
                }

                $list = [];
                $cartLastCartIx = '';
                if($cartRegistIx == 0){
                    if(empty($coupon)){
                        $coupon = ['cart' => null];
                    }
                }
                $cartList = $cartModel->get($recipient['cart_ix'], $zip, $coupon);

                if($coupon != 'false'){
                    $coupon['cart'] = $cartRegistIx;
                }

                if (!empty($cartList)) {
                    foreach ($cartList as $cartDataKey => $data) {
                        foreach ($data['deliveryTemplateList'] as $deliveryTemplateKey => $deliveryTemplate) {
                            foreach ($deliveryTemplate['productList'] as $key => $product) {
                                if ($cartRegistIx > 0 && $product['total_dcprice'] > 0) {
                                    $cartLastCartIx = $product['cart_ix'];
                                }

                                $list[] = $product;
                            }
                        }
                    }
                }

                $cartSummary = $cartModel->getSummary($cartList);
                $totalProductDcprice = $cartSummary['summary']['product_dcprice'];

                $cartCouponData = $couponModel->applyCartCoupon($cartRegistIx, $totalProductDcprice, $list);

                if ($cartCouponData !== false) {
                    $cartCouponData['type'] = 'CP';
                    $cartCouponData['title'] = ForbizConfig::getDiscount('CP');
                    $cartCouponData['last_cart_ix'] = $cartLastCartIx;
                    $cartCouponData['total_product_dcprice'] = $cartCouponData['targetPrice'];
                    $cartCouponData['cupon_div'] = $cartCouponData['cupon_div'];
                    $cartCouponData['sum_discount_amount'] = 0;
                    $cartCouponData['sum_headoffice_discount_amount'] = 0;
                    $reGetCartBool = true;
                }

                if ($reGetCartBool) {
                    $cartList = $cartModel->get($recipient['cart_ix'], $recipient['zipcode'], $coupon, $cartCouponData);
                } else {
                    $cartList = $cartModel->get($recipient['cart_ix'], $zip, $coupon);
                }
                $cartSummary = $cartModel->getSummary($cartList);

                if ($summary === false) {
                    $summary = $cartSummary['summary'];
                } else {
                    array_walk($summary, array($this, 'sumCartSummary'), $cartSummary['summary']);
                }
            }

            unset($summary['tax_price']);
            unset($summary['tax_free_price']);

            $summary['origin_payment_price'] = $summary['payment_price'];
            $summary['use_mileage'] = ($payment['mileage'] ?? 0);
            if ($summary['payment_price'] < $summary['use_mileage']) {
                $summary['use_mileage'] = $summary['payment_price'];
                $summary['payment_price'] = 0;
            } else {
                $summary['payment_price'] -= $summary['use_mileage'];
            }
            //주문정보 조회 및 처리
            $this->setResponseData($summary);
        } else {
            $this->setResponseResult('fail')->setResponseData(validation_errors());
        }

        ///////////////////////////
        // 마스터 DB로 처리 END //
        end_master_db();
        ///////////////////////////
    }

    /**
     * get 배송지 정보
     */
    public function getAddressBook()
    {
        $deliveryIx = $this->input->post('deliveryIx');

        /* @var $memberModel CustomMallMemberModel */
        $memberModel = $this->import('model.mall.member');

        $this->setResponseData($memberModel->getAddressBookItem(sess_val('user', 'code'), $deliveryIx));
    }

    /**
     * 결제 요청
     */
    public function paymentRequest()
    {
        ////////////////////////////
        // 마스터 DB로 처리 START //
        start_master_db();
        ////////////////////////////


        $buyer = $this->input->post('buyer');
        $recipientList = $this->input->post('recipientList');
        $coupon = $this->input->post('coupon');
        $payment = $this->input->post('payment');
        $beforePaymentSave = $this->input->post('beforePaymentSave');
        $pciIx = $this->input->post('pciIx') ?? false;
        $giftData = $this->input->post('giftData');
        $receipt = $this->input->post('receipt');

        /* @var $cartModel CustomMallCartModel */
        $cartModel = $this->import('model.mall.cart');
        /* @var $couponModel CustomMallCouponModel */
        $couponModel = $this->import('model.mall.coupon');
        /* @var $mileageModel CustomMallMileageModel */
        $mileageModel = $this->import('model.mall.mileage');

        $userCode = sess_val('user', 'code');

        $productListprice = 0;
        $productDcprice = 0;
        $totalDeliveryPrice = 0;
        $totalPrice = 0;
        $taxPrice = 0;
        $taxFreePrice = 0;

        $setProductUseCouponBool = false;
        $setProductCouponData = false;
        $cartCouponData = false;
        $reGetCartBool = false;

        $couponUsable = true;
        if (is_array($coupon)) {
            foreach ($coupon as $cartIx => $registIx) {
                if(!empty($registIx) && !$couponModel->checkCouponAvailable($registIx)) {
                    $couponUsable = false;
                }

                if (substr_count($cartIx, '|') > 0) {
                    $coupon[str_replace("|", ",", $cartIx)] = $registIx;
                    unset($coupon[$cartIx]);
                    if ($registIx > 0) {
                        $setProductUseCouponBool = true;
                    }
                }
            }
        }
        $cartRegistIx = ($coupon['cart'] ?? 0);

        // 사용 불가능한 쿠폰 존재
        if(!$couponUsable) {
            $this->setResponseResult("couponNotUsable")->setResponseData(false);
            return false;
        }
        

        foreach ($recipientList as $recipientKey => $recipient) {
            $list = [];
            $cartLastCartIx = '';
            $zip = $recipient['zipcode'];
            $cartList = $cartModel->get($recipient['cart_ix'], $zip, $coupon);

            if (!empty($cartList)) {
                foreach ($cartList as $cartDataKey => $data) {
                    foreach ($data['deliveryTemplateList'] as $deliveryTemplateKey => $deliveryTemplate) {
                        foreach ($deliveryTemplate['productList'] as $key => $product) {
                            $registIx = ($coupon[$product['cart_ix']] ?? 0);

                            if($setProductUseCouponBool && $registIx > 0 && $product['total_dcprice'] > 0) {
                                $_setProductCouponData = $couponModel->applyProductCoupon($registIx, $product['id'], $product['dcprice'],
                                    $product['total_dcprice']);
                                if ($_setProductCouponData !== false) {
                                    $_setProductCouponData['type'] = 'CP';
                                    $_setProductCouponData['title'] = ForbizConfig::getDiscount('CP');
                                    $_setProductCouponData['total_product_dcprice'] = $product['total_dcprice'];
                                    $setCartIxList = explode(",", $product['cart_ix']);
                                    $_setProductCouponData['last_cart_ix'] = array_pop($setCartIxList);
                                    $_setProductCouponData['sum_discount_amount'] = 0;
                                    $_setProductCouponData['sum_headoffice_discount_amount'] = 0;

                                    if ($setProductCouponData === false) {
                                        $setProductCouponData = [];
                                    }
                                    $setProductCouponData[$product['set_group']] = $_setProductCouponData;
                                    $reGetCartBool = true;
                                }
                            }else if ($cartRegistIx > 0 && $product['total_dcprice'] > 0) {
                                $cartLastCartIx = $product['cart_ix'];
                            }

                            $list[] = $product;
                        }
                    }
                }
            }

            $cartSummary = $cartModel->getSummary($cartList);
            $totalProductDcprice = $cartSummary['summary']['product_dcprice'];

            $cartCouponData = $couponModel->applyCartCoupon($cartRegistIx, $totalProductDcprice, $list);

            if ($cartCouponData !== false) {
                $cartCouponData['type'] = 'CP';
                $cartCouponData['title'] = ForbizConfig::getDiscount('CP');
                $cartCouponData['last_cart_ix'] = $cartLastCartIx;
                $cartCouponData['total_product_dcprice'] = $cartCouponData['targetPrice'];
                $cartCouponData['sum_discount_amount'] = 0;
                $cartCouponData['sum_headoffice_discount_amount'] = 0;
                $reGetCartBool = true;
            }

            if ($reGetCartBool) {
                $cartList = $cartModel->get($recipient['cart_ix'], $zip, $coupon, $cartCouponData, $setProductCouponData);
            } else {
                $cartList = $cartModel->get($recipient['cart_ix'], $zip, $coupon);
            }

            //상품 전체 판매중 검증
            if (!$cartModel->checkAllProductStatusSale($cartList)) {
                $this->setResponseResult('noProductStatusSale');
                return;
            }
            $cartSummary = $cartModel->getSummary($cartList);
            $productListprice += $cartSummary['summary']['product_listprice'];
            $productDcprice += $cartSummary['summary']['product_dcprice'];
            $totalDeliveryPrice += $cartSummary['summary']['total_delivery_price'];
            $totalPrice += $cartSummary['summary']['payment_price'];

            $taxPrice += $cartSummary['summary']['tax_price'];
            $taxFreePrice += $cartSummary['summary']['tax_free_price'];

            $recipientList[$recipientKey]['cartList'] = $cartList;
        }

        //마일리지 사용 검증 처리 [s]
        $mileage = ($payment['mileage'] ?? 0);
        if (!empty($userCode) && $mileage > 0) {
            $userMileage = $mileageModel->getUserAmount();

            $mileageFailData = [
                'mileageName' => $mileageModel->getName()
                , 'mileageUnit' => $mileageModel->getUnit()
            ];

            //보유하고 계신 {mileage} {mileageName} 이하로만 사용 가능합니다.
            if ($mileage > $userMileage) {
                $mileageFailData['mileage'] = number_format($userMileage);
                $this->setResponseResult('overUseMileage');
                $this->setResponseData($mileageFailData);
                return;
            }
            //보유 {mileageName}가 {mileage}{mileageUnit} 이상일 경우에만 사용 가능합니다.
            $mileageConditionMinMileage = $mileageModel->getConfig('min_mileage_price');
            if ($mileageConditionMinMileage > 0 && $userMileage < $mileageConditionMinMileage) {
                $mileageFailData['mileage'] = number_format($mileageConditionMinMileage);
                $this->setResponseResult('littleUserMinMileage');
                $this->setResponseData($mileageFailData);
                return;
            }

            //주문 상품 합계가 {price}원 이상일 경우에만 {mileageName}를 사용하실 수 있습니다.
            $mileageConditionIncludeDeliveryYn = $mileageModel->getConfig('deliveryprice');
            if ($mileageConditionIncludeDeliveryYn == 'Y') {
                $mileageTargetPrice = $totalPrice;
            } else {
                $mileageTargetPrice = $productDcprice;
            }
            $mileageConditionMinBuyAmt = $mileageModel->getConfig('total_order_price');
            if ($mileageConditionMinBuyAmt > 0 && $mileageTargetPrice < $mileageConditionMinBuyAmt) {
                $mileageFailData['price'] = number_format($mileageConditionMinBuyAmt);
                $this->setResponseResult('littleBuyAmt');
                $this->setResponseData($mileageFailData);
                return;
            }

            switch ($mileageModel->getConfig('mileage_one_use_type')) {
                case '1';
                    //보유 {mileageName}는 최대 {mileage}{mileageUnit}까지 사용 가능합니다.
                    $mileageConditionUseLimitValue = $mileageModel->getConfig('use_mileage_max');
                    if ($mileageConditionUseLimitValue > 0 && $mileage > $mileageConditionUseLimitValue) {
                        $mileageFailData['mileage'] = number_format($mileageConditionUseLimitValue);
                        $this->setResponseResult('overUseMaxmileagePrice');
                        $this->setResponseData($mileageFailData);
                        return;
                    }
                    break;
                case '2';
                    //보유 {mileageName}는 주문 상품 합계의 {rate}%인 {mileage}{mileageUnit}만 사용 가능합니다.
                    $mileageConditionUseLimitValue = $mileageModel->getConfig('max_goods_sum_rate');
                    $allowMileage = fb_round($mileageTargetPrice * $mileageConditionUseLimitValue / 100,'round');
                    if ($allowMileage < $mileage) {
                        $mileageFailData['rate'] = $mileageConditionUseLimitValue;
                        $mileageFailData['mileage'] = number_format($allowMileage);
                        $this->setResponseResult('overUseMaxmileageRate');
                        $this->setResponseData($mileageFailData);
                        return;
                    }
                    break;
            }

            //보유 {mileageName}는 최대 {mileage}{mileageUnit}까지 사용 가능합니다.
            if ($mileageTargetPrice < $mileage) {
                $mileageFailData['mileage'] = number_format((int)$mileageTargetPrice);
                $this->setResponseResult('overUseMaxmileagePrice');
                $this->setResponseData($mileageFailData);
                return;
            }

            //{mileageName}는 {unit}원 단위로 입력해 주세요.
            $mileageConditionUseUnit = $mileageModel->getConfig('use_unit');
            if ($mileageConditionUseUnit != '1') {
                $unitNum = $mileage % $mileageConditionUseUnit;
                if ($unitNum != 0) {
                    $mileageFailData['unit'] = $mileageConditionUseUnit;
                    $this->setResponseResult('noFormatMileage');
                    $this->setResponseData($mileageFailData);
                    return;
                }
            }
        }
        //마일리지 사용 조건 처리 [e]

        /* @var $orderModel CustomMallOrderModel */
        $orderModel = $this->import('model.mall.order');
        /* @var $memberModel CustomMallMemberModel */
        $memberModel = $this->import('model.mall.member');

        //주문번호 생성
        $oid = $orderModel->maxOid();

        $last_ode_ix = '';
        $last_odd_ix = '';
        $useMileage = 0; // 주문분할용 마일리지 사용분 저장
        $kindOrderProductLen = $orderModel->getKindOrderProduct($recipientList);
        $kindFlag = 1;

        //주문 배송지별 상품 정보 등록
        foreach ($recipientList as $recipient) {
            //배송지 등록
            $shippingData = [
                'name' => $recipient['name']
                , 'tel' => $recipient['tel']
                , 'mobile' => $recipient['mobile']
                , 'email' => ''
                , 'zip' => $recipient['zipcode']
                , 'addr1' => $recipient['address1']
                , 'addr2' => $recipient['address2']
                , 'msg_type' => $recipient['msg_type']
                , 'msg' => $recipient['msg']
                , 'door_msg' => (!empty($recipient['door_msg']) ? '('.$recipient['door_msg'].')' : '')
            ];
            $odd_ix = $orderModel->insertOrderShipping($oid, $shippingData);
            $last_odd_ix = $odd_ix;

            //배송지 목록에 추가
            if($recipient['basicAddressBookYn'] == 'Y'){
                //기본 배송지로 선택 시 배송지 목록에 추가 되어야 하기때문에 강제로 Y 처리
                $recipient['addAddressBookYn'] = 'Y';
            }
            if (!empty($userCode) && $recipient['addAddressBookYn'] == 'Y') {
                $addressBookData = [
                    'shipping_name' => $recipient['name']
                    , 'recipient' => $recipient['name']
                    , 'tel' => $recipient['tel']
                    , 'mobile' => $recipient['mobile']
                    , 'zipcode' => $recipient['zipcode']
                    , 'address1' => $recipient['address1']
                    , 'address2' => $recipient['address2']
                    , 'default_yn' => $recipient['basicAddressBookYn']
                ];

                $addressBookIx = $memberModel->searchAddressBook($userCode, $addressBookData);
                if ($addressBookIx !== false) {
                    $addressBookData['ix'] = $addressBookIx;
                    $addressBookData['mode'] = 'update';
                } else {
                    $addressBookData['mode'] = 'insert';
                }
                $memberModel->addressBookReplace($userCode, $addressBookData);
            }

            //get 배송지별 상품 정보
            foreach ($recipient['cartList'] as $cartCompany) {
                foreach ($cartCompany['deliveryTemplateList'] as $cartDeliveryTemplate) {
                    //배송비 등록
                    $deliveryData = [
                        'company_id' => $cartCompany['company_id']
                        , 'dt_ix' => $cartDeliveryTemplate['dt_ix']
                        , 'delivery_price' => $cartDeliveryTemplate['total_delivery_price'] //배송비
                        , 'delivery_dcprice' => $cartDeliveryTemplate['total_delivery_price'] //할인된최종배송비
                        , 'delivery_package' => $cartDeliveryTemplate['delivery_package'] //Y:개별배송 N:묶음배송
                        , 'delivery_policy' => $cartDeliveryTemplate['delivery_policy'] //1:무료배송 2:고정배송비 3:주문결제금액 할인 4:수량별할인 5:출고지별 배송비 6: 상품1개단위 배송비 9:클레임배송
                    ];
                    $ode_ix = $orderModel->insertOrderDelivery($oid, $deliveryData);
                    $last_ode_ix = $ode_ix;

                    foreach ($cartDeliveryTemplate['productList'] as $cartProduct) {
                        $mainPromotion = $this->input->cookie("main_promotion");
                        $eventContribution = $this->input->cookie("event_contribution");
                        $msgbyproduct = ""; //개별 배송메세지 - 복수 타입일때만 들어감
                        if (isset($recipient['product_msg'])) {
                            foreach ($recipient['product_msg'] as $key => $val) {
                                if ($cartProduct['cart_ix'] == $val['cart_ix']) {
                                    $msgbyproduct = $val['msg'];
                                } else {
                                    //세트 검출
                                    $cnt = 0;
                                    foreach (explode(",", $val['cart_ix']) as $value) {
                                        if ($cnt == 0) {
                                            if ($cartProduct['cart_ix'] == $value) {
                                                $msgbyproduct = $val['msg'];
                                            }
                                        }
                                        $cnt++;
                                    }
                                }
                            }
                        }

                        //상품 등록
                        if($cartProduct['product_type'] == PRODUCT_TYPE_SET){
                            $selectOptionIds = explode(',', $cartProduct['select_option_id']); // 원상품 옵션id
                            $setGroup = 0;
                            $etcJson = [];
                            $etcJson['setInfo'] = [];
                            foreach ($selectOptionIds as $oKey => $optionId) {

                                $setOpnInfo = $this->qb
                                    ->select('pcount')
                                    ->select('origin_pid')
                                    ->from(TBL_SHOP_CART_SET)
                                    ->where('cart_ix', $cartProduct['cart_ix'])
                                    ->where('opnd_ix', $optionId)
                                    ->exec()->getRowArray();

                                $option = $this->qb
                                    ->select('od.option_gid')
                                    ->select('od.option_code')
                                    ->from(TBL_SHOP_PRODUCT_OPTIONS_DETAIL . ' as od')
                                    ->where('od.id', $optionId)
                                    ->exec()->getRowArray();

                                $optionText = $cartModel->getProductOptionText($optionId, true, $cartProduct['id']);
                                $setProductData = [
                                    'set_group' => $setGroup
                                    , 'origin_pid' => $setOpnInfo['origin_pid']
                                    , 'option_id' => $optionId
                                    , 'options_text' => urlencode(trim(($optionText ?? '')))
                                    , 'ori_options_text' => trim(($optionText ?? ''))
                                    , 'set_pcount' => $setOpnInfo['pcount']
                                    , 'gid' => $option['option_gid']
                                    , 'pcode' => $option['option_code']
                                ];

                                $etcJson['setInfo'][] = $setProductData;

                                $setGroup++;
                            }

                            $cartProduct['etc_json'] = json_encode($etcJson);

                        }

                        $pt_dcprice = $cartProduct['total_coupon_with_dcprice'];

                        if($mileage > 0) {
                            // od_ix 기준 사용 마일리지 계산
                            if($totalPrice == 0 || $totalPrice == $mileage){ // 무료결제
                                $calUseReserve = $pt_dcprice;
                            } else {
                                if($kindOrderProductLen == $kindFlag){
                                    $calUseReserve =  $mileage - $useMileage;
                                } else {
                                    //  0 : 1자리 허용
                                    $calUseReserve = f_decimal($mileage * ($pt_dcprice/$productDcprice), 0, 'floor');
                                }
                            }
                        } else {
                            $calUseReserve = 0;
                        }

                        $cartProduct['use_reserve'] = $calUseReserve;
                        $pt_dcprice = $pt_dcprice-$calUseReserve; //최종할인가에서 사용한 마일리지 금액을 빼줌
                        $useMileage += $calUseReserve;
                        $kindFlag++;

                        //임직원, 제휴사 직원의 경우 할인기준이 정가 이므로 판매가는 정가가 됨.
                        //sellprice 를 변경안하면 할인율계산이 잘못되어 관리자에서 주문조회시 에러남.
                        if (in_array(sess_val('user', 'mem_type'), ['E', 'P'])) {
                            $sellPrice = $cartProduct['listprice'];
                        } else {
                            $sellPrice = $cartProduct['sellprice'];
                        }

                        $productData = [
                            'rfid' => $this->input->cookie("RFID")
                            , 'kwid' => $this->input->cookie("KWID")
                            , 'mpr_ix' => ($mainPromotion[$cartProduct['id']] ?? '')
                            , 'event_ix' => ($eventContribution[$cartProduct['id']] ?? '')
                            , 'buyer_type' => ($cartModel->getSellingType() == 'W' ? '2' : '1')//1:소매,2:도매
                            , 'order_from' => 'self'
                            , 'option_kind' => $cartProduct['option_kind']
                            , 'option_id' => $cartProduct['select_option_id']
                            , 'option_text' => $cartProduct['options_text']
                            , 'option_price' => $cartProduct['add_price']
                            , 'pcnt' => $cartProduct['pcount']
                            , 'listprice' => $cartProduct['listprice']
                            , 'psprice' => $sellPrice
                            , 'dcprice' => $cartProduct['dcprice']
                            , 'ptprice' => $sellPrice * $cartProduct['pcount']
                            , 'pt_dcprice' => $pt_dcprice
                            , 'reserve' => $cartProduct['mileage']
                            , 'use_reserve' => $cartProduct['use_reserve']
                            , 'msgbyproduct' => $msgbyproduct
                            , 'cart_ix' => $cartProduct['cart_ix']
                            , 'etc_json' => $cartProduct['etc_json'] ?? json_encode([])
                            , 'hash_idx' => $cartProduct['hash_idx']
                        ];

                        if($cartProduct['product_type'] == PRODUCT_TYPE_SET){
                            $pcodeRes = $this->qb
                                ->select('pcode')
                                ->from(TBL_SHOP_PRODUCT)
                                ->where('id', $cartProduct['id'])
                                ->exec()->getRowArray();
                            $productData['pcode'] = $pcodeRes['pcode'] ?? '';
                        }

                        //특별할인 체크
                        $specialDiscountIndex = array_search('SP', array_column($cartProduct['discountList'], 'type'));
                        if ($specialDiscountIndex !== false) {
                            $productData['special_discount_yn'] = 'Y';
                            $productData['special_discount_commission'] = $cartProduct['discountList'][$specialDiscountIndex]['commission'];
                        }

                        $od_ix = $orderModel->insertOrderProduct(MALL_IX, $oid, $cartProduct['id'], $ode_ix, $odd_ix, $productData);

                        //세트상품 주문정보 입력
//                        if(!empty($etcJson['setInfo']) && $cartProduct['product_type'] == PRODUCT_TYPE_SET) {
//                            foreach ($etcJson['setInfo'] as $data) {
//                                $data['od_ix'] = $od_ix;
//                                $orderModel->insertOrderProductSetInfo($data);
//                            }
//                        }

                        //상품 할인 정보 등록
                        foreach ($cartProduct['discountList'] as $cartDiscount) {
                            if ($cartDiscount['type'] != 'IN') { //즉시 할인 제외
                                //상품 등록
                                $discountData = [
                                    'dc_type' => $cartDiscount['type']
                                    , 'dc_title' => $cartDiscount['title']
                                    , 'dc_rate' => $cartDiscount['sale_value']
                                    , 'dc_price' => $cartDiscount['discount_amount']
                                    , 'dc_price_admin' => $cartDiscount['headoffice_discount_amount']
                                    , 'dc_price_seller' => $cartDiscount['seller_discount_amount']
                                    , 'dc_msg' => $cartDiscount['description']
                                    , 'dc_ix' => $cartDiscount['code']
                                ];
                                if ($cartDiscount['sale_type'] == "1") {
                                    $discountData['dc_rate_admin'] = $cartDiscount['headoffice_sale_value'];
                                    $discountData['dc_rate_seller'] = $cartDiscount['seller_sale_value'];
                                } else {
                                    $discountData['dc_rate_admin'] = 0;
                                    $discountData['dc_rate_seller'] = 0;
                                }
                                $orderModel->insertOrderDiscount($oid, $od_ix, '', $discountData);
                            }
                        }
                        //추가 상품 등록
                        foreach ($cartProduct['addOptionList'] as $cartAddOption) {
                            //위 상품정보 기본으로 받아서 처리
                            $productData['option_kind'] = 'a';
                            $productData['option_id'] = $cartAddOption['opn_d_ix'];
                            $productData['option_text'] = $cartAddOption['opn_text'];
                            $productData['option_price'] = 0;
                            $productData['pcnt'] = $cartAddOption['opn_count'];
                            $productData['listprice'] = $cartAddOption['listprice'];
                            $productData['psprice'] = $cartAddOption['sellprice'];
                            $productData['dcprice'] = $cartAddOption['dcprice'];
                            $productData['ptprice'] = $cartAddOption['total_dcprice'];
                            $productData['pt_dcprice'] = $cartAddOption['total_dcprice'];
                            $productData['reserve'] = $cartAddOption['mileage'];
                            $productData['use_reserve'] = 0;

                            $orderModel->insertOrderProduct(MALL_IX, $oid, $cartProduct['id'], $ode_ix, $odd_ix, $productData);
                        }

                    }
                }
            }
        }

        // 사은품 등록
        if(is_array($giftData) && !empty($giftData)) {
            /* @var $productModel CustomMallProductModel */
            $productModel = $this->import('model.mall.product');

            foreach ($giftData as $gift) {
                $pgIx = $gift['product']['pgIx'];
                $giftProduct = $productModel->getGiftProductInfo($gift['product']['pid']);

                $giftProductData = [
                    'rfid' => $this->input->cookie("RFID")
                    , 'kwid' => $this->input->cookie("KWID")
                    , 'event_ix' => $pgIx
                    , 'order_from' => 'self'
                    , 'option_kind' => $giftProduct['option_kind']
                    , 'option_id' => $giftProduct['select_option_id']
                    , 'option_text' => $giftProduct['options_text']
                    , 'option_price' => $giftProduct['option_price']
                    , 'pcnt' => 1
                    , 'listprice' => $giftProduct['listprice']
                    , 'psprice' => $giftProduct['sellprice']
                    , 'dcprice' => $giftProduct['sellprice']
                    , 'ptprice' => $giftProduct['sellprice']
                    , 'pt_dcprice' => $giftProduct['sellprice']
                    , 'reserve' => 0
                    , 'cid' => '000000000000000'
                    , 'msgbyproduct' => ''
                    , 'cart_ix' => ''
                    , 'hash_idx' => ''
                ];

                $orderModel->insertOrderProduct(MALL_IX, $oid, $gift['product']['pid'], $last_ode_ix, $last_odd_ix, $giftProductData);
            }
        }

        //주문 정보 등록

        $paymentPrice = $totalPrice - $mileage; //결제금액(예치금,포인트,적립금차감금액)

        $orderData = [
            'order_pw' => ($buyer['password'] ?? '')
            , 'buyer_type' => ($cartModel->getSellingType() == 'W' ? '2' : '1') //1:소매,2:도매
            , 'user_code' => $userCode
            , 'user_com_id' => sess_val('user', 'company_id')
            , 'buserid' => sess_val('user', 'id')
            , 'bname' => $buyer['name']
            , 'sex' => sess_val('user', 'sex')
            , 'age' => sess_val('user', 'age')
            , 'gp_ix' => sess_val('user', 'gp_ix')
            , 'mem_group' => sess_val('user', 'gp_name')
            , 'btel' => $buyer['tel'] ?? ''
            , 'bmobile' => $buyer['mobile']
            , 'bmail' => $buyer['email'] ?? ''
            , 'bzip' => ''
            , 'baddr' => ''
            , 'mem_reg_date' => sess_val('user', 'mem_reg_date')
            , 'org_delivery_price' => $totalDeliveryPrice
            , 'delivery_price' => $totalDeliveryPrice
            , 'org_product_price' => $productListprice
            , 'product_price' => $productDcprice
            , 'total_price' => $totalPrice
            , 'payment_price' => $paymentPrice
            , 'user_ip' => $this->input->server('REMOTE_ADDR')
            , 'user_agent' => $this->input->server('HTTP_USER_AGENT')
            , 'payment_agent_type' => (is_mobile() ? "M" : "W")
        ];
        if (getAppType()) {
            $orderData['payment_agent_type'] = 'A';
        }

        $orderModel->insertOrder($oid, $orderData);

        //주문 금액 등록
        $priceData = [
            'expect_price' => $orderData['product_price']
            , 'payment_price' => 0
            , 'reserve' => $mileage
        ];
        $orderModel->insertOrderPrice($oid, 'G', 'P', $priceData);
        if ($orderData['delivery_price'] > 0) {
            $priceData = [
                'expect_price' => $orderData['delivery_price']
                , 'payment_price' => 0
            ];
            $orderModel->insertOrderPrice($oid, 'G', 'D', $priceData);
        }

        //주문 결제 등록
        $taxData = $orderModel->calculationPaymentPriceTaxRate($taxPrice, $taxFreePrice, $mileage);
        $paymentData = [
            'tax_price' => $taxData['taxPrice']
            , 'tax_free_price' => $taxData['taxFreePrice']
        ];
        if ($paymentPrice == 0) {
            $paymentMethod = ORDER_METHOD_NOPAY;
        } else {
            $paymentMethod = $payment['method'];
        }

        if($paymentMethod == ORDER_METHOD_BANK) {
            $cancelAutoDay = ForbizConfig::getMallConfig('mall_cc_interval');
            $holiday_text = ForbizConfig::getMallConfig('holiday_text');
            if (empty($cancelAutoDay)) {
                $vbankExpirationDate = date('Ymd', strtotime('+7 day'));
            } else {
                $vbankExpirationDate = $this->holiday($holiday_text, $cancelAutoDay);
            }
            $paymentData['bank_input_date'] = $vbankExpirationDate;
            $bankIx = $receipt['bank_ix'] ?? '';
            $bankInfo = $orderModel->getOrderBank($bankIx);
            $paymentData['bank'] = $bankInfo['bank_name'] ?? '';
            $paymentData['bank_account_num'] = $bankInfo['bank_number'] ?? '';
            $paymentData['bank_input_name'] = $bankInfo['bank_owner'] ?? '';

            //$paymentData['receipt_yn'] = $receipt['receipt_type'] == 0 ? 'N' : 'Y';
            //$paymentData['receipt_type'] = $receipt['receipt_type'] ?? '';
            //$paymentData['receipt_applyNum'] = $receipt['receipt_applyNum'] ?? '';
        }

        $orderModel->insertOrderPayment($oid, 'G', ORDER_STATUS_INCOM_READY, $paymentMethod, $paymentPrice, $paymentData);

        if ($mileage > 0) {
            $paymentData = [
                'tax_price' => $taxData['mileageTaxPrice']
                , 'tax_free_price' => $taxData['mileageTaxFreePrice']
            ];
            $orderModel->insertOrderPayment($oid, 'G', ORDER_STATUS_INCOM_READY, ORDER_METHOD_RESERVE, $mileage, $paymentData);

            //상품별 마일리지 분할 정보 등록
            $orderModel->insertOrderMileageDivision($oid,$totalPrice,$mileage);
        }



        //주문 히스토리 등록
        $historyData = [
            'status_message' => '주문데이터생성'
            , 'admin_message' => 'system'
        ];
        $orderModel->insertOrderHistory($oid, '', ORDER_STATUS_SETTLE_READY, $historyData);

        //주문번호 FlashData 생성
        $this->setFlashData('payment_oid', $oid);

        //주문정보 조회 및 처리
        $responseData = [
            'oid' => $oid
            , 'payment' => [
                'method' => $paymentMethod
                , 'payment_price' => $paymentPrice
            ]
        ];
        $this->setResponseData($responseData);

        ///////////////////////////
        // 마스터 DB로 처리 END //
        end_master_db();
        ///////////////////////////
    }

    /**
     * 무료 결제 처리
     */
    public function paymentFree()
    {
        ////////////////////////////
        // 마스터 DB로 처리 START //
        start_master_db();
        ////////////////////////////

        $oid = $this->getFlashData('payment_oid');

        /* @var $orderModel CustomMallOrderModel */
        $orderModel = $this->import('model.mall.order');
        /* @var $cartModel CustomMallCartModel */
        $cartModel = $this->import('model.mall.cart');
        if (!empty($oid)) {
            if ($orderModel->isFreeOrderSettleReady($oid)) {
                //결제 처리
                $orderModel->payment($oid, ORDER_METHOD_NOPAY, ORDER_STATUS_INCOM_COMPLETE);
                //카트 삭제
                $products = $orderModel->getOrderProduct($oid);
                $cartIxs = [];
                foreach ($products as $product) {
                    $cartIxs[] = $product['cart_ix'];
                }
                $cartIxs = array_unique($cartIxs);
                $cartModel->delete($cartIxs);
                //주문번호 FlashData 생성
                $this->setFlashData('payment_oid', $oid);
            } else {
                $this->setResponseResult('noSettleReady');
            }
        } else {
            $this->setResponseResult('noOid');
        }

        ///////////////////////////
        // 마스터 DB로 처리 END //
        end_master_db();
        ///////////////////////////
    }

    /**
     * 무통장 결제 처리
     */
    public function paymentBank()
    {
        ////////////////////////////
        // 마스터 DB로 처리 START //
        start_master_db();
        ////////////////////////////

        $oid = $this->getFlashData('payment_oid');

        /* @var $orderModel CustomMallOrderModel */
        $orderModel = $this->import('model.mall.order');
        /* @var $cartModel CustomMallCartModel */
        $cartModel = $this->import('model.mall.cart');
        if (!empty($oid)) {
            if ($orderModel->isBankOrderSettleReady($oid)) {
                //결제 처리
                $orderModel->payment($oid, ORDER_METHOD_BANK, ORDER_STATUS_INCOM_READY);
                //카트 삭제
                $products = $orderModel->getOrderProduct($oid);
                $cartIxs = [];
                foreach ($products as $product) {
                    $cartIxs[] = $product['cart_ix'];
                }
                $cartIxs = array_unique($cartIxs);
                $cartModel->delete($cartIxs);
                //주문번호 FlashData 생성
                $this->setFlashData('payment_oid', $oid);
            } else {
                $this->setResponseResult('noSettleReady');
            }
        } else {
            $this->setResponseResult('noOid');
        }

        ///////////////////////////
        // 마스터 DB로 처리 END //
        end_master_db();
        ///////////////////////////
    }

    /**
     * PG 결제 처리
     */
    public function paymentGateway()
    {
        ////////////////////////////
        // 마스터 DB로 처리 START //
        start_master_db();
        ////////////////////////////

        $oid = $this->getFlashData('payment_oid');
        $method = $this->input->post('method');
        $agentType = $this->input->post('agentType');

        /* @var $orderModel CustomMallOrderModel */
        $orderModel = $this->import('model.mall.order');
        if (!empty($oid)) {
            if ($orderModel->isOrderSettleReady($oid, $method)) {
                /* @var $paymentGatewayModel CustomMallPaymentGatewayModel */
                $paymentGatewayModel = $this->import('model.mall.payment.gateway');
                $paymentGatewayModel->init($paymentGatewayModel->getPayModuleNameByMethod($method), $agentType);

                $order = $orderModel->getOrder($oid);
                $products = $orderModel->getOrderProduct($oid);

                $orderMainGoodsName = "";
                $orderProductName = "";
                $totalPcnt = 0;
                foreach ($products as $product) {
                    if (empty($orderMainGoodsName)) {
                        $orderMainGoodsName = $orderProductName = $product['pname'];
                    }
                    $totalPcnt += $product['pcnt'];
                }
                $orderProductCnt = count($products);
                $orderProductName = str_cut($orderProductName, 39);
                if ($orderProductCnt > 1) {
                    $orderProductName = $orderProductName . " 외 " . ($orderProductCnt - 1) . "건";
                }

                $paymentInfos = $orderModel->getPaymentInfo($oid, 'G');
                $paymentInfo = [];
                foreach ($paymentInfos as $payInfo) {
                    if ($payInfo['method'] == $method) {
                        $paymentInfo = $payInfo;
                        break;
                    }
                }

                $pgPaymentData = new PgForbizPaymentData();
                $pgPaymentData->oid = $oid;
                $pgPaymentData->goodsCount = $orderProductCnt;
                $pgPaymentData->totalPcnt = $totalPcnt;
                $pgPaymentData->mainGoodsName = $orderMainGoodsName;
                $pgPaymentData->goodsName = $orderProductName;
                $pgPaymentData->amt = $paymentInfo['payment_price'];
                $pgPaymentData->taxAmt = $paymentInfo['tax_price'];
                $pgPaymentData->taxExAmt = $paymentInfo['tax_free_price'];
                $pgPaymentData->method = $paymentInfo['method'];
                $pgPaymentData->buyerId = $order['buserid'];
                $pgPaymentData->buyerName = $order['bname'];
                $pgPaymentData->buyerMobile = $order['bmobile'];
                $pgPaymentData->buyerEmail = $order['bmail'];
                $pgPaymentData->goodsList = $products;
                if ($method == ORDER_METHOD_VBANK || $method == ORDER_METHOD_ESCROW_VBANK) {
                    $cancelAutoDay = ForbizConfig::getMallConfig('mall_cc_interval');
                    $holiday_text = ForbizConfig::getMallConfig('holiday_text');
                    if (empty($cancelAutoDay)) {
                        $vbankExpirationDate = date('Ymd', strtotime('+7 day'));
                    } else {
                        $vbankExpirationDate = $this->holiday($holiday_text, $cancelAutoDay);
                    }
                    $pgPaymentData->vbankExpirationDate = $vbankExpirationDate;
                }

                $this->setResponseData([
                    'html' => $paymentGatewayModel->requestPaymentForm($pgPaymentData)
                ]);
            } else {
                $this->setResponseResult('noSettleReady');
            }
        } else {
            $this->setResponseResult('noOid');
        }

        ///////////////////////////
        // 마스터 DB로 처리 END //
        end_master_db();
        ///////////////////////////
    }

    /**
     * cart summary data sum
     * @param type $value
     * @param type $key
     * @param type $data
     */
    protected function sumCartSummary(&$value, $key, $data)
    {
        if ($key == 'productDiscountList') {
            foreach ($value as $discount) {
                if (!isset($data['productDiscountList'])) {
                    $data['productDiscountList'] = [];
                }
                $index = array_search($discount['type'], array_column($data['productDiscountList'], 'type'));
                if ($index === false) {
                    $data['productDiscountList'][] = [
                        'type' => $discount['type']
                        , 'title' => $discount['title']
                        , 'discount_amount' => $discount['discount_amount']
                    ];
                } else {
                    $data['productDiscountList'][$index]['discount_amount'] += $discount['discount_amount'];
                }
            }
        } else {
            if (!isset($data[$key])) {
                $data[$key] = 0;
            }
            $data[$key] += $value;
        }
    }

    /**
     * vbankExpirationDate  생성
     * 관리자 자동 주문 취소일 + 주말 + 휴가 일 만큼 더하고 날짜로 반환
     * @return date
     */
    protected function holiday($holiday_text = "", $mall_cc_interval = 7)
    {
        $order_date = date('Ymd'); //오늘 주문일        
        $ex_holiday = explode(',', $holiday_text); //추가 휴일

        //영업일 기준으로 일단 형변환해서 날짜를 가지고 있음
        $date = date('Ymd', strtotime($order_date));  //비교 날짜
        $odate = date('Ymd', strtotime($order_date)); //입금 날짜

        //자동 취소일 만큼 실행
        for ($i = 0; $mall_cc_interval >= 0; $i++) {
            $is_holiy = false; //휴일 인지 여부 체크
            //해당일이 토요일 일요일 인지 구분
            if (date('w', strtotime($date)) == 0 || date('w', strtotime($date)) == 6) {
                $is_holiy = true;
            } else {
                //나머지 평일 ** 휴일 + 공휴일이 겹쳐도 카운트 되지 않음 평일만 뽑기때문
                //설정 휴일 값 계산
                foreach ($ex_holiday as $key => $val) {
                    //현재 날짜와 휴일 값이 같으면 휴일로 추가
                    if (strtotime($val) && strtotime($val) == strtotime($date)) {
                        $is_holiy = true;
                    }
                }
            }

            if ($is_holiy) {
                //휴일 추가
                $odate = date('Ymd', strtotime($odate . '+1 day'));
            } else {
                //일반 영업일 추가 일반일 이니 루프 카운트 차감 * 차감 로직상 0 번째는 더하지 않음
                if ($mall_cc_interval > 0) {
                    $odate = date('Ymd', strtotime($odate . '+1 day'));
                }
                $mall_cc_interval--;
            }

            //비교날짜 +1
            $date = date('Ymd', strtotime($date . '+1 day'));

            //무한 루프 방지. 최대 365일을 넘어갈수는 없다.
            if ($i >= 365) break;
        }

        return $odate;
    }
}