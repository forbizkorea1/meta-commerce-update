<?php
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace ForbizScm\Controller\System;

/**
 * Description of Login
 *
 * @author hoksi
 *
 * @property \CustomScm\Model\Login $loginModel Login 처리 모델
 */
class Login extends \ForbizAdminController
{
    protected $loginModel;

    public function __construct()
    {
        // Admin 로그인 여부 확인 안함
        parent::__construct(false);

        // Login 모델
        $this->loginModel = $this->import('model.scm.login');
    }

    /**
     * 로그인 화면
     */
    public function index($type = 'login')
    {
        /* @var $memberModel \CustomScm\Model\Member\Member */
        $memberModel = $this->import('model.scm.member.member');

        $this->setDefine($type);

        // 모달
        $this->define('searchIdPwModal', 'modal/searchIdPwModal');


        if ($memberModel->chkAdminId() === false) {
            //어드민 권한 계정 0일 때 첫 계정 세팅 위자드 호출
            redirect('/system/wizard');
        } else {
            $this->setLayout('layout_none');
        }

        $this->setResponseData('existsAdminInfo', $memberModel->existsAdminInfo());
    }

    protected function setDefine($type)
    {
        // Login 모델
        $login = $this->import('model.scm.login');

        if ($type == 'certification') {
            // 2차인증 설정여부 확인
            $data['secondary_authentication_use'] = \ForbizConfig::getPrivacyConfig('secondary_authentication_use');

            $this->setResponseData('charger_id', sess_val('admininfo', 'charger_id'));

            // 로그인한 상태인지?
            if (is_login() && $data['secondary_authentication_use'] == 'Y') {

                // 2차 인증 정보 삭제
                $_SESSION['secondary_auth'] = '';

                // 휴대폰 번호 가져오기
                $pcs = $login->getSmsNumber(sess_val('admininfo', 'charger_ix'));

                $sendSuccess = sendAuthMessage($pcs);

                // 인증문자 발송
                if($sendSuccess === true) {
                    $this->define('loginForm', 'loginSub/certification');
                } else {
                    $this->getAdminUrl('certification');
                }
            } else {
                redirect('/system/login');
            }
        } else {
            $this->define('loginForm', 'loginSub/login');
        }
    }

    public function getCapcha()
    {
        $cap = $this->loginModel->createCaptcha();
        $this->setFlashData('captcha_text', $cap['word']);
        $this->setResponseResult('captcha')->setResponseData(['capcha_img' => $cap['image']]);
    }

    /**
     * 관리자 로그인
     */
    public function getVerify()
    {
        $chkField = ['id', 'pw'];

        if (form_validation($chkField)) {
            $userId = $this->input->post('id'); //회원ID
            $userPw = $this->input->post('pw'); //회원비밀번호

            if ($this->chkCaptchaText($this->input->post('captcha_text'), $userId)) {
                // 로그인
                $ret = $this->loginModel->doLogin($userId, $userPw);
            } else {
                $ret = 'notMatch';
            }

            $this->setResponseResult($ret);

            switch ($ret) {
                case 'notMatch':
                case 'fail':
                    if ($this->loginModel->checkCapcha($userId)) {
                        $cap = $this->loginModel->createCaptcha();

                        $this->setFlashData('captcha_text', $cap['word']);
                        $this->setResponseResult(($ret == 'fail' ? 'captcha' : $ret))->setResponseData(['capcha_img' => $cap['image']]);
                    }

                    break;
                case 'success':
                    $this->loginModel->chkLicense();

                    $this->loginModel->resetFailCount($userId);
                    $this->setResponseData(['url' => '/system/login/getAdminUrl']);
                    break;

            }
        } else {
            $this->setResponseResult('fail')->setResponseData(validation_errors());
        }
    }

    public function getVerifyAuth() {
        $chkField = ['second_login'];

        if (form_validation($chkField)) {
            $now = time();
            $create_time = sess_val('secondary_auth', 'create_time');
            $sec = $now - intval($create_time);

            if($sec > 120){
                $_SESSION['secondary_auth'] = '';
                $this->setResponseResult('certifyExpire')->setResponseData([
                    'msg' => '인증코드 유효 시간이 만료되었습니다. 다시 로그인 해주세요.',
                ]);
            } else {
                $second_login = $this->input->post('second_login');

                if ($second_login == sess_val('secondary_auth', 'number')) {
                    $url = $this->getAdminUrl('getUrl');
                    $url = ($url == '' ? '/system/login' : $url);

                    $_SESSION['secondary_auth'] = '';
                    $_SESSION['smsAuth'] = true;

                    $this->setResponseResult('success')->setResponseData([
                        'url' => $url,
                    ]);
                } else {
                    $this->setResponseResult('fail')->setResponseData([
                        'msg' => '2차 인증 코드가 잘못 되었습니다.',
                    ]);
                }
                if ($this->isChangPaaword() === true) {
                    $this->setResponseData(['url' => '/system/changePasswd']);
                }
            }
        } else {
            $this->setResponseResult('fail')->setResponseData(validation_errors());
        }
    }

    /**
     * 로그인여부 확인 후 관리자 화면으로 이동
     */
    public function getAdminUrl($type = 'login')
    {
        // 관리자 권한을 가지고 있는가?
        $url = $this->loginModel->isLogin();

        if ($url) {
            if ($type == 'getUrl') {
                return $url;
            } else if ($type == 'certification') {
                $_SESSION['smsAuth'] = true;
                $msg = "잔여 SMS 발송 건수가 0건 입니다. SMS 발송이 불가하여 정상적인 서비스 이용이 어려울 수 있으니 확인 후 충전해 주세요.";
                if ($this->isChangPaaword() === true) {
                    $url = '/system/changePasswd';
                }
                echo "<script>alert('{$msg}');location.replace('{$url}');</script>";
            } else if ($type == 'nextChange') {
                redirect($url);
            } else {
                // 2차인증 설정여부 확인
                $secondary_authentication_use = \ForbizConfig::getPrivacyConfig('secondary_authentication_use');
                if ($secondary_authentication_use == 'Y') {
                    $_SESSION['secondary_auth'] = '';
                    redirect('/system/login/certification');
                } else {
                    $_SESSION['smsAuth'] = true;
                    if ($this->isChangPaaword() === true) {
                        $url = '/system/changePasswd';
                    }
                    redirect($url);
                }
            }
        } else {
            redirect('/system/login');
        }

    }

    /**
     * 마스터 계정 ID, PW 찾기
     */
    public function getIdPw()
    {
        $type = $this->input->post('findType');

        if ($type == 'id') {
            $checkForm = ['com_name', 'pcs_1', 'pcs_2', 'pcs_3', 'com_number_1', 'com_number_2', 'com_number_3'];
        } else {
            $checkForm = ['id', 'pcs_1', 'pcs_2', 'pcs_3', 'com_number_1', 'com_number_2', 'com_number_3'];
        }

        if (form_validation($checkForm)) {
            if ($type == 'id') {
                $result = $this->loginModel->getMasterId($this->input->post());

                if ($result !== false) {
                    $this->setResponseResult('success')->setResponseData($result);
                } else {
                    $this->setResponseResult('fail');
                }

            } else {
                $result = $this->loginModel->getMasterPw($this->input->post());

                if ($result !== false) {
                    $this->setResponseResult('success')->setResponseData($result);
                } else {
                    $this->setResponseResult('fail');
                }
            }
        } else {
            $this->setResponseResult('fail')->setResponseData(validation_errors());
        }
    }

    /**
     * 입력된 캡차 텍스트를 비교한다.
     * @param string $userText 사용자가 입력한 캡차 문자열
     * @param string $userId 회원ID
     * @return boolean
     */
    protected function chkCaptchaText($userText, $userId)
    {
        $captchaText = $this->getFlashData('captcha_text'); //캡차텍스트

        if ($captchaText != '') {
            if ($userText == '' || $captchaText != $userText) {
                return false;
            }
        } else {
            if ($this->loginModel->checkCapcha($userId)) {
                return false;
            }
        }

        return true;
    }

    protected function isChangPaaword()
    {
        $changPwDay = intval(\ForbizConfig::getPrivacyConfig('change_admin_pw_day'));
        $ret = false;

        if ($changPwDay > 0) {
            $row = $this->qb
                ->select('change_pw_date')
                ->from(TBL_COMMON_USER)
                ->where('code', sess_val('admininfo', 'charger_ix'))
                ->exec()
                ->getRowArray();

            $chnage_pw_date = isset($row['change_pw_date']) && $row['change_pw_date'] != '' ? strtotime($row['change_pw_date']) : false;

            if ($chnage_pw_date !== false) {
                $ret = time() > ($chnage_pw_date + ($changPwDay * 86400));
            } else {
                $ret = true;
            }
        }

        return $ret;
    }
}