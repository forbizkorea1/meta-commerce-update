<?php

namespace ForbizScm\Model;

/**
 * Admin 인증관련 모델
 *
 * @author hoksi
 */
class Login extends \ForbizModel
{

    protected $captchaImgPath;
    protected $adminUrl = '/store/main';
    protected $sellerUrl = '/seller/main';
    protected $loginUrl = '/';

    public function __construct()
    {
        parent::__construct();
    }

    /**
     * 로그인 확인
     * @return boolean|string
     */
    public function isLogin($url = '')
    {
        if ($this->adminInfo->admin_level) {
            if ($this->adminInfo->admin_level == 9) {
                return $this->adminUrl;
            } else {
                if ($this->adminInfo->admin_level == 8) {
                    return $this->sellerUrl;
                }
            }
        }

        return false;
    }

    public function doLogin($id, $pw)
    {
        return $this->shopAuth(['id' => $id, 'pw' => $pw]);
    }

    public function getSmsNumber($code)
    {
        $row = $this->qb
            ->decryptSelect('pcs')
            ->select('name')
            ->from(TBL_COMMON_MEMBER_DETAIL)
            ->where('code', $code)
            ->exec()
            ->getRowArray();

        return ($row['pcs'] ?? false);
    }

    public function shopAuth($logininfo)
    {
        $row = $this->qb
            ->select('ccd.*')
            ->select('cu.*')
            ->decryptSelect('cmd.name', 'name')
            ->select('cmd.gp_ix')
            ->select('cmd.mem_level')
            ->select('csde.is_contract')
            ->from(TBL_COMMON_COMPANY_DETAIL . ' AS ccd')
            ->join(TBL_COMMON_SELLER_DETAIL . ' AS csd', 'ccd.company_id = csd.company_id', 'left')
            ->join(TBL_COMMON_SELLER_DELIVERY . ' AS csde', 'ccd.company_id = csde.company_id', 'left')
            ->join(TBL_COMMON_USER . ' AS cu', 'ccd.company_id = cu.company_id')
            ->join(TBL_COMMON_MEMBER_DETAIL . ' AS cmd', 'cu.code = cmd.code')
            ->where('id', $logininfo['id'])
            ->whereIn('ccd.com_type', ['S', 'A', 'G', 'M', 'CS', 'BP', 'BO', 'BR'])
            ->groupStart()
            ->where('cu.mem_type', 'A')
            ->orWhereIn('cu.mem_div', ['S', 'MD'])
            ->groupEnd()
            ->where('pw', encrypt_user_password($logininfo['pw']))
            ->exec()
            ->getRowArray();

        //ip check
        $ipCheck = false;
        if (!empty($row)) { // 등록된 아이디와 비밀번호
            if ($row['allow_ips']) { //제한 값이 있는 경우 - 아이피가 등록된 경우만                
                $ip = $this->input->ip_address();
                // , 단위로 분리되어있음
                foreach (explode(",", $row['allow_ips']) as $key => $val) {
                    if ($val == $ip) {
                        $ipCheck = true;
                        break;
                    }
                }
                //동일한 아이피가 없으면 리잭
                if (!$ipCheck || $ipCheck === false) {
                    return 'reject';
                }
            }
        }

        if (!empty($row)) { // 등록된 아이디와 비밀번호
            if ($row['authorized'] == "N") { // common_user.auth 라는 컬럼이 존재하지 않음 authorized 회원승인여부 컬럼으로 교체 2013-06-26 이학봉
                return 'standby';
            } else {
                if ($row['authorized'] == "X") {
                    return 'reject';
                } else {
                    $_SESSION["admininfo"]["company_id"] = $row["company_id"];
                    $_SESSION["admininfo"]["company_name"] = $row["com_name"];
                    $_SESSION["admininfo"]["charger_ix"] = $row["code"];
                    $_SESSION["admininfo"]["charger_id"] = $row["id"];
                    $_SESSION["admininfo"]["charger"] = $row["name"];
                    $_SESSION["admininfo"]["charger_roll"] = $row["auth"];
                    $_SESSION["admininfo"]["language"] = $row["language"];
                    $_SESSION["admininfo"]["mem_type"] = $row["mem_type"];
                    $_SESSION["admininfo"]["mem_div"] = $row["mem_div"];
                    $_SESSION["admininfo"]["mem_level"] = $row["mem_level"];
                    $_SESSION["admininfo"]["gp_ix"] = $row["gp_ix"];
                    $_SESSION["admininfo"]["license"] = $row["license"];
                    $_SESSION["admininfo"]["mall_id"] = $row["mall_id"];

                    if (\ForbizConfig::getPrivacyConfig('secondary_authentication_use') == 'Y')
                    {
                        $_SESSION['smsAuth'] = false;
                    }

                    // ACL 그룹코드 설정
                    $grow = $this->qb
                        ->select('system_group_type_id')
                        ->from(TBL_SYSTEM_GROUP)
                        ->where('code', ($row["code"] ?? ''))
                        ->orderBy('system_group_type_id')
                        ->limit(1)
                        ->exec()
                        ->getRowArray();

                    $_SESSION["admininfo"]["group_code"] = $grow['system_group_type_id'] ?? PUBLIC_ADMIN_GROUP_CODE;

                    if ($row["mem_type"] == "S" || $row["mem_type"] == "CS") { // 셀러와 가맹점 회원은 레벨 8
                        $_SESSION["admininfo"]["admin_level"] = "8";
                    } else {
                        if ($row["mem_type"] == "A" || $row["mem_type"] == "MD") { // 직원과 관리자 MD 는 레벨 9
                            $_SESSION["admininfo"]["admin_level"] = "9";
                        } else {
                            $_SESSION["admininfo"]["admin_level"] = "8";
                        }
                    }
                    /* @var $logModel \CustomScm\Model\system\Log */
                    $logModel = $this->import('model.scm.system.log');
                    $logModel->addLoginLog('I');

                    return 'success';
                }
            }
        } else { //등록되지 않은 아이디와 비밀번호
            $user_cnt = $this->qb
                ->from(TBL_COMMON_USER)
                ->where('id', $logininfo['id'])
                ->getCount();


            if ($user_cnt > 0) {
                $this->qb
                    ->set('fail_count', 'fail_count + 1', false)
                    ->where('id', $logininfo['id'])
                    ->update(TBL_COMMON_USER)
                    ->exec();
            } else {
                $this->qb
                    ->set('fail_count', 'fail_count + 1', false)
                    ->where('id', $logininfo['id'])
                    ->update(TBL_COMMON_USER_SLEEP)
                    ->exec();
            }

            return 'fail';
        }
    }

    /**
     * 캡차 실패 횟수 점검
     * @param string $id
     * @return boolean
     */
    public function checkCapcha($id)
    {
        $row = $this->qb
            ->select('fail_count')
            ->from(TBL_COMMON_USER)
            ->where('id', $id)
            ->exec()
            ->getRowArray();

        if (isset($row['fail_count'])) {
            if ($row['fail_count'] > 4) {
                return true;
            }
        }

        return false;
    }

    public function resetFailCount($id)
    {
        $this->qb
            ->set('fail_count', 0)
            ->where('id', $id)
            ->update(TBL_COMMON_USER)
            ->exec();
    }

    /**
     * 캡차 이미지를 생성합니다.
     * @return array
     */
    public function createCaptcha()
    {
        $this->load->helper('captcha');

        $captcha = create_captcha([
            'img_path' => assets_local_path('../www/assets/captcha') . '/',
            'img_url' => '/assets/captcha/',
            'font_path' => assets_local_path('system/assets/texb.ttf'),
            'img_width' => 170,
            'img_height' => 55,
            'expiration' => 60,
            'word_length' => 6,
            'font_size' => 15,
            'img_id' => 'Imageid',
            'pool' => '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ',
            'colors' => array(
                'background' => array(255, 255, 255),
                'border' => array(255, 255, 255),
                'text' => array(0, 0, 0),
                'grid' => array(255, 40, 40)
            )
        ]);

        return $captcha;
    }

    /**
     * 회원 로그인 데이터 삭제
     * @param $connectDeleteDay
     */
    public function deleteConnectUserLog($connectDeleteDay = 180)
    {
        $delete_log_time = date('Y-m-d H:i:s', strtotime("- " . $connectDeleteDay . " days"));

        //로그 기록 기준이 만료된 데이터 삭제
        $this->qb
            ->where('connect_time <', $delete_log_time)
            ->delete(TBL_COMMON_MEMBER_CONNECT_LOG)
            ->exec();
    }

    public function chkLicense(){
        $this->sendPortalApi('/license/getCheck', []);
        return true;
    }

    public function getMasterId($data)
    {
        /* @var $memberModel \CustomScm\Model\Member\Member */
        $memberModel = $this->import('model.scm.member.member');
        $adminInfo = $memberModel->getAdminInfo();
        $pcsNum = $data['pcs_1'].'-'.$data['pcs_2'].'-'.$data['pcs_3'];
        $comNum = $data['com_number_1'].'-'.$data['com_number_2'].'-'.$data['com_number_3'];


        $row = $this->qb
            ->select('m.date')
            ->decryptSelect('md.pcs')
            ->select('cd.com_name')
            ->select('cd.com_number')
            ->from(TBL_COMMON_USER . ' m')
            ->join(TBL_COMMON_MEMBER_DETAIL . ' md', 'm.code = md.code')
            ->join(TBL_COMMON_COMPANY_DETAIL . ' cd', 'm.company_id = cd.company_id')
            ->where('m.id', $adminInfo['id'])
            ->exec()
            ->getRowArray();

        if ($row['com_name'] == $data['com_name'] && $row['pcs'] == $pcsNum && $row['com_number'] == $comNum)
        {
            $list = [
                'searchType' => $data['findType'],
                'id' => $adminInfo['id'],
                'date' => $row['date']
            ];

            return $list;
        } else {
            return false;
        }

    }

    public function getMasterPw($data)
    {
        /* @var $memberModel \CustomScm\Model\Member\Member */
        $memberModel = $this->import('model.scm.member.member');
        $adminInfo = $memberModel->getAdminInfo();
        $pcsNum = $data['pcs_1'].'-'.$data['pcs_2'].'-'.$data['pcs_3'];
        $comNum = $data['com_number_1'].'-'.$data['com_number_2'].'-'.$data['com_number_3'];


        $row = $this->qb
            ->select('m.date')
            ->decryptSelect('md.pcs')
            ->select('cd.com_number')
            ->from(TBL_COMMON_USER . ' m')
            ->join(TBL_COMMON_MEMBER_DETAIL . ' md', 'm.code = md.code')
            ->join(TBL_COMMON_COMPANY_DETAIL . ' cd', 'm.company_id = cd.company_id')
            ->where('m.id', $adminInfo['id'])
            ->exec()
            ->getRowArray();

        if ($adminInfo['id'] == $data['id'] && $row['pcs'] == $pcsNum && $row['com_number'] == $comNum)
        {
            $list = [
                'searchType' => $data['findType'],
                'pw' => $adminInfo['pw'],
                'date' => $row['date']
            ];

            return $list;
        } else {
            return false;
        }
    }
}
