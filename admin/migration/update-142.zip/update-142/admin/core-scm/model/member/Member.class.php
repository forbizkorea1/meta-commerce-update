<?php

namespace ForbizScm\Model\Member;

/**
 * 회원 관련 모델
 *
 * @author hoksi
 */
class Member extends \ForbizModel
{
    private $memType = [
        'M' => '개인회원',
        'C' => '기업회원',
        'A' => '직원(관리자)'
    ];

    public function __construct()
    {
        parent::__construct();
    }

    /**
     * get 회원 타입 TEXT
     * @param type $memType
     * @return type
     */
    public function getMemTypeText($memType)
    {
        return $this->memType[$memType];
    }

    /**
     * 승인 MD 리스트
     * @param type $cur_page
     * @param type $limit
     * @param type $search
     * @return type
     */
    public function getApprovedMDList($cur_page = 1, $limit = 20, $search = [])
    {
        $search['mem_type'] = 'A';
        $search['mem_div'] = 'MD';
        $search['authorized'] = 'Y';
        return $this->getList($cur_page, $limit, $search);
    }

    /**
     * 승인 회원 리스트
     * @param type $cur_page
     * @param type $limit
     * @param array $search
     * @return type
     */
    public function getApprovedMemberList($cur_page = 1, $limit = 20, $search = [])
    {
        $search['authorized'] = 'Y';
        return $this->getList($cur_page, $limit, $search);
    }

    /**
     * get 리스트
     * @param type $cur_page
     * @param type $limit
     * @param type $search
     * @return type
     */
    public function getList($cur_page = 1, $limit = 20, $search = [])
    {
        $this->qb->startCache();
        $this->putBatchSearch($search);  //검색조건이 셋해서 넘어온다
        $this->qb
            ->from(TBL_COMMON_USER . ' as cu')
            ->join(TBL_COMMON_MEMBER_DETAIL . ' as cmd', 'cu.code=cmd.code')
            ->join(TBL_SHOP_GROUPINFO . ' as sg', 'sg.gp_ix=cmd.gp_ix and sg.is_delete = 0', 'left')
            ->where('cu.id !=', 'forbiz');


        $this->qb->stopCache();

        $total = $this->qb->getCount();
        $paging = $this->qb
            ->setTotalRows($total)
            ->pagination($cur_page, $limit);

        $offset = ($paging['offset'] ?? 0);

        $rows = $this->qb
            ->select('cu.code')
            ->select('cu.code as mem_code')
            ->select('cu.id')
            ->select('cu.mem_type')
            ->select('cu.mem_div')
            ->select('cu.auth')
            ->select('cu.last')
            ->select('cu.visit')
            ->select('cu.mileage')
            ->decryptSelect('cmd.name')
            ->decryptSelect('cmd.mail')
            ->decryptSelect('cmd.pcs')
            ->select('sg.gp_name')
            ->select('cu.date')
            ->select('cu.language')
            ->select('cu.authorized')
            ->select('cmd.sex_div')
            ->select('cmd.birthday')
            ->select('cmd.birthday_div')
            ->select('cmd.info')
            ->select('cmd.sms')
            ->select('cu.language as language_type')
            ->select('cmd.com_group')
            ->decryptSelect('cmd.zip')
            ->decryptSelect('cmd.tel')
            ->decryptSelect('cmd.addr1')
            ->decryptSelect('cmd.addr2')
            ->select('cmd.birthday')
            ->select('cmd.gp_ix')
            ->select('cu.allow_ips')
            ->orderBy('cu.date', 'DESC')
            ->limit($limit, $offset)
            ->exec()
            ->getResultArray();

        $this->qb->flushCache();

        //치환 처리
        foreach ($rows as $key => $val) {
            $val['memTypeText'] = $this->getMemTypeText($val['mem_type']);
            $val['memTypeTextDiv'] = $this->getMemTypeText($val['mem_type']);
            $mem_div = "";
            switch ($val['mem_div']) {
                case 'D':
                    $memTypeText = "기타";
                    $mem_div = "기타";
                    break;
                case 'E':
                    $memTypeText = "임직원";
                    $mem_div = "임직원";
                    break;
                case 'C':
                    $memTypeText = "기업회원";
                    $mem_div = "기업회원";
                    break;
                case 'MD':
                    $memTypeText = "MD";
                    $mem_div = "MD";
                    break;
                case 'S':
                    $memTypeText = "셀러";
                    $mem_div = "셀러";
                    break;
                default:
                    $memTypeText = $val['mem_div'];
                    $mem_div = $val['mem_div'];
                    break;
            }
            if ($mem_div) {
                $val['memTypeTextDiv'] .= "(" . $mem_div . ")";
            } else {
                $val['memTypeTextDiv'] .= $mem_div;
            }
            $val['smsText'] = ($val['sms'] == 1) ? "O" : "X";
            $val['infoText'] = ($val['info'] == 1) ? "O" : "X";

            switch ($val['authorized']) {
                case "Y" :
                    $rows[$key]['authText'] = "승인";
                    break;
                case "N" :
                    $rows[$key]['authText'] = "승인대기";
                    break;
                case "X" :
                    $rows[$key]['authText'] = "승인거부";
                    break;
                default:
                    $rows[$key]['authText'] = "";
                    break;
            }

            $templateAuth = $this->getTemplateAuth($val['code']) ?? [];
            if (count($templateAuth) > 0) {
                $val['templateAuth'] = $templateAuth['group_name'];
            }

            switch ($val['authorized']) {
                case "Y" :
                    $val['authText'] = "승인";
                    break;
                case "N" :
                    $val['authText'] = "승인대기";
                    break;
                case "X" :
                    $val['authText'] = "승인거부";
                    break;
                default:
                    $val['authText'] = "";
                    break;
            }

            $arr = auto_explode_number('birthday', $val['birthday']) ?? [];
            if (count($arr)) {
                $val['birthday_1'] = $arr['birthday_1'] ?? "";
                $val['birthday_2'] = $arr['birthday_2'] ?? "";
                $val['birthday_3'] = $arr['birthday_3'] ?? "";
            }
            $arr = auto_explode_number('pcs', $val['pcs']) ?? [];
            if (count($arr)) {
                $val['pcs_1'] = $arr['pcs_1'] ?? "";
                $val['pcs_2'] = $arr['pcs_2'] ?? "";
                $val['pcs_3'] = $arr['pcs_3'] ?? "";
            }
            $arr = auto_explode_number('tel', $val['tel']) ?? [];
            if (count($arr)) {
                $val['tel_1'] = $arr['tel_1'] ?? "";
                $val['tel_2'] = $arr['tel_2'] ?? "";
                $val['tel_3'] = $arr['tel_3'] ?? "";
            }

            $rows[$key] = $val;

        }


        return [
            'total' => $total
            ,
            'list' => $rows
            ,
            'paging' => $paging
        ];
    }

    public function getAdminList($cur_page = 1, $limit = 20, $search = [])
    {
        $this->qb->startCache();
        $this->putBatchSearch($search);  //검색조건이 셋해서 넘어온다
        $this->qb
            ->from(TBL_COMMON_USER . ' as cu')
            ->join(TBL_COMMON_MEMBER_DETAIL . ' as cmd', 'cu.code=cmd.code')
            ->join(TBL_SHOP_GROUPINFO . ' as sg', 'sg.gp_ix=cmd.gp_ix', 'left')
            ->join(TBL_SYSTEM_GROUP . ' as sp', 'sp.code=  cmd.code', 'left');
        $this->qb->stopCache();

        $total = $this->qb->getCount();
        $paging = $this->qb
            ->setTotalRows($total)
            ->pagination($cur_page, $limit);

        $offset = ($paging['offset'] ?? 0);

        $rows = $this->qb
            ->select('cu.code')
            ->select('cu.code as mem_code')
            ->select('cu.id')
            ->select('cu.mem_type')
            ->select('cu.mem_div')
            ->select('cu.auth')
            ->select('cu.last')
            ->select('cu.visit')
            ->select('cu.mileage')
            ->decryptSelect('cmd.name')
            ->decryptSelect('cmd.mail')
            ->decryptSelect('cmd.pcs')
            ->select('sg.gp_name')
            ->select('cu.date')
            ->select('cu.language')
            ->select('cu.authorized')
            ->select('cmd.sex_div')
            ->select('cmd.birthday')
            ->select('cmd.birthday_div')
            ->select('cmd.info')
            ->select('cmd.sms')
            ->select('cu.language as language_type')
            ->select('cmd.com_group')
            ->select('cmd.gp_ix')
            ->decryptSelect('cmd.zip')
            ->decryptSelect('cmd.tel')
            ->decryptSelect('cmd.addr1')
            ->decryptSelect('cmd.addr2')
            ->select('cmd.birthday')
            ->select('sp.system_group_type_id')
            ->orderBy('cu.date', 'DESC')
            ->limit($limit, $offset)
            ->exec()
            ->getResultArray();

        $this->qb->flushCache();

        //치환 처리
        foreach ($rows as $key => $val) {
            $val['memTypeText'] = $this->getMemTypeText($val['mem_type']);
            $val['memTypeTextDiv'] = $this->getMemTypeText($val['mem_type']);
            $mem_div = "";
            switch ($val['mem_div']) {
                case "MD":
                    $mem_div = "MD담당자";
                    break;
                case "S":
                    $mem_div = "셀러";
                    break;
                case "D":
                    $mem_div = "기타";
                    break;
            }
            if ($mem_div) {
                $val['memTypeTextDiv'] .= "(" . $mem_div . ")";
            } else {
                $val['memTypeTextDiv'] .= $mem_div;
            }
            $val['smsText'] = ($val['sms'] == 1) ? "O" : "X";
            $val['infoText'] = ($val['info'] == 1) ? "O" : "X";
            $rows[$key] = $val;
        }

        foreach ($rows as $key => $val) {
            $templateAuth = $this->getTemplateAuth($val['code']);
            if (count($templateAuth) > 0) {
                $val['templateAuth'] = $templateAuth['group_name'];
            }
            $rows[$key] = $val;
        }

        foreach ($rows as $key => $val) {
            $arr = auto_explode_number('birthday', $val['birthday']);
            if (count($arr)) {
                $rows[$key]['birthday_1'] = $arr['birthday_1'] ?? "";
                $rows[$key]['birthday_2'] = $arr['birthday_2'] ?? "";
                $rows[$key]['birthday_3'] = $arr['birthday_3'] ?? "";
            }
            $arr = auto_explode_number('pcs', $val['pcs']);
            if (count($arr)) {
                $rows[$key]['pcs_1'] = $arr['pcs_1'] ?? "";
                $rows[$key]['pcs_2'] = $arr['pcs_2'] ?? "";
                $rows[$key]['pcs_3'] = $arr['pcs_3'] ?? "";
            }
            $arr = auto_explode_number('tel', $val['tel']);
            if (count($arr)) {
                $rows[$key]['tel_1'] = $arr['tel_1'] ?? "";
                $rows[$key]['tel_2'] = $arr['tel_2'] ?? "";
                $rows[$key]['tel_3'] = $arr['tel_3'] ?? "";
            }
        }


        return [
            'total' => $total
            ,
            'list' => $rows
            ,
            'paging' => $paging
        ];
    }

    /**
     * code로 해당 회원 정보 가져오기
     * @param type $code
     */
    public function getMemberInfo($code)
    {
        $result = [];
        $result['status'] = 'success';

        $this->qb
            ->select('cu.code')
            ->select('cu.id')
            ->select('cu.mem_type')
            ->select('cu.auth')
            ->select('cu.mem_div')
            ->select('cmd.com_group')
            ->select('cmd.gp_ix')
            ->decryptSelect('cmd.name')
            ->decryptSelect('cmd.mail')
            ->decryptSelect('cmd.pcs')
            ->select('cu.date')
            ->select('cu.language')
            ->select('cu.authorized')
            ->select('cmd.sex_div')
            ->select('cmd.birthday')
            ->select('cmd.birthday_div')
            ->select('cmd.info')
            ->select('cmd.sms')
            ->decryptSelect('cmd.zip')
            ->decryptSelect('cmd.tel')
            ->decryptSelect('cmd.addr1')
            ->decryptSelect('cmd.addr2')
            ->from(TBL_COMMON_USER . ' as cu')
            ->join(TBL_COMMON_MEMBER_DETAIL . ' as cmd', 'cu.code=cmd.code');
        $this->qb->where('cmd.code', $code);
        $rows = $this->qb->exec()->getRowArray();

        if (!empty($rows)) {
            if (count($rows) > 0) {
                $arr = auto_explode_number('birthday', $rows['birthday']);
                if (count($arr) > 0) {
                    $rows = array_merge($rows, $arr);
                }
                $arr = auto_explode_number('tel', $rows['tel']);
                if (count($arr) > 0) {
                    $rows = array_merge($rows, $arr);
                }

                $arr = auto_explode_number('pcs', $rows['pcs']);
                if (count($arr) > 0) {
                    $rows = array_merge($rows, $arr);
                }
            }
        }

        $templateAuth = $this->getTemplateAuth($code);
        $rows['system_group_type_id'] = false;
        if (count($templateAuth) > 0) {
            $rows['system_group_type_id'] = $templateAuth['system_group_type_id'];
        }
        $result['data'] = $rows;
        return $result;
    }

    /**
     * 해당 맴버 유저 삭제
     */
    public function delMember($post = [])
    {
        $result['status'] = 'success';
        $result['data'] = $post;

        //삭제전 조회
        $member = $this->qb->from(TBL_COMMON_USER)
            ->where('code', $post['code'])
            ->exec()
            ->getRowArray();

        if ($member) {
            $this->addAdminLog("D", $member['id'], $member['company_id']);
            $this->qb->where('code', $post['code'])
                ->delete(TBL_COMMON_USER)
                ->exec();
            $this->qb->where('code', $post['code'])
                ->delete(TBL_COMMON_MEMBER_DETAIL)
                ->exec();
        } else {
            $result['status'] = 'fail';
            $result['error'] = 'not member code';
        }
        return $result;
    }

    /**
     * 이전 비밀번호와 같은지 확인
     * @param string $password
     * @return boolean
     */
    public function chkPrevPasswd($password)
    {
        $row = $this->qb
            ->select('pw')
            ->from(TBL_COMMON_USER)
            ->where('code', $this->adminInfo->charger_ix)
            ->exec()
            ->getRowArray();

        return isset($row['pw']) && encrypt_user_password($password) == $row['pw'];
    }

    /**
     * 비밀번호 입력룰 검토
     * @param type $password
     * @param type $password2
     * @return boolean
     */
    public function validatePassword($password, $password2)
    {
        $ret = 'notMatch';

        if ($password == $password2) {
            $len = strlen($password); // 문자 길이
            $num = preg_match('/[0-9]/', $password) > 0; // 숫자
            $eng = preg_match('/[a-z]/i', $password) > 0; // 영문자
            $spe = preg_match('/[!@#$%^&*\(\)_+~]/i', $password) > 0; // 특수문자
            $space = preg_match('/\s/', $password) > 0; // 공백
            $hangul = preg_match('/[ㄱ-ㅎ|ㅏ-ㅣ|가-힣]/', $password) > 0; // 한글
            $same = preg_match('/(.)\1{4}/', $password) > 0; // 5자 이상 같은 문자
            $seq = preg_match('/abcde|bcdef|cdefg|defgh|efghi|fghij|ghijk|hijkl|ijklm|jklmn|klmno|lmnop|mnopq|nopqr|opqrs|pqrst|qrstu|rstuv|stuvw|tuvwx|uvwxy|vwxyz|qwert|werty|ertyu|rtyui|tyuio|yuiop|asdfg|sdfgh|dfghj|fghjk|ghjkl|zxcvb|xcvbn|cvbnm|12345|23456|34567|45678|56789|67890/i',
                    $password) > 0; // 연속된 문자
            // 패턴 검증
            $vlidate = ($num && $eng && $spe && $len >= 8 || ($spe && $num || $eng && $num || $eng && $spe) && $len >= 10) && $same === false;

            if ($len < 8) {
                $ret = 'len';
            } else if ($hangul) {
                $ret = 'kr';
            } else if ($space) {
                $ret = 'space';
            } else if ($seq) {
                $ret = 'seq';
            } else if ($vlidate === false) {
                $ret = 'validate';
            } else if ($this->chkPrevPasswd($password) === true) {
                $ret = 'usedPasswd';
            } else {
                $ret = true;
            }
        }

        return $ret;
    }

    /**
     * 회원 정보 수정
     * @param array $post
     * @return array
     */
    public function updateMyInfo($post = [])
    {
        $mem_code = $this->adminInfo->charger_ix;
        $result = 'fail';

        if ($mem_code != '') {

            $data_member_set = []; //common member detail 용
            $encrypt_set = []; //암호화

            $data_set = [];

            // pw 변경시
            if ($post['pw']) {
                // 비밀번호 검사
                $result = $this->validatePassword($post['pw'], $post['pw_re']);

                if ($result === true) {
                    $this->qb
                        ->set('pw', encrypt_user_password($post['pw']))
                        ->where('code', $mem_code)
                        ->update(TBL_COMMON_USER)
                        ->exec();
                } else {
                    return $result;
                }
            }

            if (isset($post['nick_name']) && $post['nick_name']) {
                $data_member_set['nick_name'] = $post['nick_name'];
            }

            if (isset($post['sex_div'])) {
                $data_member_set['sex_div'] = $post['sex_div'];
            }

            if (isset($post['birthday_1']) && isset($post['birthday_2']) && isset($post['birthday_3'])) {
                $data_member_set['birthday'] = $post['birthday_1'] . '-' . $post['birthday_2'] . '-' . $post['birthday_3'];
                $data_member_set['birthday'] = str_cut_number_dash($data_member_set['birthday']);
            }

            if (isset($post['birthday_div'])) {
                $data_member_set['birthday_div'] = $post['birthday_div'] ?? "";
            }

            if (isset($post['info'])) {
                $data_member_set['info'] = $post['info'];
            }

            if (isset($post['sms'])) {
                $data_member_set['sms'] = $post['sms'];
            }

            //encrypt 필드 암호화용

            if (isset($post['pcs_1']) && isset($post['pcs_2']) && isset($post['pcs_3'])) {
                $encrypt_set['pcs'] = $post['pcs_1'] . '-' . $post['pcs_2'] . '-' . $post['pcs_3'];
                $encrypt_set['pcs'] = str_cut_number_dash($encrypt_set ['pcs']);
            }
            if (isset($post['zip'])) {
                $encrypt_set['zip'] = $post['zip'];
            }
            if (isset($post['mail'])) {
                $encrypt_set['mail'] = $post['mail'];
            }
            if (isset($post['tel_1']) && isset($post['tel_2']) && isset($post['tel_3'])) {
                $encrypt_set['tel'] = $post['tel_1'] . '-' . $post['tel_2'] . '-' . $post['tel_3'];
                $encrypt_set['tel'] = str_cut_number_dash($encrypt_set ['tel']);
            }
            if (isset($post['addr1'])) {
                $encrypt_set['addr1'] = $post['addr1'];
            }
            if (isset($post['addr2'])) {
                $encrypt_set['addr2'] = $post['addr2'];
            }

            $log_data_member_set = [];
            foreach ($encrypt_set as $key => $val) {
                $log_data_member_set[$key] = $this->qb->encryptStr($val);
            }
            $log_data_member_set = array_merge($log_data_member_set, $data_member_set);

            //이름, 생년월일, 핸드폰, 이메일, 우편번호, 주소등
            add_history('member', TBL_COMMON_MEMBER_DETAIL . '.code', $mem_code,
                [
                    'sex_div' => '회원성별',
                    'sms' => 'SMS수신동의',
                    'info' => 'Mail수신동의',
                    'pcs' => '핸드폰',
                    'name' => '이름',
                    'mail' => '메일',
                    'tel' => '집전화',
                    'zip' => '우편번호',
                    'addr1' => '주소',
                    'addr2' => '상세주소',
                    'nick_name' => '닉네임'
                ], $log_data_member_set);

            foreach ($encrypt_set as $key => $val) {
                $this->qb->encryptSet($key, $val);
            }

            $this->qb->where('code', $mem_code)
                ->update(TBL_COMMON_MEMBER_DETAIL, $data_member_set)
                ->exec();

            $result = 'success';
        }

        return $result;
    }

    public function putMemberInfo($post = [])
    {
        $result = [];
        $result['status'] = 'success';

        $mem_code = $post['mem_code'] ?? null;
        $mode = 'insert';

        if ($mem_code) {
            $mode = 'update';
        }

        $data_user_set = []; //common user 용
        $data_member_set = []; //common member detail 용
        $encrypt_set = []; //암호화

        $data_set = [];
        if ($mem_code) {
            $data_user_set['code'] = $post['mem_code'];
            $data_member_set['code'] = $post['mem_code'];
        }


        if ($mode == 'insert') {
            //insert는 무조건 있음
            if ($post['pw'] == $post['pw_re']) {
                $is_password['pw'] = $post['pw'];
            } else {
                //같지 않음
                $result['status'] = 'fail';
                $result['error'] = 'password and password re not match';
                return $result;
            }
        } else {
            if ($mode == 'update') {
                //update 이면서 pw 입력이 있다면
                if ($post['pw']) {
                    if ($post['pw'] == $post['pw_re']) {
                        $is_password['pw'] = $post['pw'];
                    } else {
                        //같지 않음
                        $result['status'] = 'notMatchPw';
                        $result['error'] = 'password and password re not match';
                        return $result;
                    }
                }
            }
        }


        $data_user_set['authorized'] = $post['authorized'];
        $data_user_set['mem_type'] = $post['mem_type'];
        $data_user_set['allow_ips'] = $post['allow_ips'] ?? ""; //허용아이피 사원관리에만 있다


        $data_user_set['request_date'] = date('Y-m-d H:i:s');

        $data_member_set['sex_div'] = $post['sex_div'];
        $data_member_set['birthday'] = $post['birthday_1'] . '-' . $post['birthday_2'] . '-' . $post['birthday_3'];
        $data_member_set['birthday'] = str_cut_number_dash($data_member_set['birthday']);
        $data_member_set['birthday_div'] = $post['birthday_div'] ?? "";
        $data_member_set['info'] = $post['info'];
        $data_member_set['sms'] = $post['sms'] ?? 0;


        //값이 있는 경우만 그룹 변경 -- 몇몇 페이지에서만 넘겨줌
        if (isset($post['gp_ix'])) {
            $data_member_set['gp_ix'] = $post['gp_ix'];
        }

        //encrypt 필드 암호화용

        $encrypt_set['pcs'] = $post['pcs_1'] . '-' . $post['pcs_2'] . '-' . $post['pcs_3'];
        $encrypt_set['pcs'] = str_cut_number_dash($encrypt_set ['pcs']);
        $encrypt_set['zip'] = $post['zip'];
        $encrypt_set['mail'] = $post['mail'];
        $encrypt_set['tel'] = $post['tel_1'] . '-' . $post['tel_2'] . '-' . $post['tel_3'];
        $encrypt_set['tel'] = str_cut_number_dash($encrypt_set ['tel']);
        $encrypt_set['name'] = $post['name'];
        $encrypt_set['addr1'] = $post['addr1'];
        $encrypt_set['addr2'] = $post['addr2'];

        if ($mode == 'insert') {
            //common user 처리
            $data_user_set['code'] = make_member_code();
            $this->qb->set('pw', encrypt_user_password($is_password['pw']));
            $this->qb->insert(TBL_COMMON_USER, $data_user_set)->exec();


            //common member datail 처리
            foreach ($encrypt_set as $key => $val) {
                $this->qb->encryptSet($key, $val);
            }
            $data_member_set['code'] = $data_user_set['code'];
            $data_member_set['gp_ix'] = $post['gp_ix'];
            $data_member_set['date'] = date('Y-m-d H:i:s'); //insert 일때만
            $this->qb
                ->insert(TBL_COMMON_MEMBER_DETAIL, $data_member_set)
                ->exec();
        } else {

            add_history('member', TBL_COMMON_USER . '.code', $mem_code,
                [
                    'mem_type' => '회원구분',
                    'authorized' => '승인여부'
                ], $data_user_set);

            //pw 값이 있으면 추가됨
            if (($is_password['pw'] ?? false)) {
                $this->qb->set('pw', encrypt_user_password($is_password['pw']));
            }
            $this->qb
                ->where('code', $mem_code)
                ->update(TBL_COMMON_USER, $data_user_set)
                ->exec();

            $log_data_member_set = [];
            foreach ($encrypt_set as $key => $val) {
                $log_data_member_set[$key] = $this->qb->encryptStr($val);
            }
            $log_data_member_set = array_merge($log_data_member_set, $data_member_set);

            //이름, 생년월일, 핸드폰, 이메일, 우편번호, 주소등
            add_history('member', TBL_COMMON_MEMBER_DETAIL . '.code', $mem_code,
                [
                    'sex_div' => '회원성별',
                    'gp_ix' => '회원그룹',
                    'sms' => 'SMS수신동의',
                    'info' => 'Mail수신동의',
                    'pcs' => '휴대폰 번호',
                    'name' => '이름',
                    'mail' => '메일',
                    'tel' => '집전화',
                    'zip' => '우편번호',
                    'addr1' => '주소',
                    'addr2' => '상세주소'
                ], $log_data_member_set);

            foreach ($encrypt_set as $key => $val) {
                $this->qb->encryptSet($key, $val);
            }

            $this->qb->where('code', $mem_code)
                ->update(TBL_COMMON_MEMBER_DETAIL, $data_member_set)
                ->exec();
        }

        return $result;
    }

    /**
     * 권한 템플릿 리스트
     */
    public function getTemplateAuthList($authType = 'admin')
    {
        if ($authType == 'seller') {
            $this->qb->where('t.system_group_type_id >', 2); //셀러는 시스템관리자 제외
        }
        $rows = $this->qb
            ->select("t.system_group_type_id")
            ->select("t.group_name")
            ->from(TBL_SYSTEM_GROUP_TYPE . ' AS t')
            ->where('t.system_group_type_id >', 1) // 시스템관리자, public 제외
            ->exec()
            ->getResultArray();
        return $rows ?? [];
    }

    /**
     * 어드민 계정 수정
     * @param type $post
     */
    public function putAdminMember($post = [])
    {
        $result = [];
        $result['status'] = 'success';

        $mem_code = $post['mem_code'] ?? null;
        $mode = 'update';

        if ($mem_code) {
            $mode = 'update';
        } else {
            $mode = 'insert';
        }

        $data_user_set = []; //common user 용
        $data_member_set = []; //common member detail 용
        $encrypt_set = []; //암호화

        $data_set = [];
        if ($mem_code) {
            $data_user_set['code'] = $post['mem_code'];
            $data_member_set['code'] = $post['mem_code'];
        }

        $data_user_set['id'] = $post['id'];

        if ($mode == 'insert') {
            //insert는 무조건 있음
            if ($post['pw'] == $post['pw_re']) {
                $is_password['pw'] = $post['pw'];
            } else {
                //같지 않음
                $result['status'] = 'fail';
                $result['error'] = 'password and password re not match';
                return $result;
            }
        } else {
            if ($mode == 'update') {
                //update 이면서 pw 입력이 있다면
                if ($post['pw']) {
                    if ($post['pw'] == $post['pw_re']) {
                        $is_password['pw'] = $post['pw'];
                    } else {
                        //같지 않음
                        $result['status'] = 'fail';
                        $result['error'] = 'password and password re not match';
                        return $result;
                    }
                }
            }
        }

        $system_group_type_id = $post['system_group_type_id'] ?? null;

        $data_user_set['language'] = ($post['language_type'] ?? 'korea');
        $data_user_set['authorized'] = $post['authorized'];
        $data_user_set['mem_type'] = $post['mem_type'];
        $data_user_set['mem_div'] = $post['mem_div'];
        $data_user_set['request_date'] = date('Y-m-d H:i:s');
        $data_user_set['company_id'] = getAdminCompanyId();

        $data_member_set['gp_ix'] = $post['gp_ix'];
        $data_member_set['sex_div'] = $post['sex_div'];
        $data_member_set['birthday'] = $post['birthday_1'] . '-' . $post['birthday_2'] . '-' . $post['birthday_3'];
        $data_member_set['birthday'] = str_cut_number_dash($data_member_set['birthday']);
        $data_member_set['birthday_div'] = $post['birthday_div'];
        $data_member_set['info'] = $post['info'];
        $data_member_set['sms'] = $post['sms'] ?? 0;

        //encrypt 필드 암호화용
        $encrypt_set['pcs'] = $post['pcs_1'] . '-' . $post['pcs_2'] . '-' . $post['pcs_3'];
        $encrypt_set['pcs'] = str_cut_number_dash($encrypt_set ['pcs']);
        $encrypt_set['zip'] = $post['zip'];
        $encrypt_set['mail'] = $post['mail'];
        $encrypt_set['tel'] = $post['tel_1'] . '-' . $post['tel_2'] . '-' . $post['tel_3'];
        $encrypt_set['tel'] = str_cut_number_dash($encrypt_set ['tel']);
        $encrypt_set['name'] = $post['name'];
        $encrypt_set['addr1'] = $post['addr1'];
        $encrypt_set['addr2'] = $post['addr2'];

        if ($mode == 'insert') {
            //common user 처리
            $data_user_set['code'] = make_member_code();
            $data_user_set['date'] = date('Y-m-d H:i:s');
            $data_user_set['change_pw_date'] = date('Y-m-d H:i:s');

            $this->qb->set('pw', encrypt_user_password($is_password['pw']));
            $this->qb->insert(TBL_COMMON_USER, $data_user_set)->exec();


            //common member datail 처리
            foreach ($encrypt_set as $key => $val) {
                $this->qb->encryptSet($key, $val);
            }
            $data_member_set['code'] = $data_user_set['code'];
            $this->qb->insert(TBL_COMMON_MEMBER_DETAIL, $data_member_set)->exec();


            //시스템 그룹 맵핑
            if ($system_group_type_id) {
                $this->qb->set('system_group_type_id', $system_group_type_id)
                    ->set('code', $data_user_set['code'])
                    ->set('updated_at', date('Y-m-d H:i:s'))
                    ->insert(TBL_SYSTEM_GROUP)
                    ->exec();
            }
        } else {
            //pw 값이 있으면 추가됨
            if (($is_password['pw'] ?? false)) {
                $this->qb->set('pw', encrypt_user_password($is_password['pw']));
            }
            $this->qb->where('code', $mem_code)
                ->update(TBL_COMMON_USER, $data_user_set)
                ->exec();


            foreach ($encrypt_set as $key => $val) {
                $this->qb->encryptSet($key, $val);
            }
            $this->qb->where('code', $mem_code)
                ->update(TBL_COMMON_MEMBER_DETAIL, $data_member_set)
                ->exec();

            //시스템 그룹 맵핑
            if ($system_group_type_id) {
                $rows = $this->qb
                    ->from(TBL_SYSTEM_GROUP)
                    ->where('code', $mem_code)
                    ->exec()
                    ->getResultArray();

                if (count($rows) > 0) {
                    $this->qb->set('system_group_type_id', $system_group_type_id)
                        ->set('updated_at', date('Y-m-d H:i:s'))
                        ->where('code', $mem_code)
                        ->update(TBL_SYSTEM_GROUP)
                        ->exec();
                } else {
                    $this->qb->set('system_group_type_id', $system_group_type_id)
                        ->set('code', $data_user_set['code'])
                        ->set('updated_at', date('Y-m-d H:i:s'))
                        ->insert(TBL_SYSTEM_GROUP)
                        ->exec();
                }
            }
        }

        return $result;
    }

    /**
     *  셀러 유저 추가 및 수정
     */
    public function putSellerUser($post = [])
    {

        $company_id = $post['company_id'];
        $mode = $post['mode'];
        $mem_code = $post['mem_code'] ?? null;

        $data_set = [];


        $data_user_set = []; //common user 용
        $data_member_set = []; //common member detail 용
        $encrypt_set = []; //암호화

        $data_set = [];
        if ($mem_code) {
            $data_user_set['code'] = $mem_code;
            $data_member_set['code'] = $mem_code;
        } else {
            $make_code = make_member_code();
            $data_user_set['code'] = $make_code;
            $data_member_set['code'] = $make_code;
        }

        $data_user_set['id'] = $post['id'];

        if ($mode == 'insert') {
            //insert는 무조건 있음
            if ($post['pw'] == $post['pw_re']) {
                $is_password['pw'] = $post['pw'];
            } else {
                //같지 않음
                $result['status'] = 'fail pw';
                $result['data'] = [];
                $result['error'] = '패스워드와 패스워드 확인이 일치하지 않습니다.';
                return $result;
            }
        } else {
            if ($mode == 'update') {
                //update 이면서 pw 입력이 있다면
                if ($post['pw']) {
                    if ($post['pw'] == $post['pw_re']) {
                        $is_password['pw'] = $post['pw'];
                    } else {
                        //같지 않음
                        $result['status'] = 'fail pw';
                        $result['data'] = [];
                        $result['error'] = '패스워드와 패스워드 확인이 일치하지 않습니다.';
                        return $result;
                    }
                }
            }
        }

        $system_group_type_id = $post['system_group_type_id'] ?? null;

        $data_user_set['language'] = $post['language_type'];
        $data_user_set['authorized'] = $post['authorized'];
        $data_user_set['mem_type'] = $post['mem_type'];
        $data_user_set['mem_div'] = $post['mem_div'];
        $data_user_set['date'] = date('Y-m-d H:i:s');
        $data_user_set['request_date'] = date('Y-m-d H:i:s');
        $data_user_set['company_id'] = $company_id;

        $data_member_set['gp_ix'] = $post['gp_ix'];
        $data_member_set['sex_div'] = $post['sex_div'];
        $data_member_set['birthday'] = $post['birthday_1'] . '-' . $post['birthday_2'] . '-' . $post['birthday_3'];
        $data_member_set['birthday'] = str_cut_number_dash($data_member_set['birthday']);
        $data_member_set['birthday_div'] = $post['birthday_div'];
        $data_member_set['info'] = $post['info'];
        $data_member_set['sms'] = $post['sms'] ?? 0;

        //encrypt 필드 암호화용
        $encrypt_set['pcs'] = $post['pcs_1'] . '-' . $post['pcs_2'] . '-' . $post['pcs_3'];
        $encrypt_set['pcs'] = str_cut_number_dash($encrypt_set ['pcs']);

        $encrypt_set['mail'] = $post['mail'];
        $encrypt_set['tel'] = $post['tel_1'] . '-' . $post['tel_2'] . '-' . $post['tel_3'];
        $encrypt_set['tel'] = str_cut_number_dash($encrypt_set ['tel']);
        $encrypt_set['name'] = $post['name'];

        //빈값 필수 체크를 하지 않기 때문에 값이 있는 경우만 넣어야함
        if ($post['zip']) {
            $encrypt_set['zip'] = $post['zip'];
        }
        if ($post['addr1']) {
            $encrypt_set['addr1'] = $post['addr1'];
        }
        if ($post['addr2']) {
            $encrypt_set['addr2'] = $post['addr2'];
        }


        if ($mode == 'insert') {
            $this->qb->set('pw', encrypt_user_password($is_password['pw']));
            $this->qb->insert(TBL_COMMON_USER, $data_user_set)->exec();

            //common member datail 처리
            foreach ($encrypt_set as $key => $val) {
                $this->qb->encryptSet($key, $val);
            }
            $data_member_set['code'] = $data_user_set['code'];
            $this->qb->insert(TBL_COMMON_MEMBER_DETAIL, $data_member_set)->exec();


            //시스템 그룹 맵핑
            if ($system_group_type_id) {
                $this->qb->set('system_group_type_id', $system_group_type_id)
                    ->set('code', $data_user_set['code'])
                    ->set('updated_at', date('Y-m-d H:i:s'))
                    ->insert(TBL_SYSTEM_GROUP)
                    ->exec();
            }
        } else {
            //pw 값이 있으면 추가됨
            if (($is_password['pw'] ?? false)) {
                $this->qb->set('pw', encrypt_user_password($is_password['pw']));
            }
            unset($data_user_set['id']);
            $this->qb->where('code', $mem_code)
                ->update(TBL_COMMON_USER, $data_user_set)
                ->exec();


            foreach ($encrypt_set as $key => $val) {
                $this->qb->encryptSet($key, $val);
            }

            $this->qb->where('code', $mem_code)
                ->update(TBL_COMMON_MEMBER_DETAIL, $data_member_set)
                ->exec();

            //시스템 그룹 맵핑
            if ($system_group_type_id) {
                $total = $this->qb
                        ->from(TBL_SYSTEM_GROUP)
                        ->where('code', $mem_code)
                        ->getCount() > 0;
                if ($total === false) {
                    $this->qb->set('system_group_type_id', $system_group_type_id)
                        ->set('code', $data_user_set['code'])
                        ->set('updated_at', date('Y-m-d H:i:s'))
                        ->insert(TBL_SYSTEM_GROUP)
                        ->exec();
                } else {
                    $this->qb->set('system_group_type_id', $system_group_type_id)
                        ->set('updated_at', date('Y-m-d H:i:s'))
                        ->where('code', $mem_code)
                        ->update(TBL_SYSTEM_GROUP)->exec();
                }
            }
        }
        $result['status'] = "success";
        $result['data'] = ['mode' => $mode];
        return $result;
    }

    /**
     * 어드민 계정 컨트롤 로그
     */
    protected function addAdminLog($crud_div, $id, $company_id)
    {
        $logMemberData = $this->qb
            ->select('ccd.com_name')
            ->decryptSelect('cmd.name')
            ->from(TBL_COMMON_USER . ' AS cu')
            ->join(TBL_COMMON_MEMBER_DETAIL . ' AS cmd', 'cu.code = cmd.code')
            ->join(TBL_COMMON_COMPANY_DETAIL . ' AS ccd', 'cu.company_id = ccd.company_id')
            ->where('cu.id', $id)
            ->exec()
            ->getRowArray();

        $this->qb
            ->set('accept_com_name', $logMemberData['com_name'] ?? "")
            ->set('accept_m_name', $logMemberData['name'] ?? "")
            ->set('admin_id', $this->adminInfo->charger_id)
            ->set('admin_name', $this->adminInfo->charger)
            ->set('crud_div', $crud_div)
            ->set('ip', $_SERVER["REMOTE_ADDR"])
            ->set('regdate', date('Y-m-d H:i:s'))
            ->insert(TBL_ADMIN_LOG)
            ->exec();
    }

    /**
     * 권한 템플릿 이름 리턴
     * @param type $code
     * @return type
     */
    protected function getTemplateAuth($code)
    {
        $rows = $this->qb
            ->select("t.group_name")
            ->select("t.system_group_type_id")
            ->from(TBL_SYSTEM_GROUP . ' AS g ')
            ->join(TBL_SYSTEM_GROUP_TYPE . ' AS t', 'g.system_group_type_id = t.system_group_type_id')
            ->join(TBL_COMMON_USER . ' AS u', 'g.code = u.code')
            ->where('g.code', $code)
            ->exec()
            ->getRowArray();
        return $rows ?? [];
    }

    /**
     * 그룹 리스트
     */
    public function getMemberGroup($post = [])
    {
        $disp = $post['disp'] ?? "1";
        $use_coupon_yn = $post['use_coupon_yndisp'] ?? "Y";

        if ($disp != "All") {
            $this->qb->where('disp', $disp);
        }
        if ($use_coupon_yn == "All") {
            $this->qb->where('use_coupon_yn', $use_coupon_yn);
        }


        return $this->qb->from(TBL_SHOP_GROUPINFO)
            ->where('is_delete', 0)
            ->orderBy('gp_ix', 'desc')
            ->exec()->getResultArray();
    }

    /**
     * 크리마 회원등급 리스트
     */
    public function getCremaMemberGroup($post = [], $crema_id = 'false')
    {
        if ($crema_id) {
            $this->qb->where('crema_id !=', -1);
        } else {
            $this->qb->where('crema_id', -1);
        }

        return $this->getMemberGroup();
    }

    /**
     * gp_ix로 아이디 찾기
     */
    public function getCremaIdByGroup($gp_ix)
    {
        return $this->qb
            ->select('crema_id')
            ->from(TBL_SHOP_GROUPINFO)
            ->where('gp_ix', $gp_ix)
            ->limit(1)
            ->exec()
            ->getResultArray();
    }

    /**
     * oid로 주문상세 option_text 가져오기
     */
    public function getCremaProductOption($oid)
    {
        return $this->qb
            ->select('option_text')
            ->from(TBL_SHOP_ORDER_DETAIL)
            ->where('oid', $oid)
            ->exec()
            ->getResultArray();
    }

    /**
     * 크리마 회원등급 id shop_groupinfo crema_id 업데이트
     */
    public function updateCremaMemberGroup($id, $gp_ix)
    {
        return $this->qb
            ->set('crema_id', $id)
            ->where('gp_ix', $gp_ix)
            ->update(TBL_SHOP_GROUPINFO)
            ->exec();
    }

    /**
     * 크리마 회원등급 삭제 시, shop_groupinfo에서 crema_id -1로 업데이트
     */
    public function updateCremaMemberGroupAfterDelete($crema_id)
    {
        return $this->qb
            ->set('crema_id', -1)
            ->where('crema_id', $crema_id)
            ->update(TBL_SHOP_GROUPINFO)
            ->exec();
    }

    /**
     * 회원 그룹 리스트
     * @param type $cur_page
     * @param type $limit
     * @param type $search
     * @return type
     */
    public function getMemberGroupList($cur_page = 1, $limit = 20, $search = [])
    {
        $this->qb->startCache();

        $this->qb
            ->from(TBL_SHOP_GROUPINFO . ' as sg')
            ->where('is_delete', '0');


        $this->qb->stopCache();

        $total = $this->qb->getCount();
        $paging = $this->qb
            ->setTotalRows($total)
            ->pagination($cur_page, $limit);

        $offset = ($paging['offset'] ?? 0);

        $rows = $this->qb
            ->select('sg.*')
            ->orderBy('sg.gp_level', 'ASC')
            ->limit($limit, $offset)
            ->exec()
            ->getResultArray();

        $this->qb->flushCache();

        //치환 처리
        foreach ($rows as $key => $val) {
            switch ($val['use_coupon_yn']) {
                case 'Y':
                    $rows[$key]['use_coupon_yn_text'] = '쿠폰 사용 가능';
                    break;
                case 'N':
                    $rows[$key]['use_coupon_yn_text'] = '쿠폰 사용 불가능';
                    break;
            }
            switch ($val['use_reserve_yn']) {
                case 'Y':
                    $rows[$key]['use_reserve_yn_text'] = '마일리지 사용 가능';
                    break;
                case 'N':
                    $rows[$key]['use_reserve_yn_text'] = '마일리지 사용 불가능';
                    break;
            }

            switch ($val['basic']) {
                case 'Y':
                    $rows[$key]['basic_text'] = '기본';
                    break;
                default:
                    $rows[$key]['basic_text'] = '-';
                    break;
            }

            switch ($val['disp']) {
                case '1':
                    $rows[$key]['disp_text'] = '사용';
                    break;
                default:
                    $rows[$key]['disp_text'] = '미사용';
                    break;
            }
            switch ($val['selling_type']) {
                case 'R':
                    $rows[$key]['selling_type_text'] = '소매';
                    break;
                case 'W':
                    $rows[$key]['selling_type_text'] = '도매';
                    break;
                default:
                    $rows[$key]['selling_type_text'] = '';
                    break;
            }
            switch ($val['dc_standard_price']) {
                case 'l':
                    $rows[$key]['dc_standard_price_text'] = '판매가';
                    break;
                case 's':
                    $rows[$key]['dc_standard_price_text'] = '할인가';
                    break;
                case 'p':
                    $rows[$key]['dc_standard_price_text'] = '프리미엄가';
                    break;
            }
            switch ($val['use_discount_type']) {
                case '':
                    $rows[$key]['use_discount_type_text'] = '미사용';
                    break;
                case 'g':
                    $retail_dc = $val['retail_dc'] ?? 0;
                    $rows[$key]['use_discount_type_text'] = '사용(' . $retail_dc . '%)';
                    break;
            }

            if ($val['order_price'] > 0) {
                $rows[$key]['order_price_text'] = number_format($val['order_price']);
            } else {
                $rows[$key]['order_price_text'] = 0;
            }

            if ($val['ed_order_price'] > 0) {
                $rows[$key]['ed_order_price_text'] = number_format($val['ed_order_price']);
            } else {
                $rows[$key]['ed_order_price_text'] = 0;
            }

            if ($val['all_disp'] > 0) {
                $rows[$key]['all_disp_text'] = "사용";
            } else {
                $rows[$key]['all_disp_text'] = "미사용";
            }

            if ($val['gp_type'] > 0) {
                $rows[$key]['gp_type_text'] = $val['gp_type'] . " 개월";
            } else {
                $rows[$key]['gp_type_text'] = "1 개월";
            }

            $rows[$key]['organization_img_src'] = '';
            if ($val['organization_img']) {
                $rows[$key]['organization_img_src'] = MEMBER_GROUP_UPLOAD_WEB_PATH . $val['organization_img'];
            }
        }

        return [
            'total' => $total
            ,
            'list' => $rows
            ,
            'paging' => $paging
        ];
    }

    /**
     * 회원 그룹 변경
     * @param type $post
     * @param type $file
     * @return type
     */
    public function putMemberGroup($post = [], $file = [])
    {
        if (isset($post['deleteFile'])) {
            $deleteFile = json_decode($post['deleteFile'], true) ?? [];
        } else {
            $deleteFile = [];
        }

        if (count($deleteFile) > 0) {
            foreach ($deleteFile as $delFile) {
                @unlink(DOCUMENT_ROOT . $delFile['file']);
            }

            $this->qb->where('gp_ix', $post['gp_ix'])
                ->update(TBL_SHOP_GROUPINFO, ['organization_img' => ""])
                ->exec();
        }


        if (($file['fileName'] ?? null)) {
            $data_set ['organization_img'] = $file['fileName'];
        }

        $data_set ['gp_name'] = $post['gp_name'];
        $data_set ['gp_type'] = $post['gp_type'];
        $data_set ['all_disp'] = $post['all_disp'];
        $data_set ['order_price'] = $post['order_price'];
        $data_set ['ed_order_price'] = $post['ed_order_price'];
        $data_set ['gp_level'] = $post['gp_level'];
        $data_set ['selling_type'] = $post['selling_type'];
        $data_set ['dc_standard_price'] = $post['dc_standard_price'];
        $data_set ['disp'] = $post['disp'];
        $data_set ['use_coupon_yn'] = $post['use_coupon_yn'];
        $data_set ['use_reserve_yn'] = $post['use_reserve_yn'];
        $data_set ['use_discount_type'] = $post['use_discount_type'];
        $data_set ['retail_dc'] = $post['retail_dc'];
        $data_set['basic'] = $post['basic'];

        if ($data_set['basic'] == 'Y') {
            $this->qb
                ->set('basic', 'N')
                ->update(TBL_SHOP_GROUPINFO)
                ->where('basic', 'Y')
                ->exec();
        }

        if ($post['gp_ix']) {
            $this->qb->where('gp_ix', $post['gp_ix'])
                ->update(TBL_SHOP_GROUPINFO, $data_set)
                ->exec();
        } else {
            $this->qb
                ->insert(TBL_SHOP_GROUPINFO, $data_set)
                ->exec();
        }
        $result['status'] = 'success';
        $result['data'] = $data_set;
        return $result;
    }

    /**
     * 탈퇴회원리스트
     */
    public function getListMemberDrop($cur_page = 1, $limit = 20, $search = [])
    {
        $this->qb->startCache();

        // 검색 조건
        if (isset($search['searchType']) && $search['searchType'] && isset($search['searchText']) && $search['searchText']) {
            $this->qb->like($search['searchType'], $search['searchText']);
        }

        if (isset($search['name']) && $search['name']) {
            $this->qb->like($this->qb->decrypt('name'), $search['name']);
        }

        //날짜검색
        if (($search['betweenDatePickerStart'] ?? null) && ($search['betweenDatePickerEnd'] ?? null)) {
            $this->qb->betweenDate('dropdate', $search['betweenDatePickerStart'], $search['betweenDatePickerEnd']);
        }

        $this->qb
            ->from(TBL_COMMON_DROPMEMBER . ' AS cd')
            ->join(TBL_COMMON_DROPMEMBER_SETUP . ' AS cds', 'cds.drop_ix = cd.drop_ix');


        $this->qb->stopCache();
        $total = $this->qb->getCount();
        $paging = $this->qb
            ->setTotalRows($total)
            ->pagination($cur_page, $limit);

        $offset = ($paging['offset'] ?? 0);

        $rows = $this->qb
            ->decryptSelect('cd.name', 'name')
            ->select('cd.id')
            ->select('cd.code')
            ->decryptSelect('cd.email', 'email')
            ->select('cd.message')
            ->select('cd.dropdate')
            ->select('cds.dp_name')
            ->orderBy('dropdate', 'DESC')
            ->limit($limit, $offset)
            ->exec()
            ->getResultArray();

        $this->qb->flushCache();
        return [
            'total' => $total
            ,
            'list' => $rows
            ,
            'paging' => $paging
        ];
    }

    /**
     *  탈퇴 회원 삭제
     */
    public function delListMemberDrop($post = [])
    {
        $this->qb
            ->where('code', $post['code'])
            ->delete(TBL_COMMON_DROPMEMBER)
            ->exec();
        $result['status'] = 'success';
        return $result;
    }

    /**
     * 탈퇴사유리스트
     * @param type $cur_page
     * @param type $limit
     * @param type $search
     * @return type
     */
    public function getListDropMemberConfig($cur_page = 1, $limit = 20, $search = [])
    {
        $this->qb->startCache();

        // 검색 조건
        if (isset($search['searchType']) && $search['searchType'] && isset($search['searchText']) && $search['searchText']) {
            $this->qb->like($search['searchType'], $search['searchText']);
        }

        if (isset($search['name']) && $search['name']) {
            $this->qb->like('name', $search['name']);
        }

        //날짜검색
        if (($search['betweenDatePickerStart'] ?? null) && ($search['betweenDatePickerEnd'] ?? null)) {
            $this->qb->betweenDate('dropdate', $search['betweenDatePickerStart'], $search['betweenDatePickerEnd']);
        }

        $this->qb
            ->from(TBL_COMMON_DROPMEMBER_SETUP . ' AS cds');


        $this->qb->stopCache();
        $total = $this->qb->getCount();
        $paging = $this->qb
            ->setTotalRows($total)
            ->pagination($cur_page, $limit);

        $offset = ($paging['offset'] ?? 0);

        $rows = $this->qb
            ->select('cds.*')
            ->orderBy('regdate', 'ASC')
            ->limit($limit, $offset)
            ->exec()
            ->getResultArray();

        $this->qb->flushCache();
        return [
            'total' => $total
            ,
            'list' => $rows
            ,
            'paging' => $paging
        ];
    }

    /**
     * 탈퇴회원 사유 분류설정 수정
     * @param type $post
     * @return string
     */
    public function putListDropMemberConfig($post = [])
    {
        $mode = $post['mode'];

        if ($mode == 'update') {
            $this->qb
                ->set('dp_name', $post['dp_name'])
                ->set('disp', $post['disp'])
                ->set('dp_msg', $post['dp_msg'])
                ->set('editdate', date('Y-m-d H:i:s'))
                ->where('drop_ix', $post['drop_ix'])
                ->update(TBL_COMMON_DROPMEMBER_SETUP)
                ->exec();
        } else {
            $this->qb
                ->set('dp_name', $post['dp_name'])
                ->set('disp', $post['disp'])
                ->set('dp_msg', $post['dp_msg'])
                ->set('regdate', date('Y-m-d H:i:s'))
                ->insert(TBL_COMMON_DROPMEMBER_SETUP)
                ->exec();
        }
        $result['status'] = 'success';
        return $result;
    }

    /**
     * 탈퇴회원 사유 분류설정 삭제
     * @param type $post
     * @return string
     */
    public function delListDropMemberConfig($post = [])
    {
        $this->qb
            ->where('drop_ix', $post['drop_ix'])
            ->delete(TBL_COMMON_DROPMEMBER_SETUP)
            ->exec();
        $result['status'] = 'success';
        return $result;
    }

    /**
     * 마일리지 리스트
     * @param type $cur_page
     * @param type $limit
     * @param type $search
     * @return type
     */
    public function getListMileage($cur_page = 1, $limit = 20, $search = [])
    {

        $this->qb->startCache();

        // 검색 조건
        if (isset($search['searchType']) && $search['searchType'] && isset($search['searchText']) && $search['searchText']) {
            if (in_array($search['searchType'], ['name', 'mail', 'pcs'])) {
                $this->qb->like($this->qb->decrypt($search['searchType']), $search['searchText']);
            } elseif ($search['searchType'] == 'etc') {
                $this->qb->like('ri.message', $search['searchText']);
            } else {
                $this->qb->like($search['searchType'], $search['searchText']);
            }
        }

        if (isset($search['info_type']) && $search['info_type']) {
            if ($search['info_type'] == 'add') {
                $this->qb->where('ml_state', 1);
            } else {
                if ($search['info_type'] == 'use') {
                    $this->qb->where('ml_state', 2);
                }
            }
        }

        //날짜검색
        if (($search['devBetweenDatePickerStart'] ?? null) && ($search['devBetweenDatePickerEnd'] ?? null)) {
            $this->qb->betweenDate('ri.date', $search['devBetweenDatePickerStart'], $search['devBetweenDatePickerEnd']);
        }

        //code
        if (isset($search['code']) && $search['code']) {
            $this->qb->where('cu.code', $search['code']);
        }

        $this->qb
            ->from(TBL_SHOP_MILEAGE_LOG . ' AS ri')
            ->join(TBL_COMMON_USER . ' AS cu', 'ri.uid = cu.code')
            ->join(TBL_COMMON_MEMBER_DETAIL . ' AS cmd', 'cu.code = cmd.code')
            ->join(TBL_SHOP_GROUPINFO . ' AS g', 'cmd.gp_ix = g.gp_ix', 'left');

        $this->qb->stopCache();
        $total = $this->qb->getCount();

        //마일리지 합산 쿼리
        $sum = $this->qb
            ->select('ml_state')
            ->selectSum('ri.ml_mileage')
            ->groupBy('ml_state')
            ->exec()->getResultArray();

        //상태값 1과 상태값 2의 배열의 값을 합산
        $sum = array_column($sum, 'ml_mileage', 'ml_state');

        $paging = $this->qb
            ->setTotalRows($total)
            ->pagination($cur_page, $limit);

        $offset = ($paging['offset'] ?? 0);

        $rows = $this->qb
            ->select('ri.*')
            ->select('cu.id')
            ->select('cu.code')
            ->select('g.gp_name')
            ->decryptSelect('cmd.name')
            ->decryptSelect('cmd.mail')
            ->orderBy('ri.regdate', 'desc')
            ->limit($limit, $offset)
            ->exec()
            ->getResultArray();

        $this->qb->flushCache();


        //치환 처리
        $sum_mileage = 0;
        foreach ($rows as $key => $val) {
            switch ($val['ml_state']) {
                case '1':
                    $rows[$key]['ml_state_text'] = '적립완료(+)';
                    break;
                case '2':
                    $rows[$key]['ml_state_text'] = '사용(-)';
                    break;
            }
            if ($val['ml_mileage']) {
                $rows[$key]['ml_mileage'] = number_format($val['ml_mileage']);
            }
        }

        return [
            'total' => $total
            ,
            'list' => $rows
            ,
            'paging' => $paging
            ,
            'sum_mileage' => $sum
        ];
    }

    /**
     * 마일리지 설정 값 가져오기
     * @return type
     */
    public function getMileageConfig()
    {
        $reserve_data = \ForbizConfig::getSharedMemory("b2c_mileage_rule");
        $memberGroup = $this->getMemberGroup();

        //common , p , m 타입 레이트 넣음
        foreach ($reserve_data["mileage_rate"] as $key => $val) {
            $reserve_data['mileage_rate_' . $key] = $val;
        }

        //gp_ix 타입 레이트 넣음
        foreach ($memberGroup as $key => $val) {
            $memberGroup[$key]['mileage_rate'] = $reserve_data['mileage_rate'][$val["gp_ix"]] ?? 0;
        }

        return [
            'memberGroup' => $memberGroup
            ,
            'reserveData' => $reserve_data
        ];
    }

    /**
     * 마일리지 설정
     * @param type $post
     * @return type
     */
    public function putMileageConfig($post = [])
    {
        $result = [];
        $result['status'] = 'success';

        $data_set = [];
        $data_set ['mileage_use_yn'] = $post['mileage_use_yn'];
        $data_set ['mileage_name'] = $post['mileage_name'];
        $data_set ['mileage_unit_txt'] = $post['mileage_unit_txt'];
        $data_set ['scale'] = $post['scale'];
        $data_set ['standard'] = $post['standard'];
        $data_set ['mileage_info_use'] = $post['mileage_info_use'];

        foreach ($this->input->post('mileage_rate') as $key => $val) {
            $data_set['mileage_rate'][$key] = $val;
        }

        $data_set ['mileage_add_setup'] = $post['mileage_add_setup'];
        $data_set ['join_use'] = $post['join_use'];
        $data_set ['join_rate'] = $post['join_rate'];
        $data_set ['use_unit'] = $post['use_unit'];
        $data_set ['min_mileage_price'] = $post['min_mileage_price'];
        $data_set ['deliveryprice'] = $post['deliveryprice'];
        $data_set ['total_order_price'] = $post['total_order_price'];
        $data_set ['mileage_one_use_type'] = $post['mileage_one_use_type'];
        $data_set ['use_mileage_max'] = $post['use_mileage_max'];
        $data_set ['max_goods_sum_rate'] = $post['max_goods_sum_rate'];
        $data_set ['auto_extinction'] = $post['auto_extinction'];
        $data_set ['cancel_year'] = $post['cancel_year'];
        $data_set ['cancel_month'] = $post['cancel_month'];

        $status = \ForbizConfig::setSharedMemory("b2c_mileage_rule", $data_set);
        if (!$status) {
            $result['status'] = 'fail';
            $result['error'] = 'shareMemory write fail';
        }

        $result['data'] = $data_set;
        return $result;
    }

    /**
     * 회원 그룹 일괄 변경
     * @param type $search
     * @return string
     */
    public function putBatchChangeMemberGroup($search = [])
    {
        $data_set = [];
        if ($search['update_type'] == 1) {
            $this->putBatchSearch($search);  //검색조건이 qb->where 해서 넘어온다
            $this->qb
                ->set('gp_ix', $search['update_gp_ix'])
                ->update(TBL_COMMON_MEMBER_DETAIL . ' as  cmd')
                ->exec();
        } else {
            //선택 회원            
            $this->qb
                ->whereIn('code', explode(",", $search['selectCode']))
                ->set('gp_ix', $search['update_gp_ix'])
                ->update(TBL_COMMON_MEMBER_DETAIL . ' as cmd')
                ->exec();
        }
        $result['data'] = $search;
        $result['status'] = 'success';
        return $result;
    }

    /**
     * 일반 회원 휴면 회원 전환
     * @param type $search
     * @return type
     */
    public function putManageSleepMemberNomal($search = [])
    {
        $message = $search['message'] ?? "일반회원->휴면회원";

        if ($search['update_type'] == 1) {
            $this->putBatchSearch($search);  //검색조건이 셋해서 넘어온다

            $userArr = $this->qb
                ->select('cu.code')
                ->from(TBL_COMMON_USER . ' as cu')
                ->join(TBL_COMMON_MEMBER_DETAIL . ' as cmd', 'cu.code=cmd.code')
                ->whereNotIn('cu.id', ['forbiz']) // 포비즈 계정 제외
                ->exec()
                ->getResultArray();
        } else {
            //선택 회원            
            $this->qb->whereIn('code', explode(",", $search['selectCode']));
            $userArr = $this->qb
                ->select('code')
                ->from(TBL_COMMON_MEMBER_DETAIL)
                ->exec()
                ->getResultArray();
        }


        $change = 0;
        foreach ($userArr as $key => $value) {
            $status = $this->changeMemberToSleep($value['code'], $message, (sess_val('admininfo', 'charger_ix') ?? ''));
            $change += $status;
        }

        return [
            'status' => 'success',
            'data' => [
                'total' => count($userArr),
                'change' => $change
            ]
        ];
    }

    /**
     * 휴면 회원 일반 회원 전환
     * @param type $search
     * @return type
     */
    public function putManageSleepMember($search = [])
    {

        $message = (!empty($search['message']) ? $search['message'] : "휴면회원->일반회원");

        $userArr = [];
        $data_set = [];
        if ($search['update_type'] == 1) {
            $this->putBatchSearch($search);  //검색조건이 셋해서 넘어온다
            $userArr = $this->qb
                ->from(TBL_COMMON_MEMBER_DETAIL_SLEEP . ' mds')
                ->join(TBL_COMMON_USER_SLEEP . ' us', 'mds.code=us.code')
                ->exec()
                ->getResultArray();
        } else {
            //선택 회원            
            $this->qb->whereIn('us.code', explode(",", $search['selectCode']));
            $userArr = $this->qb
                ->from(TBL_COMMON_MEMBER_DETAIL_SLEEP . ' mds')
                ->join(TBL_COMMON_USER_SLEEP . ' us', 'mds.code=us.code')
                ->exec()
                ->getResultArray();
        }

        $change = 0;
        foreach ($userArr as $key => $value) {
            $status = $this->changeSleepToMember($value['code'], $message, (sess_val('admininfo', 'charger_ix') ?? ''));
            $change += $status;
        }

        return [
            'status' => 'success'
            ,
            'data' => [
                'total' => count($userArr)
                ,
                'change' => $change
            ]
        ];
    }

    /**
     * 일반계정 휴면
     * @param type $userCode
     * @param type $message
     * @return type
     */
    public function changeMemberToSleep($userCode, $message, $charger_ix = '')
    {
        $this->qb->transStart();

        // log 작성
        $this->qb
            ->set('code', $userCode)
            ->set('message', $message)
            ->set('charger_ix', $charger_ix)
            ->set('change_type', 'S')
            ->set('regdate', date('Y-m-d H:i:s'))
            ->set('id',
                $this->qb
                    ->startSubQuery()
                    ->select('id')->from(TBL_COMMON_USER)->where('code', $userCode)
                    ->endSubQuery(), false
            )
            ->set('name',
                $this->qb
                    ->startSubQuery()
                    ->select('name')->from(TBL_COMMON_MEMBER_DETAIL)->where('code', $userCode)
                    ->endSubQuery(), false
            )
            ->set('status', 'A')
            ->insert(TBL_COMMON_USER_SLEEP_LOG)
            ->exec();

        // 회원 정보 삭제
        $this->qb->exec($this->qb->queryBind(
            'INSERT INTO ' . TBL_COMMON_USER_SLEEP . ' SELECT * FROM ' . TBL_COMMON_USER . ' WHERE code = ? AND NOT EXISTS (SELECT code FROM ' . TBL_COMMON_USER_SLEEP . ' WHERE code=?)',
            [$userCode, $userCode]
        ));

        // 회원 상세 정보 삭제
        $this->qb->exec($this->qb->queryBind(
            'INSERT INTO ' . TBL_COMMON_MEMBER_DETAIL_SLEEP . ' SELECT * FROM ' . TBL_COMMON_MEMBER_DETAIL . ' WHERE code = ? AND NOT EXISTS (SELECT code FROM ' . TBL_COMMON_MEMBER_DETAIL_SLEEP . ' WHERE code=?)',
            [$userCode, $userCode]
        ));

        // 회원 정보 삭제
        $this->qb->where('code', $userCode)->delete(TBL_COMMON_USER)->exec();

        // 회원 상세 정보 삭제
        $this->qb->where('code', $userCode)->delete(TBL_COMMON_MEMBER_DETAIL)->exec();

        // 주문정보 조회
        $rows = $this->qb->select('oid')->from(TBL_SHOP_ORDER)->where('user_code', $userCode)->exec()->getResultArray();
        if (!empty($rows)) {
            foreach ($rows as $row) {

                $sql = [
                    'INSERT INTO',
                    TBL_SEPARATION_SHOP_ORDER,
                    '(oid, btel, bmobile, bmail, bzip, baddr, regdate)',
                    'SELECT',
                    'oid, btel, bmobile, bmail, bzip, baddr, NOW()',
                    'FROM',
                    TBL_SHOP_ORDER,
                    'WHERE oid = ?'
                ];

                $this->qb->exec($this->qb->queryBind(implode(' ', $sql), [$row['oid']]));

                $this->qb
                    ->set('btel', '')
                    ->set('bmobile', '')
                    ->set('bmail', '')
                    ->set('bzip', '')
                    ->set('baddr', '')
                    ->where('oid', $row['oid'])
                    ->update(TBL_SHOP_ORDER)
                    ->exec();

                //휴면 진행 시 배송지 정보 휴면 처리
                $this->changeOrderDeliveryToSleep($row['oid']);

            }
        }

        //트랜젹션 끝
        $this->qb->transComplete();
        return $this->qb->transStatus();
    }

    protected function changeOrderDeliveryToSleep($oid)
    {
        $rows = $this->qb->select('odd_ix')->from(TBL_SHOP_ORDER_DETAIL_DELIVERYINFO)->where('oid',
            $oid)->exec()->getResultArray();
        if (!empty($rows)) {
            foreach ($rows as $row) {
                $sql = [
                    'INSERT INTO',
                    TBL_SEPARATION_SHOP_ORDER_DELIVERYINFO,
                    '(odd_ix, oid, od_ix, rname, rtel, rmobile, rmail, zip, addr1, addr2, regdate) ',
                    'SELECT',
                    'odd_ix, oid, od_ix, rname, rtel, rmobile, rmail, zip, addr1, addr2, NOW()',
                    'FROM',
                    TBL_SHOP_ORDER_DETAIL_DELIVERYINFO,
                    'WHERE odd_ix = ?'
                ];

                $this->qb->exec($this->qb->queryBind(implode(' ', $sql), [$row['odd_ix']]));

                $this->qb
                    ->set('rname', '휴면회원')
                    ->set('rtel', '')
                    ->set('rmobile', '')
                    ->set('rmail', '')
                    ->set('zip', '')
                    ->set('addr1', '')
                    ->set('addr2', '')
                    ->where('odd_ix', $row['odd_ix'])
                    ->update(TBL_SHOP_ORDER_DETAIL_DELIVERYINFO)
                    ->exec();
            }
        }
    }

    /**
     * 휴면계정 활성화
     * @param type $userCode
     * @param type $message
     * @return type
     */
    public function changeSleepToMember($userCode, $message, $charger_ix = '')
    {
        $this->qb->transStart();

        // log 작성
        $this->qb
            ->set('code', $userCode)
            ->set('message', $message)
            ->set('charger_ix', $charger_ix)
            ->set('change_type', 'M')
            ->set('regdate', date('Y-m-d H:i:s'))
            ->set('id',
                $this->qb
                    ->startSubQuery()
                    ->select('id')->from(TBL_COMMON_USER_SLEEP)->where('code', $userCode)
                    ->endSubQuery(), false
            )
            ->set('name',
                $this->qb
                    ->startSubQuery()
                    ->select('name')->from(TBL_COMMON_MEMBER_DETAIL_SLEEP)->where('code', $userCode)
                    ->endSubQuery(), false
            )
            ->set('status', 'A')
            ->insert(TBL_COMMON_USER_SLEEP_LOG)
            ->exec();

        // 회원 정보 복원
        $this->qb->exec($this->qb->queryBind(
            'INSERT INTO ' . TBL_COMMON_USER . ' SELECT * FROM ' . TBL_COMMON_USER_SLEEP . ' WHERE code = ? AND NOT EXISTS (SELECT code FROM ' . TBL_COMMON_USER . ' WHERE code=?)',
            [$userCode, $userCode]
        ));

        // 회원 상세 정보 복원
        $this->qb->exec($this->qb->queryBind(
            'INSERT INTO ' . TBL_COMMON_MEMBER_DETAIL . ' SELECT * FROM ' . TBL_COMMON_MEMBER_DETAIL_SLEEP . ' WHERE code = ? AND NOT EXISTS (SELECT code FROM ' . TBL_COMMON_MEMBER_DETAIL . ' WHERE code=?)',
            [$userCode, $userCode]
        ));

        // 휴면회원 정보 삭제
        $this->qb->where('code', $userCode)->delete(TBL_COMMON_USER_SLEEP)->exec();

        // 휴면회원 상세 정보 삭제
        $this->qb->where('code', $userCode)->delete(TBL_COMMON_MEMBER_DETAIL_SLEEP)->exec();

        // 주문정보 조회
        $rows = $this->qb->select('oid')->from(TBL_SHOP_ORDER)->where('user_code', $userCode)->exec()->getResultArray();
        if (!empty($rows)) {
            foreach ($rows as $row) {
                $sql = "
                UPDATE " . TBL_SHOP_ORDER . " as o, " . TBL_SEPARATION_SHOP_ORDER . " as so
                SET o.btel = so.btel,
                     o.bmobile = so.bmobile,
                     o.bmail = so.bmail,
                     o.bzip = so.bzip,
                     o.baddr = so.baddr
                WHERE
                    `o`.`oid` = '" . $row['oid'] . "'
                AND o.oid = so.oid
                ";
                $this->qb->exec($sql);
                $this->qb->where('oid', $row['oid'])->delete(TBL_SEPARATION_SHOP_ORDER)->exec();

                $this->changeOrderDeliveryToMember($row['oid']);
            }
        }

        //트랜젹션 끝
        $this->qb->transComplete();
        return $this->qb->transStatus();
    }

    protected function changeOrderDeliveryToMember($oid)
    {
        $rows = $this->qb->select('odd_ix')->from(TBL_SEPARATION_SHOP_ORDER_DELIVERYINFO)->where('oid',
            $oid)->exec()->getResultArray();
        if (!empty($rows)) {
            foreach ($rows as $row) {

                $sql = "UPDATE " . TBL_SEPARATION_SHOP_ORDER_DELIVERYINFO . " as d, " . TBL_SHOP_ORDER_DETAIL_DELIVERYINFO . " as sd
                SET sd.rname = d.rname,
                     sd.rtel = d.rtel,
                     sd.rmobile = d.rmobile,
                     sd.rmail = d.rmail,
                     sd.zip = d.zip,
                     sd.addr1 = d.addr1,
                     sd.addr2 = d.addr2
                WHERE
                    `d`.`odd_ix` = '" . $row['odd_ix'] . "'
                AND d.odd_ix = sd.odd_ix";
                $this->qb->exec($sql);
                $this->qb->where('odd_ix', $row['odd_ix'])->delete(TBL_SEPARATION_SHOP_ORDER_DELIVERYINFO)->exec();

            }
        }
    }

    /**
     * get 휴면 리스트
     * @param type $cur_page
     * @param type $limit
     * @param type $search
     * @return type
     */
    public function getSleepList($cur_page = 1, $limit = 20, $search = [])
    {
        $this->qb->startCache();

        // 검색 조건
        if (isset($search['searchType']) && $search['searchType'] && isset($search['searchText']) && $search['searchText']) {
            if (in_array($search['searchType'], ['name', 'mail', 'pcs'])) {
                if ($search['searchType'] == 'pcs') {
                    $this->qb->like('REPLACE(CAST(' . $this->qb->decrypt($search['searchType']) . ' AS CHAR),"-","")', $search['searchText']);
                } else {
                    $this->qb->like($this->qb->decrypt($search['searchType']), $search['searchText']);
                }
            } else {
                $this->qb->like($search['searchType'], $search['searchText']);
            }
        }

        //회원 그룹
        if (isset($search['gp_ix']) && !empty($search['gp_ix'])) {
            $this->qb->whereIn('cmd.gp_ix', $search['gp_ix']);
        }

        //회원구분
        if (isset($search['mem_type']) && !empty($search['mem_type'])) {
            $this->qb->whereIn('cu.mem_type', $search['mem_type']);
        }

        //회원타입
        if (isset($search['mem_div']) && !empty($search['mem_div'])) {
            $this->qb->whereIn('cu.mem_div', $search['mem_div']);
        }

        //승인여부
        if (isset($search['authorized']) && !empty($search['authorized'])) {
            $this->qb->whereIn('cu.authorized', $search['authorized']);
        }

        //셀러 타입
        if (isset($search['company_id']) && !empty($search['company_id'])) {
            $this->qb->where('cu.company_id', $search['company_id']);
        }

        //날짜검색
        if (isset($search['selDateType']) && !empty($search['selDateType'])) {
            if ($search['selDateType'] == "R") {
                //가입기준
                if (($search['betweenDatePickerStart'] ?? null) && ($search['betweenDatePickerEnd'] ?? null)) {
                    $this->qb->betweenDate('cmd.date', $search['betweenDatePickerStart'], $search['betweenDatePickerEnd']);
                }
            } elseif ($search['selDateType'] == "C") {
                //최근 방문일 기준
                if (($search['betweenDatePickerStart'] ?? null) && ($search['betweenDatePickerEnd'] ?? null)) {
                    $this->qb->betweenDate('cu.last', $search['betweenDatePickerStart'], $search['betweenDatePickerEnd']);
                }
            }
        }

        //회원승인관리 기간검색 -- 등록일
        if (($search['authBetweenDatePickerStart'] ?? null) && ($search['authBetweenDatePickerEnd'] ?? null)) {
            $this->qb->betweenDate('cu.date', $search['authBetweenDatePickerStart'], $search['authBetweenDatePickerEnd']);
        }

        //미승인 여부 -- 처음 리스트 가져올경우
        if (isset($search['is_serach']) && !empty($search['is_serach']) && $search['is_serach'] == "N") {
            $this->qb->where('cu.authorized', 'N');
        }

        //신청처리상태
        if (isset($search['authorized']) && !empty($search['authorized'])) {
            $this->qb->where('cu.authorized', $search['authorized']);
        }

        //일괄 회원구분
        if (isset($search['chk_mem_type']) && !empty($search['chk_mem_type'])) {
            $this->qb->whereIn('cu.mem_type', $search['chk_mem_type']);
        }

        //일괄 회원타입
        if (isset($search['chk_mem_div']) && !empty($search['chk_mem_div'])) {
            $this->qb->whereIn('mem_div', $search['chk_mem_div']);
        }

        //일괄 성별 검색
        if (isset($search['chk_sex_div']) && !empty($search['chk_sex_div'])) {
            $this->qb->whereIn('sex_div', $search['chk_sex_div']);
        }
        //일괄 sms 동의 검색
        if (isset($search['smssend_yn']) && !empty($search['smssend_yn'])) {
            $this->qb->whereIn('sms', $search['smssend_yn']);
        }
        //일괄 메일수신 동의 검색
        if (isset($search['mailsend_yn']) && !empty($search['mailsend_yn'])) {
            $this->qb->whereIn('info', $search['mailsend_yn']);
        }
        //일괄 회원그룹 검색
        if (isset($search['memberGroupBath']) && !empty($search['memberGroupBath'])) {
            $this->qb->whereIn('cmd.gp_ix', $search['memberGroupBath']);
        }

        $this->qb
            ->from(TBL_COMMON_USER_SLEEP . ' as cu')
            ->join(TBL_COMMON_MEMBER_DETAIL_SLEEP . ' as cmd', 'cu.code=cmd.code')
            ->join(TBL_SHOP_GROUPINFO . ' as sg', 'sg.gp_ix=cmd.gp_ix', 'left');
        $this->qb->stopCache();

        $total = $this->qb->getCount();
        $paging = $this->qb
            ->setTotalRows($total)
            ->pagination($cur_page, $limit);

        $offset = ($paging['offset'] ?? 0);

        $rows = $this->qb
            ->select('cu.code')
            ->select('cu.code as mem_code')
            ->select('cu.id')
            ->select('cu.mem_type')
            ->select('cu.mem_div')
            ->select('cu.auth')
            ->select('cu.last')
            ->select('cu.visit')
            ->select('cu.mileage')
            ->decryptSelect('cmd.name')
            ->decryptSelect('cmd.mail')
            ->decryptSelect('cmd.pcs')
            ->select('sg.gp_name')
            ->select('cu.date')
            ->select('cu.language')
            ->select('cu.authorized')
            ->select('cmd.sex_div')
            ->select('cmd.birthday')
            ->select('cmd.birthday_div')
            ->select('cmd.info')
            ->select('cmd.sms')
            ->select('cu.language as language_type')
            ->select('cmd.com_group')
            ->select('cmd.gp_ix')
            ->decryptSelect('cmd.zip')
            ->decryptSelect('cmd.tel')
            ->decryptSelect('cmd.addr1')
            ->decryptSelect('cmd.addr2')
            ->select(
                $this->qb->startSubQuery('`status`')
                    ->select('status')->from(TBL_COMMON_USER_SLEEP_LOG)->where('code', 'cmd.code', false)
                    ->orderBy('code', 'desc')
                    ->limit(1)
                    ->endSubQuery(), false
            )
            ->select(
                $this->qb->startSubQuery('change_date')
                    ->select('regdate as change_date')->from(TBL_COMMON_USER_SLEEP_LOG)->where('code', 'cmd.code', false)
                    ->orderBy('code', 'desc')
                    ->limit(1)
                    ->endSubQuery(), false
            )
            ->select('cmd.birthday')
            ->orderBy('cu.date', 'DESC')
            ->limit($limit, $offset)
            ->exec()
            ->getResultArray();

        $this->qb->flushCache();

        //치환 처리
        foreach ($rows as $key => $val) {
            $val['memTypeText'] = $this->getMemTypeText($val['mem_type']);
            $val['memTypeTextDiv'] = $this->getMemTypeText($val['mem_type']);
            $mem_div = "";
            switch ($val['mem_div']) {
                case "MD":
                    $mem_div = "MD";
                    break;
                case "S":
                    $mem_div = "셀러";
                    break;
                case "D":
                    $mem_div = "기타";
                    break;
            }
            if ($mem_div) {
                $val['memTypeTextDiv'] .= "(" . $mem_div . ")";
            } else {
                $val['memTypeTextDiv'] .= $mem_div;
            }
            $val['smsText'] = ($val['sms'] == 1) ? "O" : "X";
            $val['infoText'] = ($val['info'] == 1) ? "O" : "X";

            $templateAuth = $this->getTemplateAuth($val['code']) ?? [];
            if (count($templateAuth) > 0) {
                $val['templateAuth'] = $templateAuth['group_name'];
            }

            $status = "";
            switch ($val['status']) {
                case "A":
                    $status = "어드민 일괄처리";
                    break;
                case "S":
                    $status = "시스템 자동";
                    break;
            }
            $val['change_type_text'] = $status;
            $visit_delay = intval((strtotime(date('Ymd', strtotime("+1 day"))) - strtotime($val['last'])) / 86400);
            $val['lost_day'] = $visit_delay;

            $arr = auto_explode_number('birthday', $val['birthday']) ?? [];
            if (count($arr)) {
                $val['birthday_1'] = $arr['birthday_1'] ?? "";
                $val['birthday_2'] = $arr['birthday_2'] ?? "";
                $val['birthday_3'] = $arr['birthday_3'] ?? "";
            }
            $arr = auto_explode_number('pcs', $val['pcs']) ?? [];
            if (count($arr)) {
                $val['pcs_1'] = $arr['pcs_1'] ?? "";
                $val['pcs_2'] = $arr['pcs_2'] ?? "";
                $val['pcs_3'] = $arr['pcs_3'] ?? "";
            }
            $arr = auto_explode_number('tel', $val['tel']) ?? [];
            if (count($arr)) {
                $val['tel_1'] = $arr['tel_1'] ?? "";
                $val['tel_2'] = $arr['tel_2'] ?? "";
                $val['tel_3'] = $arr['tel_3'] ?? "";
            }

            $rows[$key] = $val;
        }

        return [
            'total' => $total
            ,
            'list' => $rows
            ,
            'paging' => $paging
        ];
    }

    /**
     * 휴면 회원 로그 리스트
     * @param type $cur_page
     * @param type $limit
     * @param type $search
     * @return type
     */
    public function getSleepLogList($cur_page = 1, $limit = 20, $search = [])
    {
        $this->qb->startCache();

        // 검색 조건
        if (isset($search['searchType']) && $search['searchType'] && isset($search['searchText']) && $search['searchText']) {
            if (in_array($search['searchType'], ['name', 'mail', 'pcs'])) {
                $this->qb->like($this->qb->decrypt('cul.' . $search['searchType']), $search['searchText']);
            } else {
                $this->qb->like($search['searchType'], $search['searchText']);
            }
        }

        //상태 검색
        if (isset($search['status']) && !empty($search['status'])) {
            $this->qb->where('cul.status', $search['status']);
        }


        //날짜검색        
        if (($search['betweenDatePickerStart'] ?? null) && ($search['betweenDatePickerEnd'] ?? null)) {
            $this->qb->betweenDate('cul.regdate', $search['betweenDatePickerStart'], $search['betweenDatePickerEnd']);
        }

        //회원승인관리 기간검색 -- 등록일
        if (($search['authBetweenDatePickerStart'] ?? null) && ($search['authBetweenDatePickerEnd'] ?? null)) {
            $this->qb->betweenDate('cu.date', $search['authBetweenDatePickerStart'], $search['authBetweenDatePickerEnd']);
        }

        $this->qb
            ->from(TBL_COMMON_USER_SLEEP_LOG . ' as cul')
            ->join(TBL_COMMON_MEMBER_DETAIL . ' as cmd', 'cul.charger_ix = cmd.code', 'left');

        $this->qb->stopCache();

        $total = $this->qb->getCount();
        $paging = $this->qb
            ->setTotalRows($total)
            ->pagination($cur_page, $limit);

        $offset = ($paging['offset'] ?? 0);

        $rows = $this->qb
            ->select('id')
            ->select('status')
            ->select('message')
            ->select('regdate')
            ->select('change_type')
            ->decryptSelect('cul.name')
            ->decryptSelect('cmd.name', 'admin_name')
            ->select('charger_ix')
            ->orderBy('cul.regdate', 'DESC')
            ->limit($limit, $offset)
            ->exec()
            ->getResultArray();

        $this->qb->flushCache();


        foreach ($rows as $key => $val) {
            $status = "";
            switch ($val['change_type']) {
                case "M":
                    $status = "휴면계정 활성화";
                    break;
                case "S":
                    $status = "휴면계정 전환";
                    break;
            }
            $val['change_type_text'] = $status;

            //변경자 구하기 2021-04-28 정책변경 수정 #11600
            if (!empty($val['charger_ix'])) {
                $adminInfo = $this->getMemberInfo($val['charger_ix']);
                if (!empty($adminInfo['data']['id'])) {
                    $val['admin_name'] = $adminInfo['data']['name'] . '(' . $adminInfo['data']['id'] . ')';
                }
            } else {
                //시스템 배치
                $val['admin_name'] = '시스템 배치';
            }

            $rows[$key] = $val;
        }

        return [
            'total' => $total
            ,
            'list' => $rows
            ,
            'paging' => $paging
        ];
    }

    /**
     * 개인정보 이력 리스트
     * @param type $cur_page
     * @param type $limit
     * @param type $search
     * @return type
     */
    public function getPrivacyEditLogList($cur_page = 1, $limit = 20, $search = [])
    {
        $this->qb->startCache();

        // 검색 조건
        if (isset($search['searchType']) && $search['searchType'] && isset($search['searchText']) && $search['searchText']) {
            if (in_array($search['searchType'], ['name', 'mail', 'pcs'])) {
                $this->qb->like($this->qb->decrypt('cmd.' . $search['searchType']), $search['searchText']);
            } else {
                $this->qb->like($search['searchType'], $search['searchText']);
            }
        }
        //회원그룹
        if (isset($search['gp_ix']) && !empty($search['gp_ix'])) {
            $this->qb->where('cmd.gp_ix', $search['gp_ix']);
        }

        //수정일자 검색        
        if (($search['betweenDatePickerStart'] ?? null) && ($search['betweenDatePickerEnd'] ?? null)) {
            $this->qb->betweenDate('seh.regdate', $search['betweenDatePickerStart'], $search['betweenDatePickerEnd']);
        }

        //가입일자       
        if (($search['cmdBetweenDatePickerStart'] ?? null) && ($search['cmdBetweenDatePickerEnd'] ?? null)) {
            $this->qb->betweenDate('cmd.date', $search['cmdBetweenDatePickerStart'], $search['cmdBetweenDatePickerEnd']);
        }

        //회원타입
        if (isset($search['mem_div']) && !empty($search['mem_div'])) {
            $this->qb->where('cu.mem_div', $search['mem_div']);
        }

        //회원구분
        if (isset($search['mem_type']) && !empty($search['mem_type'])) {
            $this->qb->where('cu.mem_type', $search['mem_type']);
        }

        //email
        if (isset($search['mailsend_yn']) && !empty($search['mailsend_yn']) && $search['mailsend_yn'] != "A") {
            if ($search['mailsend_yn'] == "Y") {
                $this->qb->where('cmd.info', 1);
            } else {
                if ($search['mailsend_yn'] == "N") {
                    $this->qb->where('cmd.info', 0);
                }
            }
        }
        //sms
        if (isset($search['smssend_yn']) && !empty($search['smssend_yn']) && $search['smssend_yn'] != "A") {
            if ($search['smssend_yn'] == "Y") {
                $this->qb->where('cmd.sms', 1);
            } else {
                if ($search['smssend_yn'] == "N") {
                    $this->qb->where('cmd.sms', 0);
                }
            }
        }


        $this->qb->where('history_type', 'member');
        $this->qb
            ->from(TBL_SYSTEM_EDIT_HISTORY . ' as seh')
            ->join(TBL_COMMON_USER . ' as cu', 'seh.pkey = cu.code', 'inner')
            ->join(TBL_COMMON_MEMBER_DETAIL . ' as cmd', 'cu.code = cmd.code', 'inner')
            ->join(TBL_SHOP_GROUPINFO . ' as sg', 'sg.gp_ix=cmd.gp_ix', 'left');
        $this->qb->stopCache();

        $total = $this->qb->getCount();
        $paging = $this->qb
            ->setTotalRows($total)
            ->pagination($cur_page, $limit);

        $offset = ($paging['offset'] ?? 0);

        $rows = $this->qb
            ->select('seh.seh_ix')
            ->select('seh.pkey')
            ->decryptSelect('seh.b_data')
            ->decryptSelect('seh.after_data')
            ->select('seh.b_data as b_data_text')
            ->select('seh.after_data as after_data_text')
            ->select('seh.column_name')
            ->select('seh.column_text')
            ->select('seh.regdate')
            ->select('seh.charger_name as admin_name')
            ->select('seh.charger_ix')
            ->select('cu.mem_type')
            ->select('cu.mem_div')
            ->select('cu.id')
            ->select('sg.gp_name')
            ->decryptSelect('cmd.name')
            ->select('cu.date')
            ->orderBy('seh.regdate', 'DESC')
            ->limit($limit, $offset)
            ->exec()
            ->getResultArray();

        $this->qb->flushCache();


        foreach ($rows as $key => $val) {
            $val['memTypeText'] = $this->getMemTypeText($val['mem_type']);
            $val['memTypeTextDiv'] = $this->getMemTypeText($val['mem_type']);
            $mem_div = "";
            switch ($val['mem_div']) {
                case "MD":
                    $mem_div = "MD담당자";
                    break;
                case "S":
                    $mem_div = "셀러";
                    break;
                case "D":
                    $mem_div = "기타";
                    break;
            }
            if ($mem_div) {
                $val['memTypeTextDiv'] .= "(" . $mem_div . ")";
            } else {
                $val['memTypeTextDiv'] .= $mem_div;
            }

            if (isset($val['b_data'])) {
                $val['before_modify'] = $val['b_data'];
            } else {
                $val['before_modify'] = $val['b_data_text'];
            }

            if (isset($val['after_data'])) {
                $val['after_modify'] = $val['after_data'];
            } else {
                $val['after_modify'] = $val['after_data_text'];
            }

            // 회원 그룹 치환
            if ($val['column_name'] == 'gp_ix') {
                $after_group_info = $this->getGroupInfo($val['after_modify']);
                $val['after_modify'] = isset($after_group_info['gp_name']) ? $after_group_info['gp_name'] : "";
                $before_group_info = $this->getGroupInfo($val['before_modify']);
                $val['before_modify'] = isset($before_group_info['gp_name']) ? $before_group_info['gp_name'] : "";
            }
            // 회원 구분 치환
            if ($val['column_name'] == 'mem_div') {
                $after_mem_div = $this->getMemberPattern('M', $val['after_modify']);
                $val['after_modify'] = $after_mem_div;
                $before_mem_div = $this->getMemberPattern('M', $val['before_modify']);
                $val['before_modify'] = $before_mem_div;
            }

            $rows[$key] = $val;
        }
        return [
            'total' => $total
            ,
            'list' => $rows
            ,
            'paging' => $paging
        ];
    }

    /**
     * 회원 유형
     * @param string $memberType
     * @return list
     */
    public function getMemberPattern($memberType = false, $memText = false)
    {
        $list = "";
        if ($memberType == 'M') {
            if ($memText) {
                $list = $this->memberPattern[$memberType][$memText];
            } else {
                $list = $this->memberPattern[$memberType];
            }
        } elseif ($memberType == 'A') {
            if ($memText) {
                $list = $this->memberPattern[$memberType][$memText];
            } else {
                $list = $this->memberPattern[$memberType];
            }
        } else {
            $list = $this->memberPattern;
        }

        return $list;
    }

    /**
     * get 회원 그룹 정보
     * @param type $gpIx
     * @return type
     */
    public function getGroupInfo($gpIx)
    {
        $row = $this->qb
            ->from(TBL_SHOP_GROUPINFO)
            ->where('gp_ix', $gpIx)
            ->where('is_delete', 0)
            ->exec()
            ->getRowArray();

        return $row;
    }

    /**
     * 일괄 메일 보내기
     * @param type $search
     * @return string
     */
    public function putBatchEmail($search = [])
    {
        $data_set = [];
        if ($search['update_type'] == 1) {
            $this->putBatchSearch($search);  //검색조건이 셋해서 넘어온다
        } else {
            //선택 회원            
            $this->qb->whereIn('cu.code', explode(",", $search['selectCode']));
        }
        $member = $this->qb
            ->decryptSelect('cmd.mail')
            ->select('cmd.info')
            ->from(TBL_COMMON_MEMBER_DETAIL . ' AS cmd')
            ->join(TBL_COMMON_USER . ' as cu', 'cu.code=cmd.code')
            ->exec()
            ->getResultArray();


        //send form
        // CC 는 일단 제외
        foreach ($member as $key => $val) {
            $to = $val['mail'];
            $title = $search['email_subject'];
            $msg_txt = $search['content'];
            $msg_type = 'html';

            if ($val['info'] == '1') {
                mail_msg_send($to, $title, $msg_txt, $msg_type);
            }
        }

        if (!empty($search['email_subject'])) {
            $mail['email_subject'] = $search['email_subject'];
        }
        if (!empty($search['mail_cc'])) {
            $mail['mail_cc'] = $search['mail_cc'];
        }
        if (!empty($search['email_max'])) {
            $mail['email_max'] = $search['email_max'];
        }
//        $mail['email_stop'] = $search['email_stop']; #html에 주석처리 되어있음.
        $mail['content'] = $search['content'];


        $result['data'] = $member;
        $result['mail_form'] = $mail;
        $result['status'] = 'success';
        return $result;
    }

    /**
     * 일괄 SMS 전송
     * @param type $search
     * @return string
     */
    public function putBatchSms($search = [])
    {
        $data_set = [];
        if ($search['update_type'] == 1) {
            $this->putBatchSearch($search);  //검색조건이 셋해서 넘어온다
        } else {
            //선택 회원            
            $this->qb->whereIn('code', explode(",", $search['selectCode']));
        }
        $member = $this->qb
            ->decryptSelect('cmd.pcs')
            ->select('cmd.sms')
            ->from(TBL_COMMON_MEMBER_DETAIL . ' AS cmd')
            ->exec()
            ->getResultArray();

        //send form
        foreach ($member as $key => $val) {
            $to = $val['pcs'];
            $msg_text = $search['sms_text'];
            if (!empty($search['send_time_sms'])) {
                $sendDateTime = $search['send_time_sms'];
            } else {
                $sendDateTime = '';
            }

            //common.helper에 메시지 전송 모듈로 전송
            //SMS 수신여부 분기처리 뺀 이유는 관리자가 중요공지를 보낼때에 'SMS수신여부' 상관없이 고객이 받을 수 있어야 하기 때문. (LSH)
            //관리자가 평소에 수신여부 필터 검색 후 일괄 발송하는 것으로 안내.
            sms_msg_send($to, $msg_text, $sendDateTime);
        }

        $result['data'] = $member;
        $result['status'] = 'success';
        return $result;
    }

    /**
     * 회원 검색 조건 폼
     * @param type $search
     * @return Qb set
     */
    protected function putBatchSearch($search = [])
    {
        //검색 회원 in_array는 암호화 된 컬럼
        if (isset($search['searchType']) && $search['searchType'] && isset($search['searchText']) && $search['searchText']) {
            if (in_array($search['searchType'], ['name', 'mail', 'pcs', 'tel', 'addr1'])) {
                if ($search['searchType'] == 'pcs' || $search['searchType'] == 'tel') {
                    $this->qb->like('REPLACE(CAST(' . $this->qb->decrypt($search['searchType']) . ' AS CHAR),"-","")',
                        str_replace('-', '', $search['searchText']));
                } else {
                    $this->qb->like($this->qb->decrypt($search['searchType']), $search['searchText']);
                }
            } else {
                $this->qb->like($search['searchType'], $search['searchText']);
            }
        }

        //회원 그룹
        if (isset($search['gp_ix']) && !empty($search['gp_ix'])) {
            $this->qb->whereIn('cmd.gp_ix', $search['gp_ix']);
        }

        //회원구분
        if (isset($search['mem_type']) && !empty($search['mem_type'])) {
            $this->qb->whereIn('cu.mem_type', $search['mem_type']);
        }

        //회원구분 - cron 에서 사용
        if (isset($search['not_mem_type']) && !empty($search['not_mem_type'])) {
            $this->qb->whereNotIn('cu.mem_type', $search['not_mem_type']);
        }

        //회원타입
        if (isset($search['mem_div']) && !empty($search['mem_div'])) {
            $this->qb->whereIn('cu.mem_div', $search['mem_div']);
        }

        //승인여부
        if (isset($search['authorized']) && !empty($search['authorized'])) {
            $this->qb->whereIn('cu.authorized', $search['authorized']);
        }

        //셀러 타입
        if (isset($search['company_id']) && !empty($search['company_id'])) {
            $this->qb->where('cu.company_id', $search['company_id']);
        }

        //날짜검색
        if (isset($search['selDateType']) && !empty($search['selDateType'])) {
            if ($search['selDateType'] == "R") {
                //가입기준
                if (($search['betweenDatePickerStart'] ?? null) && ($search['betweenDatePickerEnd'] ?? null)) {
                    $this->qb->betweenDate('cmd.date', $search['betweenDatePickerStart'], $search['betweenDatePickerEnd']);
                }
            } elseif ($search['selDateType'] == "C") {
                //최근 방문일 기준
                if (($search['betweenDatePickerStart'] ?? null) && ($search['betweenDatePickerEnd'] ?? null)) {
                    $this->qb->betweenDate('cu.last', $search['betweenDatePickerStart'], $search['betweenDatePickerEnd']);
                }
            }
        } else {
            if (($search['betweenDatePickerStart'] ?? null) && ($search['betweenDatePickerEnd'] ?? null)) {
                $this->qb->betweenDate('cu.date', $search['betweenDatePickerStart'], $search['betweenDatePickerEnd']);
            }
        }


        //회원승인관리 기간검색 -- 등록일
        if (($search['authBetweenDatePickerStart'] ?? null) && ($search['authBetweenDatePickerEnd'] ?? null)) {
            $this->qb->betweenDate('cu.date', $search['authBetweenDatePickerStart'], $search['authBetweenDatePickerEnd']);
        }

        //MD 여부
        if (isset($search['mdCheck']) && !empty($search['mdCheck']) && $search['mdCheck'] == "Y") {
            $this->qb->where('cu.mem_div', 'MD');
        } elseif (isset($search['mdCheck']) && !empty($search['mdCheck']) && $search['mdCheck'] == "N") {
            $this->qb->whereNotIn('cu.mem_div', 'MD');
        }

        //미승인 여부 -- 처음 리스트 가져올경우
        if (isset($search['is_serach']) && !empty($search['is_serach']) && $search['is_serach'] == "N") {
            $this->qb->where('cu.authorized', 'N');
        }

        //신청처리상태
        if (isset($search['authorized']) && !empty($search['authorized'])) {
            $this->qb->where('cu.authorized', $search['authorized']);
        }

        //일괄 회원구분
        if (isset($search['chk_mem_type']) && !empty($search['chk_mem_type'])) {
            $this->qb->whereIn('cu.mem_type', $search['chk_mem_type']);
        }

        //일괄 회원타입
        if (isset($search['chk_mem_div']) && !empty($search['chk_mem_div'])) {
            $this->qb->whereIn('mem_div', $search['chk_mem_div']);
        }

        //일괄 성별 검색
        if (isset($search['chk_sex_div']) && !empty($search['chk_sex_div'])) {
            $this->qb->whereIn('sex_div', $search['chk_sex_div']);
        }
        //일괄 sms 동의 검색
        if (isset($search['smssend_yn']) && !empty($search['smssend_yn'])) {
            $this->qb->whereIn('sms', $search['smssend_yn']);
        }
        //일괄 메일수신 동의 검색
        if (isset($search['mailsend_yn']) && !empty($search['mailsend_yn'])) {
            $this->qb->whereIn('info', $search['mailsend_yn']);
        }
        //일괄 회원그룹 검색
        if (isset($search['memberGroupBath']) && !empty($search['memberGroupBath'])) {
            $this->qb->whereIn('cmd.gp_ix', $search['memberGroupBath']);
        }

        //휴면 기간 검색
        if (isset($search['sleepDate']) && !empty($search['sleepDate'])) {
            $this->qb->where('MID(replace(if ( isnull(cu.last), cu.date, cu.last ) ,"-",""),1,8) < ', $search['sleepDate']);
        }
        //임직원 여부
        if (isset($search['is_emp']) && !empty($search['is_emp'])) {
            if ($search['is_emp'] == 'Y') {
                $this->qb->where('LENGTH(cmd.emp_id) > 0');
            } elseif ($search['is_emp'] == 'N') {
                $this->qb
                    ->Where('cmd.emp_id', '');
            }
        }
    }

    /**
     * 회원가입시 id 체크
     * @param $userId
     * @return bool
     */
    public function checkUserId($id)
    {
        return (
            $this->qb->from(TBL_COMMON_USER)->where('id', $id)->getCount() > 0 ||
            $this->qb->from(TBL_COMMON_DROPMEMBER)->where('id', $id)->getCount() > 0 ||
            $this->qb->from(TBL_COMMON_USER_SLEEP)->where('id', $id)->getCount() > 0
        ) ? false : true;
    }

    /**
     * 회원등급 기본값 확인
     */
    public function getBasicGroupIx()
    {
        $res = $this->qb
            ->select('gp_ix')
            ->from(TBL_SHOP_GROUPINFO)
            ->where('basic', 'Y')
            ->exec()->getRowArray();
        if (empty($res)) {
            return false;
        } else {
            return $res['gp_ix'];
        }
    }

    /**
     * 회원그룹에 해당하는 회원수 조회
     * @param $gpIx
     * @return int
     * @throws \Exception
     */
    public function getCountUserInGroup($gpIx)
    {
        return $this->qb
            ->from(TBL_COMMON_MEMBER_DETAIL)
            ->where('gp_ix', $gpIx)
            ->getCount();
    }

    /**
     * 회원 그룹 삭제
     * @param $gpIx
     * @return array|string
     * @throws \Exception
     */
    public function delMemberGroup($gpIx)
    {
        if ($gpIx === $this->getBasicGroupIx()) {
            return 'isBasicGroup';
        }

        if ($this->getCountUserInGroup($gpIx) > 0) {
            return 'existUser';
        }

        $this->qb
            ->set('is_delete', 1)
            ->update(TBL_SHOP_GROUPINFO)
            ->where('gp_ix', $gpIx)
            ->exec();

        return 'success';
    }

    /**
     * 포인트 설정 값 가져오기
     * @return type
     */
    public function getPointConfig()
    {
        $reserve_data = \ForbizConfig::getSharedMemory("b2c_point_rule");
        $memberGroup = $this->getMemberGroup();

        //common , p , m 타입 레이트 넣음
        foreach ($reserve_data["point_rate"] as $key => $val) {
            $reserve_data['point_rate_' . $key] = $val;
        }

        //gp_ix 타입 레이트 넣음
        foreach ($memberGroup as $key => $val) {
            $memberGroup[$key]['point_rate'] = $reserve_data['point_rate'][$val["gp_ix"]] ?? 0;
        }

        return [
            'memberGroup' => $memberGroup
            ,
            'reserveData' => $reserve_data
        ];
    }

    /**
     * 포인트 설정
     * @param type $post
     * @return type
     */
    public function putPointConfig($post = [])
    {
        $result = [];
        $result['status'] = 'success';

        $data_set = [];
        $data_set ['point_use_yn'] = $post['point_use_yn'];
        $data_set ['point_name'] = $post['point_name'];
        $data_set ['point_unit_txt'] = $post['point_unit_txt'];
        $data_set ['scale'] = $post['scale'];
        $data_set ['standard'] = $post['standard'];
        $data_set ['point_info_use'] = $post['point_info_use'];

        foreach ($this->input->post('point_rate') as $key => $val) {
            $data_set['point_rate'][$key] = $val;
        }

        $data_set ['point_add_setup'] = $post['point_add_setup'];
        $data_set ['join_use'] = $post['join_use'];
        $data_set ['join_rate'] = $post['join_rate'];

        $data_set ['point_add_use_yn'] = $post['point_add_use_yn'];
        $data_set ['point_tm'] = $post['point_tm'];
        $data_set ['point_tm_day'] = $post['point_tm_day'];
        $data_set ['point_tm_login'] = $post['point_tm_login'];
        $data_set ['point_tm_comment'] = $post['point_tm_comment'];
        $data_set ['point_tm_sns'] = $post['point_tm_sns'];
        $data_set ['point_tm_wish'] = $post['point_tm_wish'];
        $data_set ['point_ddt_use_yn'] = $post['point_ddt_use_yn'];
        $data_set ['point_tm_comment_cancel'] = $post['point_tm_comment_cancel'];
        $data_set ['point_tm_wish_cancel'] = $post['point_tm_wish_cancel'];
        $data_set ['auto_extinction'] = $post['auto_extinction'];
        $data_set ['cancel_year'] = $post['cancel_year'];
        $data_set ['cancel_month'] = $post['cancel_month'];

        $status = \ForbizConfig::setSharedMemory("b2c_point_rule", $data_set);
        if (!$status) {
            $result['status'] = 'fail';
            $result['error'] = 'shareMemory write fail';
        }

        $result['data'] = $data_set;
        return $result;
    }

    /**
     * 포인트 리스트
     * @param type $cur_page
     * @param type $limit
     * @param type $search
     * @return type
     */
    public function getListPoint($cur_page = 1, $limit = 20, $search = [])
    {
        $this->qb->startCache();

        // 검색 조건
        if (isset($search['searchType']) && $search['searchType'] && isset($search['searchText']) && $search['searchText']) {
            if (in_array($search['searchType'], ['name', 'mail', 'pcs'])) {
                $this->qb->like($this->qb->decrypt($search['searchType']), $search['searchText']);
            } elseif ($search['searchType'] == 'etc') {
                $this->qb->like('ri.message', $search['searchText']);
            } else {
                $this->qb->like($search['searchType'], $search['searchText']);
            }
        }

        if (isset($search['info_type']) && $search['info_type']) {
            if ($search['info_type'] == 'add') {
                $this->qb->where('pl_state', 1);
            } elseif ($search['info_type'] == 'use') {
                $this->qb->where('pl_state', 2);
            }
        }

        //날짜검색
        if (($search['devBetweenDatePickerStart'] ?? null) && ($search['devBetweenDatePickerEnd'] ?? null)) {
            $this->qb->betweenDate('ri.date', $search['devBetweenDatePickerStart'], $search['devBetweenDatePickerEnd']);
        }

        //code
        if (isset($search['code']) && $search['code']) {
            $this->qb->where('cu.code', $search['code']);
        }

        $this->qb
            ->from(TBL_SHOP_POINT_LOG . ' AS ri')
            ->join(TBL_COMMON_USER . ' AS cu', 'ri.uid = cu.code')
            ->join(TBL_COMMON_MEMBER_DETAIL . ' AS cmd', 'cu.code = cmd.code')
            ->join(TBL_SHOP_GROUPINFO . ' AS g', 'cmd.gp_ix = g.gp_ix');

        $this->qb->stopCache();
        $total = $this->qb->getCount();

        //포인트 합산 쿼리
        $sum = $this->qb
            ->select('pl_state')
            ->selectSum('ri.pl_point')
            ->groupBy('pl_state')
            ->exec()->getResultArray();

        $paging = $this->qb
            ->setTotalRows($total)
            ->pagination($cur_page, $limit);

        $offset = ($paging['offset'] ?? 0);

        $rows = $this->qb
            ->select('ri.*')
            ->select('cu.id')
            ->select('cu.code')
            ->select('g.gp_name')
            ->decryptSelect('cmd.name')
            ->decryptSelect('cmd.mail')
            ->orderBy('ri.regdate', 'desc')
            ->limit($limit, $offset)
            ->exec()
            ->getResultArray();

        $this->qb->flushCache();

        //치환 처리
        foreach ($rows as $key => $val) {
            switch ($val['pl_state']) {
                case '1':
                    $rows[$key]['pl_state_text'] = '적립완료(+)';
                    break;
                case '2':
                    $rows[$key]['pl_state_text'] = '사용(-)';
                    break;
            }
            if ($val['pl_point']) {
                $rows[$key]['pl_point'] = number_format($val['pl_point']);
            }
        }

        return [
            'total' => $total
            , 'list' => $rows
            , 'paging' => $paging
        ];
    }

    public function updateChangPwDate()
    {
        return $this->qb
            ->set('change_pw_date', fb_now())
            ->where('code', $this->adminInfo->charger_ix)
            ->update(TBL_COMMON_USER)
            ->exec();
    }

    public function changePassword($password)
    {
        return $this->qb
            ->set('pw', encrypt_user_password($password))
            ->set('change_pw_date', fb_now())
            ->where('code', $this->adminInfo->charger_ix)
            ->update(TBL_COMMON_USER)
            ->exec();
    }

    /**
     * 어드민 권한 계정 갯수 체크
     * @return int
     */
    public function chkAdminId()
    {
        $row = $this->qb
            ->select('id')
            ->from(TBL_COMMON_USER)
            ->where('mem_type', 'A')
            ->limit(1)
            ->exec()
            ->getRowArray();

        return ($row['id'] ?? false);
    }

    protected function createAdminInfo($id, $pw)
    {
        $adminInfoFile = APPLICATION_ROOT . '/adminInfo.php';
        $midLen = strlen($pw) - 3;

        return file_put_contents($adminInfoFile, implode("\n", [
            '<?php',
            '// Admin Id : ' . $id,
            '// Admin Pw : ' . substr($pw, 0, 2) . str_repeat('*', $midLen) . substr($pw, -1)
        ]));
    }

    public function putFirstJoin($post = [])
    {
        $result = [];
        $result['status'] = 'success';

        // 등록된 관리자가 있는지 확인
        if ($this->chkAdminId()) {
            $result['status'] = 'fail';
            $result['data']['error'] = 'Exist Admin User';

            return $result;
        }

        // 비밀번호 확인
        if ($post['pw'] == $post['pw_re']) {
            $is_password['pw'] = $post['pw'];
        } else {
            //같지 않음
            $result['status'] = 'fail';
            $result['data']['error'] = 'password and password re not match';

            return $result;
        }

        // 트랜잭션 시작
        $this->qb->transStart();

        // 회원코드 생성
        $mem_code = make_member_code();
        // 업체코드 생성
        $company_id = make_company_id();
        $now = date('Y-m-d H:i:s');

        // 회원기본 정보 입력
        $this->qb
            ->set('mem_type', 'A')
            ->set('mem_div', 'D')
            ->set('language', 'korea')
            ->set('authorized', 'Y')
            ->set('auth', '1')
            ->set('request_info', 'M')
            ->set('request_yn', 'Y')
            ->set('is_id_auth', 'Y')
            ->set('id', $post['id'])
            ->set('code', $mem_code)
            ->set('company_id', $company_id)
            ->set('date', $now)
            ->set('request_date', $now)
            ->set('pw', encrypt_user_password($is_password['pw']))
            ->insert(TBL_COMMON_USER)
            ->exec();

        // 회원 상세 정보 입력
        $this->qb
            ->set('code', $mem_code)
            ->set('gp_ix', 7)
            ->set('date', $now)
            ->encryptSet('pcs', str_cut_number_dash($post['pcs_1'] . '-' . $post['pcs_2'] . '-' . $post['pcs_3'])) // 핸드폰 번호
            ->encryptSet('mail', $post['mail'])
            ->encryptSet('name', $post['name'])
            ->insert(TBL_COMMON_MEMBER_DETAIL)
            ->exec();

        //시스템 그룹 맵핑
        $this->qb->set('system_group_type_id', 2)
            ->set('code', $mem_code)
            ->set('updated_at', $now)
            ->insert(TBL_SYSTEM_GROUP)
            ->exec();

        // 업체 상세 정보 입력
        $this->qb
            ->set('seller_type', '1|2')
            ->set('com_type', 'A')
            ->set('seller_auth', 'Y')
            ->set('company_id', $company_id)
            ->set('com_name', $post['com_name'])
            ->set('com_ceo', $post['name'])
            ->set('com_business_status', $post['com_business_status'])
            ->set('com_business_category', $post['com_business_category'])
            ->set('online_business_number', $post['online_business_number'])
            ->set('com_email', $post['mail'])
            ->set('mall_id', $post['mall_id'])
            ->set('license', $post['license'])
            ->set('regdate', $now)
            ->set('com_number', str_cut_number_dash($post['com_number_1'] . '-' . $post['com_number_2'] . '-' . $post['com_number_3'])) //사업자번호
            ->set('com_phone', str_cut_number_dash($post['com_phone1'] . '-' . $post['com_phone2'] . '-' . $post['com_phone3'])) //전화번호
            ->insert(TBL_COMMON_COMPANY_DETAIL)->exec();

        // 셀러 정보 입력
        $this->qb
            ->set('company_id', $company_id)
            ->set('shop_name', $post['com_name']) //회사명과 동일하게 셋팅
            ->set('seller_message', '') //사업자정보 탭에서 넘어오는 데이터
            ->set('regdate', $now)
            ->set('authorized_date', $now)
            ->insert(TBL_COMMON_SELLER_DETAIL)
            ->exec();

        // mall_id 입력
        $this->setMallID($post['mall_id']);

        // 배송정책 기본 정보 설정
        $this->qb
            ->set('company_id', $company_id)
            ->where('company_id', 'sample_company_id')
            ->update(TBL_COMMON_SELLER_DELIVERY)
            ->exec();

        $this->qb
            ->set('company_id', $company_id)
            ->where('company_id', 'sample_company_id')
            ->update(TBL_SHOP_DELIVERY_ADDRESS)
            ->exec();

        $this->qb
            ->set('company_id', $company_id)
            ->where('company_id', 'sample_company_id')
            ->update(TBL_SHOP_DELIVERY_TEMPLATE)
            ->exec();

        // 상품 정보 기본 설정
        $this->qb
            ->set('admin', $company_id)
            ->where('admin', 'sample_company_id')
            ->update(TBL_SHOP_PRODUCT)
            ->exec();

        $this->qb
            ->set('company_id', $company_id)
            ->where('company_id', 'sample_company_id')
            ->update(TBL_SHOP_PRODUCT_DELIVERY)
            ->exec();

        // 트랜잭션 끝
        $status = $this->qb->transComplete();

        $this->createAdminInfo($post['id'], $is_password['pw']);

        if ($status) {
            //프론트 정보 파일생성
            /* @var $companyModel \CustomScm\Model\Company\Company */
            $companyModel = $this->import('model.scm.company.company');
            $companyModel->setManageCompanyId($company_id);
            $companyModel->createCompanyFile();

            $post['packageCompanyId'] = $company_id;
            $this->sendPortalApi('/wizard/putLicense', $post);
            $result['status'] = 'success';

            // metapay 등록용 정보 설정
            $_SESSION['joined'] = [
                'code' => $mem_code,
                'license' => $post['license'],
                'mall_id' => $post['mall_id'],
                'id' => $post['id'],
                'name' => $post['name'],
                'company_id' => $company_id,
            ];
        } else {
            $result['status'] = 'fail';
            $result['data']['error'] = 'insert error';
        }

        return $result;
    }

    //프론트에서 mall_id 접근할 수 있도록 세팅
    public function setMallID($mall_id)
    {
        // 등록된 mall_id 있는지 확인
        $cnt = $this->qb
            ->from(TBL_SHOP_MALL_ID)
            ->getCount();

        if ($cnt == 0) {
            $this->qb
                ->set('mall_id', $mall_id)
                ->insert(TBL_SHOP_MALL_ID)
                ->exec();
        }

        return true;
    }

    public function getAdminInfo()
    {
        $cnt = $this->qb
            ->from(TBL_CON_LOG)
            ->getCount();

        if($cnt == 0) {
            $infoFile = realpath(APPLICATION_ROOT . '/adminInfo.php');
            if ($infoFile !== false) {
                $tmpInfo = file($infoFile);
                $admInfo = [];
                $admInfo['id'] = trim(explode(':', $tmpInfo[1])[1]);
                $admInfo['pw'] = trim(explode(':', $tmpInfo[2])[1]);

                return $admInfo;
            }
        }

        return false;
    }

    public function existsAdminInfo()
    {
        return $this->getAdminInfo() !== false;
    }

}
