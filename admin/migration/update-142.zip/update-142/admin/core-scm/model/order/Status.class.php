<?php

namespace ForbizScm\Model\Order;

/**
 * 주문 상태관련 모델
 *
 * @author hoksi
 */
class Status extends \ForbizModel
{

    /**
     * 배송 상태
     * @var type
     */
    protected $status = [
        ORDER_STATUS_INCOM_READY => '입금예정',
        ORDER_STATUS_INCOM_COMPLETE => '입금확인',
        ORDER_STATUS_DELIVERY_READY => '배송준비중',
        ORDER_STATUS_DELIVERY_DELAY => '배송지연',
        ORDER_STATUS_DELIVERY_ING => '배송중',
        ORDER_STATUS_DELIVERY_COMPLETE => '배송완료',
        ORDER_STATUS_BUY_FINALIZED => '구매확정',
        ORDER_STATUS_EXCHANGE_READY => '교환상품발송예정'
    ];

    /**
     * 취소 상태
     * @var type
     */
    protected $cancelStatus = [
        ORDER_STATUS_INCOM_BEFORE_CANCEL_COMPLETE => '입금전취소완료',
        ORDER_STATUS_CANCEL_APPLY => '취소요청',
        ORDER_STATUS_CANCEL_COMPLETE => '취소완료'
    ];

    /**
     * 반품 상태
     * @var type
     */
    protected $returnStatus = [
        ORDER_STATUS_RETURN_APPLY => '반품요청',
        ORDER_STATUS_RETURN_DENY => '반품거부',
        ORDER_STATUS_RETURN_ING => '반품승인',
        ORDER_STATUS_RETURN_ACCEPT => '반품회수완료',
        ORDER_STATUS_RETURN_COMPLETE => '반품확정',
        ORDER_STATUS_RETURN_IMPOSSIBLE => '반품불가',
    ];

    /**
     * 교환 상태
     * @var type
     */
    protected $exchangeStatus = [
        ORDER_STATUS_EXCHANGE_APPLY => '교환요청',
        ORDER_STATUS_EXCHANGE_DENY => '교환거부',
        ORDER_STATUS_EXCHANGE_ING => '교환승인',
        ORDER_STATUS_EXCHANGE_ACCEPT => '교환회수완료',
        ORDER_STATUS_EXCHANGE_COMPLETE => '교환반품확정',
        ORDER_STATUS_EXCHANGE_IMPOSSIBLE => '교환불가',
    ];

    /**
     * 황불상태
     */
    protected $refundStatus = [
        ORDER_STATUS_REFUND_READY => '환불대기',
        ORDER_STATUS_REFUND_APPLY => '환불요청',
        ORDER_STATUS_REFUND_COMPLETE => '환불완료',
    ];

    /**
     * 관리 manageCompanyId
     * @var type
     */
    protected $manageCompanyId;

    /**
     * 로그인 회원 아이디
     * @var type
     */
    protected $adminUserId;

    /**
     * 로그인 회원 이름
     * @var type
     */
    protected $adminUserName;

    /**
     * 로그인 회원 코드
     * @var type
     */
    protected $adminUserCode;

    public function __construct()
    {
        parent::__construct();

        //셀러일 경우
        if ($this->adminInfo->admin_level < 9) {
            $this->setManageCompanyId($this->adminInfo->company_id);
        }

        $this->adminUserId = $this->adminInfo->charger_id;
        $this->adminUserName = $this->adminInfo->charger;
        $this->adminUserCode = $this->adminInfo->charger_ix;
    }

    /**
     * set manageCompanyId
     * @param type $manageCompanyId
     */
    public function setManageCompanyId($manageCompanyId)
    {
        $this->manageCompanyId = $manageCompanyId;
    }

    /**
     * set 로그인 회원 (batch에서 돌릴때는 setAdminUser('system')
     * @param type $adminUserCode
     * @param type $adminUserId
     * @param type $adminUserName
     */
    public function setAdminUser($adminUserName, $adminUserCode = '', $adminUserId = '')
    {
        $this->adminUserCode = $adminUserCode;
        $this->adminUserId = $adminUserId;
        $this->adminUserName = $adminUserName;
    }

    /**
     * get 주문 상태
     * @param type $status
     * @param type $mode
     * @return type
     */
    public function getStatus($status = false, $mode = '')
    {
        if ($mode == 'delivery') {
            $list = $this->status;
        } elseif ($mode == 'cancel') {
            $list = $this->cancelStatus;
        } elseif ($mode == 'return') {
            $list = $this->returnStatus;
            unset($list[ORDER_STATUS_RETURN_DENY]);
            unset($list[ORDER_STATUS_RETURN_IMPOSSIBLE]);
        } elseif ($mode == 'exchange') {
            $list = $this->exchangeStatus;
            unset($list[ORDER_STATUS_EXCHANGE_DENY]);
            unset($list[ORDER_STATUS_EXCHANGE_IMPOSSIBLE]);
        } elseif ($mode == 'refund') {
            $list = $this->refundStatus;
        } else {
            $list = array_merge($this->status, $this->cancelStatus, $this->returnStatus,
                $this->exchangeStatus);
        }

        if ($status === false) {
            return $list;
        } else {
            return $list[$status] ?? $status;
        }
    }

    /**
     * get 클레임 사유
     * @param type $oid
     * @param type $odIx
     * @param type $claimType
     * @return type
     */
    public function getOrderCalimReason($oid, $odIx, $claimType)
    {
        $applyStatus = ($claimType == 'I' ? ORDER_STATUS_INCOM_BEFORE_CANCEL_COMPLETE : $claimType . 'A');

        if ($applyStatus == ORDER_STATUS_INCOM_BEFORE_CANCEL_COMPLETE) {
            $searchStatus = [ORDER_STATUS_INCOM_BEFORE_CANCEL_COMPLETE];
        } else {
            $searchStatus = [$claimType . 'A'];
            if ($applyStatus == ORDER_STATUS_CANCEL_APPLY) {
                $searchStatus[] = ORDER_STATUS_CANCEL_COMPLETE;
            } else {
                $searchStatus[] = $claimType . 'I';
            }
        }

        $row = $this->qb
            ->select('status_message')
            ->select('reason_code')
            ->from(TBL_SHOP_ORDER_STATUS)
            ->where('oid', $oid)
            ->where('od_ix', ($applyStatus == ORDER_STATUS_INCOM_BEFORE_CANCEL_COMPLETE ? '0' : $odIx))
            ->whereIn('status', $searchStatus)
            ->whereNotIn('reason_code', [''])
            ->orderBy('regdate', 'DESC')
            ->limit(1)
            ->exec()
            ->getRowArray();

        if ($applyStatus == ORDER_STATUS_INCOM_BEFORE_CANCEL_COMPLETE) {
            $fkey = ORDER_STATUS_INCOM_READY;
            $applyStatus = ORDER_STATUS_CANCEL_APPLY;
        } else {
            if ($applyStatus == ORDER_STATUS_CANCEL_APPLY) {
                $fkey = ORDER_STATUS_INCOM_COMPLETE;
            } else {
                $fkey = ORDER_STATUS_DELIVERY_COMPLETE;
            }
        }

        if (!isset($row['reason_code'])) {
            $row['reason_code'] = '';
        }

        $type_text = \ForbizConfig::getOrderSelectStatus('F', $fkey, $applyStatus, $row['reason_code'], 'title');
        $responsibility_type = \ForbizConfig::getOrderSelectStatus('F', $fkey, $applyStatus, $row['reason_code'],
            'type');
        if (empty($type_text)) {
            $type_text = \ForbizConfig::getOrderSelectStatus('A', $fkey, $applyStatus, $row['reason_code'], 'title');
            $responsibility_type = \ForbizConfig::getOrderSelectStatus('A', $fkey, $applyStatus, $row['reason_code'],
                'type');
        }
        return [
            'type_text' => !empty($type_text) ? $type_text : '',
            'detail_text' => $row['status_message'] ?? '',
            'responsibility_type' => !empty($responsibility_type) ? $responsibility_type : 'N',
            'reason_code' => $row['reason_code']
        ];
    }

    /**
     * 주문 변경 내역 리스트
     * @param type $oid
     * @param type $odIx
     * @return type
     */
    public function getOrderHistoryList($oid, $odIx = [])
    {
        if (!empty($odIx)) {
            if (is_array($odIx)) {
                $this->qb->whereIn('os.od_ix', array_merge([0], $odIx));
            } else {
                $this->qb->whereIn('os.od_ix', [0, $odIx]);
            }
        }

        if (!empty($this->manageCompanyId)) {
            $this->qb->where('os.company_id', $this->manageCompanyId);
        }

        /* @var $refundModel \CustomScm\Model\Order\Refund */
        $refundModel = $this->import('model.scm.order.refund');

        /* @var $accountsModel \CustomScm\Model\Order\Accounts */
        $accountsModel = $this->import('model.scm.order.accounts');

        $list = $this->qb
            ->select('os.od_ix')
            ->select('os.status')
            ->select('os.status_message')
            ->select('os.admin_message')
            ->select('os.regdate')
            ->from(TBL_SHOP_ORDER_STATUS . ' AS os')
            ->where('os.oid', $oid)
            ->whereNotIn('os.status', [ORDER_STATUS_SETTLE_READY])
            ->orderBy('os.regdate')
            ->exec()
            ->getResultArray();

        foreach ($list as $key => $val) {
            $val['statusText'] = $this->getStatus($val['status']);
            if ($val['statusText'] == $val['status']) {
                $val['statusText'] = $refundModel->getStatus($val['status']);
            }
            if ($val['statusText'] == $val['status']) {
                $val['statusText'] = $accountsModel->getStatus($val['status']);
            }
            $list[$key] = $val;
        }

        return $list;
    }

    /**
     * 주문 변경 리턴 구조
     * @param type $failCode
     * @return type
     */
    protected function changeReturnStructure($failCode = false, $failMsg = false)
    {
        return [
            'result' => ($failCode ? 'changeOrderStatusFail' : 'success'),
            'data' => [
                'failCode' => $failCode,
                'failMsg' => $failMsg
            ]
        ];
    }

    /**
     * insert order price
     * @param type $oid
     * @param type $paymentStatus
     * @param type $priceDiv
     * @param type $data
     */
    protected function insertOrderPrice($oid, $paymentStatus, $priceDiv, $data)
    {
        $expect_price = ($data['expect_price'] ?? 0);
        $payment_price = ($data['payment_price'] ?? 0);
        $reserve = ($data['reserve'] ?? 0);

        $this->qb
            ->set('oid', $oid)
            ->set('od_ix', ($data['od_ix'] ?? ''))
            ->set('payment_status', $paymentStatus)
            ->set('price_div', $priceDiv)
            ->set('expect_price', $expect_price)
            ->set('payment_price', $payment_price)
            ->set('reserve', $reserve)
            ->set('claim_group', ($data['claim_group'] ?? 0))
            ->set('msg', ($data['msg'] ?? ''))
            ->set('charger', $this->adminUserName)
            ->set('charger_ix', $this->adminUserCode)
            ->set('regdate', fb_now())
            ->insert(TBL_SHOP_ORDER_PRICE_HISTORY)
            ->exec();

        $row = $this->qb
            ->select('op_ix')
            ->from(TBL_SHOP_ORDER_PRICE)
            ->where('oid', $oid)
            ->where('payment_status', $paymentStatus)
            ->exec()
            ->getRow();

        if ($priceDiv == 'D') {
            if ($expect_price > 0) {
                if ($this->qb->total > 0) {
                    $this->qb->set('expect_delivery_price', 'expect_delivery_price +' . $expect_price, false);
                } else {
                    $this->qb->set('expect_delivery_price', $expect_price);
                }
            }
            if ($payment_price > 0) {
                if ($this->qb->total > 0) {
                    $this->qb->set('delivery_price', 'delivery_price +' . $payment_price, false);
                } else {
                    $this->qb->set('delivery_price', $payment_price);
                }
            }
        } else {
            if ($expect_price > 0) {
                if ($this->qb->total > 0) {
                    $this->qb->set('expect_product_price', 'expect_product_price +' . $expect_price, false);
                } else {
                    $this->qb->set('expect_product_price', $expect_price);
                }
            }
            if ($payment_price > 0) {
                if ($this->qb->total > 0) {
                    $this->qb->set('product_price', 'product_price +' . $payment_price, false);
                } else {
                    $this->qb->set('product_price', $payment_price);
                }
            }
        }
        if ($reserve > 0) {
            $this->qb->set('reserve', $reserve);
        }
        if ($this->qb->total > 0) {
            $this->qb
                ->update(TBL_SHOP_ORDER_PRICE)
                ->where('op_ix', $row->op_ix)
                ->exec();
        } else {
            $this->qb
                ->set('oid', $oid)
                ->set('payment_status', $paymentStatus)
                ->insert(TBL_SHOP_ORDER_PRICE)
                ->exec();
        }
    }

    /**
     * 주문 히스토리 등록
     * @param type $odIx
     * @param type $status
     * @param type $statusMessage
     * @param type $oid
     * @param type $reasonCode
     */
    public function insertOrderHistory($odIx, $status, $statusMessage, $oid = '', $reasonCode = '')
    {
        $companyId = '';
        if (!empty($odIx) && $odIx > 0) {
            $row = $this->qb
                ->select('oid')
                ->select('company_id')
                ->from(TBL_SHOP_ORDER_DETAIL)
                ->where('od_ix', $odIx)
                ->exec()
                ->getRow();

            $oid = $row->oid;
            $companyId = $row->company_id;
        }

        $this->qb
            ->set('oid', $oid)
            ->set('od_ix', $odIx)
            ->set('status', $status)
            ->set('status_message', $statusMessage)
            ->set('admin_message', $this->adminUserName . ($this->adminUserId ? '(' . $this->adminUserId . ')' : ''))
            ->set('company_id', $companyId)
            ->set('reason_code', $reasonCode)
            ->set('data_channel', '2')
            ->set('regdate', date('Y-m-d H:i:s'))
            ->insert(TBL_SHOP_ORDER_STATUS)
            ->exec();
    }

    /**
     * 입금 확인 처리
     * @param type $oid
     * @return type
     */
    public function doIncomComplete($oid)
    {
        $count = $this->qb
            ->from(TBL_SHOP_ORDER . ' o')
            ->where('o.oid', $oid)
            ->where('o.status', ORDER_STATUS_INCOM_READY)
            ->getCount();

        if ($count > 0) {

            //shop_order update
            $this->qb
                ->set('status', ORDER_STATUS_INCOM_COMPLETE)
                ->update(TBL_SHOP_ORDER)
                ->where('oid', $oid)
                ->where('status', ORDER_STATUS_INCOM_READY)
                ->exec();

            //shop_order_detail update
            $this->qb
                ->set('status', ORDER_STATUS_INCOM_COMPLETE)
                ->set('ic_date', date('Y-m-d H:i:s'))
                ->set('update_date', date('Y-m-d H:i:s'))
                ->update(TBL_SHOP_ORDER_DETAIL)
                ->where('oid', $oid)
                ->where('status', ORDER_STATUS_INCOM_READY)
                ->exec();

            //shop_order_price insert
            $price = $this->qb
                ->select('expect_product_price')
                ->select('expect_delivery_price')
                ->from(TBL_SHOP_ORDER_PRICE)
                ->where('oid', $oid)
                ->where('payment_status', 'G')
                ->exec()->getRow();

            if ($price->expect_product_price > 0) {
                $priceData = [];
                $priceData['payment_price'] = $price->expect_product_price;
                $this->insertOrderPrice($oid, 'G', 'P', $priceData);
            }

            if ($price->expect_delivery_price > 0) {
                $priceData = [];
                $priceData['payment_price'] = $price->expect_delivery_price;
                $this->insertOrderPrice($oid, 'G', 'D', $priceData);
            }

            //shop_order_payment update
            $this->qb
                ->set('pay_status', ORDER_STATUS_INCOM_COMPLETE)
                ->set('ic_date', date('Y-m-d H:i:s'))
                ->update(TBL_SHOP_ORDER_PAYMENT)
                ->where('oid', $oid)
                ->where('pay_type', 'G')
                ->where('pay_status', ORDER_STATUS_INCOM_READY)
                ->exec();

            //shop_order_history insert
            $this->insertOrderHistory(0, ORDER_STATUS_INCOM_COMPLETE, '관리자 수동처리', $oid);

            return $this->changeReturnStructure();
        } else {
            return $this->changeReturnStructure('canNotIncomComplete');
        }
    }

    /**
     * 입금 전 취소 처리
     * @param type $oid
     * @return type
     */
    public function doIncomBeforCancelComplete($oid)
    {
        static $mileageModel = false;

        $count = $this->qb
            ->from(TBL_SHOP_ORDER . ' o')
            ->where('o.oid', $oid)
            ->where('o.status', ORDER_STATUS_INCOM_READY)
            ->getCount();

        if ($count > 0) {

            //shop_order update
            $this->qb
                ->set('status', ORDER_STATUS_INCOM_BEFORE_CANCEL_COMPLETE)
                ->update(TBL_SHOP_ORDER)
                ->where('oid', $oid)
                ->where('status', ORDER_STATUS_INCOM_READY)
                ->exec();

            //shop_order_detail update
            $this->qb
                ->set('status', ORDER_STATUS_INCOM_BEFORE_CANCEL_COMPLETE)
                ->set('update_date', date('Y-m-d H:i:s'))
                ->set('ra_date', date('Y-m-d H:i:s'))
                ->update(TBL_SHOP_ORDER_DETAIL)
                ->where('oid', $oid)
                ->where('status', ORDER_STATUS_INCOM_READY)
                ->exec();

            //판매진행중 재고 업데이트
            $this->updateSellIngCnt($oid);

            //쿠폰 돌려주기
            $this->returnUsedCoupon(ORDER_STATUS_INCOM_BEFORE_CANCEL_COMPLETE, $oid);

            //마일리지 돌려주기
            $row = $this->qb
                ->select('p.payment_price')
                ->select('o.user_code')
                ->select('o.gp_ix')
                ->from(TBL_SHOP_ORDER_PAYMENT . ' AS p')
                ->join(TBL_SHOP_ORDER . ' AS o', 'p.oid=o.oid')
                ->where('p.oid', $oid)
                ->where('p.method', ORDER_METHOD_RESERVE)
                ->where('p.pay_type', 'G')//F : 환불처리 G : 결제처리
                ->exec()
                ->getRowArray();

            if (!empty($row) && $row['payment_price'] > 0) {
                if ($mileageModel === false) {
                    /* @var $mileageModel \CustomScm\Model\Member\Mileage */
                    $mileageModel = $this->import('model.scm.member.mileage');
                }
                $mileageModel
                    ->setMember($row['user_code'])
                    ->addMileage($row['payment_price'], 4, '입금전 취소에 따른 사용 마일리지 재적립', ['oid' => $oid]); //마일리지 재적립
            }

            return $this->changeReturnStructure();
        } else {
            return $this->changeReturnStructure('canNotIncomBeforCancelComplete');
        }
    }

    /**
     * 주문 상태 변경 (통합)
     * @param type $status
     * @param type $odIxs
     * @param type $msg
     * @param type $etcData
     * @param type $view
     * @return type
     */
    public function doChangeStatus($status, $odIxs, $msg = '', $etcData = [], $view = false, $order_from = 'self')
    {
        //변경된 주문이 있는지 체크
        $check = $this->checkViewStatus($view, $status);
        if ($check !== true) {
            if ($check == 'same') {
                return $this->changeReturnStructure('sameChangeStatus');
            } else {
                return $this->changeReturnStructure('beforeActingChangeStatus');
            }
        }

        //주문 상태별 로직
        switch ($status) {
            //배송준비중
            case ORDER_STATUS_DELIVERY_READY:
                $return = $this->doChangeStatusDeliveryReady($odIxs, ($etcData['cancelDeliveryIng'] ?? false));
                break;
            //배송지연
            case ORDER_STATUS_DELIVERY_DELAY:
                $return = $this->doChangeStatusDeliveryDelay($odIxs);
                break;
            //배송중
            case ORDER_STATUS_DELIVERY_ING:
                $return = $this->doChangeStatusDeliveryIng($odIxs, $etcData['quick'], $etcData['invoice_no']);
                break;
            //배송완료
            case ORDER_STATUS_DELIVERY_COMPLETE:
                $return = $this->doChangeStatusDeliveryComplete($odIxs);
                break;
            //구매확정
            case ORDER_STATUS_BUY_FINALIZED:
                $return = $this->doChangeStatusbuyFinalized($odIxs);
                break;
            //취소완료
            case ORDER_STATUS_CANCEL_COMPLETE:
                $return = $this->doChangeStatusCancelComplete($odIxs, ($etcData['reason'] ?? false));
                break;
            //반품승인
            case ORDER_STATUS_RETURN_ING:
                $return = $this->doChangeStatusReturnIng($odIxs);
                break;
            //반품거부
            case ORDER_STATUS_RETURN_DENY:
                $return = $this->doChangeStatusReturnDeny($odIxs, ($etcData ?? false));
                break;
            //반품회수완료
            case ORDER_STATUS_RETURN_ACCEPT:
                $return = $this->doChangeStatusReturnAccept($odIxs);
                break;
            //반품확정
            case ORDER_STATUS_RETURN_COMPLETE:
                $return = $this->doChangeStatusReturnComplete($odIxs);
                break;
            //반품불가
            case ORDER_STATUS_RETURN_IMPOSSIBLE:
                $return = $this->doChangeStatusReturnImpossible($odIxs);
                break;
            //교환승인
            case ORDER_STATUS_EXCHANGE_ING:
                $return = $this->doChangeStatusExchangeIng($odIxs);
                break;
            //교환거부
            case ORDER_STATUS_EXCHANGE_DENY:
                $return = $this->doChangeStatusExchangeDeny($odIxs, ($etcData ?? false));
                break;
            //교환회수완료
            case ORDER_STATUS_EXCHANGE_ACCEPT:
                $return = $this->doChangeStatusExchangeAccept($odIxs);
                break;
            //교환확정
            case ORDER_STATUS_EXCHANGE_COMPLETE:
                $return = $this->doChangeStatusExchangeComplete($odIxs);
                break;
            //교환불가
            case ORDER_STATUS_EXCHANGE_IMPOSSIBLE:
                $return = $this->doChangeStatusExchangeImpossible($odIxs);
                break;
            default :
                $return = $this->changeReturnStructure('undefinedStatus');
                break;
        }

        //히스토리 등록
        if ($return['result'] == 'success') {
            /* @var $orderModel \CustomScm\Model\Order\Order */
            $orderModel = $this->import('model.scm.order.order');

            foreach ($odIxs as $odIx) {
                $this->insertOrderHistory($odIx, $status, ($etcData['reasonDetail'] ?? $msg), '',
                    ($etcData['reason'] ?? ''));

                //제휴사 연동 주문 업데이트처리
                if ($order_from != 'self') {
                    $orderModel->updateSiteOrder($odIx, $status, $etcData);
                }
            }
        }
        return $return;
    }

    /**
     * 주문 상태 변경전 체크
     * @param type $view
     * @param type $changeStatus
     * @return boolean
     */
    protected function checkViewStatus($view, $changeStatus)
    {
        if ($view === false) {
            return true;
        } else {
            $list = [];
            foreach ($view as $val) {
                $list[$val['status']][] = $val['od_ix'];
            }

            $return = true;
            foreach ($list as $status => $odIxs) {
                //변경하려는 상태가 같으면.. 실패
                if ($changeStatus == $status) {
                    $return = 'same';
                    break;
                } else {
                    $count = $this->getDetailCountByStatus($status, $odIxs);
                    //view에서 보여지는 상태 건수와 실제 상태 건수 비교
                    if ($count != count($odIxs)) {
                        $return = false;
                        break;
                    }
                }
            }
            return $return;
        }
    }

    /**
     * 상태 변경 기본 조건 where
     * @return type
     */
    protected function qbChangeStatusBaiscWhere()
    {
        if (!empty($this->manageCompanyId)) {
            $this->qb->where('company_id', $this->manageCompanyId);
        }
        return $this->qb;
    }

    /**
     * get od_ix, status 의 count
     * @param type $status
     * @param type $odIxs
     * @return type
     */
    protected function getDetailCountByStatus($status, $odIxs)
    {
        return $this->qbChangeStatusBaiscWhere()
            ->from(TBL_SHOP_ORDER_DETAIL)
            ->whereIn('status', $status)
            ->whereIn('od_ix', $odIxs)
            ->getCount();
    }

    /**
     * 주문 상태 변경 - 배송준비중
     * @param type $odIxs
     * @param type $cancelDeliveryIng
     * @return type
     */
    protected function doChangeStatusDeliveryReady($odIxs, $cancelDeliveryIng = false)
    {
        //배송완료, 구매확정 상태 건수와 변경건수 비교
        $count = $this->getDetailCountByStatus([ORDER_STATUS_DELIVERY_COMPLETE, ORDER_STATUS_BUY_FINALIZED], $odIxs);
        if ($count > 0) {
            return $this->changeReturnStructure('canNotDeliveryReady');
        }

        //네이버페이 주문 상태 변경
        /* @var $naverPayModel \CustomScm\Model\Npay */
        $naverPayModel = $this->import('model.scm.npay');
        /* @var $naverPayOrderModel \CustomScm\Model\Npay\NaverPayOrder */
        $naverPayOrderModel = $this->import('model.scm.npay.naverPayOrder');
        /* @var $orderModel \CustomScm\Model\Order\Order */
        $orderModel = $this->import('model.scm.order.order');

        foreach ($odIxs as $odIx) {
            $orderDetailData = $orderModel->getOrderDetailNpay($odIx);

            if (!empty($orderDetailData['co_od_ix'])) {
                $npayInfo = $naverPayOrderModel->getProductOrderInfoList($orderDetailData['co_od_ix']);
                if (!(isset($npayInfo['ProductOrder']['ClaimType']) && $npayInfo['ProductOrder']['ClaimType'] == 'EXCHANGE')
                    && $orderDetailData['status'] != ORDER_STATUS_CANCEL_APPLY) {
                    $npayResponse = $naverPayModel->changeOrderStatusNpay($orderDetailData['co_od_ix'], 'PlaceProductOrder');

                    if ($npayResponse !== TRUE) {
                        return $this->changeReturnStructure('changeOrderStatusFail', $npayResponse);
                    }
                }
            }
        }

        //update order detail
        $this->qbChangeStatusBaiscWhere()
            ->set('status', ORDER_STATUS_DELIVERY_READY)
            ->set('dr_date', date('Y-m-d H:i:s'))
            ->set('update_date', date('Y-m-d H:i:s'))
            ->update(TBL_SHOP_ORDER_DETAIL)
            ->whereIn('od_ix', $odIxs)
            ->exec();

        if ($cancelDeliveryIng) {
            //재고 업데이트
            $list = $this->getGroupByOidByOdIxs($odIxs);
            foreach ($list as $oid => $orderOdIxs) {
                foreach ($orderOdIxs as $odIx) {
                    //재고 입고 처리
                    $this->storeStock($odIx, '배송취소');
                    //진행중 재고 처리
                    $this->updateSellIngCnt($oid, $odIx);
                }
            }
        }

        return $this->changeReturnStructure();
    }

    /**
     * 주문 상태 변경 - 배송지연
     * @param type $odIxs
     * @return type
     */
    protected function doChangeStatusDeliveryDelay($odIxs)
    {
        //update order detail
        $this->qbChangeStatusBaiscWhere()
            ->set('status', ORDER_STATUS_DELIVERY_DELAY)
            ->set('update_date', date('Y-m-d H:i:s'))
            ->update(TBL_SHOP_ORDER_DETAIL)
            ->whereIn('od_ix', $odIxs)
            ->exec();

        return $this->changeReturnStructure();
    }

    /**
     * 주문 상태 변경 - 배송중
     * @param type $odIxs
     * @param type $quick
     * @param type $invoiceNo
     * @return type
     */
    protected function doChangeStatusDeliveryIng($odIxs, $quick, $invoiceNo)
    {
        static $quickList = false;

        //배송준비중, 배송지연 상태 건수와 변경건수 비교
        $count = $this->getDetailCountByStatus([ORDER_STATUS_DELIVERY_READY, ORDER_STATUS_DELIVERY_DELAY], $odIxs);
        if ($count != count($odIxs)) {
            return $this->changeReturnStructure('canNotDeliveryIng');
        }

        if ($quickList === false) {
            /* @var $deliveryCompanyModel \CustomScm\Model\System\DeliveryCompany */
            $deliveryCompanyModel = $this->import('model.scm.system.deliveryCompany');
            $deliveryList = $deliveryCompanyModel->getUseDeliveryCompanyList();
            $quickList = array_column($deliveryList, 'code_ix');
        }

        if (!in_array($quick, $quickList)) {
            return $this->changeReturnStructure('unacceptableQuick');
        }
    
    	// 이니시스 에스크로 배송등록

        /* @var $orderModel \CustomScm\Model\Order\Order */
        $orderModel = $this->import('model.scm.order.order');
        $orderChangeInfo = $orderModel->getOrderInfo($odIxs[0]);

        if (in_array($orderChangeInfo['method'], [ORDER_METHOD_ESCROW_ICHE, ORDER_METHOD_ESCROW_VBANK])) {
            $class = 'PgForbizInicis';
            $module = new $class('W');

            $oid = $orderChangeInfo['oid'];
            $orderModel->setOid($oid);

            $orderInfo = $orderModel->getOrder();
            $info = $orderModel->getNormalProductList();

            $data = [
                'tid' => $orderInfo['tid']
                , 'oid' => $oid
                , 'price' => $orderInfo['total_price']
                , 'invoice' => $invoiceNo // **
                , 'registName' => "관리자"
                , 'exCode' => $quick // CJ **
                , 'exName' => \ForbizConfig::getDeliveryCompanyInfo($quick, 'name') // **
                , 'sendName' => $orderInfo['bname']
                , 'sendTel' => $orderInfo['bmobile']
                , 'sendPost' => $info[0]['zip']
                , 'sendAddr1' => $info[0]['addr1']
                , 'sendAddr2' => $info[0]['addr2']
                , 'recvTel' => $info[0]['rmobile']
                , 'recvName' => $info[0]['rname']
                , 'recvPost' => $info[0]['zip']
                , 'recvAddr' => $info[0]['addr1']
            ];

            $result = $module->doDelivery($data);

            if ($result["resultCode"] != "00") {
                $msg = '(' . $result["resultCode"] . ') '. $result["resultMsg"];
                return $this->changeReturnStructure('escrowDoDeliveryFail', $msg);
            }
        } else {
            /* @var $orderModel \CustomScm\Model\Order\Order */
            $orderModel = $this->import('model.scm.order.order');
            /* @var $naverPayModel \CustomScm\Model\Npay */
            $naverPayModel = $this->import('model.scm.npay');

	        foreach ($odIxs as $odIx) {
	            $orderDetailData = $orderModel->getOrderDetailNpay($odIx);
	
	            if (!empty($orderDetailData['co_od_ix'])) {
	                $exchanged = $this->exchangeDeliveryProductCheck($orderDetailData['co_od_ix']);
	                $npayResponse = TRUE;
	
	                $nPayData = [];
	                $nPayData['quick'] = $quick;
	                $nPayData['invoice_no'] = $invoiceNo;
	
	                if (empty($exchanged)) {                                    //일반발송
	                    $npayResponse = $naverPayModel->changeOrderStatusNpay($orderDetailData['co_od_ix'], 'shipProductOrder', $nPayData);
	                } else {                                                    //교환 상품 재발송
	                    $npayResponse = $naverPayModel->changeOrderStatusNpay($orderDetailData['co_od_ix'], 'ReDeliveryExchange', $nPayData);
	                }
	
	                if ($npayResponse !== TRUE) {
	                    return $this->changeReturnStructure('changeOrderStatusFail', $npayResponse);
	                }
	            }
	        }
        }

        //update order detail
        $this->qbChangeStatusBaiscWhere()
            ->set('status', ORDER_STATUS_DELIVERY_ING)
            ->set('quick', $quick)
            ->set('invoice_no', $invoiceNo)
            ->set('di_date', date('Y-m-d H:i:s'))
            ->set('update_date', date('Y-m-d H:i:s'))
            ->update(TBL_SHOP_ORDER_DETAIL)
            ->whereIn('od_ix', $odIxs)
            ->exec();

        //재고 업데이트
        $list = $this->getGroupByOidByOdIxs($odIxs);
        foreach ($list as $oid => $orderOdIxs) {
            foreach ($orderOdIxs as $odIx) {
                //재고 출고 처리
                $this->releaseStock($odIx, '출고');
                //진행중 재고 처리
                $this->updateSellIngCnt($oid, $odIx);
            }
        }

        //메일&문자 발송
        $this->sendMessage(ORDER_STATUS_DELIVERY_ING, $odIxs);

        return $this->changeReturnStructure();
    }

    /**
     * 주문 상태 변경 - 배송완료
     * @param type $odIxs
     * @return type
     */
    protected function doChangeStatusDeliveryComplete($odIxs)
    {
        //update order detail
        $this->qbChangeStatusBaiscWhere()
            ->set('status', ORDER_STATUS_DELIVERY_COMPLETE)
            ->set('dc_date', date('Y-m-d H:i:s'))
            ->set('update_date', date('Y-m-d H:i:s'))
            ->update(TBL_SHOP_ORDER_DETAIL)
            ->whereIn('od_ix', $odIxs)
            ->exec();

        return $this->changeReturnStructure();
    }

    /**
     * 주문 상태 변경 - 구매확정
     * @param type $odIxs
     * @return type
     */
    protected function doChangeStatusbuyFinalized($odIxs)
    {
        //update order detail
        $this->qbChangeStatusBaiscWhere()
            ->set('status', ORDER_STATUS_BUY_FINALIZED)
            ->set('bf_date', date('Y-m-d H:i:s'))
            ->set('update_date', date('Y-m-d H:i:s'))
            ->update(TBL_SHOP_ORDER_DETAIL)
            ->whereIn('od_ix', $odIxs)
            ->exec();

        //마일리지 적립
        $reserveList = $this->qb
            ->select('od.od_ix')
            ->select('od.reserve')
            ->select('o.user_code')
            ->from(TBL_SHOP_ORDER_DETAIL . ' AS od')
            ->join(TBL_SHOP_ORDER . ' AS o', 'o.oid=od.oid')
            ->whereIn('od_ix', $odIxs)
            ->exec()
            ->getResultArray();

        $reserveData = [];
        foreach ($reserveList as $rl) {
            $reserveData[$rl['od_ix']]['reserve'] = $rl['reserve'];
            $reserveData[$rl['od_ix']]['user_code'] = $rl['user_code'];
        }

        /* @var $mileageModel \CustomScm\Model\Member\Mileage */
        $mileageModel = $this->import('model.scm.member.mileage');

        $list = $this->getGroupByOidByOdIxs($odIxs);
        foreach ($list as $oid => $orderOdIxs) {
            foreach ($orderOdIxs as $odIx) {
                $userCode = $reserveData[$odIx]['user_code'];
                $reserve = $reserveData[$odIx]['reserve'];
                if (!empty($userCode) && $reserve > 0) {
                    $mileageModel->setMember($userCode, 'Y');
                    $mileageModel->addMileage($reserve, 1, '구매확정으로 인한 마일리지 적립', ['oid' => $oid, 'od_ix' => $odIx]);
                }
            }
        }

        return $this->changeReturnStructure();
    }

    /**
     * 주문 상태 변경 - 취소완료
     * @param type $odIxs
     * @param type $reason
     * @return type
     */
    protected function doChangeStatusCancelComplete($odIxs, $reason = false)
    {
        //클레임 처리 여부
        $claimBool = ($reason === false ? false : true);

        //취소요청 상태 건수와 변경건수 비교
        if ($claimBool) {
            //입금 확인, 배송준비중, 배송지연 -> 취소완료로 바로 되는 경우
            $checkStatus = [ORDER_STATUS_INCOM_COMPLETE, ORDER_STATUS_DELIVERY_READY, ORDER_STATUS_DELIVERY_DELAY];
        } else {
            $checkStatus = [ORDER_STATUS_CANCEL_APPLY];
        }
        $count = $this->getDetailCountByStatus($checkStatus, $odIxs);
        if ($count != count($odIxs)) {
            return $this->changeReturnStructure(($claimBool ? 'canNotCancelCompleteClaim' : 'canNotCancelComplete'));
        }

        if ($claimBool) {
            $this->qb->set('ca_date', date('Y-m-d H:i:s'));
        }

        //update order detail
        $this->qbChangeStatusBaiscWhere()
            ->set('status', ORDER_STATUS_CANCEL_COMPLETE)
            ->set('refund_status', ORDER_STATUS_REFUND_APPLY)
            ->set('cc_date', date('Y-m-d H:i:s'))
            ->set('fa_date', date('Y-m-d H:i:s'))
            ->set('update_date', date('Y-m-d H:i:s'))
            ->update(TBL_SHOP_ORDER_DETAIL)
            ->whereIn('od_ix', $odIxs)
            ->exec();

        $list = $this->getGroupByOidByOdIxs($odIxs);
        foreach ($list as $oid => $orderOdIxs) {
            foreach ($orderOdIxs as $odIx) {
                //판매진행중 재고 업데이트
                $this->updateSellIngCnt($oid, $odIx);

                //쿠폰 돌려주기
                $this->returnUsedCoupon(ORDER_STATUS_CANCEL_COMPLETE, $oid, $odIx);
            }

            if ($claimBool) {
                //클레임 상품 수량 데이터 만들기
                $rows = $this->qb
                    ->select('pcnt')
                    ->select('od_ix')
                    ->from(TBL_SHOP_ORDER_DETAIL)
                    ->whereIn('od_ix', $odIxs)
                    ->exec()
                    ->getResultArray();
                $pcntInfo = [];
                foreach ($rows as $row) {
                    $pcntInfo[$row['od_ix']] = $row['pcnt'];
                }

                //클레임 데이터 생성
                $companyList = $this->getGroupByDeliveryCompanyIdByOdIxs($orderOdIxs);
                foreach ($companyList as $companyId => $companyOdIxs) {
                    $claimGroup = $this->getClaimGroup($oid);

                    //클레임 요청 상품 데이터 만들기
                    $productList = [];
                    foreach ($companyOdIxs as $odIx) {
                        array_push($productList, [
                            'od_ix' => $odIx,
                            'applyPcnt' => $pcntInfo[$odIx],
                            'pcnt' => $pcntInfo[$odIx]
                        ]);
                    }

                    //클레임 배송비 계산
                    $claimDeliveryData = $this->claimCalculate(ORDER_STATUS_CANCEL_COMPLETE, $oid, $productList,
                        ['reason' => $reason]);

                    //클레임 배송지 정보 저장
                    $this->insertClaimDelivery($oid, $claimGroup, $companyId, $claimDeliveryData['claimDeliveryPrice']);

                    //주문 상세 claim_group update
                    $this->qb
                        ->set('claim_group', $claimGroup)
                        ->update(TBL_SHOP_ORDER_DETAIL)
                        ->whereIn('od_ix', $companyOdIxs)
                        ->exec();
                }
            }
        }
        return $this->changeReturnStructure();
    }

    /**
     * 주문 상태 변경 - 반품승인
     * @param type $odIxs
     * @return type
     */
    protected function doChangeStatusReturnIng($odIxs)
    {
        //네이버페이 주문 상태 변경
        /* @var $naverPayModel \CustomScm\Model\Npay */
        $naverPayModel = $this->import('model.scm.npay');
        /* @var $orderModel \CustomScm\Model\Order\Order */
        $orderModel = $this->import('model.scm.order.order');

        foreach ($odIxs as $odIx) {
            $orderDetailData = $orderModel->getOrderDetailNpay($odIx);

            if (!empty($orderDetailData['co_od_ix'])) {
                $returnData = $this->qb
                    ->select('reason_code')
                    ->from(TBL_SHOP_ORDER_STATUS)
                    ->where('od_ix', $odIx)
                    ->whereIn('status', [ORDER_STATUS_RETURN_APPLY, ORDER_STATUS_RETURN_ING])
                    ->orderBy('regdate', 'DESC')
                    ->limit(1)
                    ->exec()
                    ->getRowArray();

                $npayResponse = TRUE;

                if ($npayResponse !== TRUE) {
                    return $this->changeReturnStructure('changeOrderStatusFail', $npayResponse);
                }
            }
        }

        //update order detail
        $this->qbChangeStatusBaiscWhere()
            ->set('status', ORDER_STATUS_RETURN_ING)
            ->set('update_date', date('Y-m-d H:i:s'))
            ->update(TBL_SHOP_ORDER_DETAIL)
            ->whereIn('od_ix', $odIxs)
            ->exec();

        return $this->changeReturnStructure();
    }

    /**
     * 주문 상태 변경 - 반품거부
     * @param type $odIxs
     * @return type
     */
    protected function doChangeStatusReturnDeny($odIxs, $reason = false)
    {
        //네이버페이 주문 상태 변경
        /* @var $naverPayModel \CustomScm\Model\Npay */
        $naverPayModel = $this->import('model.scm.npay');
        /* @var $orderModel \CustomScm\Model\Order\Order */
        $orderModel = $this->import('model.scm.order.order');

        foreach ($odIxs as $odIx) {
            $orderDetailData = $orderModel->getOrderDetailNpay($odIx);

            if (!empty($orderDetailData['co_od_ix'])) {
                if ($reason) {
                    if ($reason['reason'] == "MPNE") {
                        $reasonMessage = '주문제작상품으로 교환불가' . "(" . $reason['reasonDetail'] . ")";
                    } elseif ($reason['reason'] == "NEP") {
                        $reasonMessage = '교환불가상품(상세페이지참조)' . "(" . $reason['reasonDetail'] . ")";
                    } else {
                        $reasonMessage = '기타' . "(" . $reason['reasonDetail'] . ")";
                    }
                }

                $npayData['reason_message'] = $reasonMessage;

                $npayResponse = $naverPayModel->changeOrderStatusNpay($orderDetailData['co_od_ix'], 'RejectReturn', $npayData);

                if ($npayResponse !== TRUE) {
                    return $this->changeReturnStructure('changeOrderStatusFail', $npayResponse);
                }
            }
        }

        //update order detail
        $this->qbChangeStatusBaiscWhere()
            ->set('status', ORDER_STATUS_DELIVERY_COMPLETE)
            ->set('update_date', date('Y-m-d H:i:s'))
            ->update(TBL_SHOP_ORDER_DETAIL)
            ->whereIn('od_ix', $odIxs)
            ->exec();

        return $this->changeReturnStructure();
    }

    /**
     * 주문 상태 변경 - 반품회수완료
     * @param type $odIxs
     * @return type
     */
    protected function doChangeStatusReturnAccept($odIxs)
    {
        //update order detail
        $this->qbChangeStatusBaiscWhere()
            ->set('status', ORDER_STATUS_RETURN_ACCEPT)
            ->set('update_date', date('Y-m-d H:i:s'))
            ->update(TBL_SHOP_ORDER_DETAIL)
            ->whereIn('od_ix', $odIxs)
            ->exec();

        foreach ($odIxs as $odIx) {
            //재고 입고 처리
            $this->storeStock($odIx, '반품회수');
        }

        return $this->changeReturnStructure();
    }

    /**
     * 주문 상태 변경 - 반품확정
     * @param type $odIxs
     * @return type
     */
    protected function doChangeStatusReturnComplete($odIxs)
    {
        //update order detail
        $this->qbChangeStatusBaiscWhere()
            ->set('status', ORDER_STATUS_RETURN_COMPLETE)
            ->set('refund_status', ORDER_STATUS_REFUND_APPLY)
            ->set('update_date', date('Y-m-d H:i:s'))
            ->set('fa_date', date('Y-m-d H:i:s'))
            ->update(TBL_SHOP_ORDER_DETAIL)
            ->whereIn('od_ix', $odIxs)
            ->exec();

        $list = $this->getGroupByOidByOdIxs($odIxs);
        foreach ($list as $oid => $orderOdIxs) {
            foreach ($orderOdIxs as $odIx) {
                //쿠폰 돌려주기
                $this->returnUsedCoupon(ORDER_STATUS_RETURN_COMPLETE, $oid, $odIx);
            }
        }

        return $this->changeReturnStructure();
    }

    /**
     * 주문 상태 변경 - 반품불가
     * @param type $odIxs
     * @return type
     */
    protected function doChangeStatusReturnImpossible($odIxs)
    {
        //update order detail
        $this->qbChangeStatusBaiscWhere()
            ->set('status', ORDER_STATUS_DELIVERY_COMPLETE)
            ->set('update_date', date('Y-m-d H:i:s'))
            ->update(TBL_SHOP_ORDER_DETAIL)
            ->whereIn('od_ix', $odIxs)
            ->exec();

        foreach ($odIxs as $odIx) {
            //재고 출고 처리
            $this->releaseStock($odIx, '반품불가');
        }

        return $this->changeReturnStructure();
    }

    /**
     * 주문 상태 변경 - 교환승인
     * @param type $odIxs
     * @return type
     */
    protected function doChangeStatusExchangeIng($odIxs)
    {
        //update order detail
        $this->qbChangeStatusBaiscWhere()
            ->set('status', ORDER_STATUS_EXCHANGE_ING)
            ->set('update_date', date('Y-m-d H:i:s'))
            ->update(TBL_SHOP_ORDER_DETAIL)
            ->whereIn('od_ix', $odIxs)
            ->exec();

        return $this->changeReturnStructure();
    }

    /**
     * 주문 상태 변경 - 교환거부
     * @param type $odIxs
     * @return type
     */
    protected function doChangeStatusExchangeDeny($odIxs, $reason = false)
    {
        //네이버페이 주문 상태 변경
        /* @var $naverPayModel \CustomScm\Model\Npay */
        $naverPayModel = $this->import('model.scm.npay');
        /* @var $orderModel \CustomScm\Model\Order\Order */
        $orderModel = $this->import('model.scm.order.order');

        foreach ($odIxs as $odIx) {
            $orderDetailData = $orderModel->getOrderDetailNpay($odIx);

            if (!empty($orderDetailData['co_od_ix'])) {
                if ($reason) {
                    if ($reason['reason'] == "MPNE") {
                        $reasonMessage = '주문제작상품으로 교환불가' . "(" . $reason['reasonDetail'] . ")";
                    } elseif ($reason['reason'] == "NEP") {
                        $reasonMessage = '교환불가상품(상세페이지참조)' . "(" . $reason['reasonDetail'] . ")";
                    } else {
                        $reasonMessage = '기타' . "(" . $reason['reasonDetail'] . ")";
                    }
                }

                $npayData['reason_message'] = $reasonMessage;

                $npayResponse = $naverPayModel->changeOrderStatusNpay($orderDetailData['co_od_ix'], 'RejectExchange', $npayData);

                if ($npayResponse !== TRUE) {
                    return $this->changeReturnStructure('changeOrderStatusFail', $npayResponse);
                }
            }
        }

        //update order detail
        $this->qbChangeStatusBaiscWhere()
            ->set('status', ORDER_STATUS_DELIVERY_COMPLETE)
            ->set('update_date', date('Y-m-d H:i:s'))
            ->update(TBL_SHOP_ORDER_DETAIL)
            ->whereIn('od_ix', $odIxs)
            ->exec();

        foreach ($odIxs as $odIx) {
            //교환 상품 취소 처리
            $this->changeExchangeProduct($odIx, ORDER_STATUS_SETTLE_READY, '교환거부');
        }

        return $this->changeReturnStructure();
    }

    /**
     * 주문 상태 변경 - 교환회수완료
     * @param type $odIxs
     * @return type
     */
    protected function doChangeStatusExchangeAccept($odIxs)
    {
        //네이버페이 주문 상태 변경
        /* @var $naverPayModel \CustomScm\Model\Npay */
        $naverPayModel = $this->import('model.scm.npay');
        /* @var $orderModel \CustomScm\Model\Order\Order */
        $orderModel = $this->import('model.scm.order.order');

        foreach ($odIxs as $odIx) {
            $orderDetailData = $orderModel->getOrderDetailNpay($odIx);

            if (!empty($orderDetailData['co_od_ix'])) {
                $npayResponse = $naverPayModel->changeOrderStatusNpay($orderDetailData['co_od_ix'], 'ApproveCollectedExchange');
                if ($npayResponse !== TRUE) {
                    return $this->changeReturnStructure('changeOrderStatusFail', $npayResponse);
                }
            }
        }

        //update order detail
        $this->qbChangeStatusBaiscWhere()
            ->set('status', ORDER_STATUS_EXCHANGE_ACCEPT)
            ->set('update_date', date('Y-m-d H:i:s'))
            ->update(TBL_SHOP_ORDER_DETAIL)
            ->whereIn('od_ix', $odIxs)
            ->exec();

        foreach ($odIxs as $odIx) {
            //재고 입고 처리
            $this->storeStock($odIx, '교환회수');
        }

        return $this->changeReturnStructure();
    }

    /**
     * 주문 상태 변경 - 교환확정
     * @param type $odIxs
     * @return type
     */
    protected function doChangeStatusExchangeComplete($odIxs)
    {
        //update order detail
        $this->qbChangeStatusBaiscWhere()
            ->set('status', ORDER_STATUS_EXCHANGE_COMPLETE)
            ->set('update_date', date('Y-m-d H:i:s'))
            ->update(TBL_SHOP_ORDER_DETAIL)
            ->whereIn('od_ix', $odIxs)
            ->exec();

        foreach ($odIxs as $odIx) {
            //교환 상품 배송준비중 처리
            $this->changeExchangeProduct($odIx, ORDER_STATUS_EXCHANGE_READY, '교환확정');
        }

        return $this->changeReturnStructure();
    }

    /**
     * 주문 상태 변경 - 교환불가
     * @param type $odIxs
     * @return type
     */
    protected function doChangeStatusExchangeImpossible($odIxs)
    {
        //update order detail
        $this->qbChangeStatusBaiscWhere()
            ->set('status', ORDER_STATUS_DELIVERY_COMPLETE)
            ->set('update_date', date('Y-m-d H:i:s'))
            ->update(TBL_SHOP_ORDER_DETAIL)
            ->whereIn('od_ix', $odIxs)
            ->exec();

        foreach ($odIxs as $odIx) {
            //재고 출고 처리
            $this->releaseStock($odIx, '교환불가');

            //교환 상품 취소 처리
            $this->changeExchangeProduct($odIx, ORDER_STATUS_SETTLE_READY, '교환불가');
        }

        return $this->changeReturnStructure();
    }

    /**
     * 일반발송/교환주문 재발송 구분
     * @param $odIx
     * @return false|mixed
     * @throws \Exception
     */
    protected function exchangeDeliveryProductCheck($coOdIx)
    {
        return $this->qb
            ->select('claim_delivery_od_ix')
            ->from(TBL_SHOP_ORDER_DETAIL)
            ->where('co_od_ix', $coOdIx)
            ->where('claim_delivery_od_ix !=', 0)
            ->exec()
            ->getRowArray();
    }

    /**
     * 교환 재배송 상품 상태 변경
     * @param $odIx
     * @param $status
     * @param string $msg
     */
    public function changeExchangeProduct($odIx, $status, $msg = '')
    {
        $row = $this->qb
            ->select('od_ix')
            ->from(TBL_SHOP_ORDER_DETAIL)
            ->where('status', ORDER_STATUS_EXCHANGE_READY)
            ->where('claim_delivery_od_ix', $odIx)
            ->exec()
            ->getRowArray();

        $targetOdIx = $row['od_ix'] ?? false;
        if (!empty($targetOdIx)) {
            $this->qb
                ->set('status', $status)
                ->set('update_date', date('Y-m-d H:i:s'))
                ->update(TBL_SHOP_ORDER_DETAIL)
                ->where('od_ix', $targetOdIx)
                ->exec();

            $this->insertOrderHistory($targetOdIx, $status, $msg);
        }
    }

    /**
     * get odixs 로 oid => odixs 배열
     * @param type $odIxs
     * @return type
     */
    protected function getGroupByOidByOdIxs($odIxs)
    {
        $rows = $this->qb
            ->select('oid')
            ->select('od_ix')
            ->from(TBL_SHOP_ORDER_DETAIL)
            ->whereIn('od_ix', $odIxs)
            ->exec()
            ->getResultArray();

        $data = [];
        foreach ($rows as $row) {
            $data[$row['oid']][] = $row['od_ix'];
        }

        return $data;
    }

    /**
     * get odixs 로 배송업체 company_id => odixs 배열
     * @param type $odIxs
     * @return type
     */
    protected function getGroupByDeliveryCompanyIdByOdIxs($odIxs)
    {
        $rows = $this->qb
            ->select('ode.company_id')
            ->select('od.od_ix')
            ->from(TBL_SHOP_ORDER_DETAIL . ' AS od')
            ->join(TBL_SHOP_ORDER_DELIVERY . ' AS ode', 'ode.ode_ix=od.ode_ix')
            ->whereIn('od_ix', $odIxs)
            ->exec()
            ->getResultArray();

        $data = [];
        foreach ($rows as $row) {
            $data[$row['company_id']][] = $row['od_ix'];
        }

        return $data;
    }

    /**
     * 메일&문자 발송
     * @param type $type
     * @param type $odIxs
     */
    protected function sendMessage($type, $odIxs)
    {
        //self 일때만 보내야함
        switch ($type) {
            //배송중
            case ORDER_STATUS_DELIVERY_ING:
                /* @var $orderModel \CustomScm\Model\Order\Order */
                $orderModel = $this->import('model.scm.order.order');

                //송장번호 별로 sendMessage 데이터가 넘어옴
                $groupByData = $this->getGroupByOidByOdIxs($odIxs);
                foreach ($groupByData as $oid => $_odIxs) {
                    $orderModel->setOid($oid);
                    $messageData = $orderModel->getOrder();
                    $messageData['productList'] = $orderModel->getNormalProductList(['od_ix' => $_odIxs]);

                    $product = $messageData['productList'][0];
                    $pname = str_cut($product['pname'], 39);
                    $messageData['pnameAbbreviation'] = count($messageData['productList']) > 1 ? $pname . " 외 " . (count($messageData['productList']) - 1) . "건" : $pname;
                    $messageData['di_date'] = $product['di_date'] ?? date('Y-m-d H:i:s');
                    $messageData['quick'] = $product['quick'] ?? '';
                    $messageData['quickText'] = $product['quickText'] ?? '';
                    $messageData['invoice_no'] = $product['invoice_no'] ?? '';
                    $messageData['rname'] = $product['rname'] ?? '';
                    $messageData['zip'] = $product['zip'] ?? '';
                    $messageData['addr1'] = $product['addr1'] ?? '';
                    $messageData['addr2'] = $product['addr2'] ?? '';
                    $messageData['rmobile'] = $product['rmobile'] ?? '';
                    $messageData['rtel'] = $product['rtel'] ?? '';
                    $messageData['msg_type'] = $product['msg_type'] ?? '';
                    $messageData['msg'] = $product['msg'] ?? '';

                    sendMessage('good_send_sucess', $messageData['bmail'], $messageData['bmobile'], $messageData);
                }
                break;
        }
    }

    /**
     * 재고 입고 처리
     * @param $odIx
     */
    protected function storeStock($odIx, $msg = '')
    {
        static $stockModel = false;

        if ($stockModel === false) {
            /* @var $stockModel \CustomScm\Model\Inventory\Stock */
            $stockModel = $this->import('model.scm.inventory.stock');
        }

        $data = $this->qb
            ->select('oid')
            ->select('stock_use_yn')
            ->select('gid')
            ->select('company_id')
            ->select('gu_ix')
            ->select('pcnt')
            ->select('option_id')
            ->from(TBL_SHOP_ORDER_DETAIL)
            ->where('od_ix', $odIx)
            ->exec()
            ->getRowArray();

        if ($data['stock_use_yn'] == 'Y') { //WMS
            //입고 처리
            $stockModel->store($data['gid'], $data['company_id'], $data['pcnt'],
                $data['oid'] . ' - ' . $odIx . ($msg != '' ? ' ' . $msg : ''));
        } else {
            if ($data['stock_use_yn'] == 'Q') { //재고옵션
                //재고 추가
                $this->qb
                    ->set('option_stock', 'option_stock + ' . $data['pcnt'], false)
                    ->update(TBL_SHOP_PRODUCT_OPTIONS_DETAIL)
                    ->where('id', $data['option_id'])
                    ->exec();
            }
        }
    }

    /**
     * 재고 출고 처리
     * @param $odIx
     */
    protected function releaseStock($odIx, $msg = '')
    {
        static $stockModel = false;

        if ($stockModel === false) {
            /* @var $stockModel \CustomScm\Model\Inventory\Stock */
            $stockModel = $this->import('model.scm.inventory.stock');
        }

        $data = $this->qb
            ->select('oid')
            ->select('stock_use_yn')
            ->select('gid')
            ->select('gu_ix')
            ->select('company_id')
            ->select('pcnt')
            ->select('option_id')
            ->from(TBL_SHOP_ORDER_DETAIL)
            ->where('od_ix', $odIx)
            ->exec()
            ->getRowArray();

        if ($data['stock_use_yn'] == 'Y') { //WMS
            //출고 처리
            $stockModel->release($data['gid'], $data['company_id'], $data['pcnt'],
                $data['oid'] . ' - ' . $odIx . ($msg != '' ? ' ' . $msg : ''));
        } else {
            if ($data['stock_use_yn'] == 'Q') { //재고옵션
                //재고 차감
                $this->qb
                    ->set('option_stock',
                        '(CASE WHEN option_stock < ' . $data['pcnt'] . ' THEN 0 ELSE option_stock - ' . $data['pcnt'] . ' END)',
                        false)
                    ->update(TBL_SHOP_PRODUCT_OPTIONS_DETAIL)
                    ->where('id', $data['option_id'])
                    ->exec();
            }
        }
    }

    /**
     * 판매 진행 재고 업데이트
     * @param type $oid
     * @param type $odIx
     */
    protected function updateSellIngCnt($oid, $odIx = false)
    {
        if ($odIx !== false && !empty($odIx)) {
            $this->qb->whereIn('od_ix', $odIx);
        }

        $ingStatus = [
            ORDER_STATUS_INCOM_READY,
            ORDER_STATUS_INCOM_COMPLETE,
            ORDER_STATUS_DELIVERY_READY,
            ORDER_STATUS_DELIVERY_DELAY,
            ORDER_STATUS_CANCEL_APPLY
        ];

        $rows = $this->qb
            ->select('stock_use_yn')
            ->select('gid')
            ->select('gu_ix')
            ->select('pcnt')
            ->select('pid')
            ->select('option_id')
            ->from(TBL_SHOP_ORDER_DETAIL)
            ->where('oid', $oid)
            ->exec()
            ->getResultArray();
        foreach ($rows as $data) {
            if ($data['stock_use_yn'] == 'Y') { //WMS
                $row = $this->qb
                    ->selectSum('pcnt')
                    ->from(TBL_SHOP_ORDER_DETAIL)
                    ->whereIn('gid', $data['gid'])
                    ->whereIn('gu_ix', $data['gu_ix'])
                    ->whereIn('status', $ingStatus)
                    ->exec()
                    ->getRowArray();
                $sellIngCnt = ($row['pcnt'] ?? 0);

                $this->qb
                    ->set('option_sell_ing_cnt', $sellIngCnt)
                    ->update(TBL_SHOP_PRODUCT_OPTIONS_DETAIL)
                    ->whereIn('option_gid', $data['gid'])
                    ->whereIn('option_code', $data['gu_ix'])
                    ->exec();

                $this->qb
                    ->set('sell_ing_cnt', $sellIngCnt)
                    ->update(TBL_INVENTORY_GOODS_UNIT)
                    ->where('gu_ix', $data['gu_ix'])
                    ->exec();
            } else {
                if ($data['stock_use_yn'] == 'Q') { //재고옵션
                    $row = $this->qb
                        ->selectSum('pcnt')
                        ->from(TBL_SHOP_ORDER_DETAIL)
                        ->whereIn('pid', $data['pid'])
                        ->whereIn('option_id', $data['option_id'])
                        ->whereIn('status', $ingStatus)
                        ->exec()
                        ->getRowArray();
                    $sellIngCnt = ($row['pcnt'] ?? 0);

                    $this->qb
                        ->set('option_sell_ing_cnt', $sellIngCnt, false)
                        ->update(TBL_SHOP_PRODUCT_OPTIONS_DETAIL)
                        ->where('id', $data['option_id'])
                        ->exec();
                }
            }
        }
    }

    /**
     * Npay - 판매 진행 재고 업데이트
     * @param $oid
     * @param $odIx
     * @return void
     */
    public function updateNpaySellIngCnt($oid, $odIx = false)
    {
        return $this->updateSellIngCnt($oid);
    }

    /**
     * Npay 클레임 처리 - 교환
     * @param $data
     * @param $companyId
     * @param $insUp
     * @throws \Exception
     */
    public function changedOrderNpayExchange($data, $companyId, $insUp)
    {
        //반품 배송정보
        if ($data['send_type'] == 1) { //직접 발송
            $orderType = 3;
            $data['send_yn'] = 'Y';

            //업체 배송지 정보 가지고 오기
            /* @var $deliveryPolicyModel \CustomScm\Model\Company\DeliveryPolicy */
            $deliveryPolicyModel = $this->import('model.scm.company.deliveryPolicy');
            $deliveryPolicyModel->setManageCompanyId($companyId);
            $returnAddress = $deliveryPolicyModel->getReturnAddress();
            $data['cname'] = $returnAddress['addr_name'];
            $data['cmobile'] = $returnAddress['addr_phone'];
            $data['czip'] = $returnAddress['zip_code'];
            $data['caddr1'] = $returnAddress['address_1'];
            $data['caddr2'] = $returnAddress['address_2'];
            $data['cmsg'] = '';
        } else { //지정택배 방문요청
            $orderType = 4;
            $data['send_yn'] = 'N';
        }

        /* @var $orderModel \CustomScm\Model\Order\Order */
        $orderModel = $this->import('model.scm.order.order');

        //반품 배송정보 입력
        $returnDeliveryIx = $orderModel->insertOrderDeliveryInfo($data['oid'], $orderType, [
            'rname' => $data['cname'],
            'rmobile' => $data['cmobile'],
            'zip' => $data['czip'],
            'addr1' => $data['caddr1'],
            'addr2' => $data['caddr2'],
            'quick' => $data['quick'],
            'invoice_no' => $data['invoice_no'],
            'send_yn' => $data['send_yn'],
            'send_type' => $data['send_type'],
            'delivery_pay_type' => $data['delivery_pay_type']
        ]);

        //재배송 배송정보 입력
        $reDeliveryIx = $orderModel->insertOrderDeliveryInfo($data['oid'], 2, [
            'rname' => $data['cname'],
            'rmobile' => $data['cmobile'],
            'zip' => $data['czip'],
            'addr1' => $data['caddr1'],
            'addr2' => $data['caddr2']
        ]);

        if ($insUp == 'update') {
            $claimGroup = $this->getClaimGroup($data['oid']);

            /* @var $createOrderModel \CustomScm\Model\Order\CreateOrder */
            $createOrderModel = $this->import('model.scm.order.createOrder');
            //재배송 배송정보 수정
            $newOdIx = $createOrderModel->updateExchangeOrder($data['od_ix'], $reDeliveryIx, $claimGroup);

            //반품 상품 주문
            $this->qb
                ->set('status', $data['status'])
                ->set('ea_date', $data['ea_date'])
                ->set('dc_date', "IFNULL(dc_date,'" . fb_now() . "')", false)
                ->set('bf_date', "IFNULL(bf_date,'" . fb_now() . "')", false)
                ->set('update_date', date('Y-m-d H:i:s'))
                ->set('claim_group', $claimGroup)
                ->set('odd_ix', $returnDeliveryIx)
                ->update(TBL_SHOP_ORDER_DETAIL)
                ->where('od_ix', $data['od_ix'])
                ->exec();

            $cnt = $this->qb
                ->from(TBL_SHOP_ORDER_STATUS)
                ->where('od_ix', $data['od_ix'])
                ->where('status', $data['status'])
                ->where('status_message', $data['reasonDetail'])
                ->where('reason_code', $data['reason'])
                ->where('data_channel', '2')
                ->getCount();

            if ($cnt == 0) {
                //주문 상태 변경 기록
                $this->insertOrderHistory($newOdIx, ORDER_STATUS_EXCHANGE_READY, "주문 상세번호 " . $data['od_ix'] . " 교환상품", $data['oid']);
            }

        } elseif ($insUp = 'insert') {
            $claimGroup = 1;
        }

        $this->insertClaimDelivery($data['oid'], $claimGroup, $companyId, $data['claim_delivery_price']);

        $returnData['reDeliveryIx'] = $reDeliveryIx;
        $returnData['returnDeliveryIx'] = $returnDeliveryIx;

        return $returnData;
    }

    /**
     * 클레임 처리
     * @param type $status
     * @param type $oid
     * @param type $productList
     * @param type $claimData
     * @param type $claimDeliveryPrice
     * @param type $returnDeliveryInfo
     * @param type $exchangeDeliveryInfo
     */
    public function doClaim($status, $oid, $productList, $claimData, $claimDeliveryPrice)
    {
        $claimGroup = $this->getClaimGroup($oid);

        foreach ($productList as $key => $product) {
            if ($product['pcnt'] > $product['applyPcnt'] && $product['applyPcnt'] > 0) {
                //주문 분할
                /* @var $orderModel \CustomScm\Model\Order\Order */
                $orderModel = $this->import('model.scm.order.order');
                $productList[$key]['od_ix'] = $orderModel->orderSeparate($product['od_ix'], $product['applyPcnt']);
            }
        }

        $odIxs = array_column($productList, 'od_ix');

        //UI에서 ode_ix 가 같아야 신청이 가능하지만 배송업체 company_id (shop_order_delivery.company_id) 같은 주문건을 넘겨도 문제 없음
        $companyId = array_keys($this->getGroupByDeliveryCompanyIdByOdIxs($odIxs))[0];

        if (in_array($status, [ORDER_STATUS_CANCEL_APPLY, ORDER_STATUS_CANCEL_COMPLETE])) {
            //취소
            $this->doClaimCancel($status, $claimGroup, $oid, $odIxs, $claimData, $companyId, $claimDeliveryPrice);
        } else {
            if (in_array($status, [ORDER_STATUS_RETURN_APPLY, ORDER_STATUS_RETURN_ING])) {
                //반품
                $this->doClaimReturn($status, $claimGroup, $oid, $odIxs, $claimData, $companyId, $claimDeliveryPrice);
            } else {
                if (in_array($status, [ORDER_STATUS_EXCHANGE_APPLY, ORDER_STATUS_EXCHANGE_ING])) {
                    //교환
                    $this->doClaimExchange($status, $claimGroup, $oid, $odIxs, $claimData, $companyId,
                        $claimDeliveryPrice);
                }
            }
        }
    }

    /**
     * 클레임 처리 - 취소
     * @param $status
     * @param $claimGroup
     * @param $oid
     * @param $odIxs
     * @param $claimData
     * @param $companyId
     * @param $claimDeliveryPrice
     */
    protected function doClaimCancel($status, $claimGroup, $oid, $odIxs, $claimData, $companyId, $claimDeliveryPrice)
    {
        if (!empty($odIxs)) {
            foreach ($odIxs as $odIx) {
                if ($status == ORDER_STATUS_CANCEL_COMPLETE) {
                    $this->qb
                        ->set('cc_date', date('Y-m-d H:i:s'))
                        ->set('fa_date', date('Y-m-d H:i:s'))
                        ->set('refund_status', ORDER_STATUS_REFUND_APPLY);
                }

                $this->qb
                    ->set('status', $status)
                    ->set('ca_date', date('Y-m-d H:i:s'))
                    ->set('update_date', date('Y-m-d H:i:s'))
                    ->set('claim_group', $claimGroup)
                    ->update(TBL_SHOP_ORDER_DETAIL)
                    ->where('od_ix', $odIx)
                    ->exec();

                if ($status == ORDER_STATUS_CANCEL_COMPLETE) {
                    //판매진행중 재고 업데이트
                    $this->updateSellIngCnt($oid, $odIx);

                    //쿠폰 돌려주기
                    $this->returnUsedCoupon(ORDER_STATUS_CANCEL_COMPLETE, $oid, $odIx);
                }

                //주문 상태 변경 기록
                $this->insertOrderHistory($odIx, $status, $claimData['reasonDetail'], $oid, $claimData['reason']);
            }

            //클레임 배송지 정보 저장
            $this->insertClaimDelivery($oid, $claimGroup, $companyId, $claimDeliveryPrice);
        }
    }

    /**
     * 클레임 처리 - 반품
     * @param $status
     * @param $claimGroup
     * @param $oid
     * @param $odIxs
     * @param $claimData
     * @param $companyId
     * @param $claimDeliveryPrice
     */
    protected function doClaimReturn($status, $claimGroup, $oid, $odIxs, $claimData, $companyId, $claimDeliveryPrice)
    {
        if (!empty($odIxs)) {
            //반품 배송정보
            if ($claimData['send_type'] == 1) { //직접 발송
                $orderType = 3;
                $claimData['send_yn'] = 'Y';

                //업체 배송지 정보 가지고 오기
                /* @var $deliveryPolicyModel \CustomScm\Model\Company\DeliveryPolicy */
                $deliveryPolicyModel = $this->import('model.scm.company.deliveryPolicy');
                $deliveryPolicyModel->setManageCompanyId($companyId);
                $returnAddress = $deliveryPolicyModel->getReturnAddress();
                $claimData['cname'] = $returnAddress['addr_name'];
                $claimData['cmobile'] = $returnAddress['addr_phone'];
                $claimData['czip'] = $returnAddress['zip_code'];
                $claimData['caddr1'] = $returnAddress['address_1'];
                $claimData['caddr2'] = $returnAddress['address_2'];
                $claimData['cmsg'] = '';
            } else { //지정택배 방문요청
                $orderType = 4;
                $claimData['send_yn'] = 'N';
                $claimData['quick'] = '';
                $claimData['invoice_no'] = '';
            }

            /* @var $orderModel \CustomScm\Model\Order\Order */
            $orderModel = $this->import('model.scm.order.order');

            foreach ($odIxs as $odIx) {
                $oderDetailData = $orderModel->getOrderDetailNpay($odIx);

                if (!empty($oderDetailData['co_od_ix'])) {
                    /* @var $naverPayModel \CustomScm\Model\Npay */
                    $naverPayModel = $this->import('model.scm.npay');
                    /* @var $naverPayOrderModel \CustomScm\Model\Npay\NaverPayOrder */
                    $naverPayOrderModel = $this->import('model.scm.npay.naverPayOrder');

                    if ($status == ORDER_STATUS_RETURN_APPLY) {
                        $npayData['reason_code'] = $claimData['reason'];
                        if ($claimData['send_type'] == 1) {                 //직접반송
                            $npayData['collect_delivery_method_code'] = 'RETURN_INDIVIDUAL';
                            $npayData['collect_delivery_company_code'] = $naverPayOrderModel->getDeliveryCompanyCode($claimData['quick']);
                            $npayData['collect_tracking_number'] = $claimData['invoice_no'];
                        } elseif ($claimData['send_type'] == 2) {
                            $npayData['collect_delivery_method_code'] = 'RETURN_DESIGNATED';
                        }

                        $npayResponse = $naverPayModel->changeOrderStatusNpay($oderDetailData['co_od_ix'], 'RequestReturn', $npayData);

                        if ($npayResponse !== TRUE) {
                            return $this->changeReturnStructure('changeOrderStatusFail', $npayResponse);
                        }
                    }
                }

                //반품 배송정보 입력
                $returnDeliveryIx = $orderModel->insertOrderDeliveryInfo($oid, $orderType, [
                    'rname' => $claimData['cname'],
                    'od_ix' => $odIx,
                    'rmobile' => $claimData['cmobile'],
                    'zip' => $claimData['czip'],
                    'addr1' => $claimData['caddr1'],
                    'addr2' => $claimData['caddr2'],
                    'msg' => $claimData['cmsg'],
                    'quick' => $claimData['quick'],
                    'invoice_no' => $claimData['invoice_no'],
                    'send_yn' => $claimData['send_yn'],
                    'send_type' => $claimData['send_type'],
                    'delivery_pay_type' => $claimData['delivery_pay_type']
                ]);

                $this->qb
                    ->set('status', $status)
                    ->set('ra_date', date('Y-m-d H:i:s'))
                    ->set('update_date', date('Y-m-d H:i:s'))
                    ->set('claim_group', $claimGroup)
                    ->set('odd_ix', $returnDeliveryIx)
                    ->update(TBL_SHOP_ORDER_DETAIL)
                    ->where('od_ix', $odIx)
                    ->exec();

                //주문 상태 변경 기록
                $this->insertOrderHistory($odIx, $status, $claimData['reasonDetail'], $oid, $claimData['reason']);
            }

            //클레임 배송지 정보 저장
            $this->insertClaimDelivery($oid, $claimGroup, $companyId, $claimDeliveryPrice);
        }
    }

    /**
     * 클레임 처리 - 교환
     * @param $status
     * @param $claimGroup
     * @param $oid
     * @param $odIxs
     * @param $claimData
     * @param $companyId
     * @param $claimDeliveryPrice
     */
    protected function doClaimExchange($status, $claimGroup, $oid, $odIxs, $claimData, $companyId, $claimDeliveryPrice)
    {
        if (!empty($odIxs)) {
            //반품 배송정보
            if ($claimData['send_type'] == 1) { //직접 발송
                $orderType = 3;
                $claimData['send_yn'] = 'Y';

                //업체 배송지 정보 가지고 오기
                /* @var $deliveryPolicyModel \CustomScm\Model\Company\DeliveryPolicy */
                $deliveryPolicyModel = $this->import('model.scm.company.deliveryPolicy');
                $deliveryPolicyModel->setManageCompanyId($companyId);
                $returnAddress = $deliveryPolicyModel->getReturnAddress();
                $claimData['cname'] = $returnAddress['addr_name'];
                $claimData['cmobile'] = $returnAddress['addr_phone'];
                $claimData['czip'] = $returnAddress['zip_code'];
                $claimData['caddr1'] = $returnAddress['address_1'];
                $claimData['caddr2'] = $returnAddress['address_2'];
                $claimData['cmsg'] = '';
            } else { //지정택배 방문요청
                $orderType = 4;
                $claimData['send_yn'] = 'N';
                $claimData['quick'] = '';
                $claimData['invoice_no'] = '';
            }

            /* @var $orderModel \CustomScm\Model\Order\Order */
            $orderModel = $this->import('model.scm.order.order');


            foreach ($odIxs as $odIx) {
                // 주문 상세 정보 order_from 가져오기
                $mallOrderDetail = $orderModel->getOrderFromDetail($odIx);

                // 제휴사 이미 교완요청 상태시, orderSeperate 안 부르기
                if ($mallOrderDetail['order_from'] == 'self' || $mallOrderDetail['status'] != 'EA') {
                    $newOdIx = $orderModel->orderSeparate($odIx, 0, true);
                }

                if (isset($newOdIx)) {
                    //반품 배송정보 입력
                    $returnDeliveryIx = $orderModel->insertOrderDeliveryInfo($oid, $orderType, [
                        'od_ix' => $odIx,
                        'rname' => $claimData['cname'],
                        'rmobile' => $claimData['cmobile'],
                        'zip' => $claimData['czip'],
                        'addr1' => $claimData['caddr1'],
                        'addr2' => $claimData['caddr2'],
                        'msg' => $claimData['cmsg'],
                        'quick' => $claimData['quick'],
                        'invoice_no' => $claimData['invoice_no'],
                        'send_yn' => $claimData['send_yn'],
                        'send_type' => $claimData['send_type'],
                        'delivery_pay_type' => $claimData['delivery_pay_type']
                    ]);

                    //재배송 배송정보 입력
                    $reDeliveryIx = $orderModel->insertOrderDeliveryInfo($oid, 2, [
                        'od_ix' => $newOdIx,
                        'rname' => $claimData['rname'],
                        'rmobile' => $claimData['rmobile'],
                        'zip' => $claimData['rzip'],
                        'addr1' => $claimData['raddr1'],
                        'addr2' => $claimData['raddr2'],
                        'msg' => $claimData['rmsg']
                    ]);

                    //신규 복사(생성)된 주문 정보 초기화.
                    $resetDatas = [
                        'refund_status ' => '',
                        'quick ' => '',
                        'invoice_no ' => '',
                        'accounts_status ' => '',
                        'ac_ix ' => '',
                        'refund_ac_ix ' => '',
                        'dr_date' => null,
                        'di_date' => null,
                        'ac_date ' => null,
                        'dc_date ' => null,
                        'bf_date' => null,
                        'ea_date ' => null,
                        'ra_date ' => null,
                        'fa_date ' => null,
                        'fc_date ' => null,
                        'due_date ' => ''
                    ];

                    $this->qb->where('od_ix', $newOdIx)
                        ->update(TBL_SHOP_ORDER_DETAIL, $resetDatas)
                        ->exec();

                    // 주문 상태 변경
                    $this->qb//반품 상품 주문
                    ->set('status', $status)
                        ->set('ea_date', date('Y-m-d H:i:s'))
                        ->set('dc_date', "IFNULL(dc_date,'" . fb_now() . "')", false)
                        ->set('bf_date', "IFNULL(bf_date,'" . fb_now() . "')", false)
                        ->set('update_date', date('Y-m-d H:i:s'))
                        ->set('claim_group', $claimGroup)
                        ->set('odd_ix', $returnDeliveryIx)
                        ->update(TBL_SHOP_ORDER_DETAIL)
                        ->where('od_ix', $odIx)
                        ->exec();

                    $this->qb//재배송 상품 주문
                    ->set('status', ORDER_STATUS_EXCHANGE_READY)
                        ->set('update_date', date('Y-m-d H:i:s'))
                        ->set('claim_delivery_od_ix', $odIx)
                        ->set('claim_group', $claimGroup)
                        ->set('odd_ix', $reDeliveryIx)
                        ->update(TBL_SHOP_ORDER_DETAIL)
                        ->where('od_ix', $newOdIx)
                        ->exec();

                    // 제휴사 경우, od_ix 교환재배송예정 올바른 값으로 변경  
                    if ($mallOrderDetail['order_from'] != 'self') {
                        $this->qb
                            ->set('co_od_ix', $claimData['exchange_od_ix'])
                            ->update(TBL_SHOP_ORDER_DETAIL)
                            ->where('od_ix', $newOdIx)
                            ->exec();
                    }

                    //주문 상태 변경 기록
                    $this->insertOrderHistory($odIx, $status, $claimData['reasonDetail'], $oid, $claimData['reason']);
                    $this->insertOrderHistory($newOdIx, ORDER_STATUS_EXCHANGE_READY, "주문 상세번호 " . $odIx . " 교환상품", $oid);
                }
            }

            if (isset($newOdIx)) {
                //클레임 배송지 정보 저장
                $this->insertClaimDelivery($oid, $claimGroup, $companyId, $claimDeliveryPrice);
            }
        }
    }

    /**
     * 클레임 그룹 출력
     * @param string $oid
     * @return int
     */
    protected function getClaimGroup($oid)
    {
        $sqlDatas = $this->qb
            ->select('( max(claim_group) +1 ) as claim_group')
            ->from(TBL_SHOP_ORDER_DETAIL)
            ->where('oid', $oid)
            ->exec()
            ->getRowArray();
        return $sqlDatas["claim_group"];
    }

    /**
     * 쿠폰 돌려주기
     * @staticvar type $couponModel
     * @param type $status
     * @param type $oid
     * @param type $odIx
     */
    protected function returnUsedCoupon($status, $oid, $odIx = '')
    {
        static $couponModel = false;

        //쿠폰 돌려주기. 전체 취소 혹은 관련 쿠폰으로 사용된 건이 전부 취소되었을 경우 사용함.
        if ($odIx) {
            $this->qb->where('dc_ix in (select dc_ix from shop_order_detail_discount where od_ix="' . $odIx . '")');
        }

        $rows = $this->qb
            ->select('odd.dc_ix')
            ->selectSum("CASE WHEN od.status IN ('" . implode("','", [
                    ORDER_STATUS_INCOM_COMPLETE,
                    ORDER_STATUS_DELIVERY_READY,
                    ORDER_STATUS_DELIVERY_ING,
                    ORDER_STATUS_DELIVERY_COMPLETE,
                    ORDER_STATUS_BUY_FINALIZED
                ]) . "') THEN 1 ELSE 0 END", 'count')
            ->from(TBL_SHOP_ORDER_DETAIL . ' as od')
            ->join(TBL_SHOP_ORDER_DETAIL_DISCOUNT . ' as odd', 'od.od_ix=odd.od_ix', 'inner')
            ->where('od.oid', $oid)
            ->whereIn('odd.dc_type', ['CP'])
            ->groupBy('odd.dc_ix')
            ->exec()->getResultArray();

        $registIx = [];
        foreach ($rows as $row) {
            if ($row['count'] == 0) {
                array_push($registIx, $row['dc_ix']);
            }
        }

        if (!empty($registIx)) {
            if ($couponModel === false) {
                /* @var $couponModel \CustomScm\Model\Marketing\Coupon */
                $couponModel = $this->import('model.scm.marketing.coupon');
            }
            $couponModel->returnUsedCoupon($status, $registIx);
        }
    }

    /**
     * insert 클레임 delivery 정보
     * @param type $oid
     * @param type $claimGroup
     * @param type $companyId
     * @param type $claimDeliveryPrice
     */
    protected function insertClaimDelivery($oid, $claimGroup, $companyId, $claimDeliveryPrice)
    {
        $this->qb->insert(TBL_SHOP_ORDER_CLAIM_DELIVERY, [//클레임 배송비 DB 입력. 해당 값 없을 경우 환불완료로 상태변경 불가.
            'oid' => $oid,
            'claim_group' => $claimGroup,
            'company_id' => $companyId,
            'delivery_price' => $claimDeliveryPrice,
            'regdate' => date('Y-m-d H:i:s')
        ])->exec();
    }

    /**
     * 클레임 금액 계산
     * @param type $status
     * @param type $oid
     * @param type $productList
     * @param type $claimData
     * @return type
     */
    public function claimCalculate($status, $oid, $productList, $claimData)
    {
        //초기화
        $refundProductPrice = 0; // 환불 상품 금액
        $refundDeliveryPrice = 0; // 환불 배송비
        $addDeliveryPrice = 0; // 추가 결제 배송비

        $deliveryPriceInfo = $this->getDeliveryPriceInfo($productList, $status, $refundProductPrice);
        $deliveryPriceInfo = $this->chkAllRefund($oid, $deliveryPriceInfo);

        foreach ($deliveryPriceInfo as $odeIx => $info) {
            //취소
            if (in_array($status, [ORDER_STATUS_CANCEL_APPLY, ORDER_STATUS_CANCEL_COMPLETE])) {
//                $faultType = \ForbizConfig::getOrderSelectStatus('A', ORDER_STATUS_DELIVERY_READY, ORDER_STATUS_CANCEL_APPLY, $claimData['reason'], 'type');
                if ($info['allCancelBool'] === false) { // 부분취소일 경우 계산
                    if ($this->isFirstCancel($oid)) {
                        //남은 주문으로 배송비 재계산
                        $newDeliveryPriceInfo = $this->getDeliveryInfo($info['dt_ix'], ['price' => $info['remainProductPrice'], 'qty' => $info['remainPcnt']]);
                        //실제 결제 보다 남은 주문 금액으로 배송비 재계산 금액이 크면 추가 배송비로 처리
                        if ($info['dcprice'] < $newDeliveryPriceInfo['sumPrice']) {
                            $addDeliveryPrice += $newDeliveryPriceInfo['sumPrice'];
                        }
                    } else {
                        $addDeliveryPrice = 0;
                    }
                } else {
                    // 지불한 클레임 추가 배송비 환불
                    $claimDeliveryPrice = $this->getClaimDeliveryAllPrice($oid, $odeIx);
                    //판매자 귀책 혹은 전체취소일 경우에는 배송비 전체 환불
                    $refundDeliveryPrice += ($info['dcprice'] + $claimDeliveryPrice);
                }
            } else {
                if (in_array($status, [ORDER_STATUS_EXCHANGE_APPLY, ORDER_STATUS_EXCHANGE_ING])) {
                    $faultType = \ForbizConfig::getOrderSelectStatus('A', ORDER_STATUS_DELIVERY_COMPLETE, ORDER_STATUS_EXCHANGE_APPLY, $claimData['reason'], 'type');
                } else {
                    $faultType = \ForbizConfig::getOrderSelectStatus('A', ORDER_STATUS_DELIVERY_COMPLETE, ORDER_STATUS_RETURN_APPLY, $claimData['reason'], 'type');
                }
                if ($faultType == 'B') { //구매자 귀책
                    $template = $this->qb
                        ->select('return_shipping_cnt')
                        ->select('return_shipping_price')
                        ->select('exchange_shipping_price')
                        ->from(TBL_SHOP_DELIVERY_TEMPLATE)
                        ->where('dt_ix', $info['dt_ix'])
                        ->exec()
                        ->getRowArray();

                    if (in_array($status, [ORDER_STATUS_RETURN_APPLY, ORDER_STATUS_RETURN_ING])) { //반품
                        $returnPrice = 0;
                        //1.배송된 배송비
                        if ($info['dcprice'] == 0) { //무료배송시에만 왕복, 편도 선택이 적용되며 무료배송이 아닐 경우 편도만 가능                            
                            if ($info['allCancelBool']) { //전체 클레임
                                // 이전 취소한 주문이 있는가?
                                if ($this->isFirstCancel($oid)) {
                                    //무료 배송일때 전체 반품이고 왕복 설정이면 +
                                    if ($template['return_shipping_cnt'] == 2) {//왕복 1:편도 2:왕복
                                        $returnPrice += $template['return_shipping_price'];
                                    }
                                }
                            }
                        }
                        //2.반품 배송비
                        if ($claimData['send_type'] == 1) {
                            // 직접 발송
                            if ($claimData['delivery_pay_type'] == 2) {
                                // 착불
                                $returnPrice += $template['return_shipping_price'];
                            }
                        } else {
                            // 지정택배
                            $returnPrice += $template['return_shipping_price'];
                        }
                        $addDeliveryPrice += $returnPrice;
                    } else {
                        if (in_array($status, [ORDER_STATUS_EXCHANGE_APPLY, ORDER_STATUS_EXCHANGE_ING])) { //교환
                            if ($claimData['send_type'] == 1) {
                                // 직접발송
                                if ($claimData['delivery_pay_type'] == 1) { // 선불
                                    $exchangePrice = $template['exchange_shipping_price']; // 편도 배송비 설정
                                } else {
                                    $exchangePrice = $template['exchange_shipping_price'] * 2; //교환 배송비 편도*2
                                }
                            } else {
                                // 지정택배
                                $exchangePrice = $template['exchange_shipping_price'] * 2; //교환 배송비 편도*2
                            }
                            $addDeliveryPrice += $exchangePrice; //교환시 추가 청구되는 배송비
                        }
                    }
                } else { //판매자 귀책
                    if (in_array($status, [ORDER_STATUS_RETURN_APPLY, ORDER_STATUS_RETURN_ING])) { //반품
                        if ($info['allCancelBool']) {
                            // 이전 취소한 주문이 있는가?
                            if ($this->isFirstCancel($oid)) {
                                // 이전 취소한 주문이 없을 경우
                                $refundDeliveryPrice += $info['dcprice'];
                            } else {
                                // 지불한 클레임 추가 배송비 환불
                                $claimDeliveryPrice = $this->getClaimDeliveryAllPrice($oid, $odeIx);
                                // 전체취소시 배송되지 않았으므로 배송비 전체 환불
                                $refundDeliveryPrice += ($info['dcprice'] + $claimDeliveryPrice);
                            }
                        } else {
                            // 지불한 클레임 추가 배송비 환불
                            $template = $this->qb
                                ->select('sum(delivery_price) * -1 AS delivery_price')
                                ->from(TBL_SHOP_ORDER_CLAIM_DELIVERY)
                                ->where('oid', $oid)
                                ->whereIn('claim_group',
                                    $this->qb->startSubQuery()
                                        ->select('claim_group')
                                        ->from(TBL_SHOP_ORDER_DETAIL)
                                        ->where('ode_ix', $odeIx)
                                        ->endSubQuery()
                                )
                                ->where('delivery_price < 0')
                                ->exec()
                                ->getRowArray();

                            $claimDeliveryPrice = $template['delivery_price'];
                            //판매자 귀책 혹은 전체취소일 경우에는 배송비 전체 환불
                            $refundDeliveryPrice += ($info['dcprice'] + $claimDeliveryPrice);
                        }
                    }
                }
            }
        }

        $claimDeliveryPrice = $refundDeliveryPrice - $addDeliveryPrice;
        $refundTotalPrice = $refundProductPrice + $claimDeliveryPrice;

        return [
            'refundProductPrice' => $refundProductPrice, // 환불 상품 금액
            'refundDeliveryPrice' => $refundDeliveryPrice, // 환불 배송비
            'addDeliveryPrice' => $addDeliveryPrice, // 추가 결제 배송비
            'claimDeliveryPrice' => $claimDeliveryPrice, // 클레임 배송비 (환불 배송비 - 추가 결제 배송비) : + 환불, -추가결제금액
            'refundTotalPrice' => $refundTotalPrice //총 환불 배송비
        ];
    }

    /**
     * 첫번째 취소 여부 확인
     * @param $oid
     * @return bool
     */
    public function isFirstCancel($oid)
    {
        $row = $this->qb
            ->select('count(*) AS cnt')
            ->from(TBL_SHOP_ORDER_DETAIL)
            ->where('oid', $oid)
            ->where('status', ORDER_STATUS_CANCEL_COMPLETE)
            ->exec()
            ->getRowArray();

        $cancelCnt = $row['cnt'] ?? 0;

        if ($cancelCnt == 0) {
            return true;
        }

        $row = $this->qb
            ->select('SUM(delivery_price) AS delivery_price')
            ->from(TBL_SHOP_ORDER_CLAIM_DELIVERY)
            ->where('oid', $oid)
            ->exec()
            ->getRowArray();

        return ($row['delivery_price'] == 0);
    }

    /**
     * 배송 정보 조회
     * @param $productList
     * @return array
     * @throws \Exception
     */
    public function getDeliveryPriceInfo($productList, $status, &$refundProductPrice)
    {
        //아래 로직에서 사용하기 위해 $productList 가공
        $productInfo = [];
        foreach ($productList as $product) {
            $productInfo[$product['od_ix']] = [
                'applyPcnt' => $product['applyPcnt'],
                'pcnt' => $product['pcnt']
            ];
        }

        //        //배송 정책별 데이터 만들기
        $rows = $this->qb
            ->select('od.od_ix')
            ->select('od.pt_dcprice')
            ->select('ode.ode_ix')
            ->select('ode.dt_ix')
            ->select('ode.delivery_dcprice')
            ->from(TBL_SHOP_ORDER_DETAIL . ' AS od')
            ->join(TBL_SHOP_ORDER_DELIVERY . ' AS ode', 'ode.ode_ix = od.ode_ix')
            ->whereIn('od.od_ix', array_column($productList, 'od_ix'))
            ->exec()
            ->getResultArray();

        $deliveryPriceInfo = [];

        if (!empty($rows)) {
            foreach ($rows as $row) {
                $product = $productInfo[$row['od_ix']];

                if ($product['applyPcnt'] == $product['pcnt']) {
                    $productPrice = $row['pt_dcprice'];
                } else {
                    $productPrice = round($row['pt_dcprice'] / $product['pcnt'] * $product['applyPcnt']);
                }
                //교환은 상품금액 X
                if (!in_array($status, [ORDER_STATUS_EXCHANGE_APPLY, ORDER_STATUS_EXCHANGE_ING])) {
                    $refundProductPrice += $productPrice;
                }
                if (!isset($deliveryPriceInfo[$row['ode_ix']])) {
                    $deliveryPriceInfo[$row['ode_ix']] = [
                        'dt_ix' => $row['dt_ix'],
                        'dcprice' => $row['delivery_dcprice'],
                        'applyPcnt' => $product['applyPcnt'],
                        'productPrice' => $productPrice,
                        'allCancelBool' => true
                    ];
                } else {
                    $deliveryPriceInfo[$row['ode_ix']]['applyPcnt'] += $product['applyPcnt'];
                    $deliveryPriceInfo[$row['ode_ix']]['productPrice'] += $productPrice;
                }
            }
        }

        return $deliveryPriceInfo;
    }

    /**
     * 전체 취소 여부 체크
     * @param $oid
     * @param $deliveryPriceInfo
     * @return mixed
     * @throws \Exception
     */
    public function chkAllRefund($oid, $deliveryPriceInfo)
    {
        //전체 취소 여부 체크
        $rows = $this->qb
            ->select('ode_ix')
            ->selectSum('pcnt')
            ->selectSum('pt_dcprice')
            ->from(TBL_SHOP_ORDER_DETAIL)
            ->where('oid', $oid)
            ->whereIn('ode_ix', array_keys($deliveryPriceInfo))
            ->whereIn('status', [
                    ORDER_STATUS_INCOM_COMPLETE,
                    ORDER_STATUS_INCOM_READY,
                    ORDER_STATUS_DELIVERY_READY,
                    ORDER_STATUS_DELIVERY_DELAY,
                    ORDER_STATUS_DELIVERY_ING,
                    ORDER_STATUS_DELIVERY_COMPLETE,
                    ORDER_STATUS_BUY_FINALIZED
                ]
            )
            ->groupBy('ode_ix')
            ->exec()
            ->getResultArray();

        if (!empty($rows)) {
            foreach ($rows as $row) {
                //남은 상품 수량 및 금액 계산
                $deliveryPriceInfo[$row['ode_ix']]['remainPcnt'] = $row['pcnt'] - $deliveryPriceInfo[$row['ode_ix']]['applyPcnt'];
                $deliveryPriceInfo[$row['ode_ix']]['remainProductPrice'] = $row['pt_dcprice'] - $deliveryPriceInfo[$row['ode_ix']]['productPrice'];

                if ($deliveryPriceInfo[$row['ode_ix']]['remainPcnt'] > 0) {
                    $deliveryPriceInfo[$row['ode_ix']]['allCancelBool'] = false;
                }
            }
        }

        return $deliveryPriceInfo;
    }

    /**
     * // 지불한 클레임 배송비 조회
     * @return void
     * @throws \Exception
     */
    public function getClaimDeliveryAllPrice($oid, $odeIx)
    {
        // 지불한 클레임 추가 배송비 환불
        $row = $this->qb
            ->select('sum(delivery_price) * -1 AS delivery_price')
            ->from(TBL_SHOP_ORDER_CLAIM_DELIVERY)
            ->where('oid', $oid)
            ->whereIn('claim_group',
                $this->qb->startSubQuery()
                    ->select('claim_group')
                    ->from(TBL_SHOP_ORDER_DETAIL)
                    ->where('oid', $oid)
//                    ->where('ode_ix', $odeIx)
                    ->endSubQuery()
                , false)
            ->where('delivery_price < 0')
            ->exec()
            ->getRowArray();

        return ($row['delivery_price'] ?? 0);
    }

    /**
     * 배송비 정보
     * @param int $dtIx
     * @param array $productData
     * @param string $zipCode
     * @return array
     */
    public function getDeliveryInfo($dtIx, $productData = [], $zipCode = '')
    {
        if (!is_array($productData)) {
            $productData = [];
        }
        $productPrice = ($productData['price'] ?? 0);
        $productQty = ($productData['qty'] ?? 1);

        $deliveryPrice = 0;
        $addDeliveryPrice = 0;
        $conditionText = "";
        $regionText = "";

        $template = $this->qb
            ->select('delivery_policy')
            ->select('delivery_price')
            ->select('delivery_cnt_price')
            ->select('free_shipping_term')
            ->select('delivery_unit_price')
            ->select('delivery_region_use')
            ->select('delivery_region_area')
            ->select('delivery_jeju_price')
            ->select('delivery_except_price')
            ->select('delivery_region_use')
            ->select('company_id')
            ->select('delivery_policy_text_m')
            ->select('delivery_policy_text')
            ->select('tekbae_ix')
            ->from(TBL_SHOP_DELIVERY_TEMPLATE)
            ->where('dt_ix', $dtIx)
            ->exec()->getRowArray();

        if (empty($template)) {
            return [
                'sumPrice' => 0,
                'price' => 0,
                'addPrice' => 0,
                'text' => false,
                'regionText' => false,
                'deliveryPolicy' => false,
                'deliveryRegionUse' => false,
                'deliveryClaimText' => false,
                'deliveryComCode' => false,
                'deliveryComName' => false,
                'company_id' => false
            ];
        }

        switch ($template['delivery_policy']) {
            //무료배송
            case '1':
                $conditionText = "무료배송";
                break;
            //고정 배송비
            case '2':
                $deliveryPrice = $template['delivery_price'];
                $conditionText = "배송비 " . number_format($deliveryPrice) . "원";
                break;
            //결제금액당 배송비
            case '3':
                //수량별 할인/할증적용(상품단위)
            case '4':
                $this->qb
                    ->select('delivery_price')
                    ->select('delivery_basic_terms')
                    ->from(TBL_SHOP_DELIVERY_TERMS)
                    ->where('dt_ix', $dtIx)
                    ->where('delivery_policy_type', $template['delivery_policy']);

                $basicDeliveryPrice = 0;
                $conditionDeliveryPrice = false;
                switch ($template['delivery_policy']) {
                    //결제금액당 배송비
                    case '3':
                        $row = $this->qb
                            ->exec()->getRowArray();
                        if (!empty($row)) {
                            if ($row['delivery_basic_terms'] > $productPrice && $conditionDeliveryPrice === false) {
                                $conditionDeliveryPrice = $row['delivery_price'];
                            }
                            $conditionText = number_format($row['delivery_basic_terms']) . "원 이상 구매 시 무료배송";
                        }
                        break;
                    //수량별 할인/할증적용(상품단위)
                    case '4':
                        $basicDeliveryPrice = $template['delivery_cnt_price'];

                        $rows = $this->qb
                            ->orderBy('delivery_basic_terms', 'desc')
                            ->exec()->getResultArray();

                        if (!empty($rows)) {
                            $conditionTextList = [];
                            foreach ($rows as $key => $row) {
                                if ($row['delivery_basic_terms'] <= $productQty && $conditionDeliveryPrice === false) {
                                    $conditionDeliveryPrice = $row['delivery_price'];
                                }
                                $conditionTextList[] = number_format($row['delivery_basic_terms']) . "개 이상 " . number_format($row['delivery_price']) . "원";
                            }
                            $conditionText = "기본 배송비 " . number_format($basicDeliveryPrice) . "원 / " . implode(", ",
                                    $conditionTextList);
                        }
                        break;
                }
                $deliveryPrice = ($conditionDeliveryPrice !== false ? $conditionDeliveryPrice : $basicDeliveryPrice);
                break;
            //상품 1개단위 배송비
            case '6':
                $deliveryPrice = $template['delivery_unit_price'] * $productQty;
                $conditionText = "1개당 배송비 " . number_format($template['delivery_unit_price']) . "원";
                break;
            default :
                break;
        }


        //추가 배송비
        if ($template['delivery_region_use'] == '1') {

            if ($template['delivery_region_area'] == '2') {
                $regionText = "제주 및 도서산간 " . number_format($template['delivery_jeju_price']) . "원 추가";
            } else {
                if ($template['delivery_region_area'] == '3') {
                    $regionText = "제주 " . number_format($template['delivery_jeju_price']) . "원 / 제주 외 도서산간 " . number_format($template['delivery_except_price']) . "원 추가";
                }
            }

            if (!empty($zipCode)) {
                $region = $this->qb
                    ->select('jeju_yn')
                    ->select('island_yn')
                    ->from(TBL_SHOP_DELIVERY_AREA)
                    ->where('zip', $zipCode)
                    ->exec()->getRowArray();

                if (!empty($region)) {
                    //2권역
                    if ($template['delivery_region_area'] == '2') {
                        $addDeliveryPrice = (!empty($template['delivery_jeju_price']) ? $template['delivery_jeju_price'] : 0);
                    } //3권역
                    else {
                        if ($template['delivery_region_area'] == '3') {
                            if ($region['jeju_yn'] == 'Y') {
                                $addDeliveryPrice = (!empty($template['delivery_jeju_price']) ? $template['delivery_jeju_price'] : 0);
                            } else {
                                $addDeliveryPrice = (!empty($template['delivery_except_price']) ? $template['delivery_except_price'] : 0);
                            }
                        }
                    }
                }
            }
        }

        //교환/반품안내
        if (is_mobile()) {
            $deliveryClaimText = $template['delivery_policy_text_m'];
        } else {
            $deliveryClaimText = $template['delivery_policy_text'];
        }

        //택배업체명
        $deliveryCompany = $this->qb
            ->select('c.code_name')
            ->from(TBL_SHOP_DELIVERY_TEMPLATE . ' as t')
            ->join(TBL_SHOP_CODE . ' as c', 't.tekbae_ix=c.code_ix', 'inner')
            ->where('t.dt_ix', $dtIx)
            ->where('c.code_gubun', '02')
            ->exec()->getRowArray();

        return [
            'sumPrice' => ($deliveryPrice + $addDeliveryPrice),
            'price' => $deliveryPrice,
            'addPrice' => $addDeliveryPrice,
            'text' => $conditionText,
            'regionText' => $regionText,
            'deliveryPolicy' => $template['delivery_policy'],
            'deliveryRegionUse' => $template['delivery_region_use'],
            'deliveryClaimText' => $deliveryClaimText,
            'deliveryComCode' => $template['tekbae_ix'],
            'deliveryComName' => ($deliveryCompany['code_name'] ?? ''),
            'company_id' => $template['company_id']
        ];
    }

    /**
     * NPay 주문 상태 변경 - 결제완료
     * @param $data
     */
    public function changedOrderNpay($data)
    {
        //update order detail
        $this->qbChangeStatusBaiscWhere()
            ->set('status', $data['status'])
            ->set('quick', $data['quick'])
            ->set('invoice_no', $data['invoice_no'])
            ->set('dr_date', $data['dr_date'])
            ->set('dc_date', $data['dc_date'])
            ->set('di_date', $data['di_date'])
            ->set('bf_date', $data['bf_date'])
            ->set('update_date', fb_now())
            ->update(TBL_SHOP_ORDER_DETAIL)
            ->whereIn('od_ix', $data['od_ix'])
            ->exec();
    }

    /**
     * NPay 클레임 처리 - 취소
     * @param $status
     * @param $oid
     * @param $odIx
     * @param $claimData
     * @param $companyId
     * @param $claimDeliveryPrice
     * @param $insUp
     * @return int
     * @throws \Exception
     */
    public function changedOrderNpayCancel($status, $oid, $odIx, $claimData, $companyId, $claimDeliveryPrice, $insUp)
    {
        if ($insUp == 'update') {
            $claimGroup = $this->getClaimGroup($oid);
            if (!empty($odIx)) {
                if ($status == ORDER_STATUS_CANCEL_COMPLETE) {
                    $this->qb
                        ->set('cc_date', $claimData['cc_date'])
                        ->set('fa_date', $claimData['cc_date'])
                        ->set('refund_status', ORDER_STATUS_REFUND_APPLY);
                }

                $this->qb
                    ->set('status', $status)
                    ->set('ca_date', $claimData['ca_date'])
                    ->set('update_date', date('Y-m-d H:i:s'))
                    ->set('claim_group', $claimGroup)
                    ->update(TBL_SHOP_ORDER_DETAIL)
                    ->where('od_ix', $odIx)
                    ->exec();
            }
        } elseif ($insUp = 'insert') {
            $claimGroup = 1;
        }
        $claimData = $this->qb
            ->from(TBL_SHOP_ORDER_CLAIM_DELIVERY)
            ->where('oid', $oid)
            ->exec()
            ->getRow();

        if ($this->qb->total > 0) {
            //클레임 배송지 정보 저장
            $this->insertClaimDelivery($oid, $claimGroup, $companyId, $claimDeliveryPrice);
        }
    }

    /**
     * Npay 클레임 처리 - 반품
     * @param $returnData
     * @param $companyId
     * @param $insUp
     * @return bool|\NunaResult
     * @throws \Exception
     */
    public function changedOrderNpayReturn($returnData, $companyId, $insUp)
    {
        //반품 배송정보
        if ($returnData['send_type'] == 1) { //직접 발송
            $orderType = 3;
            $returnData['send_yn'] = 'Y';

            //업체 배송지 정보 가지고 오기
            /* @var $deliveryPolicyModel \CustomScm\Model\Company\DeliveryPolicy */
            $deliveryPolicyModel = $this->import('model.scm.company.deliveryPolicy');
            $deliveryPolicyModel->setManageCompanyId($companyId);
            $returnAddress = $deliveryPolicyModel->getReturnAddress();
            $returnData['cname'] = $returnAddress['addr_name'];
            $returnData['cmobile'] = $returnAddress['addr_phone'];
            $returnData['czip'] = $returnAddress['zip_code'];
            $returnData['caddr1'] = $returnAddress['address_1'];
            $returnData['caddr2'] = $returnAddress['address_2'];
            $returnData['cmsg'] = '';
        } else { //지정택배 방문요청
            $orderType = 4;
            $returnData['send_yn'] = 'N';
        }

        /* @var $orderModel \CustomScm\Model\Order\Order */
        $orderModel = $this->import('model.scm.order.order');

        //반품 배송정보 입력
        $returnDeliveryIx = $orderModel->insertOrderDeliveryInfo($returnData['oid'], $orderType, [
            'rname' => $returnData['cname'],
            'rmobile' => $returnData['cmobile'],
            'zip' => $returnData['czip'],
            'addr1' => $returnData['caddr1'],
            'addr2' => $returnData['caddr2'],
            'quick' => $returnData['quick'],
            'invoice_no' => $returnData['invoice_no'],
            'send_yn' => $returnData['send_yn'],
            'send_type' => $returnData['send_type'],
            'delivery_pay_type' => $returnData['delivery_pay_type']
        ]);

        if ($insUp == 'update') {
            $claimGroup = $this->getClaimGroup($returnData['oid']);

            $this->qb
                ->set('status', $returnData['status'])
                ->set('ra_date', $returnData['ra_date'])
                ->set('update_date', date('Y-m-d H:i:s'))
                ->set('claim_group', $claimGroup)
                ->set('odd_ix', $returnDeliveryIx)
                ->update(TBL_SHOP_ORDER_DETAIL)
                ->where('od_ix', $returnData['od_ix'])
                ->exec();
        } elseif ($insUp = 'insert') {
            $claimGroup = 1;
        }

        $this->insertClaimDelivery($returnData['oid'], $claimGroup, $companyId, $returnData['claim_delivery_price']);


        return $returnDeliveryIx;
    }
}
