<?php

namespace ForbizScm\Model\Util;

/**
 * 업로드 파일 관리 모델
 *
 * @author hoksi
 */
class Upload extends \ForbizModel
{
    protected $allowType = 'gif|jpg|jpeg|png|ico';
    protected $overWrite = true;

    public function __construct()
    {
        parent::__construct();
    }

    public function setAllowType($allowType)
    {
        $this->allowType = $allowType;

        return $this;
    }

    public function setOverWrite($overWrite)
    {
        $this->overWrite = $overWrite;

        return $this;
    }


    /**
     * CKEditor 이미지 업로더
     * @param string $fldName
     * @param string $subType
     * @return type
     */
    public function ckUpload($fldName, $subType)
    {
        if ($fldName) {
            $data = $this->uploadFile($fldName, CKEDITOR_UPLOAD_PATH . ($subType ? '/' . $subType : ''), false);

            if (isset($data['file_name'])) {
                $this->putUploadFileInfo('ckeditor', $subType, $data);

                return [
                    "uploaded" => 1,
                    "fileName" => $data['file_name'],
                    "url" => str_replace('//', '/', ('/'.str_replace(DOCUMENT_ROOT, '', $data['full_path']))),
                    "data" => $data
                ];
            } else {
                return [
                    "uploaded" => 0,
                    "error" => [
                        "message" => strip_tags($data['error'])
                    ]
                ];
            }
        } else {
            return [
                "uploaded" => 0,
                "error" => [
                    "message" => "upload data empty"
                ]
            ];
        }
    }

    /**
     * 상품 포토리뷰 업로드 이미지 등록
     * @param $filesUrl
     * @param $bbs_ix
     * @return array
     */
    public function uploadProductAfterFile($filesUrl, $bbs_ix)
    {
        $upData = [];
        if (!empty($filesUrl)) {
            foreach ($filesUrl as $upfile) {
                $upData[] = $this->uploadProductImageFile($upfile, $bbs_ix);
            }
        }
        return $upData;
    }

    /**
     * 후기 이미지 등록
     * @param $fldName
     * @param $bbs_ix
     * @return array|string
     */
    public function uploadProductImageFile($fldName, $bbs_ix)
    {
        static $resizeInfo = false;
        static $imgLib = false;

        if ($fldName) {
            $productDirPath = MALL_DATA_PATH . '/product_after/' . $bbs_ix;
            $fullPath = $this->dwnUrl($fldName, $productDirPath);

            if ($fullPath !== false && is_file($fullPath)) {

                $imgInfo = getimagesize($fullPath);
                $fsize = filesize($fullPath);
                $url = str_replace(DOCUMENT_ROOT, "", $fullPath);

                $data = [
                    'upload_type' => 'after',
                    'sub_type' => $bbs_ix,
                    'file_name' => basename($fullPath),
                    'file_path' => str_replace(DIRECTORY_SEPARATOR, '/', $productDirPath),
                    'file_size' => round($fsize / 1024, 2),
                    'org_file_size' => $fsize,
                    'file_type' => ($imgInfo['mime'] ?: ''),
                    'full_path' => str_replace(DIRECTORY_SEPARATOR, '/', $fullPath),
                    'image_height' => ($imgInfo[1] ?: 0),
                    'image_width' => ($imgInfo[0] ?: 0),
                    'image_type' => 'jpg',
                    'is_image' => '1',
                    'raw_name' => basename($fullPath),
                    'client_name' => basename($fullPath),
                    'file_ext' => 'gif',
                    'url_path' => str_replace(DIRECTORY_SEPARATOR, '/', $url),
                    'hash' => md5('addimg' . $bbs_ix . basename($fullPath)),
                    'updated_at' => fb_now()
                ];

                $this->putUploadFileInfo('after', $bbs_ix, $data);

                if ($resizeInfo === false) {
                    /* @var $resizeInfoModel \CustomScm\Model\Product\resizeInfo */
                    $resizeInfoModel = $this->import('model.scm.product.resizeInfo');
                    $resizeInfo = $resizeInfoModel->getList();
                }

                if ($imgLib === false) {
                    $imgLib = ci_load_library('image_lib');
                }

                $resizeConfig['image_library'] = 'gd2';
                $resizeConfig['create_thumb'] = false;
                $resizeConfig['maintain_ratio'] = TRUE;

                foreach ($resizeInfo as $resize) {
                    $resizeConfig['width'] = $resize['width'];
                    $resizeConfig['height'] = $resize['height'];
                    $resizeConfig['source_image'] = $fullPath;
                    $resizeConfig['new_image'] = $productDirPath . '/' . $resize['div'] . '_' . $data['file_name'];
                    $imgLib->initialize($resizeConfig);
                    $imgLib->resize();
                }

                return $data;
            } else {
                return [
                    "uploaded" => 0,
                    "error" => [
                        "message" => 'error'
                    ]
                ];
            }
        } else {
            return [
                "uploaded" => 0,
                "error" => [
                    "message" => "upload data empty"
                ]
            ];
        }
    }

    /**
     * url path download
     * @param $url
     * @param $dirPath
     * @return bool
     */
    public function dwnUrl($url, $dirPath)
    {
        $ch = curl_init();

        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_NOBODY, true);
        curl_exec($ch);

        $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);

        if ($http_code == 200) {
            $filename = basename($url);

            if (strpos($filename, '?')) {
                $orgFileName = explode('?', $filename);
                $filename = $orgFileName[0];
            }

            if (preg_match("/\.(gif|jpg|jpeg|png)$/i", $filename)) {
                @mkdir($dirPath, 0777, true);

                // 파일 다운로드
                $path = $dirPath . '/' . $filename;
                $fp = fopen($path, 'w+');
                $ch = curl_init();
                curl_setopt($ch, CURLOPT_URL, $url);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, false);
                curl_setopt($ch, CURLOPT_BINARYTRANSFER, true);
                curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
                curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 10);
                curl_setopt($ch, CURLOPT_FILE, $fp);
                curl_exec($ch);
                curl_close($ch);
                fclose($fp);
            }
        }

        return $path;
    }

    /**
     * admin 전용
     * @param type $fldName
     * @param type $subType
     * @return type
     */
    public function adminUpload($fldName, $subType, $path = null, $drFileName = null)
    {
        $fullPath = "";

        if ($fldName) {
            if ($path) {
                $fullPath = $path;
            } else {
                $fullPath = ADMIN_UPLOAD_PATH . ($subType ? '/' . $subType : '');
            }


            if (!empty($drFileName)) {
                $data = $this->uploadFile($fldName, $fullPath, $drFileName);
            } else {
                $data = $this->uploadFile($fldName, $fullPath, false);
            }


            if (isset($data['file_name'])) {
                $this->putUploadFileInfo('admin', $subType, $data);
                return [
                    "uploaded" => 1,
                    "fileName" => $data['file_name'],
                    "url" => str_replace(DOCUMENT_ROOT, '', $data['full_path']),
                    "data" => $data
                ];
            } else {
                return [
                    "uploaded" => 0,
                    "error" => [
                        "message" => strip_tags($data['error'])
                    ]
                ];
            }
        } else {
            return [
                "uploaded" => 0,
                "error" => [
                    "message" => "upload data empty"
                ]
            ];
        }
    }

    /**
     * MallConfig 전용
     * 지정된 주소와 파일명으로만 업로드
     * @param type $fldName
     * @param type $subType
     * @param type $path
     * @return type
     */
    public function adminUploadRealName($fldName, $subType, $path = null, $changeName = null)
    {
        $fullPath = "";
        if ($fldName) {
            if ($path) {
                $fullPath = $path;
            } else {
                $fullPath = ADMIN_UPLOAD_PATH . ($subType ? '/' . $subType : '');
            }

            $data = $this->uploadFile($fldName, $fullPath, $changeName);

            if (isset($data['file_name'])) {
                $this->putUploadFileInfo('admin', $subType, $data);

                $url = str_replace(DOCUMENT_ROOT, '', $data['full_path']);
                return [
                    "uploaded" => 1,
                    "fileName" => $data['file_name'],
                    "url" => ($url[0] != '/' ? '/' : '') . $url,
                    "data" => $data
                ];
            } else {
                return [
                    "uploaded" => 0,
                    "error" => [
                        "message" => strip_tags($data['error'])
                    ]
                ];
            }
        } else {
            return [
                "uploaded" => 0,
                "error" => [
                    "message" => "upload data empty"
                ]
            ];
        }
    }

    /**
     * 아이콘 업로드용
     * @param type $fldName
     * @return type
     */
    public function iconUpload($fldName, $fileName, $subType = 'P')
    {
        if ($fldName) {
            $data = $this->uploadFile($fldName, ICON_UPLOAD_PATH, $fileName);

            if (isset($data['file_name'])) {
                $this->putUploadFileInfo('icon', $subType, $data);
                return [
                    "uploaded" => 1,
                    "fileName" => $data['file_name'],
                    "url" => str_replace(DOCUMENT_ROOT, '', $data['full_path']),
                    "data" => $data
                ];
            } else {
                return [
                    "uploaded" => 0,
                    "error" => [
                        "message" => strip_tags($data['error'])
                    ]
                ];
            }
        } else {
            return [
                "uploaded" => 0,
                "error" => [
                    "message" => "upload data empty"
                ]
            ];
        }
    }

    /**
     * 상품 이미지용
     * @param type $fldName
     * @param type $pid
     * @return type
     */
    public function productUpload($fldName, $pid)
    {

        static $resizeInfo = false;
        static $imgLib = false;

        if ($fldName) {
            if ($resizeInfo === false) {
                /* @var $resizeInfoModel \CustomScm\Model\Product\resizeInfo */
                $resizeInfoModel = $this->import('model.scm.product.resizeInfo');
                $resizeInfo = $resizeInfoModel->getList();
            }

            if ($imgLib === false) {
                $imgLib = ci_load_library('image_lib');
            }

            $pid = zerofill($pid);
            $pidPathSplit = str_split($pid, 2);
            $pidPath = '';
            foreach ($pidPathSplit as $key => $val) {
                if ($key > 0) {
                    $pidPath .= "/" . $val;
                } else {
                    $pidPath .= $val;
                }
            }

            $data = $this->uploadFile($fldName, PRODUCT_UPLOAD_PATH . $pidPath, 'basic_' . $pid . '.gif');

            if (isset($data['file_name'])) {
                $this->putUploadFileInfo('product', $pid, $data);

                $resizeConfig['image_library'] = 'gd2';
                $resizeConfig['create_thumb'] = false;
                $resizeConfig['maintain_ratio'] = true;

                foreach ($resizeInfo as $resize) {
                    $resizeConfig['width'] = $resize['width'];
                    $resizeConfig['height'] = $resize['height'];
                    $resizeConfig['source_image'] = $data['full_path'];
                    $resizeConfig['new_image'] = $data['file_path'] . $resize['div'] . '_' . $pid . '.gif';
                    $imgLib->initialize($resizeConfig);
                    $imgLib->resize();
                }

                return [
                    "uploaded" => 1,
                    "fileName" => $data['file_name'],
                    "url" => str_replace(DOCUMENT_ROOT, '', $data['full_path']),
                    "data" => $data
                ];
            } else {
                return [
                    "uploaded" => 0,
                    "error" => [
                        "message" => strip_tags($data['error'])
                    ]
                ];
            }
        } else {
            return [
                "uploaded" => 0,
                "error" => [
                    "message" => "upload data empty"
                ]
            ];
        }
    }

    /**
     * 상품 추가 이미지용
     * @param $fldName
     * @param $pid
     * @param $adIx
     * @return array
     */
    public function productAddUpload($fldName, $pid, $adIx)
    {
        static $resizeInfo = false;
        static $imgLib = false;

        if ($fldName) {
            if ($resizeInfo === false) {
                /* @var $resizeInfoModel \CustomScm\Model\Product\resizeInfo */
                $resizeInfoModel = $this->import('model.scm.product.resizeInfo');
                $resizeInfo = $resizeInfoModel->getList();
            }

            if ($imgLib === false) {
                $imgLib = ci_load_library('image_lib');
            }

            $pid = zerofill($pid);
            $pidPathSplit = str_split($pid, 2);
            $pidPath = '';
            foreach ($pidPathSplit as $key => $val) {
                if ($key > 0) {
                    $pidPath .= "/" . $val;
                } else {
                    $pidPath .= $val;
                }
            }

            $data = $this->uploadFile($fldName, PRODUCT_ADD_UPLOAD_PATH . $pidPath, 'basic_' . $adIx . '_add.gif');

            if (isset($data['file_name'])) {
                $this->putUploadFileInfo('product', $pid, $data);

                $resizeConfig['image_library'] = 'gd2';
                $resizeConfig['create_thumb'] = false;
                $resizeConfig['maintain_ratio'] = true;

                foreach ($resizeInfo as $resize) {
                    if (in_array($resize['div'], ['b', 'm', 'c'])) {
                        $resizeConfig['width'] = $resize['width'];
                        $resizeConfig['height'] = $resize['height'];
                        $resizeConfig['source_image'] = $data['full_path'];
                        $resizeConfig['new_image'] = $data['file_path'] . $resize['div'] . '_' . $adIx . '_add.gif';
                        $imgLib->initialize($resizeConfig);
                        $imgLib->resize();
                    }
                }

                return [
                    "uploaded" => 1,
                    "fileName" => $data['file_name'],
                    "url" => str_replace(DOCUMENT_ROOT, '', $data['full_path']),
                    "data" => $data
                ];
            } else {
                return [
                    "uploaded" => 0,
                    "error" => [
                        "message" => strip_tags($data['error'])
                    ]
                ];
            }
        } else {
            return [
                "uploaded" => 0,
                "error" => [
                    "message" => "upload data empty"
                ]
            ];
        }
    }

    /**
     * 메인전시 이미지용
     * @param type $fldName
     * @param type $pid
     * @return type
     */
    public function mainGoodsUpload($fldName, $mgIx, $groupNum)
    {
        static $imgLib = false;

        if ($fldName) {
            if ($imgLib === false) {
                $imgLib = ci_load_library('image_lib');
            }

            $data = $this->uploadFile($fldName, MAIN_GOODS_UPLOAD_PATH, $mgIx . '_main_group_' . $groupNum . '.gif');

            if (isset($data['file_name'])) {
                $this->putUploadFileInfo('display', $mgIx, $data);

                return [
                    "uploaded" => 1,
                    "fileName" => $data['file_name'],
                    "url" => str_replace(DOCUMENT_ROOT, '', $data['full_path']),
                    "data" => $data
                ];
            } else {
                return [
                    "uploaded" => 0,
                    "error" => [
                        "message" => strip_tags($data['error'])
                    ]
                ];
            }
        } else {
            return [
                "uploaded" => 0,
                "error" => [
                    "message" => "upload data empty"
                ]
            ];
        }
    }

    /**
     * 이벤트 이미지용
     * @param type $fldName
     * @param type $pid
     * @return type
     */
    public function eventUpload($fldName, $ix, $groupNum = '')
    {
        static $imgLib = false;

        if ($fldName) {
            if ($imgLib === false) {
                $imgLib = ci_load_library('image_lib');
            }

            if ($fldName == 'bannerImage') {
                $eventFileName = 'event_banner_' . $ix;
            } elseif ($fldName == 'bannerImage_pc') {
                $eventFileName = 'event_banner_pc' . $ix;
            } elseif ($fldName == 'bannerImage_m') {
                $eventFileName = 'event_banner_m' . $ix;
            } elseif ($fldName == 'bannerImage_main_pc') {
                $eventFileName = 'event_banner_main_pc' . $ix;
            } elseif ($fldName == 'bannerImage_main_m') {
                $eventFileName = 'event_banner_main_m' . $ix;
            } elseif ($fldName == 'ogImageSrc') {
                $eventFileName = 'event_banner_og' . $ix;
            } else if($fldName == 'devAnnounceImg') {
                $eventFileName = 'event_announce' . $ix;
            }else {
                if ($fldName == 'groupImage' . $groupNum) {
                    $eventFileName = 'event_group_' . $groupNum;
                }
            }

            $data = $this->uploadFile($fldName, EVENT_UPLOAD_PATH . '/' . $ix . '/', $eventFileName . '.gif');

            if (isset($data['file_name'])) {
                $this->putUploadFileInfo('display', $ix, $data);

                return [
                    "uploaded" => 1,
                    "fileName" => $data['file_name'],
                    "url" => str_replace(DOCUMENT_ROOT, '', $data['full_path']),
                    "data" => $data
                ];
            } else {
                return [
                    "uploaded" => 0,
                    "error" => [
                        "message" => strip_tags($data['error'])
                    ]
                ];
            }
        } else {
            return [
                "uploaded" => 0,
                "error" => [
                    "message" => "upload data empty"
                ]
            ];
        }
    }

    /**
     * 검색창 키워드 이미지용
     * @param type $fldName
     * @param type $pid
     * @return type
     */
    public function keywordUpload($fldName, $ix)
    {
        static $imgLib = false;

        if ($fldName) {
            if ($imgLib === false) {
                $imgLib = ci_load_library('image_lib');
            }

            $data = $this->uploadFile($fldName, KEYWORD_UPLOAD_PATH . '/' . $ix . '/', $ix . '.gif');

            if (isset($data['file_name'])) {
                $this->putUploadFileInfo('marketing', $ix, $data);

                return [
                    "uploaded" => 1,
                    "fileName" => $data['file_name'],
                    "url" => str_replace(DOCUMENT_ROOT, '', $data['full_path']),
                    "data" => $data
                ];
            } else {
                return [
                    "uploaded" => 0,
                    "error" => [
                        "message" => strip_tags($data['error'])
                    ]
                ];
            }
        } else {
            return [
                "uploaded" => 0,
                "error" => [
                    "message" => "upload data empty"
                ]
            ];
        }
    }

    /**
     * 통합배너 이미지용
     * @param type $fldName
     * @param type $pid
     * @return type
     */
    public function bannerUpload($fldName, $ix, $fileName)
    {
        static $imgLib = false;

        if ($fldName) {
            if ($imgLib === false) {
                $imgLib = ci_load_library('image_lib');
            }

            $data = $this->uploadFile($fldName, BANNER_UPLOAD_PATH . '/' . $ix . '/', $fileName);

            if (isset($data['file_name'])) {
                $this->putUploadFileInfo('banner', $ix, $data);

                return [
                    "uploaded" => 1,
                    "fileName" => $data['file_name'],
                    "url" => str_replace(DOCUMENT_ROOT, '', $data['full_path']),
                    "data" => $data
                ];
            } else {
                return [
                    "uploaded" => 0,
                    "error" => [
                        "message" => strip_tags($data['error'])
                    ]
                ];
            }
        } else {
            return [
                "uploaded" => 0,
                "error" => [
                    "message" => "upload data empty"
                ]
            ];
        }
    }

    public function uploadFile($fldName, $upload_path, $fileName = false)
    {
        if (!is_dir($upload_path)) {
            $tag = @mkdir($upload_path, 0777, true);
            if (!$tag) {
                return '"' . $upload_path . '" Permition ckeck please';
            }
        }

        // 파일명
        $config = [
            'upload_path' => $upload_path,
            'allowed_types' => $this->allowType,
            'overwrite' => $this->overWrite
        ];

        if ($fileName) {
            $config['file_name'] = $fileName;
        } else {
            $config['encrypt_name'] = true;
        }

        $upload = ci_load_library('upload');
        $upload->initialize($config);
        if ($upload->do_upload($fldName)) {
            return $upload->data();
        } else {
            return [
                'error' => $upload->display_errors()
            ];
        }
    }

    /**
     * 업로드 파일 정보 추가
     * @param string $uploadType
     * @param string $subType
     * @param array $data
     * @return int
     */
    public function putUploadFileInfo($uploadType, $subType, $data)
    {
        $data = $this->qb
            ->set('upload_type', $uploadType)
            ->set('sub_type', $subType)
            ->set('org_file_name', $data['client_name'])
            ->set('file_name', $data['file_name'])
            ->set('file_path', $data['file_path'])
            ->set('file_size', $data['file_size'])
            ->set('org_file_size', filesize($data['full_path']))
            ->set('file_type', $data['file_type'])
            ->set('full_path', $data['full_path'])
            ->set('image_height', $data['image_height'])
            ->set('image_width', $data['image_width'])
            ->set('image_type', $data['image_type'])
            ->set('is_image', $data['is_image'])
            ->set('raw_name', $data['raw_name'])
            ->set('file_ext', $data['file_ext'])
            ->set('url', $data['url_path'])
            ->set('hash', md5(str_replace(DOCUMENT_ROOT, '', $data['full_path'])))
            ->insert(TBL_SYSTEM_UPLOAD_FILE)
            ->exec();

        return $data;
    }

    /**
     * 업로드 파일 및 정보 삭제
     * @param string $url
     * @return boolean
     */
    public function deleteUploadFileInfo($url)
    {
        $urlHash = md5(str_replace(DOCUMENT_ROOT, '', $url));

        $row = $this->qb
            ->select('full_path')
            ->from(TBL_SYSTEM_UPLOAD_FILE)
            ->where('hash', $urlHash)
            ->exec()
            ->getRowArray();

        if (isset($row['full_path'])) {
            @unlink($row['full_path']);
        } else {
            if(url_file_exists(IMAGE_SERVER_DOMAIN.$url)) {
                @unlink(IMAGE_SERVER_DOMAIN.$url);
            }
        }

        return $this->qb
            ->where('hash', $urlHash)
            ->delete(TBL_SYSTEM_UPLOAD_FILE)
            ->exec();
    }

    /**
     * 업로드 파일 및 정보 삭제 외부 URL
     * @param string $url
     * @return boolean
     */
    public function deleteUploadFileUrl($url)
    {
        $url = str_replace('//', '/', parse_url($url, PHP_URL_PATH));
        
        $rows = $this->qb
            ->select('full_path')
            ->select('upload_type')
            ->select('file_path')
            ->select('raw_name')
            ->from(TBL_SYSTEM_UPLOAD_FILE)
            ->where('url', $url)
            ->exec()
            ->getResultArray();

        if(is_array($rows) && count($rows) > 0){
            foreach($rows as $row){
                if (isset($row['full_path'])) {
                    if (@unlink($row['full_path'])) {

                        //상품의 이미지 및 추가이미지의 경우 리사이징 된 이미지가 존재하기 때문에 해당 경로에 있는 파일을 모두 제거 시켜야 함
                        if(isset($row['upload_type']) && $row['upload_type'] == 'product'){
                            $directory = $row['file_path'];
                            $handle = opendir($directory); // 절대경로
                            //이미지 고유 키 획득
                            $fileInfo = explode('_',$row['raw_name']);
                            $fileId = $fileInfo[1];
                            $fileType = $fileInfo[2] ?? "";
                            while ($file = readdir($handle)) {
                                if(strpos($file, $fileId) !== false) {
                                    @unlink($directory.$file);
                                }
                            }
                            if($fileType == 'add'){
                                $this->qb
                                    ->where('id', $fileId)
                                    ->delete(TBL_SHOP_ADDIMAGE)
                                    ->exec();
                            }
                            closedir($handle);
                        }

                        $this->qb
                            ->where('url', $url)
                            ->delete(TBL_SYSTEM_UPLOAD_FILE)
                            ->exec();
                    }
                }
            }
            return true;
        }else{
            return 'notUploadFile';
        }
    }

    /**
     * 게시판 파일 업로드
     * @param $fldName
     * @param $subType
     * @param null $path
     * @param null $drFileName
     * @return array
     */
    public function bbsUpload($fldName, $subType, $bbs_index = null, $drFileName = null)
    {
        if ($fldName) {
            $fullPath = MALL_DATA_PATH . "/bbs_data" . "/bbs_" . $subType . "/" . $bbs_index;

            if ($drFileName) {
                $data = $this->uploadFile($fldName, $fullPath, $drFileName);
            } else {
                $data = $this->uploadFile($fldName, $fullPath, false);
            }


            if (isset($data['file_name'])) {
                $uploadId = $this->putUploadFileInfo('admin', $subType, $data);
                return [
                    "uploaded" => 1,
                    "fileName" => $data['file_name'],
                    "url" => str_replace(DOCUMENT_ROOT, '', $data['full_path']),
                    "data" => $data,
                    "uploadId" => $uploadId
                ];
            } else {
                return [
                    "uploaded" => 0,
                    "error" => [
                        "message" => strip_tags($data['error'])
                    ]
                ];
            }
        } else {
            return [
                "uploaded" => 0,
                "error" => [
                    "message" => "upload data empty"
                ]
            ];
        }
    }

    /**
     * 브랜드 관리 업로드용
     * @param type $fldName
     * @return type
     */
    public function brandUpload($fldName, $fileName, $subType = 'P')
    {
        if ($fldName) {
            $data = $this->uploadFile($fldName, BRAND_UPLOAD_PATH, $fileName);

            if (isset($data['file_name'])) {
                $this->putUploadFileInfo('brand', $subType, $data);
                return [
                    "uploaded" => 1,
                    "fileName" => $data['file_name'],
                    "url" => str_replace(DOCUMENT_ROOT, '', $data['full_path']),
                    "data" => $data
                ];
            } else {
                return [
                    "uploaded" => 0,
                    "error" => [
                        "message" => strip_tags($data['error'])
                    ]
                ];
            }
        } else {
            return [
                "uploaded" => 0,
                "error" => [
                    "message" => "upload data empty"
                ]
            ];
        }
    }

    /**
     * 푸쉬 이미지 업로드용
     * @param type $fldName
     * @return type
     */
    public function pushImageUpload($fldName, $fileName)
    {
        if ($fldName) {
            $data = $this->setAllowType('gif|jpg|jpeg|png')
                ->uploadFile($fldName, PUSH_UPLOAD_PATH, $fileName);

            if (isset($data['file_name'])) {
                $this->putUploadFileInfo('push', $fldName, $data);
                return [
                    "uploaded" => 1,
                    "fileName" => $data['file_name'],
                    "url" => str_replace(DOCUMENT_ROOT, '', $data['full_path']),
                    "data" => $data
                ];
            } else {
                return [
                    "uploaded" => 0,
                    "error" => [
                        "message" => strip_tags($data['error'])
                    ]
                ];
            }
        } else {
            return [
                "uploaded" => 0,
                "error" => [
                    "message" => "upload data empty"
                ]
            ];
        }
    }
}