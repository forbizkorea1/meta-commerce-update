<?php

namespace ForbizScm\Model\Util;

/**
 * 엑셀 다운로드 이력관리 모델
 *
 * @author hoksi
 */
class ExcelDwnHistory extends \ForbizModel
{
    protected $mem_type    = [
        'M' => '개인회원',
        'C' => '기업회원',
        'A' => '직원(관리자)'
    ];
    protected $mem_div     = [
        'S' => '셀러',
        'MD' => 'MD',
        'D' => '기타'
    ];
    protected $dstr_status = [
        'Y' => '파기완료',
        'N' => '파기안함'
    ];
    protected $downloadType = 'csv';

    protected $company_id = false;

    public function __construct()
    {
        parent::__construct();
    }

    public function setDownloadType($type)
    {
        $this->downloadType = $type;
        return $this;
    }

    public function setCompanyId($company_id)
    {
        $this->company_id = $company_id;
        return $this;
    }

    public function getMemType($idx = false)
    {
        if ($idx === false) {
            return $this->mem_type;
        } else {
            return $this->mem_type[$idx] ?? '';
        }
    }

    public function getMemDiv($idx = false)
    {
        if ($idx === false) {
            return $this->mem_div;
        } else {
            return $this->mem_div[$idx] ?? '';
        }
    }

    public function getDstrStatus($idx = false)
    {
        if ($idx === false) {
            return $this->dstr_status;
        } else {
            return $this->dstr_status[$idx] ?? '';
        }
    }

    protected function cvtData($data)
    {
        foreach ($data as $key => $cvt) {
            $data[$key]['mem_type']    = $this->getMemType($cvt['mem_type']);
            $data[$key]['mem_div']     = $this->getMemDiv($cvt['mem_div']);
            $data[$key]['dstr_status'] = $this->getDstrStatus($cvt['dstr_status']);
        }

        return $data;
    }

    /**
     * 엑셀파일 다운로드 히스토리 조회
     * @param int $cur_page
     * @param int $per_page
     * @param array $search
     * @return array
     */
    public function getHistory($cur_page, $per_page, $search = [])
    {
        // 쿼리 캐시 시작
        $this->qb->startCache();

        //회원구분
        if(!empty($search['mem_type'])) {
            $this->qb->where('mem_type', $search['mem_type']);
        }

        //회원타입
        if(!empty($search['mem_div'])) {
            $this->qb->where('mem_div', $search['mem_div']);
        }

        //다운로드 날짜 검색
        if(!empty($search['dateStart']) && !empty($search['dateEnd'])) {
            $this->qb->betweenDate('dwn_date', $search['dateStart'], $search['dateEnd']);
        }

        //검색어
        if(!empty($search['searchText'])) {
            $this->qb->like($search['searchType'], $search['searchText']);
        }

        //파기여부
        if(!empty($search['dstr_status'])) {
            $this->qb->where('dstr_status', $search['dstr_status']);
        }

        if($this->company_id) {
            $this->qb->where('company_id', $this->company_id);
        }

        $this->qb
            ->from(TBL_SYSTEM_EXCEL_DWN_HISTORY);
        // 쿼리 캐시 끝
        $this->qb->stopCache();

        // total 산출
        $total = $this->qb->getCount();

        // 페이징 설정
        $paging = $this->qb
            ->setTotalRows($total)
            ->pagination($cur_page, $per_page);

        // limit 값 산출
        $limit  = $per_page;
        $offset = ($paging['offset'] ?? 0);

        $rows = $this->qb
            ->orderBy('dwn_date', 'desc')
            ->limit($limit, $offset)
            ->exec()
            ->getResultArray();

        $this->qb->flushCache();

        $this->result = 'success';
        $this->data   = [
            'list' => $this->cvtData($rows)
            , 'paging' => $paging
            , 'total' => $total
        ];

        return $this->getResult();
    }

    /**
     * 히스토리 기록후 엑셀 파일명 리턴
     * @return type
     */
    public function getExcelFileName($front="" , $near="")
    {
        // 네비게이션 정보
        $nav = get_nav();

        if (empty($nav)) {
            $nav = [
                'top' => $this->uri->segment(1)
                , 'sub' => $this->uri->segment(2)
            ];
        }

        // 엑셀파일명 설정
        if($this->downloadType == 'csv') {
            $ext = 'csv';
        }else if($this->downloadType == 'excel'){
            $ext = 'xlsx';
        } else {
            $ext = 'xls';
        }

        $excelFileName = $this->makeFileName($nav['top'] ?? '', $nav['sub'] ?? '', $ext);
        if(!empty($front)){
            $excelFileName = $front.$excelFileName;
        }
        if(!empty($near)){
            $excelFileName = $excelFileName.$near;
        }

        $this->addHistory(['file_type' => $nav['top'], 'file_name' => $excelFileName]);

        return $excelFileName;
    }

    /**
     * 엑셀 파일명 생성
     * @param string $depth1
     * @param string $depth2
     * @param string $ext
     * @return string
     */
    public function makeFileName($depth1, $depth2, $ext = 'xlsx')
    {
        return sprintf('%s_%s_%s.%s', $this->adminInfo->charger_id, $depth2, date('YmdHis'), $ext);
    }

    /**
     * 엑셀 다운로드 히스토리 추가
     * @param array $data
     * @return array
     */
    public function addHistory($data)
    {
        $data = $this->qb->allowedFields($data, ['file_type', 'file_name']);

        $data['company_id'] = $this->adminInfo->company_id;
        $data['mem_type'] = $this->adminInfo->mem_type;
        $data['mem_div']  = $this->adminInfo->mem_div;
        $data['mem_name'] = $this->adminInfo->charger;
        $data['mem_id']   = $this->adminInfo->charger_id;
        $data['dwn_date'] = date('Y-m-d H:i:s');
        $data['dwn_ip']   = $this->input->ip_address();

        $this->insertHistory($data);

        return $this->getResult();
    }

    /**
     * 엑셀 다운로드 히스토리 파기
     * @param array $data
     * @return array
     */
    public function destroyHistory($data)
    {
        $data = $this->qb->allowedFields($data, ['system_excel_dwn_history_id']);

        $data['dstr_status'] = 'Y';
        $data['dstr_name']   = $this->adminInfo->charger;
        $data['dstr_id']     = $this->adminInfo->charger_id;
        $data['dstr_date']   = date('Y-m-d H:i:s');
        $data['dstr_ip']     = $this->input->ip_address();

        if($this->company_id) {
            $this->qb->where('company_id', $this->company_id);
        }

        $this->updateHistory($data);

        // 업데이트용 데이터 리턴
        $data['dstr_status'] = $this->getDstrStatus($data['dstr_status']);
        $this->data          = $data;

        return $this->getResult();
    }

    /**
     * 엑셀 다운로드 히스토리 테이블에 기록
     * @param array $data
     * @return int
     */
    public function insertHistory($data)
    {
        $this->result = 'success';

        return $this->qb
                ->set($data)
                ->insert(TBL_SYSTEM_EXCEL_DWN_HISTORY)
                ->exec();
    }

    /**
     * 엑셀 다운로드 히스토리 업데이트
     * @param array $data
     * @return boolean
     */
    public function updateHistory($data)
    {
        $this->result = 'success';

        return $this->qb
                ->set($data)
                ->where('system_excel_dwn_history_id', $data['system_excel_dwn_history_id'])
                ->update(TBL_SYSTEM_EXCEL_DWN_HISTORY)
                ->exec();
    }
}