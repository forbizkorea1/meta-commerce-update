<?php
return (function(){
    // Forbiz 솔루션 관리자 버젼
    define('FORBIZ_SCM_VERSION', '4.5');
    define('META_COMMERCE_VERSION', '1.4.2');
})();
