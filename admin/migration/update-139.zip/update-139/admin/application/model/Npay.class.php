<?php

namespace CustomScm\Model;

/**
 * 네이버페이 주문형 주문 관련 모델
 * 
 * @author sammy
 */
class Npay extends \ForbizScm\Model\Npay
{
    public function __construct()
    {
        parent::__construct();
    }
}