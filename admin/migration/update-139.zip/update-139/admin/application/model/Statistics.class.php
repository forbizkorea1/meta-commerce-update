<?php

namespace CustomScm\Model;

/**
 * 통계 모델
 * 
 * @author hoksi
 */
class Statistics extends \ForbizScm\Model\Statistics
{

    public function __construct()
    {
        parent::__construct();
    }


}