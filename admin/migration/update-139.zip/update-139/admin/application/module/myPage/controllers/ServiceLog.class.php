<?php

namespace CustomScm\Controller\MyPage;

class ServiceLog extends \ForbizScm\Controller\MyPage\ServiceLog
{

    public function __construct()
    {
        parent::__construct();
    }
}