<?php

namespace CustomScm\Controller\MyPage;

class ServiceLogDetail extends \ForbizScm\Controller\MyPage\ServiceLogDetail
{

    public function __construct()
    {
        parent::__construct();
    }
}