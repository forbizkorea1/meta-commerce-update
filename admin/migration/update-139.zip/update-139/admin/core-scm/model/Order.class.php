<?php

namespace ForbizScm\Model;

/**
 * 주문 관련 모델
 *
 * @author hoksi
 */
class Order extends \ForbizModel
{
    public function __construct()
    {
        parent::__construct();

        // 부가서비스 제공하는 택배사
        $this->dCompany = [
            '01' , // 우체국택배
            '05' , // 로젠택배
            '06' , // 대한통운, CJ대한통운
            '12' , // 롯데택배
            '13' , // 한진택배
            '17' , // 사가와익
            '18' , // CJ택배, CJ대한통운
            '21' , // 경동택배
            '22' , // 대신택배
            '23' , // 일양로지스
            '24' , // 건영택배
            '25' , // 천일택배
            '26' , // 합동택배
            '27' , // 호남택배
            '42' , // CVSnet(편의점택배), CU 편의점택배
            '44' , // FedEx
            '45' , // DHL
            '46' , // UPS
        ];
    }

    /**
     * 크론 - 자동취소
     */
    public function cronAutoCancel()
    {
        get_auth_info();
        /* @var $statusModel \CustomScm\Model\Order\Status */
        $statusModel = $this->import('model.scm.order.status');

        /* @var $orderModel \CustomScm\Model\Order\Order */
        $orderModel = $this->import('model.scm.order.order');

        $mall_cc_interval = \ForbizConfig::getMallConfig('mall_cc_interval');

        $list = $this->qb
            ->select('oid')
            ->select('bmail')
            ->select('bmobile')
            ->from(TBL_SHOP_ORDER)
            ->where('DATE_ADD(order_date, INTERVAL ' . $mall_cc_interval . ' DAY)  <=', date('Y-m-d H:i:s'))
            ->where('status', ORDER_STATUS_INCOM_READY)
            ->exec()
            ->getResultArray();

        if ($this->qb->total > 0) {
            foreach ($list as $key => $val) {
                //입금 전 취소 처리
                $statusModel->doIncomBeforCancelComplete($val['oid']);

                $orderModel->setOid($val['oid']);

                //미입금 자동 주문 취소 안내 메일
                $tpl['order_cancel_date'] = date("Y-m-d H:i:s");
                $tpl['orderDetail'] = $orderModel->getClaimProductList();
                sendMessage('order_auto_cancel', $val['bmail'], $val['bmobile'], $tpl);
            }
        }
    }

    public function deliveryCompleteUseCommon()
    {
        return $this->qb
                ->select('use')
                ->from(TBL_SYSTEM_CRON)
                ->where('task_type', "module")
                ->where('task', "order.cron.php autoDeliveryComplete")
                ->where('use', "Y")
                ->getCount() > 0;
    }

    /**
     * 크론 - 자동 배송완료
     */
    public function cronDeliveryComplete()
    {
        /* @var $statusModel \CustomScm\Model\Order\Status */
        $statusModel = $this->import('model.scm.order.status');

        $mall_dc_interval = \ForbizConfig::getMallConfig('mall_dc_interval');

        // system_cron에서 order.cron.php autoDeliveryComplete 존재하는지 use 상태값 확인
        if ($this->deliveryCompleteUseCommon()) {
            $this->qb->whereNotIn('quick', $this->dCompany);
        }
        $rows = $this->qb
            ->select('od_ix')
            ->from(TBL_SHOP_ORDER_DETAIL . ' AS od')
            ->where('DATE_ADD(od.di_date, INTERVAL ' . $mall_dc_interval . ' DAY)  <=', date('Y-m-d H:i:s'))
            ->where('od.status', ORDER_STATUS_DELIVERY_ING)
            ->exec()
            ->getResultArray();

        if ($this->qb->total > 0) {
            $statusModel->setAdminUser('system');
            $statusModel->setManageCompanyId(false);
            $statusModel->doChangeStatus(ORDER_STATUS_DELIVERY_COMPLETE, array_column($rows, 'od_ix'), '시스템 자동 처리');
        }
    }

    /**
     * 크론 - 자동 배송완료(부가서비스)
     */
    public function cronAutoDeliveryComplete()
    {
        /* @var $statusModel \CustomScm\Model\Order\Status */
        $statusModel = $this->import('model.scm.order.status');

        if ($this->deliveryCompleteUseCommon()) {
            $rows = $this->qb
                ->select('od_ix')
                ->select('quick')
                ->select('invoice_no')
                ->from(TBL_SHOP_ORDER_DETAIL . ' AS od')
                ->where('od.status', ORDER_STATUS_DELIVERY_ING)
                ->whereIn('quick', $this->dCompany)
                ->exec()
                ->getResultArray();

            get_auth_info();
            if ($this->qb->total > 0) {
                $autoDelivery = [];
                foreach( $rows as $val) {
                    $deliveryInfo = get_delivery_info($val['quick'], $val['invoice_no'], 'delivery_complete');

                    if ($deliveryInfo['result'] == "success" && $deliveryInfo['data']['state']['id'] == "delivered") {
                        $autoDelivery[] = $val['od_ix'];
                    }
                }

                if (count($autoDelivery) > 0) {
                    $statusModel->setAdminUser('system');
                    $statusModel->setManageCompanyId(false);
                    $statusModel->doChangeStatus(ORDER_STATUS_DELIVERY_COMPLETE, $autoDelivery, '자동배송완료');
                }
            }
        }
    }

    /**
     * 크론 - 자동 구매확정
     */
    public function cronBuyFinalized()
    {
        /* @var $statusModel \CustomScm\Model\Order\Status */
        $statusModel = $this->import('model.scm.order.status');

        $check_order_day = \ForbizConfig::getMallConfig('check_order_day');

        $rows = $this->qb
            ->select('od_ix')
            ->from(TBL_SHOP_ORDER_DETAIL . ' AS od')
            ->where('DATE_ADD(od.dc_date, INTERVAL ' . $check_order_day . ' DAY)  <=', date('Y-m-d H:i:s'))
            ->where('od.status', ORDER_STATUS_DELIVERY_COMPLETE)
            ->exec()
            ->getResultArray();

        if ($this->qb->total > 0) {
            $statusModel->setAdminUser('system');
            $statusModel->setManageCompanyId(false);
            $statusModel->doChangeStatus(ORDER_STATUS_BUY_FINALIZED, array_column($rows, 'od_ix'), '시스템 자동 처리');
        }
    }

    /**
     * 크론 - 주문 정산 집계
     */
    public function cronAccountsReady()
    {
        //크론은 정해진 정산 일자는 집계 기준! 그래서 다음날 집계가 되어야함
        //ex> 월 2회 15일, 30일 이면 16일, 다음달 1일에 집계시 돌아야함

        $nowDay = date('j');

        $timestamp = strtotime('-1 day');
        $year = date('Y', $timestamp);
        $month = date('n', $timestamp);
        $date = date('Y-m-d', $timestamp);
        $dateTime = date('Y-m-d 23:59:59', $timestamp);
        $day = date('j', $timestamp);
        $lastDay = date('t', $timestamp);
        $week = date('w', $timestamp);

        $rows = $this->qb
            ->select('company_id')
            ->select('ac_term_div')
            ->select('(CASE ac_term_div 
            WHEN "2" THEN CONCAT("' . $year . '년 ' . $month . '월 ", IF(ac_term_date1="' . $day . '",1,2), "차 정산")
            WHEN "3" THEN "' . $year . '년 ' . $month . '월 주 ' . ceil(($week + $day - 1) / 7) . '차 정산"
            ELSE "' . $year . '년 ' . $month . '월 정산" END) AS ac_title')
            ->from(TBL_COMMON_SELLER_DELIVERY)
            ->groupStart()
            ->where('ac_term_div', '1')//월 1회
            ->groupStart()
            ->where('ac_term_date1', $day)
            ->orGroupStart()
            ->where('ac_term_date1 > ', $lastDay, false)
            ->where('1', $nowDay)
            ->groupEnd()
            ->groupEnd()
            ->groupEnd()
            ->orGroupStart()
            ->where('ac_term_div', '2')//월 2회
            ->groupStart()
            ->where('ac_term_date1', $day)
            ->orWhere('ac_term_date2', $day)
            ->orGroupStart()
            ->groupStart()
            ->where('ac_term_date1 > ', $lastDay, false)
            ->where('1', $nowDay)
            ->groupEnd()
            ->orGroupStart()
            ->where('ac_term_date2 > ', $lastDay, false)
            ->where('1', $nowDay)
            ->groupEnd()
            ->groupEnd()
            ->groupEnd()
            ->groupEnd()
            ->orGroupStart()
            ->where('ac_term_div', '3')//매주 1회
            ->where('ac_term_date1', $week)
            ->groupEnd()
            ->exec()
            ->getResultArray();

        if ($this->qb->total > 0) {

            /* @var $accountsModel \CustomScm\Model\Order\Accounts */
            $accountsModel = $this->import('model.scm.order.accounts');

            //정산 돌려야 하는 업체를 select 하여 업체별로 처리
            foreach ($rows as $row) {
                //N:과세, Y:면세 따로 정산 집계
                foreach (['N', 'Y'] as $surtaxTorn) {

                    //정산 대상 내역 추출
                    $data = $accountsModel->getCronAccountsPlanList($row['company_id'], $dateTime, $surtaxTorn);
                    if (!empty($data)) {
                        $odIxs = [];
                        $odeIxs = [];
                        $refundOdIxs = [];
                        $ocdeIx = [];

                        $p_expect_price = 0;
                        $p_dc_allotment_price = 0;
                        $p_fee_price = 0;
                        $p_ac_price = 0;
                        $d_expect_price = 0;
                        $d_dc_allotment_price = 0;
                        $d_ac_price = 0;
                        $ac_price = 0;

                        foreach ($data as $dt) {
                            $p_expect_price += $dt['product_account_plan_price'];
                            $p_dc_allotment_price += $dt['product_discount_charge_price'];
                            $p_fee_price += $dt['product_fees'];
                            $p_ac_price += $dt['product_account_price'];

                            if ($dt['isRefund']) {
                                $refundOdIxs[] = $dt['od_ix'];
                                if (!empty($dt['ocde_ix']) && !in_array($dt['ocde_ix'], $ocdeIx)) {
                                    $ocdeIx[] = $dt['ocde_ix'];
                                    $d_expect_price += $dt['delivery_account_plan_price'];
                                    $d_dc_allotment_price += $dt['delivery_discount_charge_price'];
                                    $d_ac_price += $dt['delivery_account_price'];
                                }
                            } else {
                                $odIxs[] = $dt['od_ix'];
                                //orderList 에서 ode_ix 는 무조껀 노출 시켜 주기 때문에 업데이트시 ac_ix = 0 으로 필터해서 업데이트
                                if (!in_array($dt['ode_ix'], $odeIxs)) {
                                    $odeIxs[] = $dt['ode_ix'];
                                    $d_expect_price += $dt['delivery_account_plan_price'];
                                    $d_dc_allotment_price += $dt['delivery_discount_charge_price'];
                                    $d_ac_price += $dt['delivery_account_price'];
                                }
                            }
                        }

                        $ac_price = $p_ac_price + $d_ac_price;

                        //정산 데이터 생성
                        $acIx = $this->qb
                            ->set('company_id', $row['company_id'])
                            ->set('ac_date', $date)
                            ->set('ac_title', $row['ac_title'])
                            ->set('surtax_yorn', $surtaxTorn)
                            ->set('regdate', date('Y-m-d H:i:s'))
                            ->set('p_expect_price', $p_expect_price)
                            ->set('p_dc_allotment_price', $p_dc_allotment_price)
                            ->set('p_fee_price', $p_fee_price)
                            ->set('p_ac_price', $p_ac_price)
                            ->set('d_expect_price', $d_expect_price)
                            ->set('d_dc_allotment_price', $d_dc_allotment_price)
                            ->set('d_ac_price', $d_ac_price)
                            ->set('ac_price', $ac_price)
                            ->insert(TBL_SHOP_ACCOUNTS)
                            ->exec();

                        //주문 업데이트
                        $this->qb
                            ->set('ac_ix', $acIx)
                            ->set('accounts_status', ORDER_STATUS_ACCOUNT_READY)
                            ->update(TBL_SHOP_ORDER_DETAIL)
                            ->whereIn('od_ix', $odIxs)
                            ->exec();

                        //환불 주문 업데이트
                        if (!empty($refundOdIxs)) {
                            $this->qb
                                ->set('refund_ac_ix', $acIx)
                                ->update(TBL_SHOP_ORDER_DETAIL)
                                ->whereIn('od_ix', $refundOdIxs)
                                ->exec();
                        }

                        //배송 업데이트
                        $this->qb
                            ->set('ac_ix', $acIx)
                            ->update(TBL_SHOP_ORDER_DELIVERY)
                            ->whereIn('ode_ix', $odeIxs)
                            ->where('ac_ix', '0')
                            ->exec();

                        //환불 배송 업데이트
                        if (!empty($ocdeIx)) {
                            $this->qb
                                ->set('ac_ix', $acIx)
                                ->update(TBL_SHOP_ORDER_CLAIM_DELIVERY)
                                ->whereIn('ocde_ix', $ocdeIx)
                                ->exec();
                        }
                    }
                }
            }
        }
    }

    /**
     * 크론 - 주문 상담내역 파기 기간
     */
    public function cronQnaAutoDelete()
    {
        $autoDeleteYn = \ForbizConfig::getPrivacyConfig('achievement_purpose_destruction_order_memo_yn');
        $autoDeleteDate = \ForbizConfig::getPrivacyConfig('achievement_purpose_destruction_order_memo_year');

        if($autoDeleteYn == 'Y') {
            $rows = $this->qb
                ->select('bbs_ix')
                ->from(TBL_BBS_QNA)
                ->where('regdate <= ', 'date_add(now(), INTERVAL -' . $autoDeleteDate . ' YEAR)', false)
                ->exec()
                ->getResultArray();

            foreach ($rows as $row) {
                $bbsIxs[] = $row['bbs_ix'];
            }

            if (!empty($bbsIxs)) {
                $this->qb
                    ->whereIn('bbs_ix', $bbsIxs)
                    ->delete(TBL_BBS_QNA)
                    ->exec();
            }

            $rows = $this->qb
                ->select('bbs_ix')
                ->from(TBL_SHOP_PRODUCT_QNA)
                ->where('regdate <= ', 'date_add(now(), INTERVAL -' . $autoDeleteDate . ' YEAR)', false)
                ->exec()
                ->getResultArray();

            foreach ($rows as $row) {
                $bbsIxs[] = $row['bbs_ix'];
            }

            if (!empty($bbsIxs)) {
                $this->qb
                    ->whereIn('bbs_ix', $bbsIxs)
                    ->delete(TBL_SHOP_PRODUCT_QNA)
                    ->exec();
            }
        }
    }

    /**
     * 크론 - 주문 상담내역 파기 기간
     */
    public function cronOrderAutoDelete()
    {
        $autoDeleteYn = \ForbizConfig::getPrivacyConfig('achievement_purpose_destruction_order_yn');
        $autoDeleteDate = \ForbizConfig::getPrivacyConfig('achievement_purpose_destruction_order_year');

        if($autoDeleteYn == 'Y'){

            $rows = $this->qb
                ->select('oid')
                ->from(TBL_SHOP_ORDER)
                ->where('order_date <= ', 'date_add(now(), INTERVAL -' . $autoDeleteDate . ' YEAR)', false)
                ->exec()
                ->getResultArray();

            foreach ($rows as $row) {

                $this->qb->where('oid', $row['oid'])->delete(TBL_SEPARATION_SHOP_ORDER)->exec();

                $this->qb->where('oid', $row['oid'])->delete(TBL_SEPARATION_SHOP_ORDER_DELIVERYINFO)->exec();

                $this->qb->where('oid', $row['oid'])->delete(TBL_SHOP_ORDER)->exec();

                $this->qb->where('oid', $row['oid'])->delete(TBL_SHOP_ORDER_CLAIM_DELIVERY)->exec();

                $this->qb->where('oid', $row['oid'])->delete(TBL_SHOP_ORDER_DELIVERY)->exec();

                $this->qb->where('oid', $row['oid'])->delete(TBL_SHOP_ORDER_DETAIL)->exec();

                $this->qb->where('oid', $row['oid'])->delete(TBL_SHOP_ORDER_DETAIL_DELIVERYINFO)->exec();

                $this->qb->where('oid', $row['oid'])->delete(TBL_SHOP_ORDER_DETAIL_DISCOUNT)->exec();

                $this->qb->where('oid', $row['oid'])->delete(TBL_SHOP_ORDER_PAYMENT)->exec();

                $this->qb->where('oid', $row['oid'])->delete(TBL_SHOP_ORDER_GOODSFLOW)->exec();

                $this->qb->where('oid', $row['oid'])->delete(TBL_SHOP_ORDER_MEMO)->exec();

                $this->qb->where('oid', $row['oid'])->delete(TBL_SHOP_ORDER_PRICE)->exec();

                $this->qb->where('oid', $row['oid'])->delete(TBL_SHOP_ORDER_PRICE_HISTORY)->exec();

            }
        }
    }
}