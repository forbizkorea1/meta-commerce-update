<?php

namespace ForbizScm\Model;

/**
 * 통계 모델
 *
 * @author hoksi
 */
class Statistics extends \ForbizModel
{

    //상품별 통계를 위해서 group by 를 pid, cid 처럼 pid 를 선행 하고 후속으로 타입을 group 한 데이터를 가지고 있으면 기간별 통계 상품별 통계를 할 수 있을듯한데...
    protected $statisticsTypeOrderArr = [
        'order_date' => '일별 결제금액'
        , 'order_from' => '판매채널별 결제금액'
        , 'sex' => '성별 결제금액'
        , 'age' => '연령별 결제금액'
        , 'region' => '지역별 결제금액'
        , 'payment_agent_type' => '디바이스별 결제금액'
    ];
    protected $statisticsTypeOrderDetailArr = [
        'pid' => '상품별 결제금액'
        ,'cid' => '카테고리별 결제금액'
        , 'brand_code' => '브랜드별 결제금액'
        , 'company_id' => '셀러별 결제금액'
    ];
    protected $statisticsMemTypeArr = [
//        'nation' => '국가별',
        'mem_type' => '회원유형별'
        , 'sex_div' => '성별'
        , 'birthday' => '연령별'
        , 'sns_type' => 'SNS회원별'
    ];

    protected $statisticsMemNation = [
        'all' => '전체국가회원'
        ,'kr' => '대한민국'
        , 'us' => '미국'
        , 'cn' => '중국'
        , 'jp' => '일본'
        , 'etc' => '기타 국가'
    ];
    protected $statisticsMemDiv = [
        'nation' => [
            'all' => '전체국가회원'
            ,'kr' => '대한민국'
            , 'us' => '미국'
            , 'cn' => '중국'
            , 'jp' => '일본'
            , 'etc' => '기타 국가'
        ],
        'mem_type' => [
            'all' => '전체회원유형'
            ,'M' => '일반회원'
            , 'C' => '사업자'
            , 'A' => '직원'
            , 'F' => '외국인'
            , 'etc' => '기타'
        ],
        'sex_div' =>[
            'all' => '전체성별회원'
            ,'M' => '남자회원'
            , 'W' => '여자회원'
            , 'etc' => '성별없음'
        ],
        'birthday' => [
            'all' => '전체연령회원'
            ,'00대' => '10세미만'
            , '10대' => '10대'
            , '20대' => '20대'
            , '30대' => '30대'
            , '40대' => '40대'
            , '50대' => '50대'
            , '60대' => '60대'
            , '70대' => '70대'
            , '80대' => '80대'
            , '90대' => '90대'
            , 'etc' => '기타'
        ],
        'sns_type' => [
            'all' => '전체국가회원'
            ,'naver' => '네이버간편로그인'
            , 'kakao' => '카카오간편로그인'
            , 'facebook' => '페이스북간편로그인'
            , 'google' => '구글로그인'
            , 'apple' => '애플로그인'
            , 'etc' => '기타'
        ]
    ];
    protected $statisticsTypeOrderDetail = [];
    protected $statisticsTypeOrder = [];
    protected $statisticsMemType = [];
    protected $statisticsDate;
    protected $statisticsMonth;
    protected $statisticsSdate = false;
    protected $statisticsEdate = false;

    public function __construct()
    {
        parent::__construct();


        $this->statisticsDate = date('Y-m-d',strtotime('-1 days'));
        $this->statisticsTypeOrderDetail = $this->statisticsTypeOrderDetailArr;
        $this->statisticsTypeOrder = $this->statisticsTypeOrderArr;
        $this->statisticsMemType = $this->statisticsMemTypeArr;
        $this->statisticsMonth = date('m',strtotime($this->statisticsDate));
    }

    public function setStatisticsTypeOrder($type)
    {
        $this->statisticsTypeOrder = $this->statisticsTypeOrderArr[$type];
    }
    public function setStatisticsDate($date)
    {
        $this->statisticsDate = date('Y-m-d',strtotime($date));
        $this->statisticsMonth = date('m',strtotime($this->statisticsDate));
    }
    public function setStatisticsTypeOrderDetail($type)
    {
        $this->statisticsTypeOrderDetail = $this->statisticsTypeOrderDetailArr[$type];
    }

    public function setStatisticsMemType($type)
    {
        $this->statisticsMemType = $this->statisticsMemTypeArr[$type];
    }

    public function setStatisticsSearchDate($sDate,$eDate)
    {
        $this->statisticsSdate = $sDate;
        $this->statisticsEdate = $eDate;
    }

    public function getStatisticsSearchDate()
    {
        if($this->statisticsSdate && $this->statisticsEdate){
            return [
                'sDate' => $this->statisticsSdate
                ,'eDate' => $this->statisticsEdate
            ];
        }
        return false;
    }

    /**
     * @return array|string[]
     */
    public function getStatisticsTypeOrder(): array
    {
        return $this->statisticsTypeOrder;
    }
    public function getStatisticsTypeOrderDetail(): array
    {
        return $this->statisticsTypeOrderDetail;
    }
    public function getReplaceRefundStatistics(){
        $return = [];
        foreach($this->statisticsTypeOrder as $key => $val){
            $return[$key] = str_replace('결제','환불',$val);
        }
        return $return;
    }

    /**
     * @return array|string[]
     */
    public function getStatisticsMemType(): array
    {
        return $this->statisticsMemType;
    }

    private function getStatisticeTable($date)
    {
        return
            $this->qb
                ->select('oid')
                ->select('od_ix')
                ->select('cid')
                ->select("if(brand_code != '0',brand_code,'etc' ) as brand_code",false)
                ->select('company_id')
                ->select('order_from')
                ->select('coprice')
                ->select('listprice')
                ->select('psprice')
                ->select('dcprice')
                ->select('ptprice')
                ->select('pt_dcprice')
                ->select('status')
                ->select('refund_status')
                ->select('pid')
                ->select('pname')
                ->select('pcnt')
                ->select("DATE_FORMAT( od.$date, '%Y-%m-%d' ) as order_date",false)
                ->select(
                    $this->qb->startSubQuery('sex')
                        ->select("IF(sex != '',sex,'X')")
                        ->from(TBL_SHOP_ORDER . ' as o')
                        ->where('o.oid', 'od.oid', false)
                        ->endSubQuery(), false
                )
                ->select('IFNULL('.$this->qb
                        ->startSubQuery()
                        ->select("IFNULL(IF(LENGTH(age) = 1,CONCAT(age,'0대'),CONCAT(LEFT(age,1),'0대')),'etc')")
                        ->from(TBL_SHOP_ORDER . ' as o')
                        ->where('o.oid', 'od.oid', false)
                        ->where('o.age !=',"''",false)
                        ->endSubQuery()
                    .', 0) AS age')
                ->select('IFNULL('.$this->qb
                        ->startSubQuery()
                        ->select("if(sc.code_name !='',sc.code_name,'기타')")
                        ->from(TBL_SHOP_ORDER_DETAIL_DELIVERYINFO . ' as odd')
                        ->join(TBL_FB_STATISTICE_CODE .' as sc',"(LEFT(odd.zip,2))=sc.code",'left')
                        ->where('odd.oid', 'od.oid', false)
                        ->where('odd.order_type', 1)
                        ->where('odd.zip !=',"''",false)
                        ->where('sc.type','1')
                        ->endSubQuery()
                    .', "기타") AS region')
                ->select(
                    $this->qb->startSubQuery('payment_agent_type')
                        ->select('payment_agent_type')
                        ->from(TBL_SHOP_ORDER . ' as o')
                        ->where('o.oid', 'od.oid', false)
                        ->endSubQuery(), false
                )
                ->select("DATE_FORMAT(od.ic_date, '%H') as time")
                ->from(TBL_SHOP_ORDER_DETAIL . ' od')
                ->betweenDate('od.'.$date, "$this->statisticsDate", "$this->statisticsDate")
                ->whereNotIn('od.status', ['SR'])
                ->toStr();
    }
    public function cronFbStatistics($stType)
    {
        $salesTb = $this->getStatisticeTable('ic_date');
        $refundTb = $this->getStatisticeTable('fc_date');

        if($stType == 'order'){
            foreach ($this->statisticsTypeOrder as $key => $val) {
                $main = "db.".$key;
                $sub = "cdb.".$key;


                $basic = $this->qb
                    ->select("'$stType' as st_div", false)
                    ->select("'$key' as type",false)
                    ->select("db.$key as type_value" ,false)
                    ->select("'$this->statisticsMonth' as base_month" ,false)
                    ->select("'$this->statisticsDate' as base_date" ,false)
                    ->select("count(distinct db.oid) as s_order_cnt",false)
                    ->select("count(distinct db.od_ix) as s_order_detail_cnt",false)

                    ->select($this->qb->startSubQuery('s_coprice')
                        ->selectSum('(CASE WHEN  (refund_status != "FC" or refund_status is null)  THEN coprice ELSE 0 END)','s_coprice')
                        ->from("($salesTb)" .' as cdb')
                        ->where($main,$sub,false)
                        ->groupBy("$sub")
                        ->endSubQuery(), false)
                    ->select($this->qb->startSubQuery('s_listprice')
                        ->selectSum('(CASE WHEN  (refund_status != "FC" or refund_status is null)  THEN listprice ELSE 0 END)','s_listprice')
                        ->from("($salesTb)" .' as cdb')
                        ->where($main,$sub,false)
                        ->groupBy("$sub")
                        ->endSubQuery(), false)
                    ->select($this->qb->startSubQuery('s_psprice')
                        ->selectSum('(CASE WHEN  (refund_status != "FC" or refund_status is null)  THEN psprice ELSE 0 END)','s_psprice')
                        ->from("($salesTb)" .' as cdb')
                        ->where($main,$sub,false)
                        ->groupBy("$sub")
                        ->endSubQuery(), false)
                    ->select($this->qb->startSubQuery('s_dc_price')
                        ->selectSum('(CASE WHEN  (refund_status != "FC" or refund_status is null)  THEN dcprice ELSE 0 END)','s_dc_price')
                        ->from("($salesTb)" .' as cdb')
                        ->where($main,$sub,false)
                        ->groupBy("$sub")
                        ->endSubQuery(), false)
                    ->select($this->qb->startSubQuery('s_ptprice')
                        ->selectSum('(CASE WHEN  (refund_status != "FC" or refund_status is null)  THEN ptprice ELSE 0 END)','s_ptprice')
                        ->from("($salesTb)" .' as cdb')
                        ->where($main,$sub,false)
                        ->groupBy("$sub")
                        ->endSubQuery(), false)
                    ->select($this->qb->startSubQuery('s_pt_dcprice')
                        ->selectSum('(CASE WHEN  (refund_status != "FC" or refund_status is null)  THEN pt_dcprice ELSE 0 END)','s_pt_dcprice')
                        ->from("($salesTb)" .' as cdb')
                        ->where($main,$sub,false)
                        ->groupBy("$sub")
                        ->endSubQuery(), false)
                    ->select(
                        $this->qb->startSubQuery('s_cancel_cnt')
                            ->selectSum('(CASE WHEN (status = "CC" and refund_status = "FC") THEN pcnt ELSE 0 END)','s_cancel_cnt')
                            ->from("($refundTb)" .' as cdb')
                            ->where($main,$sub,false)
                            ->groupBy("$sub")
                            ->endSubQuery(), false)
                    ->select($this->qb->startSubQuery('s_cancel_price')
                        ->selectSum('(CASE WHEN (status = "CC" and refund_status = "FC") THEN pt_dcprice ELSE 0 END)','s_cancel_price')
                        ->from("($refundTb)" .' as cdb')
                        ->where($main,$sub,false)
                        ->groupBy("$sub")
                        ->endSubQuery(), false)
                    ->select($this->qb->startSubQuery('s_return_cnt')
                        ->selectSum('(CASE WHEN (status = "RC" and refund_status = "FC") THEN pcnt ELSE 0 END)','s_return_cnt')
                        ->from("($refundTb)" .' as cdb')
                        ->where($main,$sub,false)
                        ->groupBy("$sub")
                        ->endSubQuery(), false)
                    ->select($this->qb->startSubQuery('s_return_price')
                        ->selectSum('(CASE WHEN (status = "RC" and refund_status = "FC") THEN pt_dcprice ELSE 0 END)','s_return_price')
                        ->from("($refundTb)" .' as cdb')
                        ->where($main,$sub,false)
                        ->groupBy("$sub")
                        ->endSubQuery(), false)
                    ->from("($salesTb  UNION ALL  $refundTb ) as db")
                    ->groupBy("$main")
                    ->exec()
                    ->getResultArray();

                $this->insertStatistics($basic);


            }
        }else if ($stType == 'orderDetail'){
            foreach ($this->statisticsTypeOrderDetail as $key => $val) {
                $main = "db.".$key;
                $sub = "cdb.".$key;

                $basic = $this->qb
                    ->select("'$stType' as st_div", false)
                    ->select("'$key' as type",false)
                    ->select("db.$key as type_value" ,false)
                    ->select("'$this->statisticsMonth' as base_month" ,false)
                    ->select("'$this->statisticsDate' as base_date" ,false)
                    ->select("count(distinct db.oid) as s_order_cnt",false)
                    ->select("count(distinct db.od_ix) as s_order_detail_cnt",false)

                    ->select($this->qb->startSubQuery('s_coprice')
                        ->selectSum('(CASE WHEN (refund_status != "FC" or refund_status is null) THEN coprice ELSE 0 END)','s_coprice')
                        ->from("($salesTb)" .' as cdb')
                        ->where($main,$sub,false)
                        ->groupBy("$sub")
                        ->endSubQuery(), false)
                    ->select($this->qb->startSubQuery('s_listprice')
                        ->selectSum('(CASE WHEN  (refund_status != "FC" or refund_status is null)  THEN listprice ELSE 0 END)','s_listprice')
                        ->from("($salesTb)" .' as cdb')
                        ->where($main,$sub,false)
                        ->groupBy("$sub")
                        ->endSubQuery(), false)
                    ->select($this->qb->startSubQuery('s_psprice')
                        ->selectSum('(CASE WHEN  (refund_status != "FC" or refund_status is null)  THEN psprice ELSE 0 END)','s_psprice')
                        ->from("($salesTb)" .' as cdb')
                        ->where($main,$sub,false)
                        ->groupBy("$sub")
                        ->endSubQuery(), false)
                    ->select($this->qb->startSubQuery('s_dc_price')
                        ->selectSum('(CASE WHEN  (refund_status != "FC" or refund_status is null)  THEN dcprice ELSE 0 END)','s_dc_price')
                        ->from("($salesTb)" .' as cdb')
                        ->where($main,$sub,false)
                        ->groupBy("$sub")
                        ->endSubQuery(), false)
                    ->select($this->qb->startSubQuery('s_ptprice')
                        ->selectSum('(CASE WHEN  (refund_status != "FC" or refund_status is null)  THEN ptprice ELSE 0 END)','s_ptprice')
                        ->from("($salesTb)" .' as cdb')
                        ->where($main,$sub,false)
                        ->groupBy("$sub")
                        ->endSubQuery(), false)
                    ->select($this->qb->startSubQuery('s_pt_dcprice')
                        ->selectSum('(CASE WHEN  (refund_status != "FC" or refund_status is null)  THEN pt_dcprice ELSE 0 END)','s_pt_dcprice')
                        ->from("($salesTb)" .' as cdb')
                        ->where($main,$sub,false)
                        ->groupBy("$sub")
                        ->endSubQuery(), false)
                    ->select(
                        $this->qb->startSubQuery('s_cancel_cnt')
                            ->selectSum('(CASE WHEN status = "CC" THEN pcnt ELSE 0 END)','s_cancel_cnt')
                            ->from("($refundTb)" .' as cdb')
                            ->where($main,$sub,false)
                            ->groupBy("$sub")
                            ->endSubQuery(), false)
                    ->select($this->qb->startSubQuery('s_cancel_price')
                        ->selectSum('(CASE WHEN status = "CC" THEN pt_dcprice ELSE 0 END)','s_cancel_price')
                        ->from("($refundTb)" .' as cdb')
                        ->where($main,$sub,false)
                        ->groupBy("$sub")
                        ->endSubQuery(), false)
                    ->select($this->qb->startSubQuery('s_return_cnt')
                        ->selectSum('(CASE WHEN status = "RC" THEN pcnt ELSE 0 END)','s_return_cnt')
                        ->from("($refundTb)" .' as cdb')
                        ->where($main,$sub,false)
                        ->groupBy("$sub")
                        ->endSubQuery(), false)
                    ->select($this->qb->startSubQuery('s_return_price')
                        ->selectSum('(CASE WHEN status = "RC" THEN pt_dcprice ELSE 0 END)','s_return_price')
                        ->from("($refundTb)" .' as cdb')
                        ->where($main,$sub,false)
                        ->groupBy("$sub")
                        ->endSubQuery(), false)
                    ->from("($salesTb  UNION ALL  $refundTb ) as db")
                    ->groupBy("$main")
                    ->exec()
                    ->getResultArray();
//                echo $this->qb->lastQuery();
//                exit;
                $this->insertStatistics($basic);


            }
        }else if ($stType == 'product'){
            foreach ($this->statisticsTypeOrderDetail as $key => $val) {
                $main = "db.".$key;
                $sub = "cdb.".$key;

                $basic = $this->qb
                    ->select("'$stType' as st_div", false)
                    ->select("'$key' as type",false)
                    ->select("db.$key as type_value" ,false)
                    ->select('LPAD(db.pid,10,0) as pid',false)
                    ->select('db.pname')
                    ->select("'$this->statisticsMonth' as base_month" ,false)
                    ->select("'$this->statisticsDate' as base_date" ,false)
                    ->select("count(distinct db.oid) as s_order_cnt",false)
                    ->select("count(distinct db.od_ix) as s_order_detail_cnt",false)

                    ->select($this->qb->startSubQuery('s_coprice')
                        ->selectSum('(CASE WHEN  (refund_status != "FC" or refund_status is null)  THEN coprice ELSE 0 END)','s_coprice')
                        ->from("($salesTb)" .' as cdb')
                        ->where($main,$sub,false)
                        ->where('db.pid','cdb.pid',false)
                        ->groupBy("$sub")
                        ->endSubQuery(), false)
                    ->select($this->qb->startSubQuery('s_listprice')
                        ->selectSum('(CASE WHEN  (refund_status != "FC" or refund_status is null)  THEN listprice ELSE 0 END)','s_listprice')
                        ->from("($salesTb)" .' as cdb')
                        ->where($main,$sub,false)
                        ->where('db.pid','cdb.pid',false)
                        ->groupBy("$sub")
                        ->endSubQuery(), false)
                    ->select($this->qb->startSubQuery('s_psprice')
                        ->selectSum('(CASE WHEN  (refund_status != "FC" or refund_status is null)  THEN psprice ELSE 0 END)','s_psprice')
                        ->from("($salesTb)" .' as cdb')
                        ->where($main,$sub,false)
                        ->where('db.pid','cdb.pid',false)
                        ->groupBy("$sub")
                        ->endSubQuery(), false)
                    ->select($this->qb->startSubQuery('s_dc_price')
                        ->selectSum('(CASE WHEN  (refund_status != "FC" or refund_status is null)  THEN dcprice ELSE 0 END)','s_dc_price')
                        ->from("($salesTb)" .' as cdb')
                        ->where($main,$sub,false)
                        ->where('db.pid','cdb.pid',false)
                        ->groupBy("$sub")
                        ->endSubQuery(), false)
                    ->select($this->qb->startSubQuery('s_ptprice')
                        ->selectSum('(CASE WHEN  (refund_status != "FC" or refund_status is null)  THEN ptprice ELSE 0 END)','s_ptprice')
                        ->from("($salesTb)" .' as cdb')
                        ->where($main,$sub,false)
                        ->where('db.pid','cdb.pid',false)
                        ->groupBy("$sub")
                        ->endSubQuery(), false)
                    ->select($this->qb->startSubQuery('s_pt_dcprice')
                        ->selectSum('(CASE WHEN  (refund_status != "FC" or refund_status is null)  THEN pt_dcprice ELSE 0 END)','s_pt_dcprice')
                        ->from("($salesTb)" .' as cdb')
                        ->where($main,$sub,false)
                        ->where('db.pid','cdb.pid',false)
                        ->groupBy("$sub")
                        ->endSubQuery(), false)
                    ->select(
                        $this->qb->startSubQuery('s_cancel_cnt')
                            ->selectSum('(CASE WHEN status = "CC" THEN pcnt ELSE 0 END)','s_cancel_cnt')
                            ->from("($refundTb)" .' as cdb')
                            ->where($main,$sub,false)
                            ->where('db.pid','cdb.pid',false)
                            ->groupBy("$sub")
                            ->endSubQuery(), false)
                    ->select($this->qb->startSubQuery('s_cancel_price')
                        ->selectSum('(CASE WHEN status = "CC" THEN pt_dcprice ELSE 0 END)','s_cancel_price')
                        ->from("($refundTb)" .' as cdb')
                        ->where($main,$sub,false)
                        ->where('db.pid','cdb.pid',false)
                        ->groupBy("$sub")
                        ->endSubQuery(), false)
                    ->select($this->qb->startSubQuery('s_return_cnt')
                        ->selectSum('(CASE WHEN status = "RC" THEN pcnt ELSE 0 END)','s_return_cnt')
                        ->from("($refundTb)" .' as cdb')
                        ->where($main,$sub,false)
                        ->where('db.pid','cdb.pid',false)
                        ->groupBy("$sub")
                        ->endSubQuery(), false)
                    ->select($this->qb->startSubQuery('s_return_price')
                        ->selectSum('(CASE WHEN status = "RC" THEN pt_dcprice ELSE 0 END)','s_return_price')
                        ->from("($refundTb)" .' as cdb')
                        ->where($main,$sub,false)
                        ->where('db.pid','cdb.pid',false)
                        ->groupBy("$sub")
                        ->endSubQuery(), false)
                    ->from("($salesTb  UNION ALL  $refundTb ) as db")
                    ->groupBy("$main")
                    ->groupBy("pid")
                    ->exec()
                    ->getResultArray();
//                echo $this->qb->lastQuery();
//                exit;
                $this->insertStatistics($basic);


            }
        }


    }
    public function insertStatistics($basic)
    {
        if(is_array($basic)){
            foreach($basic as $item){
                $setItem = [];
                if($item['type'] == 'age'){
                    if(!$item['type_value'] || $item['type_value'] >= 70 || $item['type_value'] < 10){
                        $item['type_value'] = 'etc';
                    }
                }
                //s_order_cnt , s_delivery_price , s_sales_price
                $s_refund_price =$item['s_cancel_price'] + $item['s_return_price'];
                $s_sales_price = $item['s_pt_dcprice'] - $s_refund_price;

                $setItem['st_div'] = $item['st_div'];
                $setItem['type'] = $item['type'];
                $setItem['type_value'] = $item['type_value'];
                $setItem['base_month'] = $item['base_month'];
                $setItem['base_date'] = $item['base_date'];
                $setItem['s_order_cnt'] = $item['s_order_cnt'] ?? 0;
                $setItem['s_order_detail_cnt'] = $item['s_order_detail_cnt'] ?? 0;
                $setItem['s_coprice'] = $item['s_coprice'] ?? 0;
                $setItem['s_listprice'] = $item['s_listprice'] ?? 0;
                $setItem['s_psprice'] = $item['s_psprice'] ?? 0;
                $setItem['s_dc_price'] = $item['s_dc_price'] ?? 0;
                $setItem['s_ptprice'] = $item['s_ptprice'] ?? 0;
                $setItem['s_pt_dcprice'] = $item['s_pt_dcprice'] ?? 0;
                $setItem['s_cancel_cnt'] = $item['s_cancel_cnt'] ?? 0;
                $setItem['s_cancel_price'] = $item['s_cancel_price'] ?? 0;
                $setItem['s_return_cnt'] = $item['s_return_cnt'] ?? 0;
                $setItem['s_return_price'] = $item['s_return_price'] ?? 0;
                $setItem['s_refund_price'] = $s_refund_price ?? 0;
                $setItem['s_delivery_price'] = $item['s_delivery_price'] ?? 0;
                $setItem['s_sales_price'] = $s_sales_price;
                $setItem['regdate'] = fb_now();
                $setItem['pid'] = $item['pid'] ?? 0;
                $setItem['pname'] = $item['pname'] ?? '';

                $this->qb
                    ->delete(TBL_FB_STATISTICE_SALES)
                    ->where('st_div',$item['st_div'])
                    ->where('type',$item['type'])
                    ->where('base_date',$item['base_date'])
                    ->where('type_value',$item['type_value'])
                    ->where('pid',$setItem['pid'])
                    ->exec();
                $this->qb
                    ->set($setItem)
                    ->insert(TBL_FB_STATISTICE_SALES)
                    ->exec();
            }
        }
    }

    public function getRegion()
    {
        $rows = $this->qb
            ->select('code_name')
            ->from(TBL_FB_STATISTICE_CODE)
            ->where('type','1')
            ->where('code_name !=',"''",false)
            ->groupBy('code_name')
            ->orderBy('code')
            ->exec()
            ->getResultArray();
        $field = [];

        foreach($rows as $val){
            $field[] = $val['code_name'];
        }
        return $field;
    }

    private function getDateList($startDate,$endDate)
    {

        return $this->qb->queryBind(
            "SELECT *
                    FROM 
                        (SELECT ADDDATE('1970-01-01',t4*10000 + t3*1000 + t2*100 + t1*10 + t0) GenDate FROM
                        (SELECT 0 t0 UNION SELECT 1 UNION SELECT 2 UNION SELECT 3 UNION SELECT 4 UNION SELECT 5 UNION SELECT 6 UNION SELECT 7 UNION SELECT 8 UNION SELECT 9) t0,
                        (SELECT 0 t1 UNION SELECT 1 UNION SELECT 2 UNION SELECT 3 UNION SELECT 4 UNION SELECT 5 UNION SELECT 6 UNION SELECT 7 UNION SELECT 8 UNION SELECT 9) t1,
                        (SELECT 0 t2 UNION SELECT 1 UNION SELECT 2 UNION SELECT 3 UNION SELECT 4 UNION SELECT 5 UNION SELECT 6 UNION SELECT 7 UNION SELECT 8 UNION SELECT 9) t2,
                        (SELECT 0 t3 UNION SELECT 1 UNION SELECT 2 UNION SELECT 3 UNION SELECT 4 UNION SELECT 5 UNION SELECT 6 UNION SELECT 7 UNION SELECT 8 UNION SELECT 9) t3,
                        (SELECT 0 t4 UNION SELECT 1 UNION SELECT 2 UNION SELECT 3 UNION SELECT 4 UNION SELECT 5 UNION SELECT 6 UNION SELECT 7 UNION SELECT 8 UNION SELECT 9) t4) v
                WHERE GenDate BETWEEN '$startDate' AND '$endDate'
                order by GenDate"
        );
    }

    public function getStatisticsDateList($data)
    {
        $startDate = $data['startDate'];
        $endDate = $data['endDate'];
        $type = $data['type'];
        $st_div = $data['st_div'];

        $dateDb = $this->getDateList($data['startDate'],$data['endDate']);

        // 쿼리 캐시 시작
        $this->qb->startCache();

        $this->qb
            ->select('d.GenDate as base_date',false)
            ->from("($dateDb) as d")
            ->join(TBL_FB_STATISTICE_SALES.' as s',"d.GenDate = s.base_date and s.st_div = '$st_div' and s.type = '$type' and s.base_date between '$startDate' and '$endDate' ",'left')
          ;
        // 쿼리 캐시 끝
        $this->qb->stopCache();

        // total 산출
        $total = $this->qb->getCount('distinct GenDate');

        // 페이징 설정
        $paging = $this->qb
            ->setTotalRows($total)
            ->pagination(1, 100000);

        // limit 값 산출
        $limit = 100000;
        $offset = ($paging['offset'] ?? 0);

        $this->qb->orderBy('GenDate');

        $this->qb->groupBy('GenDate');

        $rows = $this->qb
            ->select('"order_date" as type')
            ->select('s.type_value')
            ->selectSum('s.s_order_cnt','order_cnt')
            ->selectSum('s.s_order_detail_cnt','order_detail_cnt')
            ->selectSum('s.s_pt_dcprice','payment_price')
            ->selectSum('s.s_psprice','product_price')
            ->selectSum('s.s_listprice','list_price')
            ->selectSum('s.s_cancel_cnt','cancel_cnt')
            ->selectSum('s.s_cancel_price','cancel_price')
            ->selectSum('s.s_return_cnt','return_cnt')
            ->selectSum('s.s_return_price','return_price')
            ->selectSum('s.s_refund_price','refund_price')
            ->selectSum('s.s_delivery_price','delivery_price')
            ->selectSum('s.s_sales_price','sales_price')
            ->limit($limit, $offset)
            ->exec()
            ->getResultArray();

        $this->qb->flushCache();

        //치환 처리

        $sumData['order_cnt'] = 0;
        $sumData['order_detail_cnt'] = 0;
        $sumData['payment_price'] = 0;
        $sumData['product_price'] = 0;
        $sumData['cancel_price'] = 0;
        $sumData['cancel_cnt'] = 0;
        $sumData['return_cnt'] = 0;
        $sumData['return_price'] = 0;
        $sumData['refund_price'] = 0;
        $sumData['sales_price'] = 0;

        foreach ($rows as $key => $val) {
            $val['order_cnt'] = (int)$val['order_cnt'];
            $val['order_detail_cnt'] = (int)$val['order_detail_cnt'];
            $val['payment_price'] = (float)$val['payment_price'];
            $val['product_price'] = (float)$val['product_price'];
            $val['list_price'] = (float)$val['list_price'];
            $val['cancel_price'] = (float)$val['cancel_price'];
            $val['delivery_price'] = (float)$val['delivery_price'];
            $val['sales_price'] = (float)$val['sales_price'];
            $val['cancel_cnt'] = (int)$val['cancel_cnt'];
            $val['return_cnt'] = (int)$val['return_cnt'];
            $val['return_price'] = (float)$val['return_price'];
            $val['refund_price'] = (float)$val['refund_price'];

            $sumData['order_cnt'] += $val['order_cnt'];
            $sumData['order_detail_cnt'] += $val['order_detail_cnt'];
            $sumData['payment_price'] += $val['payment_price'];
            $sumData['product_price'] += $val['product_price'];
            $sumData['cancel_price'] += $val['cancel_price'];
            $sumData['sales_price'] += $val['sales_price'];

            $sumData['cancel_cnt'] += $val['cancel_cnt'];
            $sumData['return_cnt'] += $val['return_cnt'];
            $sumData['return_price'] += $val['return_price'];
            $sumData['refund_price'] += $val['refund_price'];

            $val['type_text'] = $val['base_date'];

            $val['startDate'] = $startDate;
            $val['endDate'] = $endDate;

            $rows[$key] = $val;
        }
        //echo $this->qb->lastQuery();
        return [
            'total' => $total,
            'list' => $rows,
            'paging' => $paging,
            'sumData' =>$sumData
        ];
    }

    public function getStatisticsList($data,$pageType='sales')
    {
        $startDate = $data['startDate'];
        $endDate = $data['endDate'];
        $type = $data['type'];
        $st_div = $data['st_div'];
        if($type=='region'){
            $regionArr = $this->getRegion();
        }

        // 쿼리 캐시 시작
        $this->qb->startCache();

        if($pageType == 'refund'){
            $this->qb->where('s_refund_price >', 0,false);
        }

        $this->qb
            ->where('st_div',$st_div)
            ->where('type',$type)
            ->betweenDate('base_date',$startDate,$endDate)
            ->from(TBL_FB_STATISTICE_SALES);
        // 쿼리 캐시 끝
        $this->qb->stopCache();

        // total 산출
        if($type=='cid'){
            $total = $this->qb->getCount('distinct LEFT(type_value, 3)');
        }else{
            $total = $this->qb->getCount('distinct type_value');
        }


        // 페이징 설정
        $paging = $this->qb
            ->setTotalRows($total)
            ->pagination(1, 100000);

        // limit 값 산출
        $limit = 100000;
        $offset = ($paging['offset'] ?? 0);


        if($type=='region'){
            $regionArr = array_merge($regionArr,['기타']);
            $regionOrder = sprintf('FIELD(type_value, "%s")', implode('", "', $regionArr)) ." asc";

            $this->qb->orderBy($regionOrder);
        }else{
            $this->qb->orderBy('type_value');
        }

        if($type=='cid'){
            $this->qb->select('LEFT(type_value,3) as cid',false);
            $this->qb->groupBy('LEFT(type_value,3)');
        }else{
            $this->qb->groupBy('type_value');
        }


        $rows = $this->qb
            ->select('type')
            ->select('type_value')
            ->selectSum('s_order_cnt','order_cnt')
            ->selectSum('s_order_detail_cnt','order_detail_cnt')
            ->selectSum('s_pt_dcprice','payment_price')
            ->selectSum('s_psprice','product_price')
            ->selectSum('s_listprice','list_price')
            ->selectSum('s_cancel_price','cancel_price')
            ->selectSum('s_cancel_cnt','cancel_cnt')
            ->selectSum('s_return_cnt','return_cnt')
            ->selectSum('s_return_price','return_price')
            ->selectSum('s_refund_price','refund_price')
            ->selectSum('s_delivery_price','delivery_price')
            ->selectSum('s_sales_price','sales_price')
            ->limit($limit, $offset)
            ->exec()
            ->getResultArray();
//echo $this->qb->lastQuery();
//exit;
        $this->qb->flushCache();

        //치환 처리
        /* @var $categoryModel \CustomScm\Model\Product\Category */
        $categoryModel = $this->import('model.scm.product.category');
        /* @var $brandModel \CustomScm\Model\Product\Brand */
        $brandModel = $this->import('model.scm.product.brand');
        /* @var $companyModel \CustomScm\Model\Company\Company */
        $companyModel = $this->import('model.scm.company.company');
        /* @var $productModel \CustomScm\Model\Product\Product */
        $productModel = $this->import('model.scm.product.product');

        $sumData['order_cnt'] = 0;
        $sumData['order_detail_cnt'] = 0;
        $sumData['payment_price'] = 0;
        $sumData['product_price'] = 0;
        $sumData['list_price'] = 0;
        $sumData['cancel_price'] = 0;
        $sumData['cancel_cnt'] = 0;
        $sumData['return_cnt'] = 0;
        $sumData['return_price'] = 0;
        $sumData['refund_price'] = 0;
        $sumData['sales_price'] = 0;

        foreach ($rows as $key => $val) {
            $val['order_cnt'] = (int)$val['order_cnt'];
            $val['order_detail_cnt'] = (int)$val['order_detail_cnt'];
            $val['payment_price'] = (float)$val['payment_price'];
            $val['product_price'] = (float)$val['product_price'];
            $val['list_price'] = (float)$val['list_price'];
            $val['cancel_price'] = (float)$val['cancel_price'];
            $val['cancel_cnt'] = (int)$val['cancel_cnt'];
            $val['return_cnt'] = (int)$val['return_cnt'];
            $val['return_price'] = (float)$val['return_price'];
            $val['refund_price'] = (float)$val['refund_price'];
            $val['refund_cnt'] = $val['cancel_cnt'] + $val['return_cnt'];
            $val['delivery_price'] = (float)$val['delivery_price'];
            $val['sales_price'] = (float)$val['sales_price'];

            $sumData['order_cnt'] += $val['order_cnt'];
            $sumData['order_detail_cnt'] += $val['order_detail_cnt'];
            $sumData['payment_price'] += $val['payment_price'];
            $sumData['product_price'] += $val['product_price'];
            $sumData['cancel_price'] += $val['cancel_price'];
            $sumData['sales_price'] += $val['sales_price'];

            $sumData['list_price'] += $val['list_price'];
            $sumData['cancel_cnt'] += $val['cancel_cnt'];
            $sumData['return_cnt'] += $val['return_cnt'];
            $sumData['return_price'] += $val['return_price'];
            $sumData['refund_price'] += $val['refund_price'];


            switch ($type){
                case 'cid':
                    $pathData = $categoryModel->getCategoryPath($val['type_value'], 0);
                    $val['type_value'] = str_pad($val['cid'],15,0,STR_PAD_RIGHT);
                    if(empty($pathData)){
                        $cname = '기타';
                    }else{
                        $cname = implode(" > ", array_column($pathData, 'cname'));
                    }
                    $val['type_text'] = $cname;
                    break;
                case 'brand_code':
                    $pathData = $brandModel->get($val['type_value']);
                    $val['type_text'] = $pathData['brand_name'] ?? '기타';
                    break;
                case 'company_id':
                    $pathData = $companyModel->getManageCompany($val['type_value']);
                    $val['type_text'] = $pathData['data']['com_name'] ?? '기타';
                    break;
                case 'sex':
                    switch ($val['type_value'] ){
                        case 'M':
                            $val['type_text'] = '남성';
                            break;
                        case 'W':
                            $val['type_text'] = '여성';
                            break;
                        default:
                            $val['type_text'] = '기타';
                            break;
                    }
                    break;
                case 'age':
                    $val['type_text'] = $val['type_value'];
                    break;
                case 'payment_agent_type':
                    switch ($val['type_value'] ){
                        case 'M':
                            $val['type_text'] = '모바일';
                            break;
                        case 'W':
                            $val['type_text'] = '웹';
                            break;
                        case 'A':
                            $val['type_text'] = 'APP';
                            break;
                        default:
                            $val['type_text'] = '기타';
                            break;
                    }
                    break;
                case 'time':
                    $val['type_text'] = $val['type_value'].'시';
                    break;
                case 'pid':
                    $val['type_text'] = $productModel->getPnameById($val['type_value']);
                    break;
                default:
                    $val['type_text'] = $val['type_value'] ?? '기타';
                    break;

            }

            $val['startDate'] = $startDate;
            $val['endDate'] = $endDate;

            $rows[$key] = $val;
        }
        //echo $this->qb->lastQuery();
        return [
            'total' => $total,
            'list' => $rows,
            'paging' => $paging,
            'sumData' =>$sumData
        ];
    }


    public function getStatisticsDetailList($type,$typeValue,$st_div,$startDate,$endDate,$pageType='sales')
    {
        if($type == 'cid') {
            /* @var $categoryModel \CustomScm\Model\Product\Category */
            $categoryModel = $this->import('model.scm.product.category');
            $depth = $categoryModel->getDepth($typeValue);

        }


        $dateDb = $this->getDateList($startDate,$endDate);

        if($pageType == 'refund'){
            $this->qb->where('s.s_refund_price >',0,false);
        }

        if($type == 'cid'){
            $this->qb->where("s.type_value LIKE CONCAT(SUBSTR('$typeValue', 1, 3 * ($depth+ 1)),'%')");
        }else{
            $this->qb->where('s.type_value',$typeValue);
        }
        $statisticsDb = $this->qb
            ->where('s.type',$type)
            ->where('s.st_div',$st_div)
            ->betweenDate('s.base_date',$startDate,$endDate)
            ->from(TBL_FB_STATISTICE_SALES.' as s')
            ->toStr();

        // 쿼리 캐시 시작
        $this->qb->startCache();


        $this->qb
            ->select('d.GenDate as base_date',false)
            ->from("($dateDb) as d")
            ->join("($statisticsDb) as sd",'d.GenDate = sd.base_date','left');
        // 쿼리 캐시 끝
        $this->qb->stopCache();

        // total 산출
        $total = $this->qb->getCount('distinct d.GenDate');

        // 페이징 설정
        $paging = $this->qb
            ->setTotalRows($total)
            ->pagination(1, 100000);

        // limit 값 산출
        $limit = 100000;
        $offset = ($paging['offset'] ?? 0);

        $rows = $this->qb
            ->select('sd.type')
            ->select('sd.type_value')
            ->selectSum('sd.s_order_cnt','order_cnt')
            ->selectSum('sd.s_order_detail_cnt','order_detail_cnt')
            ->selectSum('sd.s_pt_dcprice','payment_price')
            ->selectSum('sd.s_psprice','product_price')
            ->selectSum('sd.s_listprice','list_price')
            ->selectSum('sd.s_cancel_cnt','cancel_cnt')
            ->selectSum('sd.s_cancel_price','cancel_price')
            ->selectSum('sd.s_return_cnt','return_cnt')
            ->selectSum('sd.s_return_price','return_price')
            ->selectSum('sd.s_refund_price','refund_price')
            ->selectSum('sd.s_delivery_price','delivery_price')
            ->selectSum('sd.s_sales_price','sales_price')
            ->groupBy('d.GenDate')
            ->orderBy('d.GenDate')
            ->limit($limit, $offset)
            ->exec()
            ->getResultArray();
       // echo $this->qb->lastQuery();
        $this->qb->flushCache();

        //치환 처리
        /* @var $categoryModel \CustomScm\Model\Product\Category */
        $categoryModel = $this->import('model.scm.product.category');
        foreach ($rows as $key => $val) {

            $val['type_text'] = $val['base_date'];
            $val['startDate'] = $startDate;
            $val['endDate'] = $endDate;

            $rows[$key] = $val;
        }
        //echo $this->qb->lastQuery();
        return [
            'total' => $total,
            'list' => $rows,
            'paging' => $paging
        ];
    }

    public function getStatisticsProductList($type,$typeValue,$startDate,$endDate,$pageType='sales')
    {

        if($type == 'cid') {
            /* @var $categoryModel \CustomScm\Model\Product\Category */
            $categoryModel = $this->import('model.scm.product.category');
            $depth = $categoryModel->getDepth($typeValue);

        }


          // 쿼리 캐시 시작
        $this->qb->startCache();

        if($pageType == 'refund'){
            $this->qb->where('s.s_refund_price >',0,false);
        }

        if($type == 'cid'){
            $this->qb->where("s.type_value LIKE CONCAT(SUBSTR('$typeValue', 1, 3 * ($depth+ 1)),'%')");
        }else{
            $this->qb->where('s.type_value',$typeValue);
        }


        $this->qb
            ->where('s.type',$type)
            ->where('s.st_div','product')
            ->betweenDate('s.base_date',$startDate,$endDate)
            ->from(TBL_FB_STATISTICE_SALES .' as s');
        // 쿼리 캐시 끝
        $this->qb->stopCache();

        // total 산출
        $total = $this->qb->getCount('distinct s.pid');

        // 페이징 설정
        $paging = $this->qb
            ->setTotalRows($total)
            ->pagination(1, 100000);

        // limit 값 산출
        $limit = 100000;
        $offset = ($paging['offset'] ?? 0);

        $this->qb
        ->select($this->qb->startSubQuery('pname')
            ->select('cs.pname')
        ->from(TBL_FB_STATISTICE_SALES .' as cs')
        ->where('max(s.idx)','cs.idx',false)
        ->endSubQuery(), false);

        $rows = $this->qb
            ->select('s.type')
            ->select('s.type_value')
            ->select('s.pid')
            ->selectSum('s.s_order_detail_cnt','order_detail_cnt')
            ->selectSum('s.s_pt_dcprice','payment_price')
            ->selectSum('s.s_psprice','product_price')
            ->selectSum('s.s_listprice','list_price')
            ->selectSum('s.s_cancel_cnt','cancel_cnt')
            ->selectSum('s.s_cancel_price','cancel_price')
            ->selectSum('s.s_return_cnt','return_cnt')
            ->selectSum('s.s_return_price','return_price')
            ->selectSum('s.s_refund_price','refund_price')
            ->selectSum('s.s_delivery_price','delivery_price')
            ->selectSum('s.s_sales_price','sales_price')
            ->groupBy('s.pid')
            ->limit($limit, $offset)
            ->exec()
            ->getResultArray();
        //echo $this->qb->lastQuery();
        $this->qb->flushCache();

        //치환 처리
        foreach ($rows as $key => $val) {

            $val['startDate'] = $startDate;
            $val['endDate'] = $endDate;

            $rows[$key] = $val;
        }
        //echo $this->qb->lastQuery();
        return [
            'total' => $total,
            'list' => $rows,
            'paging' => $paging
        ];
    }

    public function cronFbStatisticsMember()
    {

        $userTb = $this->getStatisticeMemberTable('user');
        $dropTb = $this->getStatisticeMemberTable('drop');
        $sleepTb = $this->getStatisticeMemberTable('sleep');


        foreach ($this->statisticsMemType as $key => $val) {

            $basic = $this->qb
                ->select("'$key' as type",false)
                ->select("b.$key as type_value" ,false)
                ->select("'$this->statisticsMonth' as base_month" ,false)
                ->select("'$this->statisticsDate' as base_date" ,false)
                ->select(
                    $this->qb->startSubQuery('user_cnt')
                        ->select("count(u.$key)",'user_cnt')
                        ->from("($userTb)" .' as u')
                        ->where('b.base_date','u.base_date',false)
                        ->where("b.$key","u.$key",false)
                        ->endSubQuery(), false)
                ->select(
                    $this->qb->startSubQuery('drop_cnt')
                        ->select("count(d.$key)",'drop_cnt')
                        ->from("($dropTb)" .' as d')
                        ->where('b.base_date','d.base_date',false)
                        ->where("b.$key","d.$key",false)
                        ->endSubQuery(), false)
                ->select(
                    $this->qb->startSubQuery('sleep_cnt')
                        ->select("count(s.$key)",'sleep_cnt')
                        ->from("($sleepTb)" .' as s')
                        ->where('b.base_date','s.base_date',false)
                        ->where("b.$key","s.$key",false)
                        ->endSubQuery(), false)
                ->from("($userTb  UNION ALL  $dropTb UNION ALL $sleepTb) as b")
                ->where("b.code is not null",'',false)
                ->groupBy("b.$key")
                ->exec()
                ->getResultArray();
//            echo $this->qb->lastQuery();
//            exit;
//            if($key == 'birthday'){
//                echo $this->qb->lastQuery();
//                exit;
//            }
//            print_r($basic);
//            exit;
            $this->insertStatisticsMember($basic);


        }
    }

    public function cronFbStatisticsMemberAll()
    {

        $userTb = $this->getStatisticeMemberTableAll('user');
        $dropTb = $this->getStatisticeMemberTableAll('drop');
        $sleepTb = $this->getStatisticeMemberTableAll('sleep');


        foreach ($this->statisticsMemType as $key => $val) {

            $type = $key.'_all';
            $basic = $this->qb
                ->select("'$type' as type",false)
                ->select("b.$key as type_value" ,false)
                ->select("'$this->statisticsMonth' as base_month" ,false)
                ->select("'$this->statisticsDate' as base_date" ,false)
                ->select(
                    $this->qb->startSubQuery('user_cnt')
                        ->select("count(u.$key)",'user_cnt')
                        ->from("($userTb)" .' as u')
                        ->where('b.base_date','u.base_date',false)
                        ->where("b.$key","u.$key",false)
                        ->endSubQuery(), false)
                ->select(
                    $this->qb->startSubQuery('drop_cnt')
                        ->select("count(d.$key)",'drop_cnt')
                        ->from("($dropTb)" .' as d')
                        ->where('b.base_date','d.base_date',false)
                        ->where("b.$key","d.$key",false)
                        ->endSubQuery(), false)
                ->select(
                    $this->qb->startSubQuery('sleep_cnt')
                        ->select("count(s.$key)",'sleep_cnt')
                        ->from("($sleepTb)" .' as s')
                        ->where('b.base_date','s.base_date',false)
                        ->where("b.$key","s.$key",false)
                        ->endSubQuery(), false)
                ->from("($userTb  UNION ALL  $dropTb UNION ALL $sleepTb) as b")
                ->where("b.code is not null",'',false)
                ->groupBy("b.$key")
                ->exec()
                ->getResultArray();

            $this->insertStatisticsMember($basic);


        }
    }

    public function cronFbStatisticsMemberSleep()
    {

        $sleepData = $this->qb
            ->select("'$this->statisticsMonth' as base_month" ,false)
            ->select("'$this->statisticsDate' as base_date" ,false)
            ->select("SUM(IF(status = 'A' ,1,0)) as in_sleep",false)
            ->select("SUM(IF(status = 'U' ,1,0)) as out_sleep",false)
                ->from(TBL_COMMON_USER_SLEEP_LOG)
                ->betweenDate('regdate',"$this->statisticsDate", "$this->statisticsDate")
                ->exec()
                ->getResultArray();

        $this->insertStatisticsMemberSleep($sleepData);

    }

    public function insertStatisticsMemberSleep($sleepData)
    {
        if(is_array($sleepData)){
            foreach($sleepData as $item){
                $setItem = [];

                $setItem['base_month'] = $item['base_month'];
                $setItem['base_date'] = $item['base_date'];
                $setItem['in_sleep'] = $item['in_sleep'] ?? 0;
                $setItem['out_sleep'] = $item['out_sleep'] ?? 0;
                $setItem['regdate'] = fb_now();

                $this->qb
                    ->delete(TBL_FB_STATISTICE_MEMBER_SLEEP)
                    ->where('base_date',$item['base_date'])
                    ->exec();
                $this->qb
                    ->set($setItem)
                    ->insert(TBL_FB_STATISTICE_MEMBER_SLEEP)
                    ->exec();
            }
        }
    }
    private function getStatisticeMemberTable($userType)
    {

        switch ($userType){
            case 'user':
                $database = $this->qb
                    ->select('cu.code')
                    ->select("'$this->statisticsDate' as base_date",false)
                    ->select('cu.mem_type')
                    ->select("IFNULL(si.sns_type,'etc') as sns_type",false)
                    ->select('cmd.gp_ix')
                    ->select('cmd.sex_div')
                    ->select("IFNULL(rpad(substring(date_format(now(),'%Y')-date_format(cmd.birthday,'%Y'),1,1),3,'0대'),'etc') as birthday")
                    ->select("'kr' as nation")
                    ->from(TBL_COMMON_USER .' as cu')
                    ->join(TBL_COMMON_MEMBER_DETAIL.' as cmd','cu.code = cmd.code','inner')
                    ->join(TBL_SNS_INFO.' as si','cu.code = si.uid','left')
                    ->betweenDate('cu.date', "$this->statisticsDate", "$this->statisticsDate")
                    ->toStr();
                break;
            case 'drop':
                $database = $this->qb
                    ->select('cd.code')
                    ->select("'$this->statisticsDate' as base_date",false)
                    ->select('cd.mem_type')
                    ->select("IFNULL(si.sns_type,'etc') as sns_type",false)
                    ->select("'0' as gp_ix")
                    ->select("'0' as sex_div")
                    ->select("'etc' as birthday")
                    ->select("'kr' as nation")
                    ->from(TBL_COMMON_DROPMEMBER .' as cd')
                    ->join(TBL_SNS_INFO.' as si','cd.code = si.uid','left')
                    ->betweenDate('cd.dropdate', "$this->statisticsDate", "$this->statisticsDate")
                    ->toStr();
                break;
            case 'sleep':
                $database = $this->qb
                    ->select('cu.code')
                    ->select("'$this->statisticsDate' as base_date",false)
                    ->select('cu.mem_type')
                    ->select("IFNULL(si.sns_type,'etc') as sns_type",false)
                    ->select('cmd.gp_ix')
                    ->select('cmd.sex_div')
                    ->select("IFNULL(rpad(substring(date_format(now(),'%Y')-date_format(cmd.birthday,'%Y'),1,1),3,'0대'),'etc') as birthday")
                    ->select("'kr' as nation")
                    ->from(TBL_COMMON_USER_SLEEP .' as cu')
                    ->join(TBL_COMMON_MEMBER_DETAIL_SLEEP.' as cmd','cu.code = cmd.code','inner')
                    ->join(TBL_COMMON_USER_SLEEP_LOG.' as cus','cu.code = cus.code','inner')
                    ->join(TBL_SNS_INFO.' as si','cu.code = si.uid','left')
                    ->where('cus.change_type' ,'S')
                    ->betweenDate('cus.regdate', "$this->statisticsDate", "$this->statisticsDate")
                    ->toStr();
                break;
        }

        return $database;
    }
    private function getStatisticeMemberTableAll($userType)
    {

        switch ($userType){
            case 'user':
                $database = $this->qb
                    ->select('cu.code')
                    ->select("'$this->statisticsDate' as base_date",false)
                    ->select('cu.mem_type')
                    ->select("IFNULL(si.sns_type,'etc') as sns_type",false)
                    ->select('cmd.gp_ix')
                    ->select('cmd.sex_div')
                    ->select("IFNULL(rpad(substring(date_format(now(),'%Y')-date_format(cmd.birthday,'%Y'),1,1),3,'0대'),'etc') as birthday")
                    ->select("'kr' as nation")
                    ->from(TBL_COMMON_USER .' as cu')
                    ->join(TBL_COMMON_MEMBER_DETAIL.' as cmd','cu.code = cmd.code','inner')
                    ->join(TBL_SNS_INFO.' as si','cu.code = si.uid','left')
                    ->where('cu.date <',  "'$this->statisticsDate'", false)
                    ->toStr();
                break;
            case 'drop':
                $database = $this->qb
                    ->select('cd.code')
                    ->select("'$this->statisticsDate' as base_date",false)
                    ->select('cd.mem_type')
                    ->select("IFNULL(si.sns_type,'etc') as sns_type",false)
                    ->select("'0' as gp_ix")
                    ->select("'0' as sex_div")
                    ->select("'etc' as birthday")
                    ->select("'kr' as nation")
                    ->from(TBL_COMMON_DROPMEMBER .' as cd')
                    ->join(TBL_SNS_INFO.' as si','cd.code = si.uid','left')
                    ->where('cd.dropdate <',  "'$this->statisticsDate'", false)
                    ->toStr();
                break;
            case 'sleep':
                $database = $this->qb
                    ->select('cu.code')
                    ->select("'$this->statisticsDate' as base_date",false)
                    ->select('cu.mem_type')
                    ->select("IFNULL(si.sns_type,'etc') as sns_type",false)
                    ->select('cmd.gp_ix')
                    ->select('cmd.sex_div')
                    ->select("IFNULL(rpad(substring(date_format(now(),'%Y')-date_format(cmd.birthday,'%Y'),1,1),3,'0대'),'etc') as birthday")
                    ->select("'kr' as nation")
                    ->from(TBL_COMMON_USER_SLEEP .' as cu')
                    ->join(TBL_COMMON_MEMBER_DETAIL_SLEEP.' as cmd','cu.code = cmd.code','inner')
                    ->join(TBL_COMMON_USER_SLEEP_LOG.' as cus','cu.code = cus.code','inner')
                    ->join(TBL_SNS_INFO.' as si','cu.code = si.uid','left')
                    ->where('cus.change_type' ,'S')
                    ->where('cu.date <',  "'$this->statisticsDate'", false)
                    ->toStr();
                break;
        }

        return $database;
    }
    public function insertStatisticsMember($basic)
    {
        if(is_array($basic)){
            foreach($basic as $item){
                $setItem = [];

                $setItem['type'] = $item['type'];
                $setItem['type_value'] = $item['type_value'];
                $setItem['base_month'] = $item['base_month'];
                $setItem['base_date'] = $item['base_date'];
                $setItem['user_cnt'] = $item['user_cnt'] ?? 0;
                $setItem['drop_cnt'] = $item['drop_cnt'] ?? 0;
                $setItem['sleep_cnt'] = $item['sleep_cnt'] ?? 0;
                $setItem['regdate'] = fb_now();

                $this->qb
                    ->delete(TBL_FB_STATISTICE_MEMBER)
                    ->where('type',$item['type'])
                    ->where('type_value',$item['type_value'])
                    ->where('base_date',$item['base_date'])
                    ->exec();
                $this->qb
                    ->set($setItem)
                    ->insert(TBL_FB_STATISTICE_MEMBER)
                    ->exec();
            }
        }
    }
    public function getStatisticsMemListAll($data)
    {

        $type = $data['type'];

        $columnArr = $this->statisticsMemDiv[$type];

        $maxItem = $this->qb
            ->selectMax('base_date')
            ->where('type',$type.'_all')
            ->from(TBL_FB_STATISTICE_MEMBER)
            ->exec()
            ->getRowArray();

        $maxDate = $maxItem['base_date'];
        // 쿼리 캐시 시작
        $this->qb->startCache();

        foreach($columnArr as $key=>$val){
            if($key == 'all'){
                $this->qb->select("COALESCE(SUM(user_cnt+sleep_cnt),0) as 'all'",false);
            }else{
                $this->qb->select("COALESCE(SUM(CASE WHEN type_value = '$key' THEN user_cnt+sleep_cnt END),0) as $key",false);
            }
        }
        $this->qb
            ->where('type',$type.'_all')
            ->where('base_date ',$maxDate)
            ->from(TBL_FB_STATISTICE_MEMBER);

        // 쿼리 캐시 끝
        $this->qb->stopCache();

        // total 산출
        $total = $this->qb->getCount('distinct type_value');

        // 페이징 설정
        $paging = $this->qb
            ->setTotalRows($total)
            ->pagination(1, 100000);

        // limit 값 산출
        $limit = 100000;
        $offset = ($paging['offset'] ?? 0);


        $rows = $this->qb
            ->limit($limit, $offset)
            ->exec()
            ->getResultArray();

        $this->qb->flushCache();


        return [
            'total' => $total,
            'list' => $rows,
            'paging' => $paging,
            'addColumn' => $columnArr
        ];
    }

    public function getStatisticsMemListSleep($data)
    {
        $startDate = $data['startDate'];
        $endDate = $data['endDate'];

        // 쿼리 캐시 시작
        $this->qb->startCache();

        $this->qb
            ->betweenDate('base_date',$startDate,$endDate)
            ->from(TBL_FB_STATISTICE_MEMBER_SLEEP);

        // 쿼리 캐시 끝
        $this->qb->stopCache();

        // total 산출
        $total = $this->qb->getCount();

        // 페이징 설정
        $paging = $this->qb
            ->setTotalRows($total)
            ->pagination(1, 100000);

        // limit 값 산출
        $limit = 100000;
        $offset = ($paging['offset'] ?? 0);


        $rows = $this->qb
            ->select('base_date')
            ->select('in_sleep')
            ->select('out_sleep')
            ->limit($limit, $offset)
            ->orderBy('base_date')
            ->exec()
            ->getResultArray();

        $this->qb->flushCache();

        $sumData['in_total'] = 0;
        $sumData['out_total'] = 0;
        //치환 처리
        foreach ($rows as $key => $val) {
            $sumData['in_total'] += $val['in_sleep'];
            $sumData['out_total'] += $val['out_sleep'];

            $val['startDate'] = $startDate;
            $val['endDate'] = $endDate;

            $rows[$key] = $val;
        }

        return [
            'total' => $total,
            'list' => $rows,
            'paging' => $paging,
            'sumData'=>$sumData
        ];
    }

    public function getStatisticsMemListDrop($data)
    {
        $startDate = $data['startDate'];
        $endDate = $data['endDate'];

        $dateDb = $this->getDateList($startDate,$endDate);
        $statisticsDb = $this->qb
            ->where('sm.type','sex_div')
            ->betweenDate('sm.base_date',$startDate,$endDate)
            ->from(TBL_FB_STATISTICE_MEMBER .' as sm')
            ->toStr();

        // 쿼리 캐시 시작
        $this->qb->startCache();

        $this->qb
            ->select('d.GenDate as base_date',false)
            ->from("($dateDb) as d")
            ->join("($statisticsDb) as sd",'d.GenDate = sd.base_date','left');

        // 쿼리 캐시 끝
        $this->qb->stopCache();

        // total 산출
        $total = $this->qb->getCount('distinct d.GenDate');

        // 페이징 설정
        $paging = $this->qb
            ->setTotalRows($total)
            ->pagination(1, 100000);

        // limit 값 산출
        $limit = 100000;
        $offset = ($paging['offset'] ?? 0);


        $rows = $this->qb
            ->select('IFNULL(sd.drop_cnt,0) as drop_cnt',false)
            ->limit($limit, $offset)
            ->groupBy('d.GenDate')
            ->orderBy('d.GenDate')
            ->exec()
            ->getResultArray();

        $this->qb->flushCache();

        $sumData['total_cnt'] = 0;
        //치환 처리
        foreach ($rows as $key => $val) {
            $sumData['total_cnt'] += $val['drop_cnt'];
            //$val['base_date'] = $val['GenDate'];
            $val['all'] = $val['drop_cnt'];
            $val['startDate'] = $startDate;
            $val['endDate'] = $endDate;

            $rows[$key] = $val;
        }

        return [
            'total' => $total,
            'list' => $rows,
            'paging' => $paging,
            'sumData'=>$sumData
        ];
    }
    public function getStatisticsMemList($data)
    {
/*
        select
        COALESCE(SUM(user_cnt+drop_cnt+sleep_cnt),0) as mem_all,
        COALESCE(SUM(CASE WHEN type_value = 'W' THEN user_cnt+drop_cnt+sleep_cnt END),0) as mem_w,
        COALESCE(SUM(CASE WHEN type_value = 'M' THEN user_cnt+drop_cnt+sleep_cnt END),0) as mem_m,
        COALESCE(SUM(CASE WHEN type_value NOT IN ('M','W') THEN user_cnt+drop_cnt+sleep_cnt END),0) as mem_etc
        FROM `fb_statistice_member`
        WHERE `type` = 'sex_div'
        AND base_date BETWEEN '2022-01-01 00:00:00' AND '2022-07-06 23:59:59'
*/
        $startDate = $data['startDate'];
        $endDate = $data['endDate'];
        $type = $data['type'];

        $columnArr = $this->statisticsMemDiv[$type];

        switch($data['st_div']){
            case 'new':
                $columnText = 'sm.user_cnt';
                break;
            case 'drop':
                $columnText = 'sm.drop_cnt';
                break;
            case 'sleep':
                $columnText = 'sm.sleep_cnt';
                break;
        }

        $dateDb = $this->getDateList($startDate,$endDate);

        foreach($columnArr as $key=>$val){
            if($key == 'all'){
                $this->qb->select("COALESCE(SUM($columnText),0) as 'all'",false);
            }else{
                $this->qb->select("COALESCE(SUM(CASE WHEN sm.type_value = '$key' THEN $columnText END),0) as $key",false);
            }
        }
        $columnArr = array_merge(["base_date" => "날짜"], $columnArr);
        $statisticsDb = $this->qb
            ->select('sm.base_date')
            ->where('sm.type',$type)
            ->betweenDate('sm.base_date',$startDate,$endDate)
            ->groupBy('sm.base_date')
            ->from(TBL_FB_STATISTICE_MEMBER .' as sm')
            ->toStr();


        // 쿼리 캐시 시작
        $this->qb->startCache();

        $this->qb
            ->from("($dateDb) as d")
            ->join("($statisticsDb) as sd",'d.GenDate = sd.base_date','left');

        // 쿼리 캐시 끝
        $this->qb->stopCache();

        // total 산출
        $total = $this->qb->getCount('distinct d.GenDate');

        // 페이징 설정
        $paging = $this->qb
            ->setTotalRows($total)
            ->pagination(1, 100000);

        // limit 값 산출
        $limit = 100000;
        $offset = ($paging['offset'] ?? 0);

        foreach($columnArr as $key=>$val){
            if($key != 'base_date'){
                $this->qb->select("IFNULL(`$key`,0) as `$key`",false);
            }

        }

        $rows = $this->qb
            ->select('d.GenDate')
            ->limit($limit, $offset)
            ->groupBy('d.GenDate')
            ->orderBy('d.GenDate')
            ->exec()
            ->getResultArray();
        //echo $this->qb->lastQuery();
        $this->qb->flushCache();

        $sumData['total_cnt'] = 0;

        //치환 처리
        foreach ($rows as $key => $val) {
            $sumData['total_cnt'] += $val['all'];
            $val['base_date'] = $val['GenDate'];
            $val['startDate'] = $startDate;
            $val['endDate'] = $endDate;

            $rows[$key] = $val;
        }
        return [
            'total' => $total,
            'list' => $rows,
            'paging' => $paging,
            'addColumn' => $columnArr,
            'sumData'=>$sumData
        ];
    }

    public function getStatisticsMemDetailList($data)
    {
        $type = $data['type'];
        $typeValue = $data['type_value'];
        $startDate = $data['startDate'];
        $endDate = $data['endDate'];
        // 쿼리 캐시 시작
        $this->qb->startCache();
        $this->qb
            ->where('type',$type)
            ->where('type_value',$typeValue)
            ->betweenDate('base_date',$startDate,$endDate)
            ->from(TBL_FB_STATISTICE_MEMBER);
        // 쿼리 캐시 끝
        $this->qb->stopCache();

        // total 산출
        $total = $this->qb->getCount('distinct type_value');

        // 페이징 설정
        $paging = $this->qb
            ->setTotalRows($total)
            ->pagination(1, 100000);

        // limit 값 산출
        $limit = 100000;
        $offset = ($paging['offset'] ?? 0);

        $rows = $this->qb
            ->select('type')
            ->select('type_value')
            ->select('base_date')
            ->selectSum('user_cnt','sum_user_cnt')
            ->selectSum('drop_cnt','sum_drop_cnt')
            ->selectSum('sleep_cnt','sum_sleep_cnt')
            ->groupBy('base_date')
            ->orderBy('base_date','asc')
            ->limit($limit, $offset)
            ->exec()
            ->getResultArray();

        $this->qb->flushCache();
//        echo $this->qb->lastQuery();
        //치환 처리
        foreach ($rows as $key => $val) {

            $val['type_text'] = $val['base_date'];
            $val['startDate'] = $startDate;
            $val['endDate'] = $endDate;

            $rows[$key] = $val;
        }
        //echo $this->qb->lastQuery();
        return [
            'total' => $total,
            'list' => $rows,
            'paging' => $paging
        ];
    }

    public function cronFbStatisticsPayMethod()
    {
        /**
         * ALTER TABLE `mall_db`.`fb_statistice_pay_method`
        ADD COLUMN `method_1` decimal(10, 2) NULL COMMENT '신용카드 결제금액' AFTER `base_date`,
        ADD COLUMN `method_4` decimal(10, 2) NULL COMMENT '가상계좌 결제금액' AFTER `method_1`,
        ADD COLUMN `method_5` decimal(10, 2) NULL COMMENT '실시간계좌이체 결제금액' AFTER `method_4`;
         */
        /* @var $orderModel \CustomScm\Model\Order\Order */
        $orderModel = $this->import('model.scm.order.order');

        $payData = $this->getPaymentData();
        $this->insertPaymentData();

        if(is_array($payData)){
            foreach($payData as $key=>$val){
                $fields = $this->qb->field_exists('method_'.$val['method'],TBL_FB_STATISTICE_PAY_METHOD);
                $columnName = 'method_'.$val['method'];
                if($fields === false){
                    $methodText = $orderModel->getPaymentMethod($val['method']);
                    $this->qb->exec("ALTER TABLE ".TBL_FB_STATISTICE_PAY_METHOD." ADD COLUMN ".$columnName." decimal(10, 2) NOT NULL COMMENT '$methodText' ");
                }

                $this->setPaymentData($columnName,$val['payment_price']);

            }
        }
    }

    private function setPaymentData($column,$price)
    {
        $this->qb
            ->set($column,$price)
            ->update(TBL_FB_STATISTICE_PAY_METHOD)
            ->where('base_date',$this->statisticsDate)
            ->where('base_month',$this->statisticsMonth)
            ->exec();

    }
    private function insertPaymentData()
    {
        $this->qb
            ->delete(TBL_FB_STATISTICE_PAY_METHOD)
            ->where('base_date',$this->statisticsDate)
            ->where('base_month',$this->statisticsMonth)
            ->exec();

        $this->qb
            ->set('base_date',$this->statisticsDate)
            ->set('base_month',$this->statisticsMonth)
            ->set('regdate',fb_now())
            ->insert(TBL_FB_STATISTICE_PAY_METHOD)
            ->exec();
    }

    private function getPaymentData($payType='G')
    {
        return $this->qb
            ->selectSum('payment_price')
            ->select('method')
            ->from(TBL_SHOP_ORDER_PAYMENT)
            ->where('pay_type',$payType)
            ->where('pay_status','IC')
            ->betweenDate('regdate', "$this->statisticsDate", "$this->statisticsDate")
            ->groupBy('method')
            ->exec()
            ->getResultArray();
    }

    public function getStatisticsPayMethodList($data)
    {
        $startDate = $data['startDate'];
        $endDate = $data['endDate'];

        $dateDb = $this->getDateList($startDate,$endDate);

        $statisticsDb = $this->qb
            ->betweenDate('sp.base_date',$startDate,$endDate)
            ->from(TBL_FB_STATISTICE_PAY_METHOD.' as sp')
            ->toStr();

        // 쿼리 캐시 시작
        $this->qb->startCache();

        $this->qb
            ->select('d.GenDate as base_date',false)
            ->from("($dateDb) as d")
            ->join("($statisticsDb) as sd",'d.GenDate = sd.base_date','left');

        // 쿼리 캐시 끝
        $this->qb->stopCache();

        // total 산출
        $total = $this->qb->getCount();

        // 페이징 설정
        $paging = $this->qb
            ->setTotalRows($total)
            ->pagination(1, 100000);

        // limit 값 산출
        $limit = 100000;
        $offset = ($paging['offset'] ?? 0);


        $this->qb->orderBy('d.base_date');


        $rows = $this->qb
            ->select('d.GenDate')
            ->select('sd.*')
            ->limit($limit, $offset)
            ->groupBy('d.GenDate')
            ->orderBy('d.GenDate')
            ->exec()
            ->getResultArray();

        $this->qb->flushCache();

        //치환 처리]
        /* @var $orderModel \CustomScm\Model\Order\Order */
        $orderModel = $this->import('model.scm.order.order');
        $basicColumn = ['method_1','method_4','method_5'];
        $addColumn = [];
        foreach ($rows as $key => $val) {
//            print_r($val);
//            exit;
            foreach($val as $k => $v){
                //echo $k;
                if(strpos($k,'method_') !== false){
                    if(!in_array($k,$basicColumn)){

                        $addColumn[$k] = $orderModel->getPaymentMethod(str_replace("method_","",$k));
                    }
                }
            }

            $val['startDate'] = $startDate;
            $val['endDate'] = $endDate;
            $val['base_date'] = $val['GenDate'];

            $rows[$key] = $val;
        }
        //echo $this->qb->lastQuery();
        return [
            'total' => $total,
            'list' => $rows,
            'addColumn' => array_unique($addColumn),
            'paging' => $paging
        ];
    }

    public function cronFbStatisticsOrderTime()
    {

        /* @var $orderModel \CustomScm\Model\Order\Order */
        $orderModel = $this->import('model.scm.order.order');

        $salesTb = $this->getOrderTimeData('ic_date');
        $refundTb = $this->getOrderTimeData('fc_date');

        $main = "db.type_value";
        $sub = "cdb.type_value";

        $basic = $this->qb
            ->select("'order' as st_div", false)
            ->select("'time' as type",false)
            ->select("db.type_value" )
            ->select("'$this->statisticsMonth' as base_month" ,false)
            ->select("'$this->statisticsDate' as base_date" ,false)
            ->select("count(distinct db.oid) as s_order_cnt",false)
            ->select("count(distinct db.od_ix) as s_order_detail_cnt",false)
            ->select($this->qb->startSubQuery('s_coprice')
                ->selectSum('(CASE WHEN (refund_status != "FC" or refund_status is null) THEN coprice ELSE 0 END)','s_coprice')
                ->from("($salesTb)" .' as cdb')
                ->where($main,$sub,false)
                ->groupBy("$sub")
                ->endSubQuery(), false)
            ->select($this->qb->startSubQuery('s_listprice')
                ->selectSum('(CASE WHEN (refund_status != "FC" or refund_status is null) THEN listprice ELSE 0 END)','s_listprice')
                ->from("($salesTb)" .' as cdb')
                ->where($main,$sub,false)
                ->groupBy("$sub")
                ->endSubQuery(), false)
            ->select($this->qb->startSubQuery('s_psprice')
                ->selectSum('(CASE WHEN (refund_status != "FC" or refund_status is null) THEN psprice ELSE 0 END)','s_psprice')
                ->from("($salesTb)" .' as cdb')
                ->where($main,$sub,false)
                ->groupBy("$sub")
                ->endSubQuery(), false)
            ->select($this->qb->startSubQuery('s_dc_price')
                ->selectSum('(CASE WHEN (refund_status != "FC" or refund_status is null) THEN dcprice ELSE 0 END)','s_dc_price')
                ->from("($salesTb)" .' as cdb')
                ->where($main,$sub,false)
                ->groupBy("$sub")
                ->endSubQuery(), false)
            ->select($this->qb->startSubQuery('s_ptprice')
                ->selectSum('(CASE WHEN (refund_status != "FC" or refund_status is null) THEN ptprice ELSE 0 END)','s_ptprice')
                ->from("($salesTb)" .' as cdb')
                ->where($main,$sub,false)
                ->groupBy("$sub")
                ->endSubQuery(), false)
            ->select($this->qb->startSubQuery('s_pt_dcprice')
                ->selectSum('(CASE WHEN (refund_status != "FC" or refund_status is null) THEN pt_dcprice ELSE 0 END)','s_pt_dcprice')
                ->from("($salesTb)" .' as cdb')
                ->where($main,$sub,false)
                ->groupBy("$sub")
                ->endSubQuery(), false)
            ->select(
                $this->qb->startSubQuery('s_cancel_cnt')
                    ->selectSum('(CASE WHEN status = "CC" THEN pcnt ELSE 0 END)','s_cancel_cnt')
                    ->from("($refundTb)" .' as cdb')
                    ->where($main,$sub,false)
                    ->groupBy("$sub")
                    ->endSubQuery(), false)
            ->select($this->qb->startSubQuery('s_cancel_price')
                ->selectSum('(CASE WHEN status = "CC" THEN pt_dcprice ELSE 0 END)','s_cancel_price')
                ->from("($refundTb)" .' as cdb')
                ->where($main,$sub,false)
                ->groupBy("$sub")
                ->endSubQuery(), false)
            ->select($this->qb->startSubQuery('s_return_cnt')
                ->selectSum('(CASE WHEN status = "RC" THEN pcnt ELSE 0 END)','s_return_cnt')
                ->from("($refundTb)" .' as cdb')
                ->where($main,$sub,false)
                ->groupBy("$sub")
                ->endSubQuery(), false)
            ->select($this->qb->startSubQuery('s_return_price')
                ->selectSum('(CASE WHEN status = "RC" THEN pt_dcprice ELSE 0 END)','s_return_price')
                ->from("($refundTb)" .' as cdb')
                ->where($main,$sub,false)
                ->groupBy("$sub")
                ->endSubQuery(), false)
            ->from("($salesTb  UNION ALL  $refundTb ) as db")
            ->groupBy("$main")
            ->exec()
            ->getResultArray();

        $this->insertStatistics($basic);

    }

    private function getOrderTimeData($date)
    {

        if($date == 'ic_date'){
            $this->qb->whereNotIn('refund_status',['FC']);
        }else if($date == 'fc_date'){
            $this->qb->whereIn('refund_status',['FC']);
        }

        return $this->qb
            ->select('oid')
            ->select('od_ix')
            ->select('cid')
            ->select('brand_code')
            ->select('company_id')
            ->select('order_from')
            ->select('coprice')
            ->select('listprice')
            ->select('psprice')
            ->select('dcprice')
            ->select('ptprice')
            ->select('pt_dcprice')
            ->select('status')
            ->select('refund_status')
            ->select('pid')
            ->select('pcnt')
            ->select("DATE_FORMAT( od.$date, '%Y-%m-%d' ) as order_date",false)
            ->select("DATE_FORMAT(od.$date, '%H') as time")
            ->select($this->qb
                    ->startSubQuery('type_value')
                    ->select("tc.idx")
                    ->from(TBL_FB_STATISTICE_TIME_CODE . ' as tc')
                    ->betweenColumn("DATE_FORMAT( od.$date, '%H:%i:%s' )",'tc.s_time','tc.e_time')
                    ->endSubQuery()
                )
            ->from(TBL_SHOP_ORDER_DETAIL . ' od')
            ->betweenDate('od.'.$date, "$this->statisticsDate", "$this->statisticsDate")
            ->whereNotIn('od.status', ['SR'])
            ->toStr();
    }

    public function getStatisticsTimeList($data)
    {
        $startDate = $data['startDate'];
        $endDate = $data['endDate'];
        $type = 'time';
        $st_div = 'order';

        // 쿼리 캐시 시작
        $this->qb->startCache();
        $this->qb
            ->from(TBL_FB_STATISTICE_TIME_CODE .' as tc')
            ->join(TBL_FB_STATISTICE_SALES .' as s',"tc.idx = s.type_value and s.st_div = '$st_div' and s.type='$type' and s.base_date between '$startDate' and '$endDate' ",'left');
        // 쿼리 캐시 끝
        $this->qb->stopCache();

        // total 산출
        $total = $this->qb->getCount('distinct type_value');

        // 페이징 설정
        $paging = $this->qb
            ->setTotalRows($total)
            ->pagination(1, 100000);

        // limit 값 산출
        $limit = 100000;
        $offset = ($paging['offset'] ?? 0);

        $this->qb->orderBy('tc.idx');

        $this->qb->groupBy('tc.idx');

        $rows = $this->qb
            ->select('tc.idx')
            ->select("'time' as type")
            ->select('tc.code_name')
            ->select('s.type_value')
            ->selectSum('IFNULL(s.s_order_cnt,0)','order_cnt')
            ->selectSum('IFNULL(s.s_order_detail_cnt,0)','order_detail_cnt')
            ->selectSum('IFNULL(s.s_pt_dcprice,0)','payment_price')
            ->selectSum('IFNULL(s.s_psprice,0)','product_price')
            ->selectSum('IFNULL(s.s_listprice,0)','list_price')
            ->selectSum('IFNULL(s.s_cancel_price,0)','cancel_price')
            ->selectSum('IFNULL(s.s_return_price,0)','return_price')
            ->selectSum('IFNULL(s.s_delivery_price,0)','delivery_price')
            ->selectSum('IFNULL(s.s_sales_price,0)','sales_price')
            ->limit($limit, $offset)
            ->exec()
            ->getResultArray();
       // echo $this->qb->lastQuery();
        $this->qb->flushCache();


        $sumData['order_cnt'] = 0;
        $sumData['order_detail_cnt'] = 0;
        $sumData['payment_price'] = 0;
        $sumData['product_price'] = 0;
        $sumData['cancel_price'] = 0;
        $sumData['return_price'] = 0;
        $sumData['sales_price'] = 0;

        //치환 처리
        foreach ($rows as $key => $val) {

            $val['order_cnt'] = (int)$val['order_cnt'];
            $val['order_detail_cnt'] = (int)$val['order_detail_cnt'];
            $val['payment_price'] = (float)$val['payment_price'];
            $val['product_price'] = (float)$val['product_price'];
            $val['list_price'] = (float)$val['list_price'];
            $val['cancel_price'] = (float)$val['cancel_price'];
            $val['return_price'] = (float)$val['return_price'];
            $val['delivery_price'] = (float)$val['delivery_price'];
            $val['sales_price'] = (float)$val['sales_price'];


            $sumData['order_cnt'] += $val['order_cnt'];
            $sumData['order_detail_cnt'] += $val['order_detail_cnt'];
            $sumData['payment_price'] += $val['payment_price'];
            $sumData['product_price'] += $val['product_price'];
            $sumData['cancel_price'] += $val['cancel_price'];
            $sumData['return_price'] += $val['return_price'];
            $sumData['sales_price'] += $val['sales_price'];


            $val['type_text'] = $val['code_name'];
            $val['startDate'] = $startDate;
            $val['endDate'] = $endDate;

            $rows[$key] = $val;
        }
        //echo $this->qb->lastQuery();
        return [
            'total' => $total,
            'list' => $rows,
            'paging' => $paging,
            'sumData' => $sumData
        ];
    }
}