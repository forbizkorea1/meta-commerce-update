<?php

namespace ForbizScm\Controller\Store;

/**
 * 쇼핑몰정보설정
 *
 * @author hoksi
 */
class ManageMallConfig extends \ForbizAdminController
{

    public function __construct()
    {
        parent::__construct();
    }

    public function index()
    {
        // 타이틀 설정
        $this->setTitle('쇼핑몰정보설정');
        // 버튼
        $this->setTopBtn('저장', 'save');

        /* @var $configModel \CustomScm\Model\Store\Config */
        $configModel = $this->import('model.scm.store.config');
        $dbData = $configModel->getIndexStoreConfig();

        $this->setResponseData(['config' => $dbData['data']]);

        $this->setResponseData('addSattleModuleList', [
            'naverpay_pg' => 'Npay ( PG형 )'
            , 'payco' => 'PAYCO'
            , 'toss' => '토스'
            , 'kakaopay' => '카카오페이'
        ]);
    }

    public function put()
    {
        // 검증할 컬럼 등록
        $chkField = ['mall_dc_interval', 'mall_cc_interval', 'cart_delete_day', 'cancel_auto_day', 'check_order_day'];


//        xmp_print_exit($_FILES);
        // 폼 검증
        if (form_validation($chkField)) {
            // 검증 성공

            /* @var $uploadModel \ForbizScm\Model\Util\Upload */
            $this->uploadModel = $this->import('model.scm.util.upload');

            /* @var $iconModel \ForbizScm\Model\Util\Icon */
            $this->iconModel = $this->import('model.scm.util.icon');
            $this->iconModel->putFavicon();

            $data = $this->input->post();
            $imgData = [];

            //넘어온것 만큼 넣음
            foreach ($_FILES as $key => $val) {
                if ($key && $val['size'] > 0) {
                    //upload_type = admin 고정 , $key 파라메터 name 값이 sub_type 명이 된다                    
                    $changeName = null;
                    if ($key == 'devShopLogo') {
                        $changeName = "shop_logo.png";
                    } else if ($key == 'devMobileLogo') {
                        $changeName = "mobile_logo.png";
                    } else if ($key == 'devMailLogo') {
                        $changeName = "mail_logo.png";
                    } else if ($key == 'devFavicon') {
                        $changeName = "favicon.ico";
                    } else if ($key == 'devFaviconPng') {
                        $changeName = "faviconPng.png";
                    }

                    $uploadInfo = $this->uploadModel->adminUploadRealName($key, $key, ADMIN_DIRECT_UPLOAD_PATH, $changeName);
                    if ($uploadInfo['uploaded'] == 1) {
                        $imgData[$key] = $uploadInfo['url'];
                    }
                }
            }

            foreach (['devShopLogo', 'devMobileLogo', 'devMailLogo', 'devFavicon', 'devFaviconPng'] as $imgKey) {
                if (isset($imgData[$imgKey])) {
                    $data[$imgKey] = $imgData[$imgKey];
                } else {
                    unset($data[$imgKey]);
                }
            }


            /* @var $configModel \CustomScm\Model\Store\Config */
            $configModel = $this->import('model.scm.store.config');
            $dbData = $configModel->putMall($data);
            $this->setResponseResult($dbData['status'])->setResponseData($dbData['data']);
        } else {
            // 검증 실패
            $this->setResponseResult('fail')
                ->setResponseData(validation_errors());
        }
    }
    public function putEasyDirect()
    {
        /* @var $configModel \CustomScm\Model\Store\Config */
        $configModel = $this->import('model.scm.store.config');
        $dbData = $configModel->putMall($this->input->post());
        $this->setResponseResult($dbData['status'])->setResponseData($dbData['data']);
    }
}
