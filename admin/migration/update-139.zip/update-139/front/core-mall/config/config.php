<?php
return (function(){
    // Forbiz 솔루션 버젼
    define('FORBIZ_MALL_VERSION', '4.5');
    define('META_COMMERCE_VERSION', '1.3.9');
})();
