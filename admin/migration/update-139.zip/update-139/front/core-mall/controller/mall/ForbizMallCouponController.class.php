<?php

/**
 * Description of ForbizMallCouponController
 *
 * @author hoksi
 */
class ForbizMallCouponController extends ForbizMallController
{
    public function __construct()
    {
        parent::__construct();
    }

    public function getUserCouponList()
    {
        if (is_login()) {
            $couponUseYn = $this->input->post("couponUseYn");
            $max = $this->input->post('max');
            $page = $this->input->post('page');

            if ($couponUseYn == '1') {
                $couponUse = false;
            } else {
                $couponUse = true;
            }

            /* @var $couponModel CustomMallCouponModel */
            $couponModel = $this->import('model.mall.coupon');
            $responseData = $couponModel->getUserCouponList($couponUse, $page, $max);

            if ($responseData == true) {
                $this->setResponseResult('success')->setResponseData($responseData);
            } else {
                $this->setResponseResult('fail')->setResponseData($responseData);
            }

        } else {
            $this->setResponseResult('loginFail');
        }
    }

    /**
     * 구매상품 중 쿠폰적용금액 제일 큰걸로 적용
     */
    public function getMaxDiscountCoupon()
    {
        if(!is_login()) {
            $this->setResponseResult('fail');
        }

        $cartIxs = $this->input->post('cartIx');
        /* @var $cartModel CustomMallCartModel */
        $cartModel = $this->import('model.mall.cart');
        /* @var $couponModel CustomMallCouponModel */
        $couponModel = $this->import('model.mall.coupon');

        $cartIxs = explode(",", $cartIxs);
        $cartData = $cartModel->get($cartIxs);

        $productLists = [];
        foreach($cartData as $cartItem) {
            $productLists = array_merge($productLists, array_column($cartItem['deliveryTemplateList'], 'productList'));
        }
        $productList = [];
        foreach ($productLists as $pList) {
            $productList = array_merge($productList, $pList);
        }

        $cartSummary = $cartModel->getSummary($cartData);
        $totalDcPrice = $cartSummary['summary']['product_dcprice'];
        if(array_search('N', array_column($productList, 'coupon_use_yn')) !== false){
            $this->setResponseResult('fail');
        }

        $couponSelect = [
            'cr.regist_ix',
            'c.cupon_div',
            'cp.use_product_type',
            'c.cupon_acnt',
            'c.haddoffice_rate',
            'c.seller_rate',
            'c.round_position',
            'c.round_type',
            'cp.publish_max',
            'cp.publish_limit_price'
        ];

        //일반쿠폰 조회
        $myCoupons = $couponModel->getUserCouponList(false, 0, 0,$couponSelect, ['c.cupon_div' => 'G'])['list'];
        //장바구니쿠폰 조회
        $myCartCoupons = $couponModel->getUserCouponList(false, 0, 0,$couponSelect, ['c.cupon_div' => ['C', 'A']])['list'];
        //최고 할인받을 수 있는 일반쿠폰 조합 조회
        $maxDiscountCouponCombination = $couponModel->getCombinationCartNCoupon($productList, $myCoupons);

        //장바구니쿠폰 유효성 검사
        $cartCouponExcept = [];
        foreach ($myCartCoupons as $coupon){
            $cartCouponExcept[$coupon['regist_ix']] = 0;
            foreach ($productList as $key => $product) {
                if(!$couponModel->checkCartCouponProductActive($product['id'], $coupon)){
                    $cartCouponExcept[$coupon['regist_ix']] += $product['total_coupon_with_dcprice'];
                }
            }
        }

        //최고 할인받을 수 있는 장바구니쿠폰 조회
        $maxDiscountCartCoupon = $couponModel->getMaxDiscountCartCoupon($totalDcPrice, $myCartCoupons, $cartCouponExcept);

        // 상품쿠폰과 장바구니쿠폰 비교해서 할인율 큰 쿠폰 찾기.
        $res = $couponModel->alignMaxCouponInfo($maxDiscountCouponCombination, $maxDiscountCartCoupon);

        if(!empty($res)){
            $this->setResponseResult('success')->setResponseData($res);
        } else {
            $this->setResponseResult('fail');
        }

    }

}
