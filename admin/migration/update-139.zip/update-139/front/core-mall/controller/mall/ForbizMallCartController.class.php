<?php

/**
 * Description of ForbizMallCartController
 *
 * @author hong
 * @property CustomMallCartModel $cartModel
 */
class ForbizMallCartController extends ForbizMallController
{
    /**
     * 장바구니 모델
     */
    public $cartModel;

    public function __construct()
    {
        parent::__construct();
        $this->cartModel = $this->import('model.mall.cart');
    }

    /**
     * 선택된 상품 Summery 정보 조회
     * array cartIxs
     */
    public function getSummary()
    {
        ////////////////////////////
        // 마스터 DB로 처리 START //
        start_master_db();
        ////////////////////////////

        $cartIxs = $this->input->post('cartIxs');
        $cart = $this->cartModel->get($cartIxs);
        $this->setResponseData($this->cartModel->getSummary($cart));

        ///////////////////////////
        // 마스터 DB로 처리 END //
        end_master_db();
        ///////////////////////////
    }

    /**
     * 상품 삭제
     * array cartIxs
     */
    public function delete()
    {
        ////////////////////////////
        // 마스터 DB로 처리 START //
        start_master_db();
        ////////////////////////////

        $cartIxs = $this->input->post('cartIxs');
        $this->cartModel->delete($cartIxs);

        ///////////////////////////
        // 마스터 DB로 처리 END //
        end_master_db();
        ///////////////////////////
    }

    /**
     * 옵션(추가구성상품) 삭제
     * array cartOptionIxs
     */
    public function deleteOption()
    {
        ////////////////////////////
        // 마스터 DB로 처리 START //
        start_master_db();
        ////////////////////////////

        $cartOptionIxs = $this->input->post('cartOptionIxs');
        $this->cartModel->deleteOption($cartOptionIxs);

        ///////////////////////////
        // 마스터 DB로 처리 END //
        end_master_db();
        ///////////////////////////
    }

    /**
     * 상품 수량 수정
     * int cartIx
     * int count
     */
    public function updateCount()
    {
        ////////////////////////////
        // 마스터 DB로 처리 START //
        start_master_db();
        ////////////////////////////

        $cartIx = $this->input->post('cartIx');
        $count = $this->input->post('count');
        $sumPidCnt = $this->input->post('sumPidCnt');

        /* @var $productModel CustomMallProductModel */
        $productModel = $this->import('model.mall.product');
        $row = $this->cartModel->getProductRow($cartIx);

        if (!empty($row)) {

            // 재고 수량 점검
            $buyCountCondition = $productModel->getBuyCountCondition($row['id'], sess_val('user', 'code'));

            //최소 구매수량 보다 적은 수량일때
            if ($buyCountCondition['allow_basic_cnt'] > 0 && $buyCountCondition['allow_basic_cnt'] > $count) {
                $this->setResponseResult('failBasicCount');
                $this->setResponseData($buyCountCondition['allow_basic_cnt']);
            } else if ($buyCountCondition['allow_byoneperson_cnt'] > 0 && !is_login()) {
                $this->setResponseResult('noLogin');

            } else if ($buyCountCondition['allow_byoneperson_cnt'] > 0
                && $buyCountCondition['allow_byoneperson_cnt'] < ($buyCountCondition['user_buy_cnt'] + $sumPidCnt)
            ) {
                $diffCartProductInfo = $this->cartModel->getDiffCartProduct($row['id'], $row['cart_ix']);

                //ID당 구매수량이 적을때
                $buyCnt = ($buyCountCondition['allow_byoneperson_cnt'] - $buyCountCondition['user_buy_cnt'] - $diffCartProductInfo['pcount']);
                if($buyCnt < 0) {
                    $buyCnt = 0;
                }
                $this->setResponseResult('failByOnePersonCount');
                $this->setResponseData($buyCnt);
            } else if ($row['status'] != 'sale') {
                //상품이 판매중이 아닐때
                $this->setResponseResult('failNoSale');
            } else if ($row['stock'] < $count) {
                //구매수량 업데이트
                $this->cartModel->updateCount($cartIx, $row['stock']);

                //재고 수량보다 많이 입력한 경우
                $this->setResponseResult('failStockLack');
                $this->setResponseData($row['stock']);
            } else {
                //구매수량 업데이트
                $this->cartModel->updateCount($cartIx, $count);

                $this->setResponseResult('success');
            }
        } else {
            $this->setResponseResult('fail');
        }

        ///////////////////////////
        // 마스터 DB로 처리 END //
        end_master_db();
        ///////////////////////////
    }

    /**
     * 옵션(추가구성상품) 수량 수정
     * array cartOptionIx
     * int count
     */
    public function updateOptionCount()
    {
        ////////////////////////////
        // 마스터 DB로 처리 START //
        start_master_db();
        ////////////////////////////

        $cartOptionIx = $this->input->post('cartOptionIx');
        $count = $this->input->post('count');

        $options = $this->cartModel->getOptionRow($cartOptionIx);

        //재고 수량보다 많이 입력한 경우
        if ($options['option_stock'] < $count) {
            $this->setResponseResult('failStockLack');
            $this->setResponseData($options['option_stock']);
            return;
        }

        //구매수량 업데이트
        $this->cartModel->updateOptionCount($cartOptionIx, $count);

        ///////////////////////////
        // 마스터 DB로 처리 END //
        end_master_db();
        ///////////////////////////
    }

    /**
     * 주문 가능 여부 체크
     * array cartIxs
     */
    public function paymentValidate()
    {
        ////////////////////////////
        // 마스터 DB로 처리 START //
        start_master_db();
        ////////////////////////////

        /* @var $productModel CustomMallProductModel */
        $productModel = $this->import('model.mall.product');

        $cartIxs = $this->input->post('cartIxs');
        $cart = $this->cartModel->get($cartIxs);

        foreach ($cart as $company) {
            foreach ($company['deliveryTemplateList'] as $deliveryTemplate) {
                $prevPid = '';
                $totalCntArray = [];
                foreach ($deliveryTemplate['productList'] as $product) {

                    // 재고 수량 점검
                    $buyCountCondition = $productModel->getBuyCountCondition($product['id'], sess_val('user', 'code'));

                    //각 상품의 total 수량
                    if($product['id'] == $prevPid ) {
                        $totalCntArray[$product['id']] += $product['pcount'];
                    } else {
                        $totalCntArray[$product['id']] = $product['pcount'];
                    }

                    if ($product['status'] != 'sale') {
                        $this->setResponseResult('fail');
                        return;
                    } else if($product['allow_basic_cnt'] > 0 && $product['allow_basic_cnt'] > $product['pcount']){
                        $this->setResponseResult('failCheckCnt');
                        return;
                    } else if ($buyCountCondition['allow_byoneperson_cnt'] > 0 && !is_login()) {
                        $this->setResponseResult('noLogin');
                        $this->setResponseData(['cart_ix' => $product['cart_ix']]);
                    } else if ($buyCountCondition['allow_byoneperson_cnt'] > 0 && $buyCountCondition['allow_byoneperson_cnt'] < ($buyCountCondition['user_buy_cnt'] + $totalCntArray[$product['id']])) {

                        //ID당 구매수량이 적을때
                        $buyCnt = ($product['pcount'] - (($buyCountCondition['user_buy_cnt'] + $totalCntArray[$product['id']]) - $buyCountCondition['allow_byoneperson_cnt']));
                        if ($buyCnt < 0) {
                            $buyCnt = 0;
                        }
                        $this->setResponseResult('failByOnePersonCount');
                        $this->setResponseData(['buy_cnt' => $buyCnt, 'pname' => $product['pname'], 'cart_ix' => $product['cart_ix']]);
                    } else if ($product['pcount'] == 0) {
                        $this->setResponseResult('failCheckCnt');
                        return;
                    } else if($product['allow_max_cnt'] > 0 && $product['allow_max_cnt'] < $product['pcount']){
                        $this->setResponseResult('failCheckCnt');
                        return;
                    } else if($product['allow_byoneperson_cnt'] > 0
                        && $product['allow_byoneperson_cnt'] - $product['user_buy_cnt'] < $product['pcount']){
                        $this->setResponseResult('failCheckCnt');
                        return;
                    } else if ($product['pcount'] == 0) {
                        $this->setResponseResult('failCheckCnt');
                        return;

                    } else if ($product['stock'] < $product['pcount']) {
                        $this->setResponseResult('failCheckCnt');
                        $this->setResponseData(['cart_ix' => $product['cart_ix'], 'stock' => $product['stock']]);
                        return;
                    }

                    foreach ($product['addOptionList'] as $addOption) {
                        if ($addOption['stock'] < $addOption['opn_count']) {
                            $this->setResponseResult('fail');
                            return;
                        }
                    }

                    $prevPid = $product['id'];
                }
            }
        }

        ///////////////////////////
        // 마스터 DB로 처리 END //
        end_master_db();
        ///////////////////////////
    }

    /**
     * 카트에 상품을 추가함
     */
    public function add()
    {
        ////////////////////////////
        // 마스터 DB로 처리 START //
        start_master_db();
        ////////////////////////////

        $datas = $this->input->post('data');

        if (empty($datas)) {
            $this->setResponseResult('fail');
            return;
        }

        /* @var $productModel CustomMallProductModel */
        $productModel = $this->import('model.mall.product');
        $buyCountCondition = $productModel->getBuyCountCondition($datas[0]['pid'], sess_val('user', 'code'));
        $totalCnt = 0;

        foreach ($datas as $k => $v) {
            $option_infos = $productModel->getOption($v['pid'], 'row', $v['optionId']);

            //최소 구매수량 보다 적은 수량일때
            if ($buyCountCondition['allow_basic_cnt'] > 0 && $buyCountCondition['allow_basic_cnt'] > $v['count']) {
                $this->setResponseResult('failBasicCount');
                $this->setResponseData($buyCountCondition['allow_basic_cnt']);
                return;
            } else if ($buyCountCondition['allow_byoneperson_cnt'] > 0 && empty(sess_val('user'))) {
                $this->setResponseResult('noLogin');
                return;
            } //재고 수량보다 많이 입력한 경우
            else if ($option_infos['option_stock'] < $v['count']) {
                $this->setResponseResult('failStockLack');
                $this->setResponseData($option_infos['option_stock']);
                return;
            } else if (!is_numeric($v['count'])) {
                $this->setResponseResult('failNotNumeric');
                return;
            }
            $totalCnt += ($buyCountCondition['user_buy_cnt'] + $v['count']);
        }

        $totalCartcnt = $this->cartModel->cartProductTotalCnt($datas[0]['pid']);

        if($buyCountCondition['allow_byoneperson_cnt'] > 0 && $buyCountCondition['allow_byoneperson_cnt'] < $totalCnt) {
            //상품기준 ID당 구매 수량 체크
            $butCnt = ($buyCountCondition['allow_byoneperson_cnt'] - $buyCountCondition['user_buy_cnt']);
            if($butCnt < 0) {
                $butCnt = 0;
            }
            $this->setResponseResult('failByOnePersonCount');
            $this->setResponseData($butCnt);
            return;
        }

        /**
         * 상품의 장바구니 수량과 선택된 상품의 수량을 더한 값이 ID당 구매수량보다 많을때 장바구니에 담지 않는다.
         */
        if($buyCountCondition['allow_byoneperson_cnt'] > 0 && $buyCountCondition['allow_byoneperson_cnt'] < ($totalCartcnt+ $totalCnt)) {
            $butCnt = ($buyCountCondition['allow_byoneperson_cnt'] - ($totalCartcnt + $totalCnt));
            if($butCnt < 0) {
                $butCnt = 0;
            }
            $this->setResponseResult('failByOnePersonCartCount');
            $this->setResponseData($butCnt);
            return;
        }

        $cartIxs = $this->cartModel->add($datas);

        $this->setResponseData($cartIxs);

        ///////////////////////////
        // 마스터 DB로 처리 END //
        end_master_db();
        ///////////////////////////
    }
}